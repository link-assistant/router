import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
paths=[Path('/tmp/router-759-core-conditional-lazy-focused.py')]
attempts=[]
for phase in ['initial','syntax-repaired']:
 for engine in ['node','bun']:
  base=Path('/tmp/router-759-core-conditional-lazy-'+phase+'-'+engine)
  receipt=base.with_suffix('.json'); d=json.loads(receipt.read_text())
  if not d['sourceInputsUnchanged'] or not d['sourceHeadUnchanged'] or d['trackedStatusAfter']: raise RuntimeError('Unclean attempt')
  if phase=='syntax-repaired' and (d['evidenceStatus']!='FOCUSED_PASS_NOT_FULL_GATE' or d['sourceHeadBefore']!=head or d['counts']['pass']!=246 or d['counts']['fail']!=0 or d['counts']['skipped']!=0): raise RuntimeError('Final focused run incomplete')
  attempts.append(d)
  paths.extend([receipt,base.with_suffix('.log'),base.with_suffix('.inputs.json')])
patch=Path('/tmp/router-759-core-conditional-lazy-syntax-repair.patch')
patch.write_bytes(subprocess.check_output(['git','show','--format=fuller',head,'--','tools/translation/conditional-attributes.mjs'],cwd=root))
paths.append(patch)
paths.append(Path(__file__))
records=[]; contents={}
for path in paths:
 raw=path.read_bytes(); name=path.name
 records.append({'name':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 contents[name]=raw
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0,filename='') as gz:
 with tarfile.open(fileobj=gz,mode='w|') as tar:
  for name,raw in contents.items():
   info=tarfile.TarInfo(name); info.size=len(raw); info.mtime=0; info.mode=0o644
   tar.addfile(info,io.BytesIO(raw))
packed=buf.getvalue()
if len(packed)>1_000_000: raise RuntimeError('Focused archive exceeds reserved compact budget')
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
 members=tar.getmembers()
 if len(members)!=len(records): raise RuntimeError('Missing archive member')
 for record in records:
  raw=tar.extractfile(record['name']).read()
  if len(raw)!=record['bytes'] or hashlib.sha256(raw).hexdigest()!=record['sha256']: raise RuntimeError('Archive mismatch')
archive=Path('/tmp/router-759-cycle-16-conditional-copy.tar.gz'); archive.write_bytes(packed)
receipt={'schemaVersion':1,'kind':'complete-focused-conditional-attribute-and-copy-provenance-evidence','status':'FOCUSED_PASS_NOT_FULL_GATE','testedSourceHead':head,'testFiles':30,'finalCountsPerEngine':{'pass':246,'fail':0,'skipped':0},'attempts':attempts,'archive':{'path':'cycle-16-conditional-copy.tar.gz','bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'members':records,'reopenedMembers':len(records),'reopenErrors':0},'initialFailures':{'node':{'pass':8,'fail':29},'bun':{'pass':8,'fail':29},'cause':'Original conditional-attribute helper delimiter-map string lacked its closing quote; all 29 affected test files failed to load. Both complete initial attempts are retained.'},'repairs':[head],'measurementLimitations':['Owned terminated-child max RSS includes git and version queries; it is neither aggregate process-tree peak nor peak physical footprint.','No before/after canonical producer benchmark has run; removing unused lexical scans has no measured speed claim.'],'verificationLimits':{'canonicalProducerRuns':0,'profileProducerRuns':0,'fullGateRuns':0,'rustBuilds':0,'strictParityGapsCleared':0,'completeTranslation':False,'nativeParity':False},'context':'The guarded actual Cargo feature profile is retained. Original conditional attributes preserve unknown predicates and private absence/inert evidence; missing Copy binding contexts retain conservative source lexical refusals. All affected original source pins and metadata/span checks are covered by the final clean scope.'}
out=Path('/tmp/router-759-cycle-16-conditional-copy-receipt.json'); out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'archiveBytes':len(packed),'archiveSha256':receipt['archive']['sha256'],'members':len(records),'receiptBytes':out.stat().st_size,'receiptSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'testedHead':head,'attempts':[{'phase':d['phase'],'engine':d['engine'],'elapsedSeconds':d['elapsedSeconds'],'counts':d['counts'],'inputSha256':d['sourceInputSha256Before']} for d in attempts]}))
