import argparse, hashlib, json, os, re, signal, subprocess, time, resource, sys
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('--engine', choices=['node', 'bun'], required=True)
parser.add_argument('--phase', choices=['initial', 'retry', 'retry2', 'final'], required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('--timeout', type=int, default=180)
parser.add_argument('--test-group', choices=['modules','repair'], default='modules')
args = parser.parse_args()
cwd = Path(args.cwd)
files = ['source-module-views', 'inline-module-project', 'module-paths', 'module-path-project', 'module-bindings', 'cfg-profile', 'cfg-production', 'derive-footprints', 'derive-layout', 'tool-attributes', 'copy-trait-owners', 'copy-translation', 'copy-methods', 'nominal-targets', 'source-links', 'source-lifetimes', 'owned-result-lifetimes', 'local-lifetime-constraints']
files.append('source-namespace-bindings')
if args.test_group == 'repair':
    files = ['inline-module-project', 'tool-attributes', 'source-namespace-bindings']
paths = ['tools/translation/test/' + name + '.test.mjs' for name in files]
for path in paths:
    if not (cwd / path).is_file():
        raise RuntimeError('Missing focused test: ' + path)
head_before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=cwd, text=True).strip()
engine_version = subprocess.check_output([args.engine, '--version'], cwd=cwd, text=True).strip()
command = ([args.engine, '--test', '--test-concurrency=1'] if args.engine == 'node' else [args.engine, 'test', '--max-concurrency', '1']) + paths
log = Path('/tmp/router-759-core-module-' + args.phase + '-' + args.engine + '.log')
receipt = log.with_suffix('.json')
if log.exists() or receipt.exists():
    raise RuntimeError('Focused attempt already exists; preserve its original evidence')
started = time.monotonic()
timed_out = False
with log.open('wb') as stream:
    process = subprocess.Popen(['/usr/bin/time', '-p'] + command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        exit_code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        exit_code = process.returncode
elapsed = round(time.monotonic() - started, 3)
raw = log.read_bytes()
clean = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode(errors='replace'))
if args.engine == 'node':
    counts = {key: int(re.search(r'^# ' + key + r' (\d+)\s*$', clean, re.M).group(1)) if re.search(r'^# ' + key + r' (\d+)\s*$', clean, re.M) else None for key in ['tests', 'pass', 'fail', 'skipped', 'todo']}
else:
    def count(label):
        matches = re.findall(r'^\s*(\d+) ' + label + r'\s*$', clean, re.M)
        return int(matches[-1]) if matches else None
    counts = {'tests': None, 'pass': count('pass'), 'fail': count('fail'), 'skipped': count('skip') or 0, 'todo': None}
    if counts['pass'] is not None and counts['fail'] is not None:
        counts['tests'] = counts['pass'] + counts['fail'] + counts['skipped']
head_after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=cwd, text=True).strip()
result = {'schemaVersion': 1, 'scope': 'focused module-view/path translator regressions; not full gate or native parity', 'engine': args.engine, 'engineVersion': engine_version, 'phase': args.phase, 'command': command, 'timeoutSeconds': args.timeout, 'elapsedSeconds': elapsed, 'exitCode': exit_code, 'timedOut': timed_out, 'sourceHeadBefore': head_before, 'sourceHeadAfter': head_after, 'sourceHeadUnchanged': head_before == head_after, 'log': str(log), 'logBytes': len(raw), 'logSha256': hashlib.sha256(raw).hexdigest(), 'counts': counts, 'producerRuns': 0, 'rustBuilds': 0, 'fullGateRuns': 0, 'measurement': {'timeFormat': 'posix', 'ownedChildrenMaxRssBytes': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss * (1 if sys.platform == 'darwin' else 1024), 'rssScope': 'all terminated child processes of this harness, including git and engine version; no peak-footprint measurement'}}
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
print(clean[-2500:], flush=True)
raise SystemExit(0 if exit_code == 0 and not timed_out and head_before == head_after and counts['pass'] and counts['fail'] == 0 and counts['skipped'] == 0 else 1)
