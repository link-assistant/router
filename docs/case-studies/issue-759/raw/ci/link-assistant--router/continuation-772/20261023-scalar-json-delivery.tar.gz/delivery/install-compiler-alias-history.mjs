import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {prepareCompilerAliasHistory} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021/tools/translation/prepare-compiler-alias-history.mjs';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021';
const plan=prepareCompilerAliasHistory(),hash=s=>createHash('sha256').update(s).digest('hex');
const before=JSON.parse(readFileSync(root+'/tools/translation/test/fixtures/compiler-data-alias-history.mjs','utf8').match(/^const RECORDS=(.*);$/m)[1]);
for(const row of plan.records){const old=before.find(r=>r.name===row.name);if(!old||row.currentSha256!==old.currentSha256||row.historicalSha256!==old.historicalSha256||JSON.stringify(row.edits)!==JSON.stringify(old.edits))throw Error('original complete alias pins or substitutions changed: '+row.name);}
for(const row of plan.files){if(readFileSync(root+'/'+row.path,'utf8')!==row.before||row.inverse!==row.before)throw Error('complete physical/CST predecessor differs');}
for(const row of plan.files)writeFileSync(root+'/'+row.path,row.after);
console.log(JSON.stringify({schema:plan.schema,files:plan.files.map(r=>({path:r.path,before:hash(r.before),after:hash(r.after)})),originalAliasRecordsUnchanged:true,rustExecuted:false}));
