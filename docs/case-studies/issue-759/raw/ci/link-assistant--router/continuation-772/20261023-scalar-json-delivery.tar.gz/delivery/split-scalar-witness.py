from pathlib import Path
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021')
p=root/'tools/translation/js-to-rust/test/owned-core-ascii.test.mjs'
s=p.read_text()
start=s.index("test('reverse scalar count preserves")
end=s.index("test('reverse ASCII copied meta",start)
newtests=s[start:end]
header=s[:s.index("test('reverse ASCII complete")]
header=header.replace('const REVERSE_ASCII_JS_WITNESS:','const REVERSE_SCALAR_JS_WITNESS:')
a=header.index('function typedSource()')
b=header.index('\nfunction data(',a)
header=header[:a]+'''function typedSource(){return source.replace('function scalar_length(value)','function scalar_length(value:Parameters<typeof count>[0]):ReturnType<typeof count>').replace('function scalar_limit(value)','function scalar_limit(value:string):boolean').replace('function selected_count(value,yes)','function selected_count(value:string,yes:boolean):ReturnType<typeof count>');}'''+header[b:]
(root/'tools/translation/js-to-rust/test/owned-core-scalars.test.mjs').write_text(header+newtests)
s=s[:start]+s[end:]
s=s.replace('row.result.program.length,7','row.result.program.length,4').replace('direct.program.length,7','direct.program.length,4')
a=s.index('function typedSource()')
b=s.index('\nfunction data(',a)
s=s[:a]+'''function typedSource(){return source.replace('function accepted(value,alphabet)','function accepted(value:Parameters<typeof ascii>[0],alphabet:Parameters<typeof ascii>[1]):ReturnType<typeof ascii>').replace('function hexadecimal(value)','function hexadecimal(value:string):boolean').replace('function lazy(value,alphabet,yes)','function lazy(value:string,alphabet:string,yes:boolean):boolean').replace('function guard(value,alphabet)','function guard(value:string,alphabet:string):string');}'''+s[b:]
for line in ["import {ownedAsciiOperation,ownedAsciiRustCall} from '../owned-ascii-source.mjs';\n","import {translateProject} from '../../project.mjs';\n","import {verifyTypedTargets} from '../../test/typed-targets.mjs';\n","import {ROUTER_CORE_RANGES_SOURCE} from '../../router-core-source-data.mjs';\n"]:s=s.replace(line,'')
p.write_text(s)
p=root/'rust/tests/translation_core_ascii_reverse_oracle.rs'
s=p.read_text(); import_line="import {router_core_unicode_scalar_count as count} from './runtime/string-iterator-runtime.mjs';\n"
s=s.replace(import_line,'',1)
a=s.index('/** @param {string} value */\nexport function scalar_length')
b=s.index('"###;',a)
scalar=s[a:b]
s=s[:a]+s[b:]
a=s.index('// This module is produced')
s=s[:a]+'''#[allow(clippy::needless_raw_string_hashes)]
pub const REVERSE_SCALAR_JS_WITNESS: &str = r###"'''+import_line+scalar+'"###;\n\n'+s[a:]
p.write_text(s)
