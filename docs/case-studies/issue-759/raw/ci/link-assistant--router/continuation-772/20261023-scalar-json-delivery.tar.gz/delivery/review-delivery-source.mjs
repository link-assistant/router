import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021';
const {ownershipCompiler}=await import(root+'/tools/translation/js-to-rust/vendor/module-syntax.mjs');
const {transportConcreteSourceEquations}=await import(root+'/tools/translation/concrete-source-equations.mjs');
const ts=ownershipCompiler();assert.equal(ts.version,'5.9.3');
const files=execFileSync('/usr/bin/git',['diff','HEAD','--name-only','-z'],{cwd:root,encoding:'utf8'}).split('\0').filter(p=>p.endsWith('.mjs'));
const rows=files.map(path=>{let before='';try{before=execFileSync('/usr/bin/git',['show','HEAD:'+path],{cwd:root,encoding:'utf8',stdio:['ignore','pipe','ignore']});}catch(e){if(e.status!==128)throw e;}const after=readFileSync(root+'/'+path,'utf8');for(const source of [before,after])assert.equal(ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS).parseDiagnostics.length,0,path);execFileSync(process.execPath,['--check',root+'/'+path],{stdio:'pipe',timeout:10000});assert.ok(after.split('\n').length<1000,path);return {path,before,after};});
for(let i=0;i<rows.length;i+=4){const chunk=rows.slice(i,i+4),equations=transportConcreteSourceEquations(chunk.map(row=>({before:row.before,after:row.after,language:'JavaScript'})));equations.forEach((eq,at)=>{assert.equal(eq.before,chunk[at].before);assert.equal(eq.after,chunk[at].after);assert.equal(eq.inverse,chunk[at].before);});}
execFileSync('/Users/konard/.bun/bin/bun',['--eval',"import {readFileSync} from 'node:fs';for(const path of process.argv.slice(1))new Bun.Transpiler({loader:'js',target:'bun'}).scan(readFileSync(path,'utf8'));",...files.map(path=>root+'/'+path)],{stdio:'pipe',timeout:20000});
const checks=[['prepare-core-ascii-assets.mjs','prepareCurrentCoreAsciiReverseAssets'],['prepare-core-ascii-assets.mjs','prepareCurrentCoreAsciiAssets'],['prepare-core-ascii-base-assets.mjs','prepareCurrentCoreAsciiBaseAssets'],['prepare-safety-json-projections.mjs','prepareSafetyJsonProjections'],['prepare-current-receiving-source-history.mjs','prepareCurrentReceivingSourceHistory'],['prepare-compiler-alias-history.mjs','prepareCompilerAliasHistory']];
for(const [module,name]of checks){const fn=(await import(root+'/tools/translation/'+module))[name],plan=fn();for(const row of plan.files)assert.equal(row.current??row.before,row.after,name+': '+row.path);console.log(JSON.stringify({producer:name,files:plan.files.length,fresh:true}));}
console.log(JSON.stringify({files:rows.map(row=>({path:row.path,sha256:createHash('sha256').update(row.after).digest('hex')})),typescript:ts.version,NodeSyntax:true,BunSyntax:true,completeCstAndInverse:true,rustExecuted:false}));
