import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {createHash} from 'node:crypto';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021';
const {buildOwnedCoreDocumentArtifacts}=await import(root+'/tools/translation/js-to-rust/owned-core-corpus.mjs');
const prefix='tools/translation/js-to-rust/generated/owned-ascii-witness';
const result=buildOwnedCoreDocumentArtifacts(root),report=JSON.parse(result.artifacts.get('parity/js-owned-core-reverse-draft.json'));
if(report.asciiWitness.functions!==7||report.asciiWitness.applicationItems!==0||report.rustExecuted!==false)throw Error('complete seven-function native witness required');
const receipt=[];
for(const [path,source]of result.artifacts){if(!path.startsWith(prefix))continue;const target=resolve(root,path),before=existsSync(target)?readFileSync(target,'utf8'):null;if(before===source)continue;mkdirSync(dirname(target),{recursive:true});writeFileSync(target,source);if(readFileSync(target,'utf8')!==source)throw Error('complete output readback differs');receipt.push({path,bytes:Buffer.byteLength(source),sha256:createHash('sha256').update(source).digest('hex')});}
console.log(JSON.stringify({functions:report.asciiWitness.functions,outputs:receipt,applicationItems:0,rustExecuted:false}));
