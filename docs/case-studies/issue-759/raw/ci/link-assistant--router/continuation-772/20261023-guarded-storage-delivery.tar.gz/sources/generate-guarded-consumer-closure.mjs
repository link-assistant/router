import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {gzipSync,gunzipSync} from 'node:zlib';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021';
await import('./install-guarded-consumer-drafts.mjs');
const specs=[['prepare-operation-proof-byte-sources.mjs','prepareOperationProofByteSources'],['prepare-whole-owner-proof-byte-candidate.mjs','prepareWholeOwnerProofByteCandidate'],['prepare-batched-proof-byte-source-candidate.mjs','prepareBatchedProofByteSourceCandidate']];
for(const [name,entry]of specs){
 const module=await import(pathToFileURL(root+'/tools/translation/'+name));
 const plan=module[entry]({root});
 for(const row of plan.files)if(readFileSync(root+'/'+row.path,'utf8')!==row.current)throw Error('Fresh full generated source differs: '+row.path);
 const changed=plan.files.filter(row=>row.current!==row.after);
 const raw=Buffer.from(JSON.stringify({producer:name,plan,rustExecuted:false})+'\n'),packed=gzipSync(raw);
 const path='/private/tmp/router-issue772-delivery-20261023/guarded-consumer-drafts/'+name+'.json.gz';
 writeFileSync(path,packed,{flag:'wx'});if(!gunzipSync(readFileSync(path)).equals(raw))throw Error('Full producer evidence readback');
 for(const row of changed)writeFileSync(root+'/'+row.path,row.after);
 for(const row of plan.files)if(readFileSync(root+'/'+row.path,'utf8')!==row.after)throw Error('Generated source readback');
 console.log(JSON.stringify({producer:name,files:plan.files.length,changed:changed.map(row=>row.path)}));
}
