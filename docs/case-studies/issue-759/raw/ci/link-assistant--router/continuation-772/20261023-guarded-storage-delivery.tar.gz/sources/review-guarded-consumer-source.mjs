import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021',hash=x=>createHash('sha256').update(x).digest('hex');
const load=name=>import(pathToFileURL(root+'/tools/translation/'+name));
const {ownershipCompiler}=await load('js-to-rust/vendor/module-syntax.mjs'),ts=ownershipCompiler();if(ts.version!=='5.9.3')throw Error('Native compiler version');
const {transportConcreteSourceEquations}=await load('concrete-source-equations.mjs');
const paths=execFileSync('git',['diff','--cached','--name-only','HEAD'],{cwd:root,encoding:'utf8'}).trim().split('\n').filter(path=>path.endsWith('.mjs'));
const rows=[];
for(const path of paths){
 const after=readFileSync(root+'/'+path,'utf8'),prior=execFileSync('git',['cat-file','--batch'],{cwd:root,input:'HEAD:'+path+'\n',encoding:'utf8',maxBuffer:2097152}),line=prior.indexOf('\n');
 const before=prior.slice(0,line).endsWith(' missing')?'':prior.slice(line+1,-1);
 execFileSync(process.execPath,['--check',root+'/'+path],{cwd:root,stdio:'pipe'});
 const f=ts.createSourceFile(path,after,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);if(f.parseDiagnostics.length||after.split('\n').length>=1000)throw Error('Native syntax or line cap');
 const equation=transportConcreteSourceEquations([{before,after,language:'JavaScript'}])[0];if(equation.inverse!==before)throw Error('Complete CST inverse');
 rows.push({path,before,after,sha256:hash(after),equation});
}
const results=[];
for(const [name,entry]of [['prepare-operation-proof-byte-sources.mjs','prepareOperationProofByteSources'],['prepare-whole-owner-proof-byte-candidate.mjs','prepareWholeOwnerProofByteCandidate']]){
 const module=await load(name),plan=module[entry]({root});if(plan.files.some(row=>row.current!==row.after))throw Error('Stale current generated source: '+name);results.push({producer:name,files:plan.files.length,fresh:true});
}
const {prepareBuiltinSourceMetaStringKeys}=await load('prepare-builtin-source-meta-string-keys.mjs');const codec=prepareBuiltinSourceMetaStringKeys();if(codec.defaultCodecUnchanged!==true)throw Error('Default codec changed');results.push({producer:'prepare-builtin-source-meta-string-keys.mjs',fresh:true,defaultCodecUnchanged:true});
const raw=Buffer.from(JSON.stringify({typescript:ts.version,rows,results,wholeGate:false,rustExecuted:false})+'\n'),packed=gzipSync(raw),path='/private/tmp/router-issue772-delivery-20261023/guarded-consumer-drafts/final-native-CST-review.json.gz';writeFileSync(path,packed,{flag:'wx'});if(!gunzipSync(readFileSync(path)).equals(raw))throw Error('Full evidence readback');
for(const row of rows)if(readFileSync(root+'/'+row.path,'utf8')!==row.after)throw Error('Final source changed');
console.log(JSON.stringify({nativeSyntax:true,completeCST:true,files:rows.map(({path,sha256})=>({path,sha256})),freshness:results,rustExecuted:false}));
