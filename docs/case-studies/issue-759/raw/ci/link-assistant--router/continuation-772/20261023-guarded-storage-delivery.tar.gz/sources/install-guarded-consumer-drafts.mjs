import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021',draft='/private/tmp/router-issue772-delivery-20261023/guarded-consumer-drafts';
const hash=x=>createHash('sha256').update(x).digest('hex');
const {ownershipCompiler}=await import(pathToFileURL(root+'/tools/translation/js-to-rust/vendor/module-syntax.mjs'));
const {transportConcreteSyntaxSource,serializeConcreteSyntaxMeta,transportConcreteSyntaxMeta,applyConcreteSyntaxSubstitutions}=await import(pathToFileURL(root+'/tools/translation/concrete-syntax-meta.mjs'));
const ts=ownershipCompiler();if(ts.version!=='5.9.3')throw Error('Exact compiler required');
const selected=JSON.parse(readFileSync(draft+'/inputs.json','utf8'));
selected.push({path:'tools/translation/guarded-proof-consumer-history.mjs',beforeSha256:hash(''),newFile:true});
const retained=[];
for(const row of selected){
 const target=root+'/'+row.path;if(row.newFile&&existsSync(target))throw Error('Fresh target required');
 const before=row.newFile?'':readFileSync(target,'utf8'),after=readFileSync(draft+'/'+row.path.split('/').at(-1),'utf8');
 if(hash(before)!==row.beforeSha256)throw Error('Full before changed: '+row.path);
 const imports=after.match(/^(?:\/\/[^\n]*\n)?import [^\n]+\n/u)?.[0];if(!imports)throw Error('Complete source import boundary');
 const language=after.slice(imports.length),pairs=[['language',before,language],['repository',language,after]],stages=[];
 for(const [phase,left,right]of pairs){
  const first=transportConcreteSyntaxSource(left,{language:'JavaScript'}),beforeMeta=serializeConcreteSyntaxMeta(first.document),fresh=transportConcreteSyntaxMeta(beforeMeta);
  const rule=(a,b,id)=>({id,edits:a===b?[]:[{span:[0,a.length],expected:a,replacement:b}]}),sequence={languageRules:phase==='language'?[rule(left,right,'javascript:retain-complete-guarded-producer-history')]:[],repositoryRules:phase==='repository'?[rule(left,right,'router:bind-actual-source-producer-and-exact-current-inputs')]:[]};
  const result=applyConcreteSyntaxSubstitutions(fresh.document,sequence),afterMeta=serializeConcreteSyntaxMeta(result.value),checked=transportConcreteSyntaxMeta(afterMeta);
  if(checked.source!==right)throw Error('Full phase differs');
  const inverse=applyConcreteSyntaxSubstitutions(checked.document,{languageRules:phase==='language'?[rule(right,left,'javascript:restore-full-source')]:[],repositoryRules:phase==='repository'?[rule(right,left,'router:restore-full-source')]:[]});
  if(transportConcreteSyntaxMeta(serializeConcreteSyntaxMeta(inverse.value)).source!==left)throw Error('Full phase inverse differs');
  stages.push({phase,before:left,after:right,beforeMeta,afterMeta,trace:result.trace,inverse:left});
 }
 const file=ts.createSourceFile(target,after,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);if(file.parseDiagnostics.length||after.split('\n').length>=1000)throw Error('Native syntax/line budget');
 retained.push({...row,before,after,afterSha256:hash(after),stages});
}
for(const row of retained){const path=root+'/'+row.path;if((existsSync(path)?readFileSync(path,'utf8'):'')!==row.before)throw Error('Source changed before install');}
const packet=Buffer.from(JSON.stringify({typescript:ts.version,files:retained,semanticAuthority:false,rustExecuted:false})+'\n'),packed=gzipSync(packet);writeFileSync(draft+'/complete-installed-source-equations.json.gz',packed,{flag:'wx'});if(!gunzipSync(readFileSync(draft+'/complete-installed-source-equations.json.gz')).equals(packet))throw Error('Evidence inverse');
for(const row of retained)writeFileSync(root+'/'+row.path,row.after);
for(const row of retained)if(readFileSync(root+'/'+row.path,'utf8')!==row.after)throw Error('Installed source readback');
console.log(JSON.stringify({installed:retained.map(row=>row.path),sourceEquations:true,rustExecuted:false}));
