from pathlib import Path
import gzip,json,hashlib,tarfile,re,io,zipfile
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021')
p=Path('/private/tmp/router-issue772-delivery-20261023')
out=root/'docs/case-studies/issue-759/raw/ci/link-assistant--router/continuation-772'
files={}
labels=['issue772-full-native-retained-canonical-v1','issue772-raw-output-retention-diagnostic-v1',
 'issue772-flat-output-source-generate-v1','issue772-flat-output-source-generate-v2',
 'issue772-flat-output-whole-Node-v1','issue772-flat-output-whole-Bun-v1',
 'issue772-ascii-sync-whole-Node-v1','issue772-ascii-sync-whole-Node-v2',
 'issue772-ascii-sync-whole-Node-v3','issue772-ascii-sync-whole-Bun-v1',
 'issue772-flat-sync-source-review-v1']
for label in labels:
 d=Path('/private/tmp/router-layout-check-'+label)
 assert (d/'receipt.json').is_file(),label
 for f in d.rglob('*'):
  if not f.is_file() or f.is_symlink() or any(x in f.parts for x in ['node-compile-cache','node_modules']):continue
  rel=f.relative_to(d)
  if len(rel.parts)>1 and f.suffix not in ['.json','.jsonl','.gz','.tap','.log']:continue
  files['receiving/'+label+'/'+str(rel)]=f
for f in Path('/private/tmp/router-issue772-cycle-4b22bd09b').iterdir():
 if f.is_file():files['complete-ci/'+f.name]=f
for f in (p/'retention-stress').iterdir():
 if f.is_file():files['diagnostic/'+f.name]=f
for name in ['retention-raw-stress.mjs','compare-raw-retention.py','review-flat-sync-source.mjs','flat-sync-complete-source-review.json.gz','package-flat-sync.py']:
 files['source/'+name]=p/name
for name in ['router-layout-bounded-receiving-js-v1.py','router-receiving-whole-Node-runner-20261021-v1.mjs','router-focused-receiving-Bun-from-complete-Node-calls-20261021-v2.mjs']:
 files['harness/'+name]=Path('/private/tmp')/name
assert sum(f.stat().st_size for f in files.values())<128*1024**2
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
vector=[]
for name,f in sorted(files.items()):
 b=f.read_bytes();expanded=gzip.decompress(b) if f.suffix=='.gz' else b
 if f.suffix=='.zip':
  with zipfile.ZipFile(io.BytesIO(b)) as z:
   assert z.testzip() is None
   expanded=b'\n'.join(z.read(n) for n in z.namelist() if not n.endswith('/'))
 for pattern in patterns:assert not re.search(pattern,expanded),name
 vector.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=out/'20261023-flat-sync-delivery.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for row in vector:t.add(files[row['path']],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(vector)
 for row in vector:
  b=t.extractfile(row['path']).read()
  assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
with gzip.open(out/'20261023-flat-sync-members.json.gz','wt') as f:json.dump(vector,f,indent=2)
receipt={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(vector),'allMembersReadBack':True,'completeCi':True,'ciRuns':6,'terminalJobs':50,'ranJobLogs':9,'artifacts':3,'credentialPatterns':'no matches in complete originals and expanded gzip/zip payloads','failedAttemptsRetained':True,'wholeGate':False,'rustExecuted':False}
(out/'20261023-flat-sync-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
