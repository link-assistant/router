import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021',mode=process.argv[2];
const selected=mode==='native'?['private-native-output-text.mjs','createPrivateOutputTextRetention']:['private-byte-output-text.mjs','createPrivateByteOutputTextRetention'];
const module=await import(pathToFileURL(root+'/tools/translation/'+selected[0]));
const bytes=Buffer.allocUnsafe(16*1024*1024);let state=0x7590772;
for(let at=0;at<bytes.length;at+=2){state^=state<<13;state^=state>>>17;state^=state<<5;bytes.writeUInt16LE(state&65535,at);}
const source=bytes.toString('utf16le'),before=createHash('sha256').update(bytes).digest('hex'),storage=module[selected[1]](),cell=storage.retain(source),result=storage.restore(cell);
if(result!==source||createHash('sha256').update(Buffer.from(result,'utf16le')).digest('hex')!==before)throw Error('Whole UTF16 input differs');
console.log(JSON.stringify({mode,units:source.length,rawBytes:bytes.length,sha256:before,observation:storage.observation(cell),memory:process.memoryUsage(),wholeGate:false,rustExecuted:false}));
