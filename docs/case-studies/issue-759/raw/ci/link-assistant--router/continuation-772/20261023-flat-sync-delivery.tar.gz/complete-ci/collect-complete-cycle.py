from pathlib import Path
import subprocess,json,gzip,hashlib,zipfile,io
p=Path('/private/tmp/router-issue772-cycle-4b22bd09b');head='4b22bd09b921a8eb0905a5451cc37ba017dab198'
def api(path):return subprocess.run(['/opt/homebrew/bin/gh','api','repos/link-assistant/router/'+path],capture_output=True,check=True).stdout
def data(path):return json.loads(api(path))
def save(name,x):(p/name).write_text(json.dumps(x,indent=2)+'\n')
runs=data('actions/runs?head_sha='+head+'&per_page=100');assert runs['total_count']==len(runs['workflow_runs']);assert all(x['status']=='completed' and x['head_sha']==head for x in runs['workflow_runs']);save('all-terminal-runs.json',runs)
receipts=[];artifacts=[];totalJobs=0
for run in runs['workflow_runs']:
 rid=run['id'];jobs=data(f'actions/runs/{rid}/jobs?per_page=100');assert jobs['total_count']==len(jobs['jobs']);assert all(x['status']=='completed' and x['conclusion'] is not None for x in jobs['jobs']);save(f'run-{rid}-terminal-jobs.json',jobs);totalJobs+=len(jobs['jobs'])
 for job in jobs['jobs']:
  if job['conclusion']=='skipped':continue
  jid=job['id'];f=p/f'job-{jid}.log.gz'
  if not f.exists():
   raw=api(f'actions/jobs/{jid}/logs');f.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(f.read_bytes())==raw
  raw=gzip.decompress(f.read_bytes());receipts.append({'run':rid,'job':jid,'name':job['name'],'conclusion':job['conclusion'],'path':f.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressedBytes':f.stat().st_size})
 a=data(f'actions/runs/{rid}/artifacts?per_page=100');assert a['total_count']==len(a['artifacts']);save(f'artifacts-{rid}.json',a)
 for artifact in a['artifacts']:
  aid=artifact['id'];f=p/f'artifact-{aid}.zip'
  if not f.exists():f.write_bytes(api(f'actions/artifacts/{aid}/zip'))
  raw=f.read_bytes();members=[]
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   assert sum(v.file_size for v in z.infolist())<128*1024**2
   assert z.testzip() is None
   for name in z.namelist():
    if name.endswith('/'):continue
    b=z.read(name);members.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
  artifacts.append({'run':rid,'id':aid,'name':artifact['name'],'path':f.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'allCrcAndMemberHashesVerified':True,'members':members})
print(json.dumps({'head':head,'complete':True,'runs':len(runs['workflow_runs']),'terminalJobs':totalJobs,'ranLogs':len(receipts),'failedCancelledLogs':sum(x['conclusion'] in ['failure','cancelled'] for x in receipts),'artifacts':len(artifacts),'rustUnlocked':False}))
save('complete-terminal-collection-receipt.json',{'head':head,'complete':True,'runs':len(runs['workflow_runs']),'terminalJobs':totalJobs,'ranLogs':receipts,'artifacts':artifacts,'rustUnlocked':False})
