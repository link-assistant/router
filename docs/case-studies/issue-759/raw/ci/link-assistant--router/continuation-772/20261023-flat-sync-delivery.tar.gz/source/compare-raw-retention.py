from pathlib import Path
import subprocess,gzip,json,hashlib,os
p=Path('/private/tmp/router-issue772-delivery-20261023/retention-stress');p.mkdir(exist_ok=True)
rows=[]
for mode in ['native','byte']:
 cmd=['/Users/konard/.nvm/versions/node/v20.19.4/bin/node','--max-old-space-size=96','/private/tmp/router-issue772-delivery-20261023/retention-raw-stress.mjs',mode]
 r=subprocess.run(cmd,capture_output=True,timeout=45)
 for name,b in [('stdout',r.stdout),('stderr',r.stderr)]:
  target=p/f'{mode}-{name}.log.gz';target.write_bytes(gzip.compress(b,mtime=0));assert gzip.decompress(target.read_bytes())==b
 rows.append({'mode':mode,'exit':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderrBytes':len(r.stderr),'stderrSha256':hashlib.sha256(r.stderr).hexdigest(),'command':cmd})
(p/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
assert rows[0]['exit']!=0 and rows[1]['exit']==0
