import {readFileSync} from 'node:fs';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const path='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021/tools/translation/source-profiles/static-source-lifecycle/originals.json.gz';
const raw=gunzipSync(readFileSync(path)),rows=[];
for(const level of [1,6,9]){const start=performance.now(),packed=gzipSync(raw,{level,mtime:0});if(!gunzipSync(packed).equals(raw))throw Error('Complete storage bytes differ');rows.push({level,bytes:packed.length,elapsedMs:performance.now()-start,sha256:createHash('sha256').update(packed).digest('hex'),fitsOriginalFileCap:packed.length<=4194304});}
console.log(JSON.stringify({engine:process.versions,rawBytes:raw.length,rows,originalCap:4194304,sourceChanged:false,rustExecuted:false}));
