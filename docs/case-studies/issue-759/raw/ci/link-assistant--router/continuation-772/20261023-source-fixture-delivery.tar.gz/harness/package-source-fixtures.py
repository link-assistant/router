from pathlib import Path
import gzip,json,hashlib,tarfile,re,io,zipfile
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021')
p=Path('/private/tmp/router-issue772-delivery-20261023')
out=root/'docs/case-studies/issue-759/raw/ci/link-assistant--router/continuation-772'
files={}
for directory in ['router-issue772-static-bank-5ed9acef-v1','router-issue772-static-bank-1325f92d-v1','router-issue772-isolated-ef7593ae-v1','router-issue772-isolated-4c337d93-v1']:
 d=Path('/private/tmp')/directory
 for f in d.rglob('*'):
  if f.is_file() and not f.is_symlink():files['proposals/'+directory+'/'+str(f.relative_to(d))]=f
labels=['issue772-static-bank-propose-v1','issue772-static-bank-review-install-v1',
 'issue772-refreshed-bank-whole-Node-v1','issue772-refreshed-bank-whole-Node-v2','issue772-refreshed-bank-whole-Bun-v1',
 'issue772-isolated-current-refresh-v1','issue772-current-isolated-whole-Node-v1',
 'issue772-source-bank-compression-Node-v1','issue772-source-bank-compression-Bun-v1',
 'issue772-strict-bank-storage-source-v1','issue772-strict-bank-storage-whole-Node-v1','issue772-strict-bank-storage-whole-Bun-v1',
 'issue772-export-bank-propose-v1','issue772-export-bank-review-install-v1','issue772-final-isolated-current-refresh-v1',
 'issue772-current-export-receiving-whole-Node-v1','issue772-current-export-receiving-whole-Bun-v1',
 'issue772-final-source-receiving-whole-Node-v1','issue772-final-source-receiving-whole-Bun-v1']
for label in labels:
 d=Path('/private/tmp/router-layout-check-'+label);assert (d/'receipt.json').is_file(),label
 for f in d.rglob('*'):
  if not f.is_file() or f.is_symlink() or any(x in f.parts for x in ['node-compile-cache','node_modules']):continue
  rel=f.relative_to(d)
  if len(rel.parts)>1 and f.suffix not in ['.json','.jsonl','.gz','.tap','.log']:continue
  files['receiving/'+label+'/'+str(rel)]=f
for name in ['review-install-static-refresh.mjs','refresh-isolated-compiler-and-git.mjs','refresh-isolated-compiler-and-git-current.mjs','diagnose-bank-compression.mjs','package-source-fixtures.py']:
 files['harness/'+name]=p/name
assert sum(f.stat().st_size for f in files.values())<128*1024**2
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
vector=[]
for name,f in sorted(files.items()):
 b=f.read_bytes();expanded=gzip.decompress(b) if f.suffix=='.gz' else b
 if f.suffix=='.zip':
  with zipfile.ZipFile(io.BytesIO(b)) as z:
   assert z.testzip() is None;expanded=b'\n'.join(z.read(n) for n in z.namelist() if not n.endswith('/'))
 for pattern in patterns:assert not re.search(pattern,expanded),name
 vector.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=out/'20261023-source-fixture-delivery.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for row in vector:t.add(files[row['path']],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(vector)
 for row in vector:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
with gzip.open(out/'20261023-source-fixture-members.json.gz','wt') as f:json.dump(vector,f,indent=2)
receipt={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(vector),'allMembersReadBack':True,'completePriorAndProposedBankBytes':True,'completeNativeCstEquationsAndInverses':True,'failedAttemptsRetained':True,'wholeGate':False,'rustExecuted':False}
(out/'20261023-source-fixture-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
