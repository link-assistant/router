import {readFileSync,writeFileSync,lstatSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021';
const output=process.argv[2],expectedHead=process.argv[3];
if(!output||!expectedHead)throw Error('Actual external proposal and full HEAD required');
const {reviewStrictStaticFixtureRefresh}=await import(pathToFileURL(root+'/tools/translation/refresh-static-source-fixtures.mjs'));
const review=await reviewStrictStaticFixtureRefresh({root,expectedHead,output});
const index=JSON.parse(readFileSync(join(output,'complete.json'),'utf8'));
const packet=index.packets.find(row=>row.path==='fixture-changes.json.gz');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const packed=readFileSync(join(output,packet.path));
if(packed.length!==packet.bytes||hash(packed)!==packet.sha256)throw Error('Reviewed complete changes packet differs');
const raw=gunzipSync(packed,{maxOutputLength:64*1024*1024});
if(raw.length!==packet.rawBytes||hash(raw)!==packet.rawSha256)throw Error('Decoded complete changes packet differs');
const changes=JSON.parse(raw),prefix='tools/translation/source-profiles/static-source-lifecycle/';
if(JSON.stringify(changes.map(row=>row.path))!==JSON.stringify(['originals.json.gz','manifest.json','NOTICE.md'].map(name=>prefix+name)))throw Error('Exactly the three reviewed bank files required');
if(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()!==expectedHead)throw Error('Reviewed actual HEAD changed');
for(const row of changes){
 const full=join(root,row.path),stat=lstatSync(full),before=readFileSync(full),after=Buffer.from(row.after.content,'base64');
 if(!stat.isFile()||stat.isSymbolicLink()||!before.equals(Buffer.from(row.before.content,'base64'))||!before.equals(Buffer.from(row.inverse.content,'base64'))||row.before.bytes!==before.length||row.before.sha256!==hash(before)||row.after.bytes!==after.length||row.after.sha256!==hash(after)||row.completeInverse!==true)throw Error('Complete original/proposed/inverse CAS differs: '+row.path);
 if(!after.equals(readFileSync(join(output,row.path.slice(prefix.length)))))throw Error('Actual reviewed output differs');
}
const installed=[];
try{
 for(const row of changes){writeFileSync(join(root,row.path),Buffer.from(row.after.content,'base64'));installed.push(row);}
 for(const row of changes)if(!readFileSync(join(root,row.path)).equals(Buffer.from(row.after.content,'base64')))throw Error('Full installed output differs');
}catch(error){for(const row of installed.reverse())writeFileSync(join(root,row.path),Buffer.from(row.inverse.content,'base64'));throw error;}
const receipt={schema:'coordinator-reviewed-static-bank-install-v1',expectedHead,review,files:changes.map(row=>({path:row.path,beforeBytes:row.before.bytes,beforeSha256:row.before.sha256,afterBytes:row.after.bytes,afterSha256:row.after.sha256,wholeInverseChecked:true})),allThreeFullBytesReadBack:true,originalHistoricalUniversesUnchanged:true,sourceInstalled:true,semanticAuthority:false,rustExecuted:false};
writeFileSync(join(output,'coordinator-install.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
