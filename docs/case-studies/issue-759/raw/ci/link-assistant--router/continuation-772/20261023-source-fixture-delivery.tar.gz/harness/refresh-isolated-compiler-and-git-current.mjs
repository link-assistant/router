import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync,lstatSync,mkdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021';
const head=process.argv[2],output=process.argv[3];if(!/^[a-f0-9]{40}$/u.test(head??'')||typeof output!=='string'||!output.startsWith('/private/tmp/router-issue772-isolated-'))throw Error('Exact head and fresh task output required');
const load=name=>import(pathToFileURL(root+'/tools/translation/'+name));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),head);
const {prepareIsolatedProjectCompiler}=await load('prepare-isolated-project-compiler.mjs');
const {preparePortableGitFixtureProposal,writePortableGitFixtureProposal,readPortableGitFixture}=await load('prepare-portable-git-fixtures.mjs');
const {transportConcreteSourceEquations}=await load('concrete-source-equations.mjs');
const {ownershipCompiler}=await load('js-to-rust/vendor/module-syntax.mjs'),ts=ownershipCompiler();assert.equal(ts.version,'5.9.3');
const wanted=['tools/translation/source-profiles/isolated-project-compiler/manifest.json.gz','tools/translation/isolated-project-driver.mjs','tools/translation/isolated-project-batch.mjs'];
const before=new Map(wanted.map(path=>[path,readFileSync(join(root,path))]));
const proposal=prepareIsolatedProjectCompiler({root,revision:head,output});assert.equal(proposal.completeUndo,true);assert.equal(proposal.sourceHead,head);
const proposals=new Map([[wanted[0],'manifest.json.gz'],[wanted[1],'isolated-project-driver.mjs'],[wanted[2],'isolated-project-batch.mjs']]);
const rows=[];
for(const [path,name]of proposals){
 assert.ok(lstatSync(join(root,path)).isFile());assert.ok(!lstatSync(join(root,path)).isSymbolicLink());assert.ok(readFileSync(join(root,path)).equals(before.get(path)));
 const after=readFileSync(join(output,name)),row={path,beforeBytes:before.get(path).length,beforeSha256:hash(before.get(path)),afterBytes:after.length,afterSha256:hash(after),before:before.get(path).toString('base64'),after:after.toString('base64')};
 if(path.endsWith('.mjs')){
  const source=after.toString('utf8'),file=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);assert.equal(file.parseDiagnostics.length,0);assert.ok(source.split('\n').length<1000);
  row.equation=transportConcreteSourceEquations([{before:before.get(path).toString('utf8'),after:source,language:'JavaScript'}])[0];assert.equal(row.equation.inverse,before.get(path).toString('utf8'));
  assert.ok(readFileSync(join(output,path.endsWith('driver.mjs')?'driver-before.mjs':'parent-before.mjs')).equals(before.get(path)));
 }
 rows.push(row);
}
// The actual producer already authenticated every complete current source against
// the selected committed Git object and installed TypeScript source tree.
for(const [path,name]of proposals)assert.ok(readFileSync(join(root,path)).equals(before.get(path)));
for(const [path,name]of proposals)writeFileSync(join(root,path),readFileSync(join(output,name)));
for(const row of rows)assert.equal(hash(readFileSync(join(root,row.path))),row.afterSha256);
const portable=preparePortableGitFixtureProposal({root,currentRevision:head}),portableOutput=output+'/portable-git';writePortableGitFixtureProposal(portable,portableOutput);
const portableRows=[];
for(const row of portable.files){
 const path=join(root,row.path),old=readFileSync(path),after=Buffer.from(row.content,row.encoding);
 assert.equal(after.length,row.bytes);assert.equal(hash(after),row.sha256);assert.ok(lstatSync(path).isFile());assert.ok(!lstatSync(path).isSymbolicLink());
 portableRows.push({path:row.path,before:old.toString('base64'),after:after.toString('base64'),beforeBytes:old.length,beforeSha256:hash(old),afterBytes:after.length,afterSha256:hash(after),inverse:old.toString('base64')});
}
for(const row of portableRows)assert.equal(hash(readFileSync(join(root,row.path))),row.beforeSha256);
for(const row of portableRows)writeFileSync(join(root,row.path),Buffer.from(row.after,'base64'));
for(const row of portableRows)assert.equal(hash(readFileSync(join(root,row.path))),row.afterSha256);
const reopened=readPortableGitFixture();assert.equal(reopened.index.sourceHead,head);
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),head);
const result={head,proposal,rows,portable,portableRows,completeReadback:true,typescript:ts.version,rustExecuted:false,semanticAuthority:false};
const raw=Buffer.from(JSON.stringify(result)+'\n'),packed=gzipSync(raw,{level:6});writeFileSync(join(output,'coordinator-complete-review.json.gz'),packed,{flag:'wx'});assert.ok(gunzipSync(readFileSync(join(output,'coordinator-complete-review.json.gz'))).equals(raw));
console.log(JSON.stringify({head,compilerFiles:proposal.files,totalSourceBytes:proposal.totalBytes,changedFiles:[...rows,...portableRows].map(row=>({path:row.path,afterBytes:row.afterBytes,afterSha256:row.afterSha256})),completeSourceInverses:true,completeReadback:true,rustExecuted:false}));
