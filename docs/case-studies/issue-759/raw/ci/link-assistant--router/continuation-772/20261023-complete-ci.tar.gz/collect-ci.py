import concurrent.futures,datetime,gzip,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).parent
OUT=ROOT/'complete-ci';OUT.mkdir(exist_ok=True)
GH='/opt/homebrew/bin/gh'
runs={r['databaseId']:r for f in ['final-pr-head-runs.json','merge-head-runs.json'] for r in json.loads((ROOT/f).read_text())}
def api(path):
 r=subprocess.run([GH,'api',path,'--paginate','--slurp'],capture_output=True,timeout=50)
 if r.returncode:raise RuntimeError(r.stderr.decode())
 return r.stdout,json.loads(r.stdout)
def packed(path,data):
 with path.open('xb') as out:
  with gzip.GzipFile(filename='',fileobj=out,mode='wb',compresslevel=1,mtime=0)as z:z.write(data)
 assert gzip.decompress(path.read_bytes())==data
def collect(run):
 folder=OUT/str(run);folder.mkdir(exist_ok=True);listed=runs[run]
 if (folder/'complete.json').exists():return json.loads((folder/'complete.json').read_text())
 raw,meta=api(f'repos/link-assistant/router/actions/runs/{run}');packed(folder/'run.json.gz',raw)
 current=meta[0];assert current['head_sha']==listed['headSha'];assert current['status']=='completed'
 raw,pages=api(f'repos/link-assistant/router/actions/runs/{run}/attempts/{current["run_attempt"]}/jobs?per_page=100');packed(folder/'jobs.json.gz',raw)
 jobs=[j for p in pages for j in p['jobs']];assert all(j['status']=='completed'for j in jobs)
 rows=[]
 for j in jobs:
  row={k:j.get(k)for k in ['id','name','status','conclusion','started_at','completed_at']};rows.append(row)
  if j['conclusion']not in ['failure','cancelled','timed_out','action_required','startup_failure']:continue
  log=folder/f'job-{j["id"]}.log';err=folder/f'job-{j["id"]}.stderr'
  with log.open('xb')as out,err.open('xb')as e:r=subprocess.run([GH,'api',f'repos/link-assistant/router/actions/jobs/{j["id"]}/logs'],stdout=out,stderr=e,timeout=50)
  row['logFetchExit']=r.returncode
  if r.returncode:row['logError']=err.read_text();continue
  assert log.stat().st_size<=64*1024*1024
  digest=hashlib.sha256();n=0;hints=[];target=log.with_suffix('.log.gz')
  with log.open('rb')as inp,target.open('xb')as out:
   with gzip.GzipFile(filename='',fileobj=out,mode='wb',compresslevel=1,mtime=0)as z:
    for chunk in iter(lambda:inp.read(65536),b''):digest.update(chunk);n+=len(chunk);z.write(chunk)
  check=hashlib.sha256();size=0
  with gzip.open(target,'rb')as inp:
   for chunk in iter(lambda:inp.read(65536),b''):check.update(chunk);size+=len(chunk)
  assert size==n and check.digest()==digest.digest()
  with gzip.open(target,'rt',errors='replace')as inp:
   for line in inp:
    if re.search(r'not ok |Error:|error TS\d|out of memory|FATAL ERROR|stale|FAIL',line):hints.append(line.rstrip())
  row.update({'log':str(target),'bytes':n,'sha256':digest.hexdigest(),'failureRecords':hints});log.unlink()
  assert sum(p.stat().st_size for p in OUT.rglob('*')if p.is_file())<384*1024*1024
 result={'run':run,'head':current['head_sha'],'attempt':current['run_attempt'],'status':current['status'],'conclusion':current['conclusion'],'jobs':rows}
 (folder/'complete.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'run':run,'jobs':len(jobs),'redLogs':sum('log'in r for r in rows),'logErrors':sum('logError'in r for r in rows)}),flush=True);return result
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for future in concurrent.futures.as_completed({pool.submit(collect,k):k for k in runs}):
  try:results.append(future.result())
  except Exception as e:results.append({'collectionError':str(e)})
(OUT/'complete-index.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':results},indent=2)+'\n')
print(json.dumps({'finishedRuns':len(results),'collectionErrors':sum('collectionError'in r for r in results),'logErrors':sum('logError'in j for r in results for j in r.get('jobs',[]))}),flush=True)
