import collections, gzip, hashlib, io, json, pathlib, subprocess, tarfile

ROOT = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
HEAD = '5eb88d4721683d44cc3ec620d68bbc93d6d326e9'
PACK = 'docs/case-studies/issue-759/raw/current-task/6f4e28f872db33ca05dd64221827281cf3078760e2b2e8c41a73632affce9336.tar.gz'
MEMBER = 'canonical-generation-5eb88d472-validation-pending/router-759-complete-gaps-5eb88d472.json.gz'
OUT = ROOT / 'docs/case-studies/issue-759/raw/current-task/source-identities-5eb88d472'
digest = lambda value: hashlib.sha256(value).hexdigest()
def git(*args, **kwargs):
    return subprocess.check_output(['git', *args], cwd=ROOT, **kwargs)

pack = git('show', 'bc9d9d24d:' + PACK)
assert digest(pack) == '6f4e28f872db33ca05dd64221827281cf3078760e2b2e8c41a73632affce9336'
with tarfile.open(fileobj=io.BytesIO(pack), mode='r:gz') as archive:
    original = archive.extractfile(MEMBER).read()
decoded = gzip.decompress(original)
gaps = json.loads(decoded)
assert gaps['sourceHead'] == HEAD
inventory_bytes = git('show', HEAD + ':parity/rust-source-inventory.json')
inventory = json.loads(inventory_bytes)
by_hash = collections.defaultdict(list)
for source in inventory['sources']:
    if source['source'].startswith('src/'):
        by_hash[source['sha256']].append(source['source'])
paths = sorted({path for row in gaps['rows'] for path in by_hash[row['sourceSha256']]})
batch = git('cat-file', '--batch', input=''.join(HEAD + ':' + path + '\n' for path in paths).encode())
stream = io.BytesIO(batch)
source_bytes = {}
source_utf16 = {}
for path in paths:
    header = stream.readline().decode().split()
    assert len(header) == 3 and header[1] == 'blob', (path, header)
    body = stream.read(int(header[2])); assert stream.read(1) == b'\n'
    source_bytes[path] = body
    source_utf16[path] = body.decode('utf8').encode('utf-16-le')
assert not stream.read()
rows, failures, ambiguous = [], [], []
for index, row in enumerate(gaps['rows']):
    candidates = sorted(by_hash[row['sourceSha256']])
    if len(candidates) != 1:
        ambiguous.append({'rowIndex':index, 'sourceSha256':row['sourceSha256'], 'sourceCandidatePaths':candidates})
    body = row['source'].encode('utf8')
    if digest(body) != row['sha256']:
        failures.append({'rowIndex':index, 'check':'original item text hash'})
    for path in candidates:
        span = row['span']
        if digest(source_bytes[path]) != row['sourceSha256']:
            failures.append({'rowIndex':index, 'sourceFile':path, 'check':'original full source hash'})
        actual = source_utf16[path][span['start']*2:span['end']*2].decode('utf-16-le').encode('utf8')
        if actual != body:
            failures.append({'rowIndex':index, 'sourceFile':path, 'check':'original UTF16 source span'})
        if 'byteStart' in span and source_bytes[path][span['byteStart']:span['byteEnd']] != body:
            failures.append({'rowIndex':index, 'sourceFile':path, 'check':'original UTF8 source span'})
    entry = {'rowIndex':index, 'sourceFile':candidates[0] if len(candidates)==1 else None}
    if len(candidates)!=1: entry['sourceCandidatePaths'] = candidates
    rows.append(entry)
sidecar = {'schema':'original-gap-source-file-index-v1','sourceHead':HEAD,
    'originalArchive':{'path':PACK,'sha256':digest(pack),'member':MEMBER,'memberSha256':digest(original),'decodedSha256':digest(decoded)},
    'inventory':{'revision':HEAD,'path':'parity/rust-source-inventory.json','sha256':digest(inventory_bytes)},
    'scope':'source text remains unchanged in original archive rows[].source; index adds sourceFile without overriding that field',
    'sourceTextRetained':True,'sourceFileScope':'all tracked src/ files in the exact source-head inventory',
    'rows':rows,'ambiguousAssociations':ambiguous,'validationFailures':failures,
    'canonicalProducerRuns':0,'compilerRuns':0,'rustBuilds':0,'runtimeParity':False}
packed = gzip.compress((json.dumps(sidecar,ensure_ascii=False,separators=(',',':'))+'\n').encode(),compresslevel=9,mtime=0)
OUT.mkdir(parents=True,exist_ok=True)
path = OUT / (digest(packed)+'.json.gz');path.write_bytes(packed)
reopened = json.loads(gzip.decompress(path.read_bytes()));assert reopened == sidecar
recipe = pathlib.Path(__file__).read_bytes()
recipe_packed = gzip.compress(recipe,compresslevel=9,mtime=0)
recipe_path = OUT / (digest(recipe_packed)+'.py.gz');recipe_path.write_bytes(recipe_packed)
assert gzip.decompress(recipe_path.read_bytes()) == recipe
receipt = {'schema':'original-gap-source-file-index-receipt-v1','sourceHead':HEAD,
    'sidecar':{'path':path.relative_to(ROOT).as_posix(),'sha256':digest(packed),'bytes':len(packed)},
    'sourceFiles':len(paths),'rows':len(rows),'ambiguousAssociations':len(ambiguous),'validationFailures':failures,
    'checks':['original archived member exact bytes','exact source-head inventory','original full Rust file SHA256','original item source SHA256','UTF16 span source bytes','UTF8 span source bytes when recorded','byte-reopened sidecar'],
    'archiveUnmodified':True,'inventoryUnmodified':True,'compilerRuns':0,'rustBuilds':0,
    'helper':{'path':recipe_path.relative_to(ROOT).as_posix(),'sha256':digest(recipe_packed),'originalSha256':digest(recipe),'bytes':len(recipe_packed)}}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(OUT/'README.md').write_text('This correction index restores original Rust file paths for the archived 5eb88d472 gap rows. The original archive is unchanged: its `source` field retains each item’s exact text. Use `rowIndex` to join the sidecar `sourceFile` to that original record. File and item hashes and UTF-16/UTF-8 spans were checked against the exact source-head Git objects. This read-only provenance correction reruns no compiler and establishes no runtime parity.\n')
print(json.dumps({'rows':len(rows),'sourceFiles':len(paths),'ambiguities':len(ambiguous),'failureCount':len(failures),'firstFailures':failures[:5],'storedBytes':sum(p.stat().st_size for p in OUT.iterdir()),'sidecarSha256':digest(packed)}))
if failures: raise SystemExit(1)
