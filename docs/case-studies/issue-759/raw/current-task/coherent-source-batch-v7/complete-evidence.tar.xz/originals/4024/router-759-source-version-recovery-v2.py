import json,hashlib,subprocess,time,os,pathlib
root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-reverse-cycle'
report='/tmp/router-759-successor-packet-plan-v4/report.json'
out=pathlib.Path('/tmp/router-759-source-version-recovery-v2');out.mkdir(exist_ok=False)
start=time.monotonic();deadline=start+180
rows=json.load(open(report))['staleOrMissingOriginalsWithoutWitness']; recovered=[];missing=[];cache={};attempts=0

def git(*args):
 if time.monotonic()>deadline:raise TimeoutError('bounded180second recovery')
 return subprocess.check_output(['git',*args],cwd=root,stderr=subprocess.DEVNULL,timeout=15)
def sha(b):return hashlib.sha256(b).hexdigest()
priority=['1b7c93a89','5586579','3c96a4bdd','88da8d34c80e318f2038854f122f2536e3edaa19','3ca6b6e48','edd500','6daf6cd495ff6b76848b0a77cb737439367596b1','e1d40ae24']
for index,row in enumerate(rows):
 rel=row['originalPath'].split('/.worktrees/')[1].split('/',1)[1]
 history=git('log','--all','--format=%H','--',rel).decode().splitlines()
 found=None;seen=set()
 for candidate in priority+history:
  try:
   commit=git('rev-parse',candidate+'^{commit}').decode().strip()
   oid=git('rev-parse',commit+':'+rel).decode().strip()
  except subprocess.CalledProcessError:continue
  if oid in seen:continue
  seen.add(oid);attempts+=1
  if oid not in cache:
   size=int(git('cat-file','-s',oid));cache[oid]=(size,None,None)
   if size==row['bytes']:
    data=git('cat-file','blob',oid);cache[oid]=(size,sha(data),data)
  size,h,data=cache[oid]
  if size!=row['bytes']:continue
  if h is None:
   data=git('cat-file','blob',oid);h=sha(data);cache[oid]=(size,h,data)
  if h!=row['sha256']:continue
  target=out/'objects'/row['sha256'];target.parent.mkdir(exist_ok=True)
  if not target.exists():target.write_bytes(data)
  copied=target.read_bytes();assert len(copied)==row['bytes'] and sha(copied)==row['sha256']
  ancestor=subprocess.run(['git','merge-base','--is-ancestor',commit,'e1d40ae24'],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15).returncode==0
  found={**row,'recoveredPath':str(target),'sourceCommit':commit,'sourcePath':rel,'sourceGitBlob':oid,'sourceCommitAncestorOfFrozenRoot':ancestor,'copiedOriginalVerified':True}
  recovered.append(found);print(json.dumps({'index':index,'recovered':rel,'commit':commit,'rootReachable':ancestor}),flush=True);break
 if not found:
  missing.append({**row,'sourcePath':rel,'distinctBlobsExamined':len(seen)})
  print(json.dumps({'index':index,'missing':rel,'distinctBlobsExamined':len(seen)}),flush=True)
manifest={'schema':'complete-source-version-recovery-v2','inputReport':report,'inputReportSha256':sha(pathlib.Path(report).read_bytes()),'frozenRootHead':git('rev-parse','e1d40ae24^{commit}').decode().strip(),'members':recovered,'missing':missing,'expectedMembers':len(rows),'recoveredMembers':len(recovered),'completeBytes':sum(r['bytes'] for r in recovered),'blobCandidatesExamined':attempts,'elapsedSeconds':time.monotonic()-start,'allRecoveredOriginalsVerified':True,'runtimeParity':False,'fullGatePass':False,'rustExecuted':False}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in manifest.items() if k not in ['members','missing']}),flush=True)
