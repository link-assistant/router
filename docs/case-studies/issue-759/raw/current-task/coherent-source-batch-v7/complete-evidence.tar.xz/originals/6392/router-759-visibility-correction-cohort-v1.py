from pathlib import Path
import datetime, hashlib, json, os, resource, signal, subprocess, time

root = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
prefix = Path('/tmp/router-759-visibility-correction-cohort-v1')
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, timeout=30).decode().strip()
head = git('rev-parse', 'HEAD')
assert not git('status', '--porcelain')
selected = ['tools/translation/test/source-scope-templates.test.mjs','tools/translation/test/source-namespace-bindings.test.mjs','tools/translation/test/module-bindings.test.mjs','tools/translation/test/reexport-generic-owners.test.mjs','scripts/test/native-portable-artifacts.test.mjs']
assert all((root / path).is_file() for path in selected)
paths = sorted(filter(None, subprocess.check_output(['git', 'ls-files', '-z', '--', '*.rs',
    'Cargo.toml', 'Cargo.lock', 'tools/translation', 'scripts'], cwd=root).decode().split('\0')))
paths = [path for path in paths if not path.startswith(('tools/translation/meta/', 'tools/translation/projects/', 'tools/translation/js-to-rust/generated/'))]
def snapshot():
    result = []
    for path in paths:
        source = root / path
        raw = source.read_bytes() if source.is_file() else subprocess.check_output(['git', 'show', head + ':' + path], cwd=root, timeout=30)
        result.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
    return result
before = snapshot()
inputs = Path(str(prefix) + '-inputs.json')
assert not inputs.exists()
inputs.write_text(json.dumps({'sourceHead': head, 'inputs': before, 'wholeTestFiles': selected,
                            'harnessSha256': sha(Path(__file__).read_bytes())}, indent=2) + '\n')
env = dict(os.environ)
env['ROUTER_TRANSLATION_TSC'] = str(root / 'packages/javascript/node_modules/.bin/tsc')
stages = []
for engine, command in [('node', ['node', '--test', '--test-concurrency=2']),
                         ('bun', ['/Users/konard/.bun/bin/bun', 'test'])]:
    raw = Path(str(prefix) + '-' + engine + '.raw.log')
    receipt = Path(str(prefix) + '-' + engine + '.json')
    assert not raw.exists() and not receipt.exists()
    start = time.monotonic()
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    timed_out = False
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with raw.open('xb') as stream:
        child = subprocess.Popen(command + selected, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try: code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
    elapsed = time.monotonic() - start
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    unchanged = before == snapshot() and git('rev-parse', 'HEAD') == head
    result = {'sourceHead': head, 'engine': engine, 'command': command + selected,
              'wholeTestFiles': len(selected), 'capSeconds': 120, 'startedUtc': started,
              'exitCode': code, 'elapsedSeconds': elapsed, 'timedOut': timed_out,
              'sourceInputsUnchanged': unchanged, 'inputReceipt': str(inputs),
              'inputReceiptSha256': sha(inputs.read_bytes()), 'raw': {'path': str(raw),
              'bytes': raw.stat().st_size, 'sha256': sha(raw.read_bytes())},
              'resource': {'method': 'RUSAGE_CHILDREN after waited engine',
              'scope': 'maximum recorded waited child, not aggregate concurrent RSS',
              'maxRssBytes': usage_after.ru_maxrss, 'userCpuSeconds': usage_after.ru_utime - usage_before.ru_utime,
              'systemCpuSeconds': usage_after.ru_stime - usage_before.ru_stime},
              'fullGatePass': False, 'runtimeParity': False, 'rustExecuted': False}
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    stages.append(result)
    if not unchanged:
        raise SystemExit(2)
terminal = Path(str(prefix) + '-terminal.json')
assert not terminal.exists()
terminal.write_text(json.dumps({'sourceHead': head, 'stages': stages,
                              'allPassed': all(row['exitCode'] == 0 and not row['timedOut'] for row in stages),
                              'fullGatePass': False, 'rustExecuted': False}, indent=2) + '\n')
raise SystemExit(0 if all(row['exitCode'] == 0 and not row['timedOut'] for row in stages) else 1)
