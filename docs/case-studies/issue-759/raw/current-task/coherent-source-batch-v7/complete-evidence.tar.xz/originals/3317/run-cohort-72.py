import subprocess,time,json,resource,sys,pathlib,signal
root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-derive-cycle')
base=pathlib.Path('/tmp/router-759-derive-cycle-20261013-into-v1')
cohort=['tools/translation/test/source-conversions.test.mjs','tools/translation/test/original-source-into.test.mjs','tools/translation/test/original-option-filter-owners.test.mjs','tools/translation/test/primitive-identity-from.test.mjs','tools/translation/test/string-ownership-operations.test.mjs','tools/translation/test/host-source-ownership.test.mjs','tools/translation/test/default-source-methods.test.mjs']
engine=sys.argv[1];cmd=([engine,'--test','--test-concurrency=2'] if engine=='node' else [engine,'test'])+cohort
name=engine+'-final';begin=time.monotonic();peak=0;samples=[]
with (base/(name+'.log')).open('wb') as log:
 process=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while process.poll() is None:
  if time.monotonic()-begin>180:
   __import__('os').killpg(process.pid,signal.SIGTERM);process.wait();break
  time.sleep(.1)
result={'command':cmd,'cohort':cohort,'exitCode':process.returncode,'seconds':time.monotonic()-begin,'peakSampledProcessTreeRssBytes':None,'samplingMethod':'process-tree ps sampling unavailable in sandbox; RUSAGE_CHILDREN observed after awaiting bounded test child','cumulativeChildrenMaxRss':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'completeLog':name+'.log','samples':samples,'rustBuild':False,'wholeCorpusProbe':False}
(base/(name+'-resource.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='samples'}));sys.exit(process.returncode)
