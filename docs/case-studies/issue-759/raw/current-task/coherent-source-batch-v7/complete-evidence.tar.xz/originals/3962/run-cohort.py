from pathlib import Path
import json,subprocess,time,hashlib,os,sys
out=Path('/tmp/router-759-shared-pattern-cycle-20261013-v1');prior=json.load(open('/tmp/router-759-option-next-cycle-20261013-v1/combined-final-runs.json'))[0]['command'][2:]
extra=['json-macro-inputs','shared-source-patterns','pattern-control','pattern-bindings','pattern-syntax','nested-match-patterns','ordered-matches','parameter-patterns','for-patterns','integer-range-patterns','shared-str-pattern','shared-nullary-enum','shared-match-field-origins','named-lifetimes','owned-result-lifetimes','json-macro-frontier','json-macro-lowering','json-macro-arrays','json-macro-runtime','source-links','data-metadata']
files=list(dict.fromkeys(prior+['tools/translation/test/'+name+'.test.mjs' for name in extra]))
vector=[{'path':p,'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}for p in files];(out/'cohort-test-input-vector.json').write_text(json.dumps(vector,indent=2))
runs=[];engine=sys.argv[1];label=sys.argv[2];cmd=[engine,'--test','--test-concurrency=2',*files] if engine=='node' else [engine,'test',*files];start=time.monotonic();log=out/(engine+'-'+label+'.log')
with log.open('w')as f:
 try: code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=420,env={**os.environ,'ROUTER_TRANSLATION_TSC':'/Users/konard/.bun/bin/tsc'}).returncode
 except subprocess.TimeoutExpired:code=124
receipt={'runner':engine,'command':cmd,'timeoutSeconds':420,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'stdoutAndStderr':str(log),'peakRssBytes':None};(out/(engine+'-'+label+'-run.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));sys.exit(code)
