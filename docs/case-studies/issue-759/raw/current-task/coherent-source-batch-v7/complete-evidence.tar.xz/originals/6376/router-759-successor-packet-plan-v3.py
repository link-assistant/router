from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile, time

root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
out=Path('/tmp/router-759-successor-packet-plan-v3')
assert not out.exists()
out.mkdir()
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,timeout=180)
started=time.monotonic()
selected={}
def add(path, expected=None):
    path=Path(path)
    row=expected or {'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
    key=(str(path),row['bytes'],row['sha256'])
    record={'originalPath':str(path),'bytes':row['bytes'],'sha256':row['sha256']}
    if key in selected:
        assert selected[key]==record,(key,'conflicting selected input metadata')
    selected[key]=record
receipts=[('/tmp/router-759-shared-pattern-cycle-20261013-v1/input-resource-receipt.json','artifactVector'),
          ('/tmp/router-759-derive-cycle-20261013-into-v1/receipt.json','files'),
          ('/tmp/router-759-reverse-cycle-final-inputs-11.json','evidence'),
          ('/tmp/router-759-reverse-cycle-final-inputs-12.json','evidence'),
          ('/tmp/router-759-reverse-cycle-final-inputs-13.json','evidence'),
          ('/tmp/router-759-standard-mapped-cycle-20261013-v1/input-resource-receipt.json','artifacts')]
for name, key in receipts:
    path=Path(name);data=json.loads(path.read_text());add(path)
    for row in data[key]:
        original=Path(row['path'])
        if not original.is_absolute():original=path.parent/original
        add(original,row)
    for row in data.get('inputs',[]):add(row['path'],row)
for pattern in ['router-759-recovery-packets-direct-git-v1*',
                'router-759-merged-source-cohort-v*', 'router-759-visibility-correction-cohort-v1*',
                'router-759-reviewer-merged-cohort-v1*', 'router-759-source-scope-duplicate-preflight-v1*',
                'router-759-native-artifacts-v5-630a7da1e*', 'router-759-native-conditional-strict-typescript-v1*',
                'router-759-native-conditional-direct-git-v1*', 'router-759-native-artifacts-incorrect-head-preflight-v1*',
                'router-759-reverse-cycle-review-vectors-13-compression.json',
                'router-759-compaction-supplement-capture-producer-v3*']:
    for path in sorted(Path('/tmp').glob(pattern)):
        if path.is_file():add(path)
for path in sorted(Path('/tmp/router-759-source-version-recovery-v1').rglob('*')):
    if path.is_file():add(path)
for pattern in ['router-759-source-version-recovery.py','router-759-source-version-recovery-v1.log','router-759-successor-packet-plan-v1.py','router-759-successor-packet-plan-v2.py','router-759-successor-packet-plan-v1.raw.log','router-759-successor-packet-plan-v2.raw.log']:
    add('/tmp/'+pattern)
for path in sorted(Path('/tmp/router-759-successor-packet-plan-v2').rglob('*')):
    if path.is_file():add(path)
assert len(selected)<=8192
# Catalog complete blobs from the current reachable commit. Source and
# generated output blobs are immutable even while regeneration is running.
names=git('ls-files','-z','--','src','tests','tools/translation','scripts','packages/javascript','Cargo.toml','Cargo.lock','docs/development').decode().split('\0')
names=sorted(filter(None,names))
assert all('\n' not in name for name in names)
raw=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join(head+':'+name+'\n' for name in names).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180,check=True).stdout
assert len(raw)<=1024**3
catalog={};offset=0
for name in names:
    end=raw.index(b'\n',offset);header=raw[offset:end];offset=end+1
    match=re.fullmatch(rb'([a-f0-9]{40}) blob (\d+)',header)
    assert match,name
    size=int(match[2]);data=raw[offset:offset+size];offset+=size
    assert raw[offset:offset+1]==b'\n';offset+=1
    catalog.setdefault((size,sha(data)),{'kind':'immutable-git-blob','commit':head,'path':name,'gitBlobSha':match[1].decode()})
assert offset==len(raw)
del raw
for packet in ['canonical-recovery','coherent-source-successor','log-compaction-continuity']:
    base='docs/case-studies/issue-759/current/'+packet+'/'
    receipt_path=base+('capture-receipt.json' if packet=='coherent-source-successor' else 'capture-receipt.json.gz')
    encoded_receipt=git('show',head+':'+receipt_path)
    receipt=json.loads(gzip.decompress(encoded_receipt) if receipt_path.endswith('.gz') else encoded_receipt)
    encoded=git('show',head+':'+base+'complete-evidence.tar.xz')
    assert sha(encoded)==receipt['archiveSha256']
    expected={row['path']:row for row in receipt['members']};decoded={}
    with tarfile.open(fileobj=io.BytesIO(encoded),mode='r|xz') as archive:
        for member in archive:
            assert member.name in expected and member.name not in decoded
            if member.islnk():
                assert member.linkname in decoded
                actual=decoded[member.linkname]
            else:
                assert member.isfile();digest=hashlib.sha256();size=0
                stream=archive.extractfile(member)
                while chunk:=stream.read(1024*1024):digest.update(chunk);size+=len(chunk)
                actual=(size,digest.hexdigest())
            assert actual==(expected[member.name]['bytes'],expected[member.name]['sha256'])
            decoded[member.name]=actual
            catalog.setdefault(actual,{'kind':'complete-immutable-packet-member','commit':head,
                'archivePath':base+'complete-evidence.tar.xz','archiveSha256':receipt['archiveSha256'],'member':member.name})
    assert set(decoded)==set(expected)
copies={}
for row in selected.values():
    path=Path(row['originalPath'])
    if path.is_file() and path.stat().st_size==row['bytes'] and sha(path.read_bytes())==row['sha256']:
        copies.setdefault((row['bytes'],row['sha256']),str(path))
members=[];witnesses=[];stale=[];aliases=[]
for number,row in enumerate(sorted(selected.values(),key=lambda row:row['originalPath'])):
    key=(row['bytes'],row['sha256']);reference=catalog.get(key)
    if reference:
        witnesses.append({**row,'completeStorageWitness':reference})
    else:
        retained=copies.get(key)
        path=Path(retained) if retained else Path(row['originalPath'])
        if not path.is_file() or path.stat().st_size!=row['bytes'] or sha(path.read_bytes())!=row['sha256']:
            stale.append(row);continue
        name='originals/'+str(number)+'/'+path.name
        members.append({'path':name,**row,'originalPath':str(path)})
        if str(path)!=row['originalPath']:aliases.append({**row,'completeRetainedOriginalPath':str(path),'completeArchiveMember':name})
report={'sourceHead':head,'selectedOriginals':len(selected),'completeStorageWitnesses':len(witnesses),
        'newCompleteMembers':len(members),'newCompleteOriginalBytes':sum(row['bytes'] for row in members),
        'staleOrMissingOriginalsWithoutWitness':stale,'elapsedSeconds':time.monotonic()-started,
        'runtimeParity':False,'fullGatePass':False,'rustExecuted':False}
(out/'complete-witnesses.json').write_text(json.dumps({'sourceHead':head,'witnesses':witnesses,'completeRetainedSourceAliases':aliases},indent=2)+'\n')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert not stale, 'Every selected complete original must retain full bytes or a byte-verified reachable Git/packet witness'
for name in ['complete-witnesses.json','report.json']:
    path=out/name;data=path.read_bytes();members.append({'path':'provenance/'+name,'originalPath':str(path),'bytes':len(data),'sha256':sha(data)})
(out/'manifest.json').write_text(json.dumps({'members':members},indent=2)+'\n')
print(json.dumps(report))
