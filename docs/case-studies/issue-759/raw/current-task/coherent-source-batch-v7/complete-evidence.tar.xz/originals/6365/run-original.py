from pathlib import Path
import subprocess,time,json,sys
out=Path('/tmp/router-759-standard-mapped-cycle-20261013-v1');label=sys.argv[1];compiler=sys.argv[2] if len(sys.argv)>2 else str(Path.cwd());cmd=['node',str(out/'original-owner-probe.mjs'),label,compiler];start=time.monotonic()
with (out/(label+'.log')).open('w')as stream:
 try:code=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=120).returncode
 except subprocess.TimeoutExpired:code=124
r={'command':cmd,'capSeconds':120,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'peakRssBytes':None,'rawLog':str(out/(label+'.log'))};(out/(label+'-run.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r));sys.exit(code)
