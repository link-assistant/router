import {translateProject} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-option-cycle/tools/translation/project.mjs';
import {pinnedMappedBody} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-option-cycle/tools/translation/extensions/standard-body-source.mjs';
console.log(JSON.stringify(pinnedMappedBody('Result','map').method));
for(const source of [
'pub fn widened(value:Result<u8,bool>)->Result<u16,bool>{value.map(|n|n as u16)}',
'pub fn nested(value:Result<u8,bool>)->Result<Option<u8>,bool>{value.map(Some)}',
'#[derive(Copy,Clone)]enum Mode{Yes,No}pub fn selected(value:Option<u8>)->Mode{value.map_or(Mode::No,|n|if n>0u8{Mode::Yes}else{Mode::No})}',
'pub fn nested(value:Option<u8>)->Option<u8>{value.map_or(None,Some)}',
'pub fn borrowed<'a>(value:Result<&'a u8,bool>)->Result<&'a u8,bool>{value.map(|n|n)}',
])try{const r=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source});console.log(JSON.stringify({source,refused:r.meta.refused,exec:r.meta.executable}));}catch(error){console.log(error.stack);}
