from pathlib import Path
import hashlib, json, re, subprocess, time
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
producer=Path('/tmp/router-759-native-artifacts-v5-630a7da1e-terminal.json')
input_path=Path('/tmp/router-759-native-artifacts-v5-630a7da1e-inputs.json')
terminal=json.loads(producer.read_text())
inputs=json.loads(input_path.read_text())['inputs']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
rows=inputs+terminal['outputsAfter']
assert len({row['path'] for row in rows})==len(rows)
assert all('\n' not in row['path'] and '\0' not in row['path'] for row in rows)
start=time.monotonic()
result=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join(head+':'+row['path']+'\n' for row in rows).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180,check=True)
offset=0
verified=[]
for row in rows:
    end=result.stdout.index(b'\n',offset)
    header=result.stdout[offset:end]
    match=re.fullmatch(rb'([a-f0-9]{40}) blob (\d+)',header)
    assert match,row['path']
    size=int(match[2]);offset=end+1
    data=result.stdout[offset:offset+size];offset+=size
    assert result.stdout[offset:offset+1]==b'\n';offset+=1
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
    verified.append({**row,'gitBlobSha':match[1].decode()})
assert offset==len(result.stdout)
assert subprocess.run(['git','diff','--quiet',head,'5586579b8e02e79608f0b035046968065c43e564','--','*.rs','Cargo.toml','Cargo.lock'],cwd=root).returncode==0
proof={'schema':'complete-native-conditional-direct-git-v1','committedHead':head,
       'producerSourceHead':terminal['head'],'producerReceiptSha256':hashlib.sha256(producer.read_bytes()).hexdigest(),
       'allOriginalInputsAndOutputsMatchCommittedGit':True,'originalInputs':len(inputs),
       'generatedOutputs':len(terminal['outputsAfter']),'verified':verified,
       'allOriginalRustAndCargoInputsUnchanged':True,'elapsedSeconds':time.monotonic()-start,
       'runtimeParity':False,'fullGatePass':False,'rustExecuted':False}
out=Path('/tmp/router-759-native-conditional-direct-git-v1.json');assert not out.exists()
out.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({key:value for key,value in proof.items() if key!='verified'}))
