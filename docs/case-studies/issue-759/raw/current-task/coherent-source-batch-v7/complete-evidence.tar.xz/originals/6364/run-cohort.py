from pathlib import Path
import json,subprocess,time,hashlib,os,sys
out=Path('/tmp/router-759-standard-mapped-cycle-20261013-v1');vector=json.load(open(out/'cohort-test-input-vector.json'));compiler=json.load(open(out/'compiler-exact-final-inputs.json'))
for item in compiler:
 p=Path(item['path']);assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
engine=sys.argv[1];files=[v['path']for v in vector];cmd=[engine,'--test','--test-concurrency=2',*files]if engine=='node'else[engine,'test',*files];start=time.monotonic();log=out/(engine+'-cohort-final.log')
with log.open('w')as stream:
 try:code=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=420,env={**os.environ,'ROUTER_TRANSLATION_TSC':'/Users/konard/.bun/bin/tsc'}).returncode
 except subprocess.TimeoutExpired:code=124
for item in compiler:
 assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
r={'runner':engine,'command':cmd,'capSeconds':420,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'peakRssBytes':None,'rawLog':str(log),'compilerInputVector':str(out/'compiler-exact-final-inputs.json'),'testInputVector':str(out/'cohort-test-input-vector.json'),'inputsStable':True};(out/(engine+'-cohort-final-run.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(code)
