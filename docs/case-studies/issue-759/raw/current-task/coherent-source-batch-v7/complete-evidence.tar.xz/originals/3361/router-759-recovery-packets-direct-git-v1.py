from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile, time
root = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
sha = lambda data: hashlib.sha256(data).hexdigest()
def blob(commit, path):
    return subprocess.check_output(['git', 'show', commit + ':' + path], cwd=root, timeout=30)
started = time.monotonic()
results = []
for name in ['canonical-recovery', 'log-compaction-continuity']:
    base = 'docs/case-studies/issue-759/current/' + name + '/'
    stored = blob(head, base + 'capture-receipt.json.gz')
    storage = json.loads(blob(head, base + 'storage-receipt.json'))
    assert sha(stored) == storage['storedReceiptSha256']
    receipt_raw = gzip.decompress(stored)
    assert sha(receipt_raw) == storage['originalReceiptSha256']
    receipt = json.loads(receipt_raw)
    archive = blob(head, base + 'complete-evidence.tar.xz')
    assert len(archive) == receipt['archiveBytes']
    assert sha(archive) == receipt['archiveSha256']
    expected = {row['path']: row for row in receipt['members']}
    assert len(expected) == len(receipt['members'])
    decoded = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r|xz') as tar:
        for member in tar:
            assert member.name in expected and member.name not in decoded
            assert member.isfile() or member.islnk()
            if member.islnk():
                assert member.linkname in decoded
                actual = dict(decoded[member.linkname])
            else:
                digest = hashlib.sha256()
                size = 0
                stream = tar.extractfile(member)
                while chunk := stream.read(1024 * 1024):
                    digest.update(chunk)
                    size += len(chunk)
                actual = {'bytes': size, 'sha256': digest.hexdigest()}
            assert actual == {key: expected[member.name][key] for key in actual}, member.name
            decoded[member.name] = actual
    assert set(decoded) == set(expected)
    assert sum(row['bytes'] for row in decoded.values()) == receipt['completeOriginalBytes']
    results.append({'packet': name, 'capturedSourceHead': receipt['sourceHead'],
                    'archiveSha256': receipt['archiveSha256'], 'decodedMembers': len(decoded),
                    'completeOriginalBytes': receipt['completeOriginalBytes'],
                    'allDecodedOriginalMetadata': decoded})
metadata = []
for suffix in ['', '-2', '-3', '-4']:
    path = 'docs/case-studies/issue-759/raw/lossless-mid-sized-log-archives' + suffix + '.json'
    original = blob('9a17018d03504d648a746a758c37f32dfa4f50e4', path)
    stored = blob(head, path + '.gz')
    assert gzip.decompress(stored) == original
    metadata.append({'originalPath': path, 'originalBytes': len(original),
                     'originalSha256': sha(original), 'storedSha256': sha(stored),
                     'decodedBytesEqualOriginalGitBlob': True})
result = {'schema': 'recovery-packets-direct-git-v1', 'committedHead': head,
          'allCompleteOriginalsVerifiedFromCommittedGit': True, 'packets': results,
          'metadataGzip': metadata, 'elapsedSeconds': time.monotonic() - started,
          'fullGatePass': False, 'runtimeParity': False, 'rustExecuted': False}
output = Path('/tmp/router-759-recovery-packets-direct-git-v1.json')
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'committedHead': head, 'allCompleteOriginalsVerifiedFromCommittedGit': True,
                  'decodedMembers': [row['decodedMembers'] for row in results],
                  'metadataContainers': len(metadata), 'elapsedSeconds': result['elapsedSeconds']}))
