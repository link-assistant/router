from pathlib import Path
import subprocess,json,time,hashlib
out=Path('/tmp/router-759-shared-pattern-cycle-20261013-v1');base=json.load(open(out/'compiler-before.json'));files=[r['path']for r in base['files']]+['tools/translation/arithmetic-copy-source.mjs','tools/translation/shared-reference-copy-source.mjs'];current={p:Path(p).read_bytes()for p in files};snapshots=[]
for p,raw in current.items():
 target=out/'compiler-exact-after'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);snapshots.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'snapshot':str(target)})
(out/'compiler-exact-after.json').write_text(json.dumps(snapshots,indent=2));runs=[]
def execute(script,label):
 cmd=['node',str(out/script),label];start=time.monotonic();log=out/(label+'.log')
 with log.open('w')as f:
  try:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=240).returncode
  except subprocess.TimeoutExpired:code=124
 receipt={'command':cmd,'timeoutSeconds':240,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'stdoutAndStderr':str(log),'peakRssBytes':None};runs.append(receipt);(out/'exact-original-before-after-runs.json').write_text(json.dumps(runs,indent=2));print(label,code,flush=True)
 if code:raise RuntimeError(label)
try:
 for r in base['files']:Path(r['path']).write_bytes(Path(r['snapshot']).read_bytes())
 for p in files[len(base['files']):]:Path(p).write_bytes(subprocess.check_output(['git','show','41199b9c60a8e070cf64e4da944d979c5e57c83a:'+p]))
 execute('original-owner-entry-probe-with-json.mjs','before-identical-entry')
 execute('original-owner-projected-probe-with-json.mjs','before-identical-root')
finally:
 for p,raw in current.items():Path(p).write_bytes(raw)
execute('original-owner-entry-probe-with-json.mjs','after-final-entry')
execute('original-owner-projected-probe-with-json.mjs','after-final-root')
