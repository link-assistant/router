from pathlib import Path
import binascii, hashlib, json, struct, zlib

source=Path('/tmp/router-759-successor-packet-plan-v5/manifest.json')
manifest=json.loads(source.read_text())
members=manifest['members']
compression=Path('/tmp/router-759-reverse-cycle-review-vectors-13-compression.json')
rows=json.loads(compression.read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
recipes=[]
for row in rows:
    raw=Path(row['original']).read_bytes()
    stored=Path(row['gzip']).read_bytes()
    assert len(raw)==row['originalBytes'] and sha(raw)==row['originalSha256']
    compressor=zlib.compressobj(6,zlib.DEFLATED,-15)
    body=compressor.compress(raw)+compressor.flush()
    rebuilt=bytes.fromhex('1f8b08000000000000ff')+body+struct.pack('<II',binascii.crc32(raw)&0xffffffff,len(raw)&0xffffffff)
    assert rebuilt==stored and len(stored)==row['gzipBytes'] and sha(stored)==row['gzipSha256']
    raw_members=[member['path'] for member in members if member['bytes']==len(raw) and member['sha256']==sha(raw)]
    assert raw_members
    recipes.append({**row,'completeRawArchiveMembers':raw_members,
        'recipe':{'codec':'zlib-raw-deflate','zlibVersion':zlib.ZLIB_VERSION,
                  'level':6,'windowBits':-15,'headerHex':'1f8b08000000000000ff',
                  'trailer':'little-endian CRC32 followed by original length modulo2^32'},
        'entireStoredContainerByteEqualityVerified':True})
excluded={(row['gzipBytes'],row['gzipSha256']) for row in rows}
kept=[member for member in members if (member['bytes'],member['sha256']) not in excluded]
removed=[member for member in members if (member['bytes'],member['sha256']) in excluded]
assert len(removed)==7
out=Path('/tmp/router-759-successor-packet-plan-v6')
out.mkdir(exist_ok=False)
record={'schema':'exact-derived-gzip-storage-v1','originalContainerMembers':removed,
        'recipes':recipes,'allCompleteRawVectorsRetained':True,
        'allOriginalCompressedContainersUntouched':True,
        'scope':'Exact byte reconstruction of optional storage derivatives; not semantic admission',
        'portability':'Requires the pinned zlib1.2.11 compressor and exact raw bytes; always verify the complete reconstructed SHA256 before use',
        'runtimeParity':False,'fullGatePass':False,'rustExecuted':False}
witness=out/'complete-derived-container-witnesses.json'
witness.write_text(json.dumps(record,indent=2)+'\n')
for name,path in [('provenance/complete-derived-container-witnesses.json',witness),
                  ('provenance/derived-gzip-storage-v1.py',Path(__file__)),
                  ('provenance/previous-complete-packet-capture-v5.json',Path('/tmp/router-759-successor-packet-capture-v5.json')),
                  ('provenance/previous-complete-packet-capture-v5.raw.log',Path('/tmp/router-759-successor-packet-capture-v5.raw.log'))]:
    data=path.read_bytes();kept.append({'path':name,'originalPath':str(path),'bytes':len(data),'sha256':sha(data)})
(out/'manifest.json').write_text(json.dumps({'members':kept},indent=2)+'\n')
print(json.dumps({'completeMembers':len(kept),'exactDerivedContainerWitnesses':len(recipes),
                  'optionalContainerBytesRepresentedByExactReconstruction':sum(member['bytes'] for member in removed),
                  'allRawObservationsAndOriginalTemporaryContainersRetained':True}))
