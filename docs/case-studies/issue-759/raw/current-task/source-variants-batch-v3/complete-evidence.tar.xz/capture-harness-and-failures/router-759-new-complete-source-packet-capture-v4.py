from pathlib import Path
import hashlib, json, os, signal, subprocess, time

root = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
out = Path('/tmp/router-759-new-complete-source-packet-v3')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip()
failed_command = ['python3', 'tools/evidence/capture-packet.py', '--source-root', '.', '--head',
                  '039f18707b53f4f7f3a3c2137d48f5bc7efc6c7d', '--manifest', str(out / 'complete-members.json'),
                  '--archive', str(out / 'complete-evidence.tar.xz'), '--receipt', str(out / 'capture-receipt.json'), '--cap-seconds', '600']
failure = Path('/tmp/router-759-new-complete-source-packet-failed-head-v3.json')
failure.write_text(json.dumps({'schema': 'failed-archive-invocation-v3', 'command': failed_command,
                              'exitCode': 1, 'actualHead': head, 'originalRaw': '/tmp/router-759-new-complete-source-packet-capture-v3.raw.log',
                              'reason': 'Incorrect hand-transcribed SHA; original output preserved; no archive was created.',
                              'fullGatePass': False}, indent=2) + '\n')
manifest = json.loads((out / 'complete-members.json').read_text())
for p in [Path(__file__), failure, Path('/tmp/router-759-new-complete-source-packet-capture-v3.raw.log'),
          Path('/tmp/router-759-new-complete-source-packet-prepare-v3.raw.log')]:
    raw = p.read_bytes()
    manifest['members'].append({'path': 'capture-harness-and-failures/' + p.name,
                                'originalPath': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
manifest_path = out / 'complete-members-v4.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
command = ['python3', 'tools/evidence/capture-packet.py', '--source-root', '.', '--head', head,
           '--manifest', str(manifest_path), '--archive', str(out / 'complete-evidence.tar.xz'),
           '--receipt', str(out / 'capture-receipt.json'), '--cap-seconds', '600']
start = time.monotonic()
with Path('/tmp/router-759-new-complete-source-packet-capture-v4.raw.log').open('xb') as stream:
    child = subprocess.Popen(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = child.wait(timeout=630)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGTERM)
        try:
            code = child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=5)
        raise
print(json.dumps({'command': command, 'exitCode': code, 'elapsedSeconds': time.monotonic() - start}))
raise SystemExit(code)
