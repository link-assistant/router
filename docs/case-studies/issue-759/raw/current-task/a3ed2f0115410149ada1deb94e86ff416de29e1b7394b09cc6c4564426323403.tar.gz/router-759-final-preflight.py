import datetime, hashlib, json, pathlib, re, subprocess, sys, time

root = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
expected = sys.argv[1]
assert re.fullmatch('[a-f0-9]{40}', expected)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
before = git('rev-parse', 'HEAD')
clean_before = git('status', '--porcelain') == ''
assert before == expected and clean_before, 'Candidate is not the reviewed clean SHA'
log = pathlib.Path('/tmp/router-759-final-preflight-' + expected[:8] + '.log')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with log.open('wb') as output:
    result = subprocess.run(['node', 'scripts/check-js-first-local.mjs'], cwd=root, stdout=output, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - clock
after = git('rev-parse', 'HEAD')
clean_after = git('status', '--porcelain') == ''
data = log.read_bytes()
text = data.decode('utf8')
failure_block = text.split('JavaScript preflight failed (no green stamp written):\n')[-1] if 'JavaScript preflight failed (no green stamp written):\n' in text else ''
failures = [line for line in failure_block.splitlines() if re.match('^[a-z-]+: ', line)]
stages = re.findall('^JavaScript stage: (.+)$', text, re.M)
expected_stages = ['lint', 'node-tests', 'bun-tests', 'typescript', 'parity', 'translation', 'reverse-translation']
strict_summaries = re.findall(r'Native parity inventory: (\d+) features; (\d+)/(\d+) operations; (\d+)/(\d+) OpenAPI routes; (\d+) draft gaps; (\d+) validation errors\.', text)
strict_summary = strict_summaries[-1] if strict_summaries else None
strict_validation_errors = int(strict_summary[-1]) if strict_summary else None
strict_draft_gaps = int(strict_summary[-2]) if strict_summary else None
only_expected = strict_validation_errors == 0 and strict_draft_gaps == 442 and failures == ['parity: node scripts/check-router-parity.mjs --strict'] and result.returncode == 1 and stages == expected_stages
receipt = {'schema': 'frozen-local-preflight-v1', 'headShaBefore': before, 'headShaAfter': after, 'cleanBefore': clean_before, 'cleanAfter': clean_after, 'startedAtUtc': started, 'elapsedSeconds': round(elapsed, 3), 'argv': ['node', 'scripts/check-js-first-local.mjs'], 'cwd': str(root), 'exitCode': result.returncode, 'stagesStarted': re.findall('^JavaScript stage: (.+)$', text, re.M), 'failures': failures, 'allExecutableStagesPass': only_expected, 'strictParityPass': False if strict_summary else None, 'strictValidationErrors': strict_validation_errors, 'strictDraftGaps': strict_draft_gaps, 'onlyExpectedStrictBlockers': only_expected, 'greenStampPath': '/tmp/router-js-first-gate.json', 'greenStampExists': pathlib.Path('/tmp/router-js-first-gate.json').exists(), 'stdoutPath': str(log), 'stdoutBytes': len(data), 'stdoutSha256': hashlib.sha256(data).hexdigest()}
path = pathlib.Path('/tmp/router-759-final-preflight-' + expected[:8] + '.json')
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
if before != after or not clean_after or not only_expected or receipt['greenStampExists']:
    sys.exit(2)
