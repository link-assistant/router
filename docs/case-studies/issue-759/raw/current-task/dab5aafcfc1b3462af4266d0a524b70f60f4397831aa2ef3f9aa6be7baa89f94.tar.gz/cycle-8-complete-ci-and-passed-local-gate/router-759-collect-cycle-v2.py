import argparse, datetime, gzip, hashlib, json, pathlib, re, resource, subprocess, sys, zipfile

REPO = 'link-assistant/router'
BRANCH = 'issue-759-js-meta-bulk'
parser = argparse.ArgumentParser()
parser.add_argument('--head-sha', required=True)
parser.add_argument('--destination', required=True)
parser.add_argument('--collect-completed', action='store_true')
args = parser.parse_args()
if not re.fullmatch(r'[a-f0-9]{40}', args.head_sha):
    parser.error('head-sha must be an exact lowercase Git SHA')
if not re.fullmatch(r'/tmp/router-759-ci-cycle-[0-9]+', args.destination):
    parser.error('destination must be a task-owned cycle directory under /tmp')
HEAD = args.head_sha
DEST = pathlib.Path(args.destination)
DEST.mkdir(exist_ok=True)

def api(route):
    return json.loads(subprocess.check_output(['gh', 'api', route]))

def write(name, data):
    target = DEST / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, indent=2) + '\n')

def pages(route, field):
    values = []
    page = 1
    while True:
        document = api(route + ('&' if '?' in route else '?') + f'per_page=100&page={page}')
        batch = document[field]
        values.extend(batch)
        if len(batch) < 100:
            return values
        page += 1

def bounded_file():
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 1024 * 1024, 32 * 1024 * 1024))

def annotation_pages(route):
    annotations = []
    page = 1
    while True:
        batch = api(route + f'?per_page=100&page={page}')
        annotations.extend(batch)
        if len(batch) < 100:
            return annotations
        page += 1

candidates = pages(f'repos/{REPO}/actions/runs?branch={BRANCH}&head_sha={HEAD}', 'workflow_runs')
# Actions records the PR branch head here; checkout verifies github.sha's merge
# commit separately. Never mix previous publication jobs or redownload its logs.
runs = [run for run in candidates if run['head_sha'] == HEAD]
write('runs.json', runs)
active = [r for r in runs if r['status'] != 'completed']
print(json.dumps({'runs': len(runs), 'active': len(active), 'headShas': sorted({r['head_sha'] for r in runs}), 'states': [{'id': r['id'], 'name': r['name'], 'status': r['status'], 'conclusion': r['conclusion']} for r in runs]}), flush=True)
if not args.collect_completed:
    sys.exit(0)
manifest_path = DEST / 'logs-manifest.json'
manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
for run in runs:
    identity = str(run['id'])
    jobs = pages(f'repos/{REPO}/actions/runs/{identity}/jobs?filter=all', 'jobs')
    write(f'runs/{identity}/jobs.json', jobs)
    for job in jobs:
        if job['conclusion'] in ('failure', 'cancelled', 'timed_out', 'action_required', 'startup_failure'):
            check = re.search(r'/check-runs/(\d+)$', job.get('check_run_url') or '')
            if check:
                annotations = annotation_pages(f'repos/{REPO}/check-runs/{check[1]}/annotations')
                write(f'runs/{identity}/job-{job["id"]}-annotations.json', annotations)
    if run['status'] != 'completed' or identity in manifest:
        continue
    temporary = DEST / f'run-{identity}-logs.zip'
    with temporary.open('wb') as output:
        fetch = subprocess.run(['gh', 'api', f'repos/{REPO}/actions/runs/{identity}/logs'], stdout=output, stderr=subprocess.PIPE, preexec_fn=bounded_file)
    if fetch.returncode:
        write(f'runs/{identity}/logs-error.json', {'exitCode': fetch.returncode, 'stderr': fetch.stderr.decode('utf8', 'replace')})
        temporary.unlink(missing_ok=True)
        continue
    records = []
    with zipfile.ZipFile(temporary) as archive:
        if sum(entry.file_size for entry in archive.infolist()) > 128 * 1024 * 1024:
            raise RuntimeError('Run log exceeds the bounded 128 MiB decode budget')
        for entry in archive.infolist():
            if entry.is_dir():
                continue
            if entry.file_size > 64 * 1024 * 1024:
                raise RuntimeError('Individual log exceeds the bounded 64 MiB decode budget')
            data = archive.read(entry)
            digest = hashlib.sha256(data).hexdigest()
            target = DEST / 'objects' / (digest + '.log.gz')
            if not target.exists():
                target.parent.mkdir(exist_ok=True)
                encoded = gzip.compress(data, compresslevel=9, mtime=0)
                stored = sum(path.stat().st_size for path in DEST.rglob('*') if path.is_file())
                if stored + len(encoded) > 40 * 1024 * 1024:
                    raise RuntimeError('Cycle evidence exceeds the bounded 40 MiB storage budget')
                target.write_bytes(encoded)
            records.append({'path': entry.filename, 'sha256': digest, 'decodedBytes': len(data), 'storedPath': str(target.relative_to(DEST)), 'storedBytes': target.stat().st_size})
    temporary.unlink()
    manifest[identity] = {'headSha': run['head_sha'], 'attempt': run['run_attempt'], 'conclusion': run['conclusion'], 'entries': records}
    write('logs-manifest.json', manifest)
write('collection-summary.json', {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'publishedHeadSha': HEAD, 'runs': len(runs), 'activeRuns': len(active), 'logsCaptured': len(manifest), 'storedBytes': sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file())})
print(json.dumps({'logsCaptured': len(manifest), 'runs': len(runs), 'active': len(active)}), flush=True)
