import argparse, collections, datetime, gzip, hashlib, json, pathlib, re
p=argparse.ArgumentParser();p.add_argument('destination');a=p.parse_args();root=pathlib.Path(a.destination)
runs=json.loads((root/'runs.json').read_text());manifest=json.loads((root/'logs-manifest.json').read_text()) if (root/'logs-manifest.json').exists() else {};reports=[];alljobs=[];unexpected=[];started=[]
for run in runs:
 jobs=json.loads((root/'runs'/str(run['id'])/'jobs.json').read_text());alljobs+=jobs
 entries=manifest.get(str(run['id']),{}).get('entries',[])
 texts={e['path']:gzip.decompress((root/e['storedPath']).read_bytes()).decode('utf8','replace') for e in entries}
 strict='\n'.join(v for k,v in texts.items() if '/parity/' in k.replace(' _ ','/').replace(' (same commit)','') and 'check-router-parity' in k)
 if not strict: strict='\n'.join(v for k,v in texts.items() if 'parity/' in k and 'check-router-parity' in k)
 inventory=list(dict.fromkeys(re.findall(r'Native parity inventory:[^\r\n]+',strict)))
 errors=list(dict.fromkeys(re.findall(r'Rust source inventory:[^\r\n]+',strict)))
 taps=list(dict.fromkeys(re.findall(r'not ok \d+[^\r\n]+','\n'.join(v for k,v in texts.items() if '/' not in k))))
 failed=[j for j in jobs if j.get('conclusion')=='failure'];failed_steps=[{'job':j['name'],'name':s['name'],'startedAt':s.get('started_at'),'completedAt':s.get('completed_at'),'conclusion':s.get('conclusion')} for j in failed for s in j.get('steps',[]) if s.get('conclusion')=='failure']
 annotations=[]
 for f in (root/'runs'/str(run['id'])).glob('job-*-annotations.json'):
  annotations += [{'message':x.get('message'),'path':x.get('path'),'level':x.get('annotation_level')} for x in json.loads(f.read_text())]
 extra=[j['name'] for j in failed if not j['name'].endswith('/ parity') and not j['name'].endswith('/ JavaScript fully green')]
 expected=(len(inventory)==1 and '442 draft gaps; 0 validation errors.' in inventory[0] and not errors and not taps and not extra)
 for j in jobs:
  if 'JavaScript first (same commit) / ' not in j['name'] and j.get('steps'):started.append({'run':run['id'],'job':j['name'],'conclusion':j.get('conclusion'),'steps':j['steps']})
 report={'run':run['id'],'name':run['name'],'status':run['status'],'jobs':dict(collections.Counter(j.get('conclusion') or j['status'] for j in jobs)),'inventory':inventory,'validationErrors':errors,'tapFailures':taps,'failedJobs':[{'id':j['id'],'name':j['name'],'url':j['html_url']} for j in failed],'failedSteps':failed_steps,'annotations':annotations,'logsCaptured':str(run['id']) in manifest,'onlyExpectedStrictFailure':expected if run['status']=='completed' and str(run['id']) in manifest else None}
 if run['status']=='completed' and str(run['id']) in manifest and not expected:unexpected.append(report)
 reports.append(report)
head={r['head_sha'] for r in runs};report={'headSha':next(iter(head)) if len(head)==1 else sorted(head),'allRunsTerminal':len(runs)==10 and all(r['status']=='completed' for r in runs),'allJobsTerminal':all(j['status']=='completed' for j in alljobs),'jobCounts':dict(collections.Counter(j.get('conclusion') or j['status'] for j in alljobs)),'unexpectedFailures':unexpected,'runs':reports,'rustStarted':len(started),'startedDownstreamJobs':started,'storedLogBytes':sum(f.stat().st_size for f in (root/'objects').glob('*')) if (root/'objects').exists() else 0,'logRunsCaptured':len(manifest)}
(root/'final-cycle-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['runs','unexpectedFailures','startedDownstreamJobs']}));print('Unexpected run IDs:',[r['run'] for r in unexpected])
if report['allRunsTerminal'] and len(manifest)==10:
 records=[e for m in manifest.values() for e in m['entries']];unique={e['storedPath']:e for e in records};errors=[]
 for path,e in unique.items():
  b=gzip.decompress((root/path).read_bytes())
  if hashlib.sha256(b).hexdigest()!=e['sha256'] or len(b)!=e['decodedBytes']:errors.append(path)
 receipt={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headSha':report['headSha'],'references':len(records),'uniqueCompressedFiles':len(unique),'decodedBytes':sum(e['decodedBytes'] for e in unique.values()),'integrityErrors':errors,'reportSha256':hashlib.sha256((root/'final-cycle-report.json').read_bytes()).hexdigest(),'skippedDownstreamJobs':sum(j.get('conclusion')=='skipped' and 'JavaScript first (same commit) / ' not in j['name'] for j in alljobs),'downstreamJobsWithSteps':len(started)}
 (root/'cycle-integrity-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
