import datetime,json,pathlib,subprocess
r=pathlib.Path('/tmp/router-759-ci-cycle-8');rows=[]
for run,job in [('38172127200','114573373748'),('38172127249','114574202531')]:
 def fetch(route):
  result=subprocess.run(['gh','api','repos/link-assistant/router/'+route],capture_output=True,text=True,timeout=30,check=True);return json.loads(result.stdout)
 jj=fetch('actions/jobs/'+job);rr=fetch('actions/runs/'+run)
 (r/('queued-aggregate-job-'+job+'.json')).write_text(json.dumps(jj,indent=2)+'\n')
 (r/('queued-aggregate-run-'+run+'.json')).write_text(json.dumps(rr,indent=2)+'\n')
 rows.append({'run':run,'job':job,'jobFields':{k:jj.get(k) for k in ['name','status','conclusion','created_at','started_at','completed_at','labels','runner_id','runner_name','runner_group_id','runner_group_name','run_attempt','head_sha']},'runFields':{k:rr.get(k) for k in ['name','status','conclusion','created_at','updated_at','run_started_at','run_attempt','head_sha']},'apiReasonFields':{k:v for k,v in jj.items() if any(x in k.lower() for x in ['reason','queue','message'])},'jobCreatedAtAvailable':'created_at' in jj})
workflow=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/.github/workflows/javascript-first.yml').read_text()
block=workflow[workflow.index('  complete:'):]
receipt={'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'readOnly':True,'jobs':rows,'workflowPath':'.github/workflows/javascript-first.yml','completeJobConfiguration':block,'noCancellationOrRerun':True}
p=r/'queued-aggregate-scheduling-audit.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'jobs':rows}))
