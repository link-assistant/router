import collections,datetime,gzip,hashlib,json,pathlib,re
r=pathlib.Path('/tmp/router-759-ci-cycle-8')
runs=json.loads((r/'runs.json').read_text()); m=json.loads((r/'logs-manifest.json').read_text())
assert len(runs)==10 and all(x['status']=='completed' for x in runs) and len(m)==10
out=[]; jobs=[]
for run in runs:
 jj=json.loads((r/'runs'/str(run['id'])/'jobs.json').read_text());jobs+=jj
 entries=m[str(run['id'])]['entries']; phases=[]; inventories=[]; diagnostics=[]; cancellations=[]; standaloneChecks=[]
 for e in entries:
  b=gzip.decompress((r/e['storedPath']).read_bytes());assert len(b)==e['decodedBytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
  if ' _ translation/' in e['path'] and 'scripts_translate-router' in e['path']:
   lines=b.decode('utf-8-sig').splitlines()
   start=lines[0].split(' ')[0];end=lines[-1].split(' ')[0]
   elapsed=(datetime.datetime.fromisoformat(end.replace('Z','+00:00'))-datetime.datetime.fromisoformat(start.replace('Z','+00:00'))).total_seconds()
   standaloneChecks.append({'logPath':e['path'],'logSha256':e['sha256'],'startedAt':start,'completedAt':end,'logTimestampSpanSeconds':elapsed,'successfulSummaryObserved':'"mode":"check"' in lines[-1]})
  if 'parity/' not in e['path']:continue
  s=b.decode('utf8','replace')
  inventories+=re.findall(r'Native parity inventory:[^\r\n]+',s)
  diagnostics+=re.findall(r'[^\r\n]*(?:timeoutBudgetMs=|Rust source inventory:)[^\r\n]*',s)
  cancellations+=re.findall(r'[^\r\n]*(?:Operation was canceled|exceeded the maximum execution time)[^\r\n]*',s)
 for j in jj:
  if not j['name'].endswith('/ parity'):continue
  for st in j.get('steps',[]):
   if st.get('started_at') and st.get('completed_at'):
    start=datetime.datetime.fromisoformat(st['started_at'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(st['completed_at'].replace('Z','+00:00'))
    phases.append({'name':st['name'],'conclusion':st['conclusion'],'elapsedSeconds':(end-start).total_seconds(),'startedAt':st['started_at'],'completedAt':st['completed_at']})
 annotations=[]
 for ap in (r/'runs'/str(run['id'])).glob('job-*-annotations.json'):
  for a in json.loads(ap.read_text()):annotations.append({'level':a.get('annotation_level'),'message':a.get('message'),'path':a.get('path')})
 out.append({'run':run['id'],'name':run['name'],'conclusion':run['conclusion'],'inventories':list(dict.fromkeys(inventories)),'diagnostics':list(dict.fromkeys(diagnostics)),'cancellations':list(dict.fromkeys(cancellations)),'paritySteps':phases,'standaloneDeterministicChecks':standaloneChecks,'annotations':annotations,'nonSuccessJobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j.get('conclusion'),'startedAt':j.get('started_at'),'completedAt':j.get('completed_at')} for j in jj if j.get('conclusion') not in ('success','skipped')]})
receipt={'version':1,'headSha':'fdee2507643f6c10bf091d24e63d4e2c6f062b74','allTenTerminal':True,'jobCounts':dict(collections.Counter(j.get('conclusion') or j['status'] for j in jobs)),'cpuLoadTelemetryRecorded':False,'runs':out}
p=pathlib.Path('/tmp/router-759-cycle-8-complete-failure-inventory.json');p.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'jobCounts':receipt['jobCounts'],'runs':[{'id':x['run'],'inventory':x['inventories'],'diagnostics':x['diagnostics'],'cancellations':x['cancellations']} for x in out]}))
