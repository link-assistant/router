import collections,datetime,json,pathlib,subprocess,time
root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
dest=pathlib.Path('/tmp/router-759-ci-cycle-8')
while True:
 result=subprocess.run(['python3','/tmp/router-759-collect-cycle-v2.py','--head-sha','fdee2507643f6c10bf091d24e63d4e2c6f062b74','--destination',str(dest),'--collect-completed'],cwd=root,capture_output=True,text=True)
 if result.returncode:
  print(json.dumps({'collectorExit':result.returncode,'diagnostic':result.stderr[-1000:]}),flush=True);break
 runs=json.loads((dest/'runs.json').read_text());runs=runs.get('workflow_runs',[]) if isinstance(runs,dict) else runs
 jobs=[]
 for p in (dest/'runs').glob('*/jobs.json'):
  v=json.loads(p.read_text());jobs.extend(v.get('jobs',[]) if isinstance(v,dict) else v)
 counts=collections.Counter((j['status'],j.get('conclusion')) for j in jobs)
 state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminalRuns':sum(r['status']=='completed' for r in runs),'totalRuns':len(runs),'jobStates':{str(k):v for k,v in counts.items()},'activeJobs':[j['name'] for j in jobs if j['status']=='in_progress']}
 print(json.dumps(state),flush=True)
 if len(runs)==10 and state['terminalRuns']==10:
  subprocess.run(['python3','/tmp/router-759-report-cycle.py',str(dest)],cwd=root,check=True,stdout=(dest/'terminal-report.stdout').open('w'));break
 time.sleep(60)
