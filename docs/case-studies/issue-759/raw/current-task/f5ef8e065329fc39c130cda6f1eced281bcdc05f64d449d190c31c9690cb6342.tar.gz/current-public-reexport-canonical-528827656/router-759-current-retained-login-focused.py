from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head=sys.argv[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
base=Path('/tmp/router-759-retained-login-'+head[:9]);assert not Path(str(base)+'.json').exists()
fixture='tools/translation/test/option-unwrapping-types.test.mjs';commands=[['node','--test','--test-concurrency=1',fixture],['bun','test',fixture]];rows=[]
env=dict(os.environ);env.pop('NODE_TEST_CONTEXT',None)
for argv in commands:
 log=Path(str(base)+'-'+argv[0]+'.log');assert not log.exists();started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
 with log.open('wb')as out:
  try:result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180);status=result.returncode
  except subprocess.TimeoutExpired:status='timeout'
 rows.append({'argv':argv,'startedAtUtc':started,'elapsedSeconds':round(time.monotonic()-clock,3),'exitCode':status,'logPath':str(log),'logBytes':log.stat().st_size,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(json.dumps(rows[-1]),flush=True)
report={'headSha':head,'cleanBefore':True,'headAfter':git('rev-parse','HEAD'),'statusAfter':git('status','--porcelain'),'runs':rows,'RustInvoked':False}
Path(str(base)+'.json').write_text(json.dumps(report,indent=2)+'\n');assert report['headAfter']==head and report['statusAfter']==''
sys.exit(0 if all(r['exitCode']==0 for r in rows)else 2)
