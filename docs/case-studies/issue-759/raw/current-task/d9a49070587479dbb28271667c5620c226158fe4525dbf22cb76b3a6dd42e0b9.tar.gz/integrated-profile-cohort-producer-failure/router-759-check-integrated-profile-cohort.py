import datetime,hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head='4f862f4ce2e03f60d74f447a75fd9ea36493bdd3'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==head and git('status','--porcelain')==''
files=['string-iterators','bool-then-some','slice-membership','slice-membership-originals','host-translation','matrix-bulk','inline-module-project','source-links','reuse-translation']
paths=['tools/translation/test/'+name+'.test.mjs' for name in files]
assert all((root/path).is_file() for path in paths)
results=[]
for engine in ['node','bun']:
 argv=[engine,'--test','--test-concurrency=1',*paths] if engine=='node' else [engine,'test',*paths]
 log=pathlib.Path('/tmp/router-759-profile-cohort-integrated-'+engine+'.log');assert not log.exists();start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();timeout=False
 with log.open('wb') as stream:
  try:result=subprocess.run(argv,cwd=root,stdout=stream,stderr=subprocess.STDOUT,timeout=180);code=result.returncode
  except subprocess.TimeoutExpired:timeout=True;code=None
 receipt={'engine':engine,'argv':argv,'head':head,'startedAtUtc':started,'elapsedSeconds':round(time.monotonic()-start,3),'exitCode':code,'timeout':timeout,'log':str(log),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'headUnchanged':git('rev-parse','HEAD')==head,'trackedClean':git('status','--porcelain')==''}
 results.append(receipt);pathlib.Path(str(log)+'.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
pathlib.Path('/tmp/router-759-profile-cohort-integrated.json').write_text(json.dumps({'sourceHead':head,'files':paths,'results':results,'generationRun':False},indent=2)+'\n')
raise SystemExit(0 if all(x['exitCode']==0 and x['trackedClean'] and x['headUnchanged'] for x in results) else 1)
