from pathlib import Path
import json,subprocess,collections
oldhead='a81bce206e381241c44e30e960e027574a96bcd3';old=json.loads(subprocess.check_output(['git','show',oldhead+':parity/rust-source-inventory.json']));new=json.loads(Path('parity/rust-source-inventory.json').read_text());changes=[];prodReasons=collections.Counter();samples={}
for s,o in zip(new['sources'],old['sources'],strict=True):
 assert s['source']==o['source']
 p=s['targets']['meta'];n=json.loads(Path(p).read_text())
 if s['source'].startswith('src/') and 'tests' not in s['source'] and 'test_support' not in s['source']:
  for i in n['items']:
   if i['term']=='fn' and i['status']=='carried':
    diagnostic=i.get('diagnostic');key=json.dumps({k:diagnostic.get(k) for k in ['kind','message']},sort_keys=True) if isinstance(diagnostic,dict) else str(diagnostic);prodReasons[key]+=1;samples.setdefault(key,{'source':s['source'],'name':i['name'],'span':i['span']})
 if any(s.get(k)!=o.get(k) for k in ['executableFunctions','executableConstants','executableTypes','carried']):
  previous=json.loads(subprocess.check_output(['git','show',oldhead+':'+p]));before={(i['term'],i['name']):i for i in previous['items'] if i['status']=='executable'};after={(i['term'],i['name']):i for i in n['items'] if i['status']=='executable'}
  entries={ (i['term'],i['name']):i for i in n['items'] }
  for term,name in after.keys()-before.keys():changes.append({'source':s['source'],'term':term,'name':name,'change':'added'})
  for term,name in before.keys()-after.keys():changes.append({'source':s['source'],'term':term,'name':name,'change':'removed','diagnostic':entries.get((term,name),{}).get('diagnostic')})
oldproject=json.loads(subprocess.check_output(['git','show',oldhead+':tools/translation/projects/src/lib.meta.json']));project=json.loads(Path('tools/translation/projects/src/lib.meta.json').read_text());before={(i['term'],i['name']):i for i in oldproject['executable']};after={(i['term'],i['name']):i for i in project['executable']};projectChanges=[]
for term,name in after.keys()-before.keys():projectChanges.append({'term':term,'name':name,'change':'added'})
for term,name in before.keys()-after.keys():projectChanges.append({'term':term,'name':name,'change':'removed','diagnostics':[r for r in project['refused'] if r.get('name')==name or '.'.join([*r.get('module',[]),r.get('name','')])==name]})
report={'publishedBaseline':oldhead,'sourceHead':'7845538045fce79d7fd7c450878778c69c6bb0d4','totals':new['totals'],'productionFunctions':new['functionCoverage']['production'],'perFileExecutableChanges':sorted(changes,key=lambda c:(c['source'],c['term'],c['name'])),'projectExecutableChanges':sorted(projectChanges,key=lambda c:(c['term'],c['name'])),'projectCheckedMethodsBefore':len(oldproject['checkedMethods']),'projectCheckedMethodsAfter':len(project['checkedMethods']),'productionTopRefusalMessages':[{'count':count,'diagnostic':reason,'sample':samples[reason]} for reason,count in prodReasons.most_common(20)],'projectTopRefusalMessages':collections.Counter((r['kind'],r['message']) for r in project['refused']).most_common(20)}
Path('/tmp/router-759-cycle-6-corpus-census.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2)[:15000])
