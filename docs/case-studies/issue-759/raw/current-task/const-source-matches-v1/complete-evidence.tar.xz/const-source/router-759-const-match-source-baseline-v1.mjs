import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {translateProject} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/project.mjs';
const sources=[
  'pub const fn one(v:u8)->bool{matches!(v,1 | 2)}pub const YES:bool=one(2u8);',
  'pub const fn yes(v:bool)->bool{matches!(v,true)}pub const YES:bool=yes(true);',
  '#[derive(Clone,Copy)]pub enum Mode{On,Off}impl Mode{pub const fn active(self)->bool{matches!(self,Self::On)}}pub const YES:bool=Mode::active(Mode::On);',
  'pub const fn still_refused(v:Option<u8>)->bool{matches!(v,Some(_))}',
  'pub const fn still_refused(v:u8)->bool{matches!(v,n if n>1)}',
];
for(const source of sources){const started=performance.now();try{const result=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source});console.log(JSON.stringify({source,sourceSha256:createHash('sha256').update(source).digest('hex'),elapsedMilliseconds:performance.now()-started,executable:result.meta.executable,checkedMethods:result.meta.checkedMethods,refused:result.meta.refused,program:result.meta.checkedSemanticProgram,javascript:result.javascript,typescript:result.typescript}));}catch(error){console.log(JSON.stringify({source,error:String(error),stack:error.stack}));process.exitCode=1;}}
