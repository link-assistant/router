// Generated draft from input.rs; sha256=bfbeb8e735346bb1336008e94815b135b22f98240c48121848d5e3bbcacec6fb
// Carried constructs are data, never runtime parity evidence.
function ml_fixed(value, min, max, message) {
  if (value < min || value > max) throw new RangeError(message);
  return value;
}

function sum(n) {
  if (typeof n !== 'bigint') throw new TypeError('argument outside supported Rust fixed-integer domain');
  ml_fixed(n, 0n, 18446744073709551615n, "u64 argument n out of range");
  if (!(typeof n === 'bigint' && n >= 0n && n <= 18446744073709551615n)) throw new TypeError('argument outside supported Rust value domain');
  let i = 0n;
  let total = 0n;
  while ((i < n)) {
    total = ml_fixed((total + i), 0n, 18446744073709551615n, "attempt to add with overflow");
    i = ml_fixed((i + 1n), 0n, 18446744073709551615n, "attempt to add with overflow");
  }
  return total;
}

const std = {
  io: {

  },
  ffi: {

  },
  env: {

  },
  time: {

  },
  num: {

  },
};

const serde_json = {
  error: {

  },
};

export const translated = { ["sum"]: sum };
export const provenance = {"sourcePath":"input.rs","sourceSha256":"bfbeb8e735346bb1336008e94815b135b22f98240c48121848d5e3bbcacec6fb","executable":1,"executableFunctions":1,"executableConstants":0,"executableTypes":0,"executableConstructors":0,"carried":0,"preserved":0,"runtimeParity":false};
