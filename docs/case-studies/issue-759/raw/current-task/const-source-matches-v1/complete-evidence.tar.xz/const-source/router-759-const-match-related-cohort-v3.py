import subprocess,json
from pathlib import Path
root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match'
files=['tools/translation/test/'+name+'.test.mjs' for name in ['const-source-matches','ordered-matches','matches-source-bridge','project-const-refusals','constant-evaluation','integer-range-patterns','copy-methods','shared-nullary-enum','source-links','original-parser-identity','source-method-parser','source-conversion-finalization','forward-typescript','const-qualification','source-method-project','pattern-control','borrowed-iterators','result-iterators']]
assert all((Path(root)/f).is_file() for f in files)
for engine,command in [('node',['node','--test','--test-concurrency=2']),('bun',['/Users/konard/.bun/bin/bun','test'])]:
 prefix='/tmp/router-759-const-match-related-'+engine+'-v3'
 code=subprocess.run(['python3','/tmp/router-759-const-match-source-diagnostic-v3.py','--root',root,'--prefix',prefix,'--cap','240','--',*command,*files]).returncode
 if code:raise SystemExit(code)
