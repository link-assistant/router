from pathlib import Path
import subprocess,json,hashlib,os,argparse,time,signal,resource
p=argparse.ArgumentParser();p.add_argument('--prefix',required=True);p.add_argument('--cap',type=int,default=600);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();assert 1<=a.cap<=1800 and a.prefix.startswith('/tmp/router-759-');command=a.command[1:] if a.command[:1]==['--'] else a.command;root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match');prefix=Path(a.prefix);assert all(not Path(a.prefix+x).exists() for x in ['.json','.raw.log','-inputs.json']);git=lambda *s:subprocess.check_output(['git',*s],cwd=root);head=git('rev-parse','HEAD').decode().strip();sha=lambda b:hashlib.sha256(b).hexdigest()
def snapshot():
 names=sorted(set(git('ls-files','-c','-o','--exclude-standard','-z').decode().split('\0'))-{''});rows=[]
 for n in names:
  f=root/n
  if not f.is_file():continue
  assert not f.is_symlink();b=f.read_bytes();rows.append({'path':n,'bytes':len(b),'sha256':sha(b)})
 return rows
before=snapshot();inputs=Path(a.prefix+'-inputs.json');inputs.write_text(json.dumps({'sourceHead':head,'inputs':before},separators=(',',':'))+'\n');start=time.monotonic();env=dict(os.environ);env['ROUTER_TRANSLATION_TSC']=str(root/'packages/javascript/node_modules/.bin/tsc');timed=False
with Path(a.prefix+'.raw.log').open('xb') as stream:
 child=subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=a.cap)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
elapsed=time.monotonic()-start;after=snapshot();raw=Path(a.prefix+'.raw.log').read_bytes();usage=resource.getrusage(resource.RUSAGE_CHILDREN);d={'schema':'router-759-complete-coordinated-repair-diagnostic-v1','sourceHead':head,'command':command,'capSeconds':a.cap,'exitCode':code,'timedOut':timed,'elapsedSeconds':elapsed,'inputCount':len(before),'inputBytes':sum(r['bytes'] for r in before),'inputReceipt':str(inputs),'inputReceiptSha256':sha(inputs.read_bytes()),'inputsUnchanged':before==after,'headUnchanged':git('rev-parse','HEAD').decode().strip()==head,'rawPath':a.prefix+'.raw.log','rawBytes':len(raw),'rawSha256':sha(raw),'harnessSha256':sha(Path(__file__).read_bytes()),'maxRecordedChildRssBytes':usage.ru_maxrss,'measurementScope':'maximum waited child RSS on Darwin, not aggregate memory or peak footprint','rustExecutions':0,'fullGatePass':False};Path(a.prefix+'.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));raise SystemExit(code if not timed and before==after else 2)
