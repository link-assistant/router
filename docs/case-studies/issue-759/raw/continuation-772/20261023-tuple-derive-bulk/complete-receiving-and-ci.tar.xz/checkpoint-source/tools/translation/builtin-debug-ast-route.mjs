// Positive original compiler AST output grammar; no formatting/runtime grant.
import {createHash} from 'node:crypto';
import {createCompletedDataFreezer} from './private-data-freeze.mjs';
import {createScopedPrivateNativeProofJsonSerializer as createPrivateFrozenJsonComposer} from "./operation-proof-byte-bridge.mjs";
import {builtinCloneDataInputs,builtinDebugDataInputs} from './builtin-derive-data-inputs.mjs';
import {inventoryDeriveQuoteMeta,createQuoteFragmentCompiler} from './derive-quote-meta.mjs';
import {originalAstFunction,originalAstDefinition,astStructLiteral,astSyntaxText,astFragmentText,astEnumVariant,originalAstPositiveConstructors} from './builtin-derive-ast-meta.mjs';
import {originalBuiltinEnumPatternSource,requireOriginalBuiltinEnumPatternSource} from './builtin-derive-enum-patterns.mjs';
import {createBuiltinAstBuilderMetaCompiler} from './builtin-ast-builder-meta.mjs';
const directory='compiler/rustc_builtin_macros/src/deriving/',generic=directory+'generic/mod.rs',build='compiler/rustc_expand/src/build.rs',schema='compiler/rustc_ast/src/ast.rs';
const hash=value=>createHash('sha256').update(value).digest('hex'),plans=new WeakMap(),inventories=new WeakMap();
const freeze=(value,seen=new WeakSet())=>{if(value&&typeof value==='object'&&!seen.has(value)){seen.add(value);Object.values(value).forEach(child=>freeze(child,seen));Object.freeze(value);}return value;};
const freezeCompleted=createCompletedDataFreezer(freeze);
const composeJson=createPrivateFrozenJsonComposer();
function field(recipe,name,expected){const actual=recipe.fields.find(row=>row.name===name);if(!actual||astSyntaxText(actual.expression)!==expected)throw new TypeError('Original Debug AST slot changed: '+recipe.name+'.'+name);return actual;}
function contains(fragment,...needles){const source=astFragmentText(fragment);for(const needle of needles)if(!source.includes(needle))throw new TypeError('Original Debug AST flow changed: '+needle);}
function sourcePlan(profile,entry){
 if(plans.has(profile)){const plan=plans.get(profile);if(plan.entry!==entry)throw new TypeError('Original Debug entry differs from its private profile');return plan;}
 const recipes=new Map(),compiler=createBuiltinAstBuilderMetaCompiler(profile),contracts=[];
 const recipe=(path,name,selector=null)=>{const value=originalAstFunction(profile,path,name,selector);recipes.set(path+'::'+name+(selector?'::'+selector:''),value);return value;};
 const descriptor=astStructLiteral(profile,entry,'TraitDef'),method=astStructLiteral(profile,entry,'MethodDef');
 field(descriptor,'path','path_std ! (fmt :: Debug)');field(descriptor,'additional_bounds','Vec :: new ()');field(descriptor,'associated_types','Vec :: new ()');field(descriptor,'supports_unions','false');field(descriptor,'needs_copy_as_bound_if_packed','true');
 const methods=descriptor.fields.find(f=>f.name==='methods').expression;if(methods.length!==3||methods[0].text!=='vec'||methods[1].text!=='!'||methods[2].delimiter!=='['||methods[2].children[0].text!=='MethodDef'||methods[2].children[1].span.start!==method.span.start||![2,3].includes(methods[2].children.length)||methods[2].children.length===3&&methods[2].children[2].text!==',')throw new TypeError('Original Debug requires exactly one source MethodDef');
 field(method,'name','sym :: fmt');field(method,'generics','Bounds :: empty ()');field(method,'explicit_self','true');field(method,'nonself_args','vec ! [(fmtr , sym :: f)]');field(method,'ret_ty','Path (path_std ! (fmt :: Result))');field(method,'attributes','thin_vec ! [cx . attr_word (sym :: inline , span)]');field(method,'fieldless_variants_strategy','FieldlessVariantsStrategy :: SpecializeIfAllVariantsFieldless');
 contains(entry,'let fmtr = Ref(Box::new(Path(path_std!(fmt::Formatter))), ast::Mutability::Mut)','show_substructure(a, b, c)','trait_def.expand(cx, mitem, item, push)');
 const show=recipe(directory+'debug.rs','show_substructure'),fieldless=recipe(directory+'debug.rs','show_fieldless_enum'),last=recipe(directory+'debug.rs','expr_for_field');
 contains(show,'cx.with_def_site_ctxt(span)','fmt_detail == FmtDebug::None','cx.expr_ok(span, cx.expr_tuple(span, ThinVec::new()))','AllFieldlessEnum(enum_def) => return show_fieldless_enum','fmt_detail == FmtDebug::Shallow','const CUTOFF: usize = 5','fields.is_empty()','fields.len() <= CUTOFF','format!("debug_struct_field{}_finish", fields.len())','for i in 0..fields.len()','expr_for_field(cx, field, i, fields.len())','BlockOrExpr::new_expr(expr)','let names_let = is_struct.then(||','Some(ty_static_ref)','cx.expr_array_ref(span, name_exprs)','ast::TyKind::TraitObject(','ast::TyKind::Slice(','cx.expr_array_ref(span, value_exprs)','stmts.push(names_let.unwrap())','stmts.push(values_let)','BlockOrExpr::new_mixed(stmts, Some(expr))');
 contains(last,'if index < len - 1','field.self_expr.clone()','cx.expr_addr_of(field.span, field.self_expr.clone())');
 contains(fieldless,'.variants','.iter()','ast::VariantData::Unit(_) => cx.pat_path(span, variant_path)','cx.arm(span, pat, cx.expr_str(span, v.ident.name))','let name = cx.expr_match(span, cx.expr_self(span), arms)','BlockOrExpr::new_expr(cx.expr_call_global(span, fn_path_write_str, thin_vec![fmt, name]))');
 const control=['expand','expand_ext','expand_struct_def','expand_struct_method_body','create_struct_field_access_fields','create_fields','expand_enum_def','expand_enum_method_body','extract_arg_details','call_substructure_method','create_method','create_derived_impl','get_ret_ty','new_expr','new_mixed','into_block','find_type_parameters'];for(const name of control)recipe(generic,name);
 const get=name=>recipes.get(generic+'::'+name);
 contains(get('expand'),'self.expand_ext(cx, mitem, item, push, false)');contains(get('expand_ext'),'AttributeParser::parse_limited','sym::repr','push(Annotatable::Item(P(ast::Item { attrs, ..(*newitem).clone() })))');
 contains(get('expand_struct_def'),'from_scratch || method_def.is_static()','method_def.expand_struct_method_body(','method_def.create_method(');contains(get('expand_struct_method_body'),'create_struct_field_access_fields','&Struct(struct_def, selflike_fields)');
 contains(get('create_struct_field_access_fields'),'ast::ExprKind::Field(','selflike_arg.clone()','struct_field.ident.unwrap_or_else','if is_packed','cx.expr_addr_of(sp, field_expr)');contains(get('create_fields'),'struct_field.span.with_ctxt(self.span.ctxt())','let self_expr = exprs.remove(0)','name: struct_field.ident','span: sp.with_ctxt(self.span.ctxt())');
 contains(get('expand_enum_method_body'),'if variants.is_empty()','let all_fieldless = variants.iter().all(|v| v.data.fields().is_empty())','FieldlessVariantsStrategy::SpecializeIfAllVariantsFieldless','&AllFieldlessEnum(enum_def)','else if let [variant] = variants.as_slice()','&EnumMatching(variant, Vec::new())');
 contains(get('extract_arg_details'),'selflike_args.push(self_expr)','let arg_expr = cx.expr_ident(span, ident)','_ => nonselflike_args.push(arg_expr)');contains(get('call_substructure_method'),'f(cx, span, &substructure)');
 const createMethod=get('create_method'),fn=astStructLiteral(profile,createMethod,'Fn'),assoc=astStructLiteral(profile,createMethod,'AssocItem');field(fn,'body','Some (body_block)');field(fn,'contract','None');field(fn,'define_opaque','None');field(assoc,'attrs','self . attributes . clone ()');field(assoc,'tokens','None');contains(createMethod,'ast::AssocItemKind::Fn(Box::new(ast::Fn {','let body_block = body.into_block(cx, span)','Ident::new(self.name, span)');
 const implementation=astStructLiteral(profile,get('create_derived_impl'),'Impl');field(implementation,'items','methods . into_iter () . chain (associated_types) . collect ()');contains(get('create_derived_impl'),'ast::ItemKind::Impl(Box::new(ast::Impl {','constness: if self.is_const { ast::Const::Yes(DUMMY_SP) } else { ast::Const::No }');contains(get('find_type_parameters'),'self.ty_param_names.contains(&segment.ident.name)');
 contains(get('new_expr'),'BlockOrExpr(ThinVec::new(), Some(expr))');contains(get('new_mixed'),'BlockOrExpr(stmts, expr)');contains(get('into_block'),'if let Some(expr) = self.1','self.0.push(cx.stmt_expr(expr))','cx.block(span, self.0)');
 for(const name of ['expr','expr_path','expr_ident','expr_self','expr_call','expr_call_global','expr_addr_of','expr_str','expr_array','expr_array_ref','expr_tuple','expr_ok','expr_match','pat','pat_path','pat_ident','pat_ident_binding_mode','arm','stmt_expr','stmt_let_ty','stmt_local','block','ty','ty_infer','ty_ref','ty_mt','trait_bound','poly_trait_ref','lifetime','lifetime_static','path','path_all','path_global','item','fn_decl','param']){const value=recipe(build,name);try{contracts.push(compiler.compile(name));}catch(error){contracts.push({recipeDigest:value.digest,sourceMetaRefusal:error.message,generatedImplBehavior:false});}}
 const b=name=>recipes.get(build+'::'+name),expression=astStructLiteral(profile,b('expr'),'Expr');field(expression,'kind','kind');field(expression,'attrs','AttrVec :: new ()');field(expression,'tokens','None');
 const local=astStructLiteral(profile,b('stmt_let_ty'),'Local');field(local,'kind','LocalKind :: Init (ex)');field(local,'ty','ty');field(local,'pat','pat');field(local,'attrs','AttrVec :: new ()');field(local,'tokens','None');contains(b('stmt_let_ty'),'self.pat_ident(sp, ident)','self.stmt_local(local, sp)');
 field(astStructLiteral(profile,b('stmt_local'),'Stmt'),'kind','ast :: StmtKind :: Let (local)');field(astStructLiteral(profile,b('stmt_expr'),'Stmt'),'kind','ast :: StmtKind :: Expr (expr)');field(astStructLiteral(profile,b('block'),'Block'),'stmts','stmts');field(astStructLiteral(profile,b('block'),'Block'),'tokens','None');
 const arm=astStructLiteral(profile,b('arm'),'Arm');field(arm,'attrs','AttrVec :: new ()');field(arm,'guard','None');field(arm,'body','Some (expr)');field(arm,'is_placeholder','false');field(astStructLiteral(profile,b('pat'),'Pat'),'tokens','None');contains(b('pat_path'),'PatKind::Path(None, path)');contains(b('pat_ident_binding_mode'),'PatKind::Ident(ann, ident.with_span_pos(span), None)');contains(b('pat_ident'),'ast::BindingMode::NONE');
 contains(b('trait_bound'),'ast::GenericBound::Trait(self.poly_trait_ref(path.span, path, is_const))');contains(show,'cx.trait_bound(path_debug, false)','ast::TraitObjectSyntax::Dyn','cx.lifetime_static(span)','cx.ty_infer(span)');contains(b('poly_trait_ref'),'ast::BoundConstness::Never','trait_ref: self.trait_ref(path)');
 field(astStructLiteral(profile,b('ty'),'Ty'),'kind','kind');field(astStructLiteral(profile,b('ty'),'Ty'),'tokens','None');field(astStructLiteral(profile,b('item'),'Item'),'kind','kind');field(astStructLiteral(profile,b('item'),'Item'),'tokens','None');
 const parser='compiler/rustc_parse/src/parser/item.rs',outer=recipe(parser,'parse_field_def'),named=recipe(parser,'parse_name_and_ty'),single=recipe(parser,'parse_single_struct_field');contains(outer,'let attrs = self.parse_outer_attributes()?','let lo = this.token.span','this.parse_visibility','UsePreAttrPos::No');field(astStructLiteral(profile,named,'FieldDef'),'span','lo . to (self . prev_token . span)');field(astStructLiteral(profile,named,'FieldDef'),'attrs','attrs');contains(single,'let a_var = self.parse_name_and_ty','token::Comma');
 const stdPath=recipe('compiler/rustc_expand/src/base.rs','std_path');contains(stdPath,'self.with_def_site_ctxt(DUMMY_SP)','Ident::new(kw::DollarCrate, def_site)');
 for(const name of ['empty','to_generics','get_explicit_self'])recipe(directory+'generic/ty.rs',name);contains(recipes.get(directory+'generic/ty.rs::get_explicit_self'),'SelfKind::Region(None, ast::Mutability::Not)');recipe(directory+'generic/ty.rs','to_ty','Unit =>');recipe(directory+'generic/ty.rs','to_path','let mut idents = self.path.iter()');
 const definitions=new Map(['ExprKind','PatKind','StmtKind','LocalKind','TyKind','ItemKind','AssocItemKind','GenericBound'].map(name=>[name,originalAstDefinition(profile,schema,'enum',name)]));
 const variant=(owner,name,arity)=>{const value=astEnumVariant(profile,definitions.get(owner),name);if(value.arity!==arity)throw new TypeError('Original Debug AST constructor arity changed: '+owner+'::'+name);return value;};
 const positiveSchemas=[variant('ExprKind','Path',2),variant('ExprKind','Field',2),variant('ExprKind','AddrOf',3),variant('ExprKind','Call',2),variant('ExprKind','Lit',1),variant('ExprKind','Array',1),variant('ExprKind','Tup',1),variant('ExprKind','Match',3),variant('PatKind','Path',2),variant('PatKind','Ident',3),variant('StmtKind','Let',1),variant('StmtKind','Expr',1),variant('LocalKind','Init',1),variant('TyKind','Infer',0),variant('TyKind','Ref',2),variant('TyKind','Slice',1),variant('TyKind','TraitObject',2),variant('ItemKind','Impl',1),variant('AssocItemKind','Fn',1),variant('GenericBound','Trait',1)];
 const constructors=new Map();for(const[name,wanted]of [['expr_path','Path'],['expr_call','Call'],['expr_addr_of','AddrOf'],['expr_str','Lit'],['expr_array','Array'],['expr_tuple','Tup'],['expr_match','Match']]){const row=originalAstPositiveConstructors(profile,b(name),'ExprKind');if(row.length!==1||row[0].variant.name!==wanted)throw new TypeError('Original Debug builder output differs: '+name);constructors.set(name,row[0]);}const projection=originalAstPositiveConstructors(profile,get('create_struct_field_access_fields'),'ExprKind');if(projection.length!==1||projection[0].variant.name!=='Field')throw new TypeError('Original Debug field projection changed');constructors.set('source_field',projection[0]);
 const result={entry,descriptor,method,recipes:[entry,...recipes.values()],compilerMeta:contracts,schemas:[...definitions.values()],positiveSchemas,constructors,sourceControls:{fmtDebug:['None','Shallow','Full'],fieldCountCutoff:5,constness:['Const::Yes','Const::No'],receiverArguments:1,nonselfArguments:1,associatedTypes:0,fromScratch:false,enumStrategy:'SpecializeIfAllVariantsFieldless',packedInputAdmitted:false},parserFieldSpans:{recipes:[outer,named,single],mapping:'outer attrs parsed before lo; lo before visibility; FieldDef ends at type before comma; original trait ctxt applied by create_fields'},namespaceAuthority:false,generatedImplBehavior:false};plans.set(profile,result);return result;
}
function typeLeaves(original,certificate,input){
 let inventory=inventories.get(original.dependencies);if(!inventory){inventory=inventoryDeriveQuoteMeta(original.dependencies);inventories.set(original.dependencies,inventory);}const compiler=createQuoteFragmentCompiler(inventory);
 return input.fields.map(field=>{const source=original.module.source.slice(field.typeSpan.start,field.typeSpan.end),typed=compiler.roundTrip(compiler.sourceType(source,{source:certificate.source,sourceSha256:certificate.sourceSha256,span:field.typeSpan,field:field.name,owner:'original Debug field Ty clone'}));return {...field,sourceSha256:hash(source),syntax:typed.syntax,semanticSyntaxRoundTrip:typed.provenance.semanticRoundTrip===true};});
}
function closeBranches(plan,branches,input,fields){
 const constructors=new Set(plan.constructors.values()),labels=new Set([input.name,...fields.map(f=>f.name),...input.variants.map(v=>v.name)]);let visited=0;
 const fail=()=>{throw new TypeError('Original Debug recursive positive namespace grammar differs');};
 const visit=expr=>{
  if(++visited>4096||expr?.kind!=='Expr'||expr.tokens!==null||expr.attrs?.length!==0||!constructors.has(expr.constructor))fail();const slots=expr.slots;
  switch(expr.constructor.variant.name){
   case 'Path':if(slots.path?.kind!=='Path'||!slots.path.segments.length)fail();break;
   case 'Lit':if(slots.s?.kind!=='Symbol'||!labels.has(slots.s.value))fail();break;
   case 'Field':visit(slots.selflike_arg);if(!fields.some(f=>f.name===slots.struct_field_ident&&JSON.stringify(f.fieldDefinitionSpan)===JSON.stringify(slots.sourceSpan)))fail();break;
   case 'AddrOf':visit(slots.e);break;
   case 'Call':visit(slots.expr);if(!Array.isArray(slots.args))fail();slots.args.forEach(visit);break;
   case 'Array':case 'Tup':if(!Array.isArray(slots.exprs))fail();slots.exprs.forEach(visit);break;
   case 'Match':visit(slots.arg);if(slots.matchKind!=='Prefix'||slots.arms.length!==input.variants.length)fail();slots.arms.forEach((arm,index)=>{const v=input.variants[index];if(arm.kind!=='Arm'||arm.attrs.length||arm.guard!==null||arm.isPlaceholder!==false||arm.pattern.kind!=='PatKind::Path'||arm.pattern.qself!==null||JSON.stringify(arm.pattern.path)!==JSON.stringify([input.name,v.name])||JSON.stringify(arm.pattern.sourceNameSpan)!==JSON.stringify(v.span))fail();visit(arm.body);});break;
   default:fail();
  }
 };
 const type=ty=>{switch(ty?.kind){case 'TyKind::Infer':break;case 'TyKind::Ref':if(ty.mutability!=='Not'||ty.lifetime!==null&&(ty.lifetime.kind!=='Lifetime'||ty.lifetime.symbol!=='StaticLifetime'))fail();type(ty.ty);break;case 'TyKind::Slice':type(ty.ty);break;case 'TyKind::TraitObject':if(ty.syntax!=='Dyn'||ty.bounds.length!==1||ty.bounds[0].kind!=='GenericBound::Trait'||ty.bounds[0].constness!=='Never'||JSON.stringify(ty.bounds[0].path.slice(1))!==JSON.stringify(['fmt','Debug']))fail();break;default:fail();}};
 return branches.map(branch=>{
  const before=visited;if(branch.statements.length&&!(input.style==='named-struct'&&fields.length>plan.sourceControls.fieldCountCutoff&&branch.statements.length===2))fail();
  branch.statements.forEach((stmt,index)=>{const local=stmt.local;if(stmt.kind!=='StmtKind::Let'||local?.kind!=='LocalKind::Init'||local.tokens!==null||local.attrs.length||local.mutable!==false||local.pattern.kind!=='PatKind::Ident'||local.pattern.bindingMode!=='NONE'||local.pattern.subpattern!==null||local.pattern.ident!==['names','values'][index])fail();type(local.ty);visit(local.initializer);});visit(branch.body);
  return {...branch,recursiveNamespaceClosure:{schema:'source-original-debug-positive-tree-closure-v1',nodes:visited-before,localInitializers:branch.statements.length,sourceConstructorsOnly:true,bodyExpressionComplete:true,namespaceAuthority:false}};
 });
}
export function liftBuiltinDebugAstRoute({profile,entry,original,certificate,input}={}){
 const plan=sourcePlan(profile,entry),fresh=builtinDebugDataInputs({source:original.module.source,span:certificate.span});if(JSON.stringify(fresh)!==JSON.stringify(input)||input.wholeSourceSha256!==certificate.sourceSha256||input.itemSha256!==certificate.itemSha256||input.name!==certificate.name||input.kind!==certificate.kind)throw new TypeError('Original Debug source syntax differs from its private invocation');if(input.attributes.some(a=>a.name==='repr'))throw new TypeError('Original Debug packed/repr field view remains outside this source route');
 if(input.style==='payload-enum')return liftPayloadEnum(profile,plan,original,certificate,input);
 const fields=typeLeaves(original,certificate,input),node=(builder,slots)=>({kind:'Expr',constructor:plan.constructors.get(builder),attrs:[],tokens:null,slots}),root={kind:'Ident',symbol:'kw::DollarCrate',hygiene:'original std_path with_def_site_ctxt(DUMMY_SP)'},path=segments=>node('expr_path',{path:{kind:'Path',segments}}),call=(segments,args)=>node('expr_call',{expr:path(segments),args}),string=value=>node('expr_str',{s:{kind:'Symbol',value}}),self=path(['self']),fmt=path(['f']);
 const ok=()=>call([root,'result','Result','Ok'],[node('expr_tuple',{exprs:[]})]),write=name=>call([root,'fmt','Formatter','write_str'],[fmt,name]);
 const fieldExpressions=fields.map(field=>node('expr_addr_of',{e:node('source_field',{selflike_arg:self,struct_field_ident:field.name,sourceSpan:field.fieldDefinitionSpan,hygiene:'original FieldDef span with trait ctxt'})}));
 const last=(expr,index)=>index<fieldExpressions.length-1?expr:node('expr_addr_of',{e:expr,sourceSpan:fields[index].fieldDefinitionSpan,hygiene:'original expr_for_field last-field span'});
 let branches=[{condition:'FmtDebug::None',statements:[],body:ok()}];
 if(input.style==='unit-enum'&&input.variants.length>1){const arms=input.variants.map(variant=>({kind:'Arm',attrs:[],guard:null,body:string(variant.name),pattern:{kind:'PatKind::Path',qself:null,path:[input.name,variant.name],sourceNameSpan:variant.span},isPlaceholder:false}));branches.push({condition:'FmtDebug::Shallow or Full; AllFieldlessEnum bypasses shallow branch',statements:[],body:write(node('expr_match',{arg:self,arms,matchKind:'Prefix'}))});}
 else{
  const name=string(input.style==='unit-enum'?input.variants[0].name:input.name);branches.push({condition:'FmtDebug::Shallow',statements:[],body:write(name)});
  if(!fields.length)branches.push({condition:'FmtDebug::Full; empty fields',statements:[],body:write(name)});
  else if(fields.length<=5)branches.push({condition:'FmtDebug::Full; fields<=original CUTOFF',statements:[],body:call([root,'fmt','Formatter',{kind:'Symbol',originalFormat:'debug_struct_field{}_finish',argument:fields.length}],[fmt,name,...fields.flatMap((field,index)=>[string(field.name),last(fieldExpressions[index],index)])])});
  else{
   const names=node('expr_addr_of',{e:node('expr_array',{exprs:fields.map(f=>string(f.name))})}),values=node('expr_addr_of',{e:node('expr_array',{exprs:fieldExpressions.map(last)})}),ref=(ty,lifetime=null)=>({kind:'TyKind::Ref',lifetime,mutability:'Not',ty}),namesTy=ref({kind:'TyKind::Infer'},{kind:'Lifetime',symbol:'StaticLifetime'}),valuesTy=ref({kind:'TyKind::Slice',ty:ref({kind:'TyKind::TraitObject',bounds:[{kind:'GenericBound::Trait',path:[root,'fmt','Debug'],constness:'Never'}],syntax:'Dyn'})});
   const local=(ident,ty,initializer)=>({kind:'StmtKind::Let',local:{kind:'LocalKind::Init',pattern:{kind:'PatKind::Ident',bindingMode:'NONE',ident,subpattern:null},ty,initializer,attrs:[],tokens:null,mutable:false}});
   branches.push({condition:'FmtDebug::Full; fields>original CUTOFF',statements:[local('names',namesTy,names),local('values',valuesTy,values)],body:call([root,'fmt','Formatter','debug_struct_fields_finish'],[fmt,name,path(['names']),path(['values'])])});
  }
 }
 const evidence={schema:'original-debug-data-ast-bridge-v1',profileDigest:profile.digest,input,typedSource:{fields,variants:input.variants,inputStyle:input.style},descriptor:plan.descriptor,method:plan.method,recipes:plan.recipes,compilerMeta:plan.compilerMeta,positiveSchemas:plan.positiveSchemas,schemas:plan.schemas,parserFieldSpans:plan.parserFieldSpans,sourceControls:plan.sourceControls,branches:closeBranches(plan,branches,input,fields).map(branch=>({...branch,outputKind:'ItemKind::Impl',associatedKind:'AssocItemKind::Fn',bodyKind:'Block',associatedItems:1,associatedTypes:0,genericParameters:0,wherePredicates:0,generatedAttributes:['automatically_derived','inline'],lastBodyWrapper:'StmtKind::Expr from original BlockOrExpr::into_block'})),positiveOutputGrammarComplete:true,namespaceAuthority:false,copyAuthority:false,noDropAuthority:false,constAuthority:false,generatedImplBehavior:false,obligations:['original compiler metadata includes independent uncompiled builder/helper execution facts','fmt/format/allocator execution is not translated','actual original caller/helper/ancestor owners require the independent private issuer join','all other derives, ownership, trait validity and const eligibility remain separate']};return freezeCompleted({...evidence,digest:hash(composeJson(evidence))});
}

// Payload enums retain their actual generic match before every callback. The
// original named-record/unit-enum route above keeps its previous source domain.
const payloadPlans=new WeakMap();
function payloadPlan(profile,base){
 if(payloadPlans.has(profile))return payloadPlans.get(profile);
 const shared=requireOriginalBuiltinEnumPatternSource(originalBuiltinEnumPatternSource(profile),profile),compiler=createBuiltinAstBuilderMetaCompiler(profile),extra=[...shared.recipes],contracts=[];
 const enumeration=originalAstFunction(profile,generic,'expand_enum_method_body');
 contains(enumeration,'iter::once("__self".to_string())','let fields = trait_.create_struct_pattern_fields','let by_ref = ByRef::No','if subpats.len() == 1','let substructure = EnumMatching(variant, fields)','cx.arm(span, single_pat, arm_expr)','_ if variants.len() > 1 && selflike_args.len() > 1','cx.expr_match(span, match_arg, match_arms)','BlockOrExpr(ThinVec::new(), Some(get_match_expr(selflike_args)))');
 const constructors=new Map([...base.constructors,...Object.entries(shared.constructors)]),selected=originalAstFunction(profile,build,'expr_block'),rows=originalAstPositiveConstructors(profile,selected,'ExprKind');extra.push(selected);
 if(rows.length!==1||rows[0].variant.name!=='Block')throw new TypeError('Original Debug enum block constructor differs');constructors.set('expr_block',rows[0]);try{contracts.push(compiler.compile('expr_block'));}catch(error){contracts.push({recipeDigest:selected.digest,sourceMetaRefusal:error.message,generatedImplBehavior:false});}
 const result={...base,constructors,recipes:[...base.recipes,...extra],compilerMeta:[...base.compilerMeta,...shared.compilerMeta,...contracts],positiveSchemas:[...base.positiveSchemas,...shared.positiveSchemas,constructors.get('expr_block').variant],schemas:[...base.schemas,...shared.schemas,originalAstDefinition(profile,schema,'struct','Block')],parserFieldSpans:{...base.parserFieldSpans,enumRecipes:[shared.parser.tuple,shared.parser.variant]},sourceControls:{...base.sourceControls,enumReceiverArguments:1,enumBinderPrefix:'__self',enumBindingMode:{byRef:'No',mutability:'Not'},enumDefaultArm:false,enumFieldTypes:'source-cloned Ty only; no field trait/runtime/Copy authority'}};
 payloadPlans.set(profile,result);return result;
}
function payloadTypes(original,certificate,input){return input.variants.map(variant=>({...variant,fields:typeLeaves(original,certificate,{fields:variant.fields})}));}
function liftPayloadEnum(profile,base,original,certificate,input){
 const plan=payloadPlan(profile,base),variants=payloadTypes(original,certificate,input),node=(builder,slots)=>({kind:'Expr',constructor:plan.constructors.get(builder),attrs:[],tokens:null,slots}),root={kind:'Ident',symbol:'kw::DollarCrate',hygiene:'original std_path with_def_site_ctxt(DUMMY_SP)'},path=segments=>node('expr_path',{path:{kind:'Path',segments}}),call=(segments,args)=>node('expr_call',{expr:path(segments),args}),string=value=>node('expr_str',{s:{kind:'Symbol',value}}),self=path(['self']),fmt=path(['f']),ok=()=>call([root,'result','Result','Ok'],[node('expr_tuple',{exprs:[]})]),write=name=>call([root,'fmt','Formatter','write_str'],[fmt,name]);
 const local=(ident,ty,initializer)=>({kind:'StmtKind::Let',local:{kind:'LocalKind::Init',pattern:{kind:'PatKind::Ident',bindingMode:'NONE',ident,subpattern:null},ty,initializer,attrs:[],tokens:null,mutable:false}}),ref=(ty,lifetime=null)=>({kind:'TyKind::Ref',lifetime,mutability:'Not',ty});
 const binder=(field,index)=>({kind:'PatKind::Ident',bindingMode:{byRef:'No',mutability:'Not'},ident:'__self_'+index,subpattern:null,sourceSpan:field.fieldDefinitionSpan,hygiene:'actual mk_pattern_ident trait span; original FieldDef span with trait ctxt'});
 const pattern=variant=>{
  const common={qself:null,path:[input.name,variant.name],sourceNameSpan:variant.nameSpan,sourceVariantSpan:variant.span,tokens:null},binders=variant.fields.map(binder);
  if(variant.style==='unit')return {kind:'PatKind::Path',...common};
  if(variant.style==='tuple')return {kind:'PatKind::TupleStruct',constructor:plan.constructors.get('pat_tuple_struct'),...common,subpatterns:binders};
  return {kind:'PatKind::Struct',constructor:plan.constructors.get('pat_struct'),...common,rest:'PatFieldsRest::None',fields:variant.fields.map((field,index)=>({kind:'PatField',ident:field.name,isShorthand:false,attrs:[],isPlaceholder:false,sourceSpan:field.fieldDefinitionSpan,pattern:binders[index]}))};
 };
 const armBody=(variant,mode)=>{
  if(mode==='None')return {statements:[],body:ok()};const name=string(variant.name),fields=variant.fields,isStruct=variant.style==='named';if(mode==='Shallow'||!fields.length)return {statements:[],body:write(name)};
  const values=fields.map((field,index)=>path(['__self_'+index])),last=(expr,index)=>index<fields.length-1?expr:node('expr_addr_of',{e:expr,sourceSpan:fields[index].fieldDefinitionSpan,hygiene:'actual expr_for_field final indirection'});
  if(fields.length<=plan.sourceControls.fieldCountCutoff)return {statements:[],body:call([root,'fmt','Formatter',{kind:'Symbol',originalFormat:isStruct?'debug_struct_field{}_finish':'debug_tuple_field{}_finish',argument:fields.length}],[fmt,name,...fields.flatMap((field,index)=>isStruct?[string(field.name),last(values[index],index)]:[last(values[index],index)])])};
  const statements=[],valuesTy=ref({kind:'TyKind::Slice',ty:ref({kind:'TyKind::TraitObject',bounds:[{kind:'GenericBound::Trait',path:[root,'fmt','Debug'],constness:'Never'}],syntax:'Dyn'})});
  if(isStruct)statements.push(local('names',ref({kind:'TyKind::Infer'},{kind:'Lifetime',symbol:'StaticLifetime'}),node('expr_addr_of',{e:node('expr_array',{exprs:fields.map(field=>string(field.name))})})));
  statements.push(local('values',valuesTy,node('expr_addr_of',{e:node('expr_array',{exprs:values.map(last)})})));
  return {statements,body:call([root,'fmt','Formatter',isStruct?'debug_struct_fields_finish':'debug_tuple_fields_finish'],[fmt,name,...(isStruct?[path(['names'])]:[]),path(['values'])])};
 };
 const wrapped=body=>body.statements.length?node('expr_block',{block:{kind:'Block',tokens:null,statements:[...body.statements,{kind:'StmtKind::Expr',expr:body.body}]},label:null}):body.body;
 const arm=(variant,body)=>({kind:'Arm',attrs:[],guard:null,body,pattern:pattern(variant),isPlaceholder:false});
 const allFieldless=variants.every(variant=>!variant.fields.length);let branches;
 if(allFieldless&&variants.length>1)branches=[{condition:'FmtDebug::None; original AllFieldlessEnum callback',statements:[],body:ok()},{condition:'FmtDebug::Shallow or Full; original AllFieldlessEnum callback',statements:[],body:write(node('expr_match',{arg:self,arms:variants.map(variant=>arm(variant,string(variant.name))),matchKind:'Prefix'}))}];
 else if(allFieldless)branches=['None','Shallow','Full'].map(mode=>({condition:'FmtDebug::'+mode+'; original single fieldless variant callback',...armBody(variants[0],mode)}));
 else branches=['None','Shallow','Full'].map(mode=>({condition:'FmtDebug::'+mode+'; original EnumMatching callback per complete variant',statements:[],body:node('expr_match',{arg:self,arms:variants.map(variant=>arm(variant,wrapped(armBody(variant,mode)))),matchKind:'Prefix'})}));
 const evidence={schema:'original-debug-payload-enum-ast-bridge-v1',profileDigest:profile.digest,input,typedSource:{fields:[],variants,inputStyle:input.style},descriptor:plan.descriptor,method:plan.method,recipes:plan.recipes,compilerMeta:plan.compilerMeta,positiveSchemas:plan.positiveSchemas,schemas:plan.schemas,parserFieldSpans:plan.parserFieldSpans,sourceControls:plan.sourceControls,branches:closePayloadBranches(plan,branches,input,variants).map(branch=>({...branch,outputKind:'ItemKind::Impl',associatedKind:'AssocItemKind::Fn',bodyKind:'Block',associatedItems:1,associatedTypes:0,genericParameters:0,wherePredicates:0,generatedAttributes:['automatically_derived','inline'],lastBodyWrapper:'StmtKind::Expr from original BlockOrExpr::into_block'})),positiveOutputGrammarComplete:true,namespaceAuthority:false,copyAuthority:false,noDropAuthority:false,constAuthority:false,generatedImplBehavior:false,obligations:['all source builder/callback refusals remain retained in compilerMeta; no complete compiler execution claim','fmt/format/allocator/trait behavior is not translated','actual original caller/helper/ancestor owners require the independent private issuer join','other derives and all nested/global source macros retain independent complete output obligations']};return freezeCompleted({...evidence,digest:hash(composeJson(evidence))});
}
function closePayloadBranches(plan,branches,input,variants){
 const constructors=new Set([...plan.constructors].filter(([name])=>name.startsWith('expr_')).map(([,constructor])=>constructor)),allFieldless=variants.every(variant=>!variant.fields.length);let nodes=0;
 const fail=()=>{throw new TypeError('Original Debug payload enum positive AST grammar differs');};
 const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const exact=(value,keys)=>{if(!value||typeof value!=='object'||Array.isArray(value)||!same(Object.keys(value).sort(),[...keys].sort()))fail();};
 const sourceRoot=value=>{exact(value,['kind','symbol','hygiene']);if(value.kind!=='Ident'||value.symbol!=='kw::DollarCrate'||value.hygiene!=='original std_path with_def_site_ctxt(DUMMY_SP)')fail();};
 const path=(value,variant)=>{exact(value,['kind','segments']);if(value.kind!=='Path'||!Array.isArray(value.segments)||!value.segments.length)fail();const s=value.segments;
  if(s.length===1){if(!['self','f','names','values',...variant.fields.map((_,index)=>'__self_'+index)].includes(s[0]))fail();return;}
  sourceRoot(s[0]);if(s.length!==4||!(['fmt','Formatter'].every((name,index)=>s[index+1]===name)||s[1]==='result'&&s[2]==='Result'&&s[3]==='Ok'))fail();
  const method=s[3];if(typeof method==='string'){if(!['Ok','write_str','debug_struct_fields_finish','debug_tuple_fields_finish'].includes(method))fail();}
  else{exact(method,['kind','originalFormat','argument']);if(method.kind!=='Symbol'||method.argument!==variant.fields.length||!['debug_struct_field{}_finish','debug_tuple_field{}_finish'].includes(method.originalFormat))fail();}
 };
 const type=value=>{switch(value?.kind){case'TyKind::Infer':exact(value,['kind']);break;case'TyKind::Ref':exact(value,['kind','lifetime','mutability','ty']);if(value.mutability!=='Not')fail();if(value.lifetime!==null){exact(value.lifetime,['kind','symbol']);if(value.lifetime.kind!=='Lifetime'||value.lifetime.symbol!=='StaticLifetime')fail();}type(value.ty);break;case'TyKind::Slice':exact(value,['kind','ty']);type(value.ty);break;case'TyKind::TraitObject':exact(value,['kind','bounds','syntax']);if(value.syntax!=='Dyn'||value.bounds.length!==1)fail();const bound=value.bounds[0];exact(bound,['kind','path','constness']);if(bound.kind!=='GenericBound::Trait'||bound.constness!=='Never'||!same(bound.path.slice(1),['fmt','Debug']))fail();sourceRoot(bound.path[0]);break;default:fail();}};
 const binding=(value,field,index)=>{exact(value,['kind','bindingMode','ident','subpattern','sourceSpan','hygiene']);exact(value.bindingMode,['byRef','mutability']);if(value.kind!=='PatKind::Ident'||value.bindingMode.byRef!=='No'||value.bindingMode.mutability!=='Not'||value.ident!=='__self_'+index||value.subpattern!==null||!same(value.sourceSpan,field.fieldDefinitionSpan)||value.hygiene!=='actual mk_pattern_ident trait span; original FieldDef span with trait ctxt')fail();};
 const pattern=(value,variant)=>{const common=['kind','qself','path','sourceNameSpan','sourceVariantSpan','tokens'];exact(value,variant.style==='unit'?common:[...common,'constructor',variant.style==='tuple'?'subpatterns':'rest',...(variant.style==='named'?['fields']:[])]);
  if(value.qself!==null||value.tokens!==null||!same(value.path,[input.name,variant.name])||!same(value.sourceNameSpan,variant.nameSpan)||!same(value.sourceVariantSpan,variant.span))fail();
  if(variant.style==='unit'){if(value.kind!=='PatKind::Path')fail();return;}
  if(variant.style==='tuple'){if(value.kind!=='PatKind::TupleStruct'||value.constructor!==plan.constructors.get('pat_tuple_struct')||value.subpatterns.length!==variant.fields.length)fail();value.subpatterns.forEach((item,index)=>binding(item,variant.fields[index],index));return;}
  if(value.kind!=='PatKind::Struct'||value.constructor!==plan.constructors.get('pat_struct')||value.rest!=='PatFieldsRest::None'||value.fields.length!==variant.fields.length)fail();value.fields.forEach((field,index)=>{exact(field,['kind','ident','isShorthand','attrs','isPlaceholder','sourceSpan','pattern']);if(field.kind!=='PatField'||field.ident!==variant.fields[index].name||field.isShorthand!==false||field.attrs.length||field.isPlaceholder!==false||!same(field.sourceSpan,variant.fields[index].fieldDefinitionSpan))fail();binding(field.pattern,variant.fields[index],index);});
 };
 const local=(stmt,variant,index)=>{exact(stmt,['kind','local']);const value=stmt.local;exact(value,['kind','pattern','ty','initializer','attrs','tokens','mutable']);exact(value.pattern,['kind','bindingMode','ident','subpattern']);const name=variant.style==='named'?['names','values'][index]:'values';if(stmt.kind!=='StmtKind::Let'||value.kind!=='LocalKind::Init'||value.pattern.kind!=='PatKind::Ident'||value.pattern.bindingMode!=='NONE'||value.pattern.ident!==name||value.pattern.subpattern!==null||value.tokens!==null||value.mutable!==false||value.attrs.length)fail();type(value.ty);visit(value.initializer,variant,'Full');};
 function visit(value,variant,mode){
  if(++nodes>4096)fail();exact(value,['kind','constructor','attrs','tokens','slots']);if(value.kind!=='Expr'||value.tokens!==null||value.attrs.length||!constructors.has(value.constructor))fail();const s=value.slots;
  switch(value.constructor.variant.name){
   case'Path':exact(s,['path']);path(s.path,variant);break;
   case'Lit':exact(s,['s']);exact(s.s,['kind','value']);if(s.s.kind!=='Symbol'||![variant.name,...(variant.style==='named'?variant.fields.map(field=>field.name):[])].includes(s.s.value))fail();break;
   case'Call':exact(s,['expr','args']);if(!Array.isArray(s.args))fail();visit(s.expr,variant,mode);s.args.forEach(item=>visit(item,variant,mode));break;
   case'AddrOf':if(Object.hasOwn(s,'sourceSpan')){exact(s,['e','sourceSpan','hygiene']);if(!variant.fields.length||!same(s.sourceSpan,variant.fields.at(-1).fieldDefinitionSpan)||s.hygiene!=='actual expr_for_field final indirection')fail();}else exact(s,['e']);visit(s.e,variant,mode);break;
   case'Array':case'Tup':exact(s,['exprs']);if(!Array.isArray(s.exprs))fail();s.exprs.forEach(item=>visit(item,variant,mode));break;
   case'Block':exact(s,['block','label']);exact(s.block,['kind','tokens','statements']);if(mode!=='Full'||variant.fields.length<=plan.sourceControls.fieldCountCutoff||s.label!==null||s.block.kind!=='Block'||s.block.tokens!==null||s.block.statements.length!==(variant.style==='named'?3:2))fail();s.block.statements.slice(0,-1).forEach((stmt,index)=>local(stmt,variant,index));const last=s.block.statements.at(-1);exact(last,['kind','expr']);if(last.kind!=='StmtKind::Expr')fail();visit(last.expr,variant,mode);break;
   case'Match':exact(s,['arg','arms','matchKind']);if(s.matchKind!=='Prefix'||s.arg.constructor!==plan.constructors.get('expr_path')||!same(s.arg.slots.path.segments,['self'])||s.arms.length!==variants.length)fail();visit(s.arg,variant,mode);s.arms.forEach((arm,index)=>{exact(arm,['kind','attrs','guard','body','pattern','isPlaceholder']);if(arm.kind!=='Arm'||arm.attrs.length||arm.guard!==null||arm.isPlaceholder!==false)fail();pattern(arm.pattern,variants[index]);visit(arm.body,variants[index],mode);});break;
   default:fail();
  }
 }
 if(branches.length!==(allFieldless&&variants.length>1?2:3))fail();return branches.map((branch,index)=>{exact(branch,['condition','statements','body']);if(branch.statements.length)fail();const before=nodes,mode=index===0?'None':index===1?'Shallow':'Full';visit(branch.body,variants[0],mode);return {...branch,recursiveNamespaceClosure:{schema:'source-original-debug-payload-enum-positive-tree-v1',nodes:nodes-before,variantCount:variants.length,sourceConstructorsOnly:true,allOriginalFieldsRetained:true,bodyExpressionComplete:true,namespaceAuthority:false}};});
}

// Explicit enclosing-only format: legacy full route above is unchanged.
export function compileBuiltinDebugEnclosingNamespaceModel({profile,entry,original,certificate,input}={}){
 const plan=sourcePlan(profile,entry),fresh=builtinDebugDataInputs({source:original.module.source,span:certificate.span});if(JSON.stringify(fresh)!==JSON.stringify(input)||input.wholeSourceSha256!==certificate.sourceSha256||input.itemSha256!==certificate.itemSha256||input.name!==certificate.name||input.kind!==certificate.kind)throw new TypeError('Original Debug source syntax differs from its private invocation');if(input.attributes.some(a=>a.name==='repr'))throw new TypeError('Original Debug packed/repr field view remains outside this source route');
 if(input.style==='payload-enum')return null;
 const fields=typeLeaves(original,certificate,input),node=(builder,slots)=>({kind:'Expr',constructor:plan.constructors.get(builder),attrs:[],tokens:null,slots}),root={kind:'Ident',symbol:'kw::DollarCrate',hygiene:'original std_path with_def_site_ctxt(DUMMY_SP)'},path=segments=>node('expr_path',{path:{kind:'Path',segments}}),call=(segments,args)=>node('expr_call',{expr:path(segments),args}),string=value=>node('expr_str',{s:{kind:'Symbol',value}}),self=path(['self']),fmt=path(['f']);
 const ok=()=>call([root,'result','Result','Ok'],[node('expr_tuple',{exprs:[]})]),write=name=>call([root,'fmt','Formatter','write_str'],[fmt,name]);
 const fieldExpressions=fields.map(field=>node('expr_addr_of',{e:node('source_field',{selflike_arg:self,struct_field_ident:field.name,sourceSpan:field.fieldDefinitionSpan,hygiene:'original FieldDef span with trait ctxt'})}));
 const last=(expr,index)=>index<fieldExpressions.length-1?expr:node('expr_addr_of',{e:expr,sourceSpan:fields[index].fieldDefinitionSpan,hygiene:'original expr_for_field last-field span'});
 let branches=[{condition:'FmtDebug::None',statements:[],body:ok()}];
 if(input.style==='unit-enum'&&input.variants.length>1){const arms=input.variants.map(variant=>({kind:'Arm',attrs:[],guard:null,body:string(variant.name),pattern:{kind:'PatKind::Path',qself:null,path:[input.name,variant.name],sourceNameSpan:variant.span},isPlaceholder:false}));branches.push({condition:'FmtDebug::Shallow or Full; AllFieldlessEnum bypasses shallow branch',statements:[],body:write(node('expr_match',{arg:self,arms,matchKind:'Prefix'}))});}
 else{
  const name=string(input.style==='unit-enum'?input.variants[0].name:input.name);branches.push({condition:'FmtDebug::Shallow',statements:[],body:write(name)});
  if(!fields.length)branches.push({condition:'FmtDebug::Full; empty fields',statements:[],body:write(name)});
  else if(fields.length<=5)branches.push({condition:'FmtDebug::Full; fields<=original CUTOFF',statements:[],body:call([root,'fmt','Formatter',{kind:'Symbol',originalFormat:'debug_struct_field{}_finish',argument:fields.length}],[fmt,name,...fields.flatMap((field,index)=>[string(field.name),last(fieldExpressions[index],index)])])});
  else{
   const names=node('expr_addr_of',{e:node('expr_array',{exprs:fields.map(f=>string(f.name))})}),values=node('expr_addr_of',{e:node('expr_array',{exprs:fieldExpressions.map(last)})}),ref=(ty,lifetime=null)=>({kind:'TyKind::Ref',lifetime,mutability:'Not',ty}),namesTy=ref({kind:'TyKind::Infer'},{kind:'Lifetime',symbol:'StaticLifetime'}),valuesTy=ref({kind:'TyKind::Slice',ty:ref({kind:'TyKind::TraitObject',bounds:[{kind:'GenericBound::Trait',path:[root,'fmt','Debug'],constness:'Never'}],syntax:'Dyn'})});
   const local=(ident,ty,initializer)=>({kind:'StmtKind::Let',local:{kind:'LocalKind::Init',pattern:{kind:'PatKind::Ident',bindingMode:'NONE',ident,subpattern:null},ty,initializer,attrs:[],tokens:null,mutable:false}});
   branches.push({condition:'FmtDebug::Full; fields>original CUTOFF',statements:[local('names',namesTy,names),local('values',valuesTy,values)],body:call([root,'fmt','Formatter','debug_struct_fields_finish'],[fmt,name,path(['names']),path(['values'])])});
  }
 }
 const closed=closeBranches(plan,branches,input,fields);
 // The candidate is DATA only. The private invocation issuer independently
 // joins current input/owner/source and the original resolver rule.
 return {schema:'original-debug-enclosing-grammar-candidate-v1',inputStyle:input.style,
  sources:plan.recipes.map(recipe=>({source:recipe.source,sourceSha256:recipe.sourceSha256,span:recipe.span,syntaxSha256:recipe.syntaxSha256,digest:recipe.digest})),
  branches:closed.map(branch=>({condition:branch.condition,statements:branch.statements.length,closure:branch.recursiveNamespaceClosure})),
  sourceControls:plan.sourceControls,generatedAttributes:['automatically_derived','inline'],
  sourceTypeRoundtrips:fields.map(field=>({name:field.name,typeSpan:field.typeSpan,sourceSha256:field.sourceSha256,semanticSyntaxRoundTrip:field.semanticSyntaxRoundTrip})),
  methodBehavior:'opaque-untranslated',namespaceAuthority:false,runtimeAuthority:false};
}

// Explicit tuple Debug paths retain every original public source entry.
function tupleDebugSourcePlan(profile,entry){
 const plan=sourcePlan(profile,entry),show=originalAstFunction(profile,directory+'debug.rs','show_substructure'),access=originalAstFunction(profile,generic,'create_struct_field_access_fields'),parser=originalAstFunction(profile,'compiler/rustc_parse/src/parser/item.rs','parse_tuple_struct_body');
 contains(show,'Struct(vdata, fields) => (substr.type_ident, *vdata, fields)','ast::VariantData::Tuple(..) => (false, 1)','format!("debug_tuple_field{}_finish", fields.len())','sym::debug_tuple_fields_finish');
 contains(access,'self.create_fields(struct_def, |i, struct_field, sp|','Ident::from_str_and_span(&i.to_string(), struct_field.span)');
 contains(parser,'self.parse_paren_comma_seq','p.parse_outer_attributes()?','let lo = p.token.span','p.parse_visibility(FollowedByType::Yes)','let ty = match p.parse_ty()','span: lo.to(ty.span)','ident: None');
 return {...plan,recipes:[...plan.recipes,show,access,parser]};
}
function closeTupleDebugBranches(plan,branches,input,fields){
 const constructors=new Set(plan.constructors.values()),labels=new Set([input.name,...fields.map(f=>f.name),...input.variants.map(v=>v.name)]);let visited=0;
 const fail=()=>{throw new TypeError('Original Debug recursive positive namespace grammar differs');};
 const visit=expr=>{
  if(++visited>4096||expr?.kind!=='Expr'||expr.tokens!==null||expr.attrs?.length!==0||!constructors.has(expr.constructor))fail();const slots=expr.slots;
  switch(expr.constructor.variant.name){
   case 'Path':if(slots.path?.kind!=='Path'||!slots.path.segments.length)fail();break;
   case 'Lit':if(slots.s?.kind!=='Symbol'||!labels.has(slots.s.value))fail();break;
   case 'Field':visit(slots.selflike_arg);if(!fields.some(f=>f.name===slots.struct_field_ident&&JSON.stringify(f.fieldDefinitionSpan)===JSON.stringify(slots.sourceSpan)))fail();break;
   case 'AddrOf':visit(slots.e);break;
   case 'Call':visit(slots.expr);if(!Array.isArray(slots.args))fail();slots.args.forEach(visit);break;
   case 'Array':case 'Tup':if(!Array.isArray(slots.exprs))fail();slots.exprs.forEach(visit);break;
   case 'Match':visit(slots.arg);if(slots.matchKind!=='Prefix'||slots.arms.length!==input.variants.length)fail();slots.arms.forEach((arm,index)=>{const v=input.variants[index];if(arm.kind!=='Arm'||arm.attrs.length||arm.guard!==null||arm.isPlaceholder!==false||arm.pattern.kind!=='PatKind::Path'||arm.pattern.qself!==null||JSON.stringify(arm.pattern.path)!==JSON.stringify([input.name,v.name])||JSON.stringify(arm.pattern.sourceNameSpan)!==JSON.stringify(v.span))fail();visit(arm.body);});break;
   default:fail();
  }
 };
 const type=ty=>{switch(ty?.kind){case 'TyKind::Infer':break;case 'TyKind::Ref':if(ty.mutability!=='Not'||ty.lifetime!==null&&(ty.lifetime.kind!=='Lifetime'||ty.lifetime.symbol!=='StaticLifetime'))fail();type(ty.ty);break;case 'TyKind::Slice':type(ty.ty);break;case 'TyKind::TraitObject':if(ty.syntax!=='Dyn'||ty.bounds.length!==1||ty.bounds[0].kind!=='GenericBound::Trait'||ty.bounds[0].constness!=='Never'||JSON.stringify(ty.bounds[0].path.slice(1))!==JSON.stringify(['fmt','Debug']))fail();break;default:fail();}};
 return branches.map(branch=>{
  const before=visited;if(branch.statements.length&&!(input.style==='tuple-struct'&&fields.length>plan.sourceControls.fieldCountCutoff&&branch.statements.length===1))fail();
  branch.statements.forEach((stmt,index)=>{const local=stmt.local;if(stmt.kind!=='StmtKind::Let'||local?.kind!=='LocalKind::Init'||local.tokens!==null||local.attrs.length||local.mutable!==false||local.pattern.kind!=='PatKind::Ident'||local.pattern.bindingMode!=='NONE'||local.pattern.subpattern!==null||local.pattern.ident!=='values')fail();type(local.ty);visit(local.initializer);});visit(branch.body);
  return {...branch,recursiveNamespaceClosure:{schema:'source-original-debug-positive-tree-closure-v1',nodes:visited-before,localInitializers:branch.statements.length,sourceConstructorsOnly:true,bodyExpressionComplete:true,namespaceAuthority:false}};
 });
}
export function liftBuiltinDebugTupleAstRoute({profile,entry,original,certificate,input}={}){
 const plan=tupleDebugSourcePlan(profile,entry),fresh=builtinCloneDataInputs({source:original.module.source,span:certificate.span});if(JSON.stringify(fresh)!==JSON.stringify(input)||input.wholeSourceSha256!==certificate.sourceSha256||input.itemSha256!==certificate.itemSha256||input.name!==certificate.name||input.kind!==certificate.kind)throw new TypeError('Original Debug source syntax differs from its private invocation');if(input.attributes.some(a=>a.name==='repr'))throw new TypeError('Original Debug packed/repr field view remains outside this source route');
 if(input.style!=='tuple-struct')throw new TypeError('Tuple Debug requires its explicit source input style');
 const fields=typeLeaves(original,certificate,input),node=(builder,slots)=>({kind:'Expr',constructor:plan.constructors.get(builder),attrs:[],tokens:null,slots}),root={kind:'Ident',symbol:'kw::DollarCrate',hygiene:'original std_path with_def_site_ctxt(DUMMY_SP)'},path=segments=>node('expr_path',{path:{kind:'Path',segments}}),call=(segments,args)=>node('expr_call',{expr:path(segments),args}),string=value=>node('expr_str',{s:{kind:'Symbol',value}}),self=path(['self']),fmt=path(['f']);
 const ok=()=>call([root,'result','Result','Ok'],[node('expr_tuple',{exprs:[]})]),write=name=>call([root,'fmt','Formatter','write_str'],[fmt,name]);
 const fieldExpressions=fields.map(field=>node('expr_addr_of',{e:node('source_field',{selflike_arg:self,struct_field_ident:field.name,sourceSpan:field.fieldDefinitionSpan,hygiene:'original FieldDef span with trait ctxt'})}));
 const last=(expr,index)=>index<fieldExpressions.length-1?expr:node('expr_addr_of',{e:expr,sourceSpan:fields[index].fieldDefinitionSpan,hygiene:'original expr_for_field last-field span'});
 let branches=[{condition:'FmtDebug::None',statements:[],body:ok()}];
 if(input.style==='unit-enum'&&input.variants.length>1){const arms=input.variants.map(variant=>({kind:'Arm',attrs:[],guard:null,body:string(variant.name),pattern:{kind:'PatKind::Path',qself:null,path:[input.name,variant.name],sourceNameSpan:variant.span},isPlaceholder:false}));branches.push({condition:'FmtDebug::Shallow or Full; AllFieldlessEnum bypasses shallow branch',statements:[],body:write(node('expr_match',{arg:self,arms,matchKind:'Prefix'}))});}
 else{
  const name=string(input.style==='unit-enum'?input.variants[0].name:input.name);branches.push({condition:'FmtDebug::Shallow',statements:[],body:write(name)});
  if(!fields.length)branches.push({condition:'FmtDebug::Full; empty fields',statements:[],body:write(name)});
  else if(fields.length<=5)branches.push({condition:'FmtDebug::Full; fields<=original CUTOFF',statements:[],body:call([root,'fmt','Formatter',{kind:'Symbol',originalFormat:'debug_tuple_field{}_finish',argument:fields.length}],[fmt,name,...fieldExpressions.map(last)])});
  else{
   const names=node('expr_addr_of',{e:node('expr_array',{exprs:fields.map(f=>string(f.name))})}),values=node('expr_addr_of',{e:node('expr_array',{exprs:fieldExpressions.map(last)})}),ref=(ty,lifetime=null)=>({kind:'TyKind::Ref',lifetime,mutability:'Not',ty}),namesTy=ref({kind:'TyKind::Infer'},{kind:'Lifetime',symbol:'StaticLifetime'}),valuesTy=ref({kind:'TyKind::Slice',ty:ref({kind:'TyKind::TraitObject',bounds:[{kind:'GenericBound::Trait',path:[root,'fmt','Debug'],constness:'Never'}],syntax:'Dyn'})});
   const local=(ident,ty,initializer)=>({kind:'StmtKind::Let',local:{kind:'LocalKind::Init',pattern:{kind:'PatKind::Ident',bindingMode:'NONE',ident,subpattern:null},ty,initializer,attrs:[],tokens:null,mutable:false}});
   branches.push({condition:'FmtDebug::Full; fields>original CUTOFF',statements:[local('values',valuesTy,values)],body:call([root,'fmt','Formatter','debug_tuple_fields_finish'],[fmt,name,path(['values'])])});
  }
 }
 const evidence={schema:'original-debug-data-ast-bridge-v1',profileDigest:profile.digest,input,typedSource:{fields,variants:input.variants,inputStyle:input.style},descriptor:plan.descriptor,method:plan.method,recipes:plan.recipes,compilerMeta:plan.compilerMeta,positiveSchemas:plan.positiveSchemas,schemas:plan.schemas,parserFieldSpans:plan.parserFieldSpans,sourceControls:plan.sourceControls,branches:closeTupleDebugBranches(plan,branches,input,fields).map(branch=>({...branch,outputKind:'ItemKind::Impl',associatedKind:'AssocItemKind::Fn',bodyKind:'Block',associatedItems:1,associatedTypes:0,genericParameters:0,wherePredicates:0,generatedAttributes:['automatically_derived','inline'],lastBodyWrapper:'StmtKind::Expr from original BlockOrExpr::into_block'})),positiveOutputGrammarComplete:true,namespaceAuthority:false,copyAuthority:false,noDropAuthority:false,constAuthority:false,generatedImplBehavior:false,obligations:['original compiler metadata includes independent uncompiled builder/helper execution facts','fmt/format/allocator execution is not translated','actual original caller/helper/ancestor owners require the independent private issuer join','all other derives, ownership, trait validity and const eligibility remain separate']};return freezeCompleted({...evidence,digest:hash(composeJson(evidence))});
}
export function compileBuiltinDebugTupleEnclosingNamespaceModel({profile,entry,original,certificate,input}={}){
 const plan=tupleDebugSourcePlan(profile,entry),fresh=builtinCloneDataInputs({source:original.module.source,span:certificate.span});if(JSON.stringify(fresh)!==JSON.stringify(input)||input.wholeSourceSha256!==certificate.sourceSha256||input.itemSha256!==certificate.itemSha256||input.name!==certificate.name||input.kind!==certificate.kind)throw new TypeError('Original Debug source syntax differs from its private invocation');if(input.attributes.some(a=>a.name==='repr'))throw new TypeError('Original Debug packed/repr field view remains outside this source route');
 if(input.style!=='tuple-struct')throw new TypeError('Tuple Debug requires its explicit source input style');
 const fields=typeLeaves(original,certificate,input),node=(builder,slots)=>({kind:'Expr',constructor:plan.constructors.get(builder),attrs:[],tokens:null,slots}),root={kind:'Ident',symbol:'kw::DollarCrate',hygiene:'original std_path with_def_site_ctxt(DUMMY_SP)'},path=segments=>node('expr_path',{path:{kind:'Path',segments}}),call=(segments,args)=>node('expr_call',{expr:path(segments),args}),string=value=>node('expr_str',{s:{kind:'Symbol',value}}),self=path(['self']),fmt=path(['f']);
 const ok=()=>call([root,'result','Result','Ok'],[node('expr_tuple',{exprs:[]})]),write=name=>call([root,'fmt','Formatter','write_str'],[fmt,name]);
 const fieldExpressions=fields.map(field=>node('expr_addr_of',{e:node('source_field',{selflike_arg:self,struct_field_ident:field.name,sourceSpan:field.fieldDefinitionSpan,hygiene:'original FieldDef span with trait ctxt'})}));
 const last=(expr,index)=>index<fieldExpressions.length-1?expr:node('expr_addr_of',{e:expr,sourceSpan:fields[index].fieldDefinitionSpan,hygiene:'original expr_for_field last-field span'});
 let branches=[{condition:'FmtDebug::None',statements:[],body:ok()}];
 if(input.style==='unit-enum'&&input.variants.length>1){const arms=input.variants.map(variant=>({kind:'Arm',attrs:[],guard:null,body:string(variant.name),pattern:{kind:'PatKind::Path',qself:null,path:[input.name,variant.name],sourceNameSpan:variant.span},isPlaceholder:false}));branches.push({condition:'FmtDebug::Shallow or Full; AllFieldlessEnum bypasses shallow branch',statements:[],body:write(node('expr_match',{arg:self,arms,matchKind:'Prefix'}))});}
 else{
  const name=string(input.style==='unit-enum'?input.variants[0].name:input.name);branches.push({condition:'FmtDebug::Shallow',statements:[],body:write(name)});
  if(!fields.length)branches.push({condition:'FmtDebug::Full; empty fields',statements:[],body:write(name)});
  else if(fields.length<=5)branches.push({condition:'FmtDebug::Full; fields<=original CUTOFF',statements:[],body:call([root,'fmt','Formatter',{kind:'Symbol',originalFormat:'debug_tuple_field{}_finish',argument:fields.length}],[fmt,name,...fieldExpressions.map(last)])});
  else{
   const names=node('expr_addr_of',{e:node('expr_array',{exprs:fields.map(f=>string(f.name))})}),values=node('expr_addr_of',{e:node('expr_array',{exprs:fieldExpressions.map(last)})}),ref=(ty,lifetime=null)=>({kind:'TyKind::Ref',lifetime,mutability:'Not',ty}),namesTy=ref({kind:'TyKind::Infer'},{kind:'Lifetime',symbol:'StaticLifetime'}),valuesTy=ref({kind:'TyKind::Slice',ty:ref({kind:'TyKind::TraitObject',bounds:[{kind:'GenericBound::Trait',path:[root,'fmt','Debug'],constness:'Never'}],syntax:'Dyn'})});
   const local=(ident,ty,initializer)=>({kind:'StmtKind::Let',local:{kind:'LocalKind::Init',pattern:{kind:'PatKind::Ident',bindingMode:'NONE',ident,subpattern:null},ty,initializer,attrs:[],tokens:null,mutable:false}});
   branches.push({condition:'FmtDebug::Full; fields>original CUTOFF',statements:[local('values',valuesTy,values)],body:call([root,'fmt','Formatter','debug_tuple_fields_finish'],[fmt,name,path(['values'])])});
  }
 }
 const closed=closeTupleDebugBranches(plan,branches,input,fields);
 // The candidate is DATA only. The private invocation issuer independently
 // joins current input/owner/source and the original resolver rule.
 return {schema:'original-debug-enclosing-grammar-candidate-v1',inputStyle:input.style,
  sources:plan.recipes.map(recipe=>({source:recipe.source,sourceSha256:recipe.sourceSha256,span:recipe.span,syntaxSha256:recipe.syntaxSha256,digest:recipe.digest})),
  branches:closed.map(branch=>({condition:branch.condition,statements:branch.statements.length,closure:branch.recursiveNamespaceClosure})),
  sourceControls:plan.sourceControls,generatedAttributes:['automatically_derived','inline'],
  sourceTypeRoundtrips:fields.map(field=>({name:field.name,typeSpan:field.typeSpan,sourceSha256:field.sourceSha256,semanticSyntaxRoundTrip:field.semanticSyntaxRoundTrip})),
  methodBehavior:'opaque-untranslated',namespaceAuthority:false,runtimeAuthority:false};
}
