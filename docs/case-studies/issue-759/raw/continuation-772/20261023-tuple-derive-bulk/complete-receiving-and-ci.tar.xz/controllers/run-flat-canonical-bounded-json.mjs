// Actual complete regeneration API; scalar resource observations only.
import {regenerate} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021/tools/translation/flat-native-retained-owned-field-bulk.mjs';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021',start=process.hrtime.bigint();
const result=regenerate({root,check:false,progress:record=>process.stderr.write(JSON.stringify({...record,elapsedMilliseconds:Number((process.hrtime.bigint()-start)/1000000n),memory:process.memoryUsage(),cpu:process.cpuUsage()})+'\n')});
console.log(JSON.stringify({...result.manifest.totals,projects:result.manifest.projects,functionCoverage:result.manifest.functionCoverage,failures:result.failures,runtimeParity:false,mode:'write',wholeGate:false,rustExecuted:false}));
if(result.failures.length)process.exitCode=1;
