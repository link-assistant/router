from pathlib import Path
import subprocess,os,json,hashlib,gzip,tarfile,io,time
ROOT=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021')
OUT=Path(os.environ['TMPDIR']); HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
NODE='/Users/konard/.nvm/versions/node/v20.19.4/bin/node'
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def names():
 paths=git('ls-files','-z','--','*.rs','Cargo.toml','Cargo.lock','tools/translation','scripts').decode().split('\0')
 return sorted(p for p in paths if p and (p.endswith('.rs')or not p.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/'))))
def capture(archive=None):
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 rows=[]; paths=names(); process=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for name in paths:
   process.stdin.write((HEAD+':'+name+'\n').encode());process.stdin.flush();h=process.stdout.readline().split();assert len(h)==3 and h[1]==b'blob',name
   n=int(h[2]);assert n<=128*1024**2;data=process.stdout.read(n);assert len(data)==n and process.stdout.read(1)==b'\n'
   p=ROOT/name;present=p.exists()or p.is_symlink()
   if present: assert p.is_file()and not p.is_symlink()and p.read_bytes()==data,name
   row=dict(path=name,bytes=n,sha256=hashlib.sha256(data).hexdigest(),physicalPresent=present);rows.append(row)
   if archive:
    item=tarfile.TarInfo(name);item.size=n;archive.addfile(item,io.BytesIO(data))
  process.stdin.close();assert process.wait()==0
 finally:
  if process.poll()is None:process.kill();process.wait()
 compiler=ROOT/'js/node_modules/typescript';assert compiler.is_dir()and not compiler.is_symlink();files=sorted(p for p in compiler.rglob('*')if p.is_file());assert len(files)==132;assert json.loads((compiler/'package.json').read_text())['version']=='5.9.3'
 for p in files:
  assert not p.is_symlink();data=p.read_bytes();name='js/node_modules/typescript/'+p.relative_to(compiler).as_posix();rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),physicalPresent=True))
  if archive:
   item=tarfile.TarInfo(name);item.size=len(data);archive.addfile(item,io.BytesIO(data))
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 return dict(sourceHead=HEAD,files=rows,typescript='5.9.3',rustExecuted=False)
with (OUT/'complete-original-canonical-inputs.tar.gz').open('xb')as f:
 with gzip.GzipFile(filename='',fileobj=f,mode='wb',compresslevel=1,mtime=0)as z:
  with tarfile.open(fileobj=z,mode='w|')as a:before=capture(a)
(OUT/'canonical-inputs-before.json').write_text(json.dumps(before)+'\n')
prior=(ROOT/'parity/rust-source-inventory.json').read_bytes(); (OUT/'complete-prior-inventory.json.gz').write_bytes(gzip.compress(prior,compresslevel=1,mtime=0))
cmd=[NODE,'/private/tmp/router-issue772-delivery-20261023/run-flat-canonical-bounded-json.mjs']
started=time.monotonic();child=subprocess.run(cmd,cwd=ROOT);after=capture();(OUT/'canonical-inputs-after.json').write_text(json.dumps(after)+'\n');same=before==after
result=dict(sourceHead=HEAD,exit=child.returncode,inputsUnchanged=same,sourceFiles=len(before['files']),sourceBytes=sum(r['bytes']for r in before['files']),seconds=time.monotonic()-started,rustExecuted=False,semanticAuthority=False)
(OUT/'canonical-generation-source-receipt.json').write_text(json.dumps(result)+'\n');print(json.dumps(result));assert same;raise SystemExit(child.returncode)
