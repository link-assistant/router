import {writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021',config=join(process.env.TMPDIR,'complete-canonical-tsconfig.json');
const options={compilerOptions:{strict:true,target:'ES2022',module:'ESNext',noEmit:true,skipLibCheck:true},include:[root+'/ts/generated/rust-draft/**/*.ts',root+'/ts/generated/rust-project/**/*.ts']};
writeFileSync(config,JSON.stringify(options)+'\n',{flag:'wx'});
const command=[process.execPath,root+'/js/node_modules/typescript/bin/tsc','-p',config],start=performance.now(),result=spawnSync(command[0],command.slice(1),{cwd:root,stdio:'inherit'});
console.log(JSON.stringify({command,options,exitCode:result.status,signal:result.signal,elapsedMs:performance.now()-start,strict:true,noEmit:true,wholeCanonicalTrees:true,profilesIncluded:false,wholeGate:false,rustExecuted:false}));
if(result.status!==0||result.error||result.signal)process.exitCode=1;
