import {runAuditedNodeTests} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021/scripts/run-node-tests.mjs';
import {join} from 'node:path';
const result=await runAuditedNodeTests({root:"/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-storage-repair-20261021",files:process.argv.slice(2),flags:['--test-concurrency=1'],outputDirectory:join(process.env.TMPDIR,'complete-Node-deadlines'),outerTimeoutMs:420000});
console.log(JSON.stringify({outputDirectory:result.outputDirectory,exitCode:result.exitCode,auditSummary:result.auditSummary,auditError:result.auditError,elapsedMs:result.elapsedMs}));process.exitCode=result.exitCode;
