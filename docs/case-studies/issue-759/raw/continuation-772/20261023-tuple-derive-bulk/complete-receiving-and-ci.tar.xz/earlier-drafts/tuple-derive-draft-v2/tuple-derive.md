# Tuple-struct derive namespace batch

The source producer extends Clone and Debug tuple-struct syntax together.
It copies complete original compiler helpers through native source selections,
separate language/repository substitution sequences, serialized/reparsed CST
stages and complete inverses. Existing public data-syntax and Debug route
domains remain unchanged; the actual private issuers explicitly select the
new tuple routes.

Clone constructs its original tuple constructor with ordered shared field
clone calls and retains both resolver branches. Debug retains None, Shallow
and Full modes, including the original five-field cutoff and the tuple
formatter's single values array for larger layouts. Both join the pinned
Rust compiler's tuple field parser and numeric field-identifier construction.

These connections close namespace uncertainty only for an independently
qualified original derive invocation. They do not implement Clone or Debug
trait execution, infer Copy or no-Drop, or admit an unknown sibling derive.
Conditional fields, field type macros, repr/packed layouts and generics keep
their existing refusals.

The batch has nine drafted Node/Bun cases and an independent Rust edge-case
oracle. Receiving execution, strict TypeScript, actual production coverage,
canonical/profile/reverse freshness and CI are pending. The Rust oracle must
run only in CI after the same-SHA JavaScript gate passes; no local Rust
invocation is permitted.

