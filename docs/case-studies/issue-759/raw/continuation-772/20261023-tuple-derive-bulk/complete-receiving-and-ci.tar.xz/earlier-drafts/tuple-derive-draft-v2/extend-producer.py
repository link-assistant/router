from pathlib import Path
p=Path(__file__).parent
source=(p/'original-clone-producer.mjs').read_text()
def once(text,old,new):
 assert text.count(old)==1,(old,text.count(old))
 return text.replace(old,new,1)
source=source.replace('prepareTupleClone','prepareTupleDerive').replace('tuple-clone','tuple-derive').replace('Tuple Clone','Tuple derive')
source=once(source,"const PIN='872986f8ffb8249f65186fff601c70e1d8625e8e42161a2c2d37ab8ffefadc93';","const PIN='3902f0a3e3e70ee0ffd87e7ec566d66b4182603fe3fbaa74a2153282abc98711';")
source=once(source,'packed.length!==18661','packed.length!==29094')
source=once(source,"originals.schema!=='tuple-derive-complete-originals-v1'||originals.files.length!==3","originals.schema!=='tuple-derive-complete-originals-v2'||originals.files.length!==4")
old="""  }else if(path.endsWith('/builtin-derive-bang-footprints.mjs')){
   language=replaceFunction(ts,path,language,'proveCloneDataOutput',source=>once(source,'const input=builtinPayloadDataInputs(', 'const input=builtinCloneDataInputs('),selections);
  }else fail('unknown source path');"""
new="""  }else if(path.endsWith('/builtin-derive-bang-footprints.mjs')){
   language=replaceFunction(ts,path,language,'proveCloneDataOutput',source=>once(source,'const input=builtinPayloadDataInputs(', 'const input=builtinCloneDataInputs('),selections);
   language=replaceFunction(ts,path,language,'debugDataInput',source=>once(source,'const input=builtinDebugDataInputs(', 'const input=builtinCloneDataInputs('),selections);
   language=replaceFunction(ts,path,language,'proveBuiltinDeriveBangFootprint',source=>once(source,'route=liftBuiltinDebugAstRoute(',\"route=(selected.input.style==='tuple-struct'?liftBuiltinDebugTupleAstRoute:liftBuiltinDebugAstRoute)(\"),selections);
   language=replaceFunction(ts,path,language,'proveBuiltinDebugEnclosingNamespace',source=>once(source,'grammar=compileBuiltinDebugEnclosingNamespaceModel(',\"grammar=(selected.input.style==='tuple-struct'?compileBuiltinDebugTupleEnclosingNamespaceModel:compileBuiltinDebugEnclosingNamespaceModel)(\"),selections);
  }else if(path.endsWith('/builtin-debug-ast-route.mjs')){
   const close=selectedFunction(ts,path,before,'closeBranches');
   let closing=once(close.source,'function closeBranches(','function closeTupleDebugBranches(');
   closing=once(closing,\"input.style==='named-struct'&&fields.length>plan.sourceControls.fieldCountCutoff&&branch.statements.length===2\",\"input.style==='tuple-struct'&&fields.length>plan.sourceControls.fieldCountCutoff&&branch.statements.length===1\");
   closing=once(closing,\"local.pattern.ident!==['names','values'][index]\",\"local.pattern.ident!=='values'\");
   selections.push({...close,name:'closeBranches',copiedAs:'closeTupleDebugBranches',replacement:closing});
   const sourcePlan=[
    'function tupleDebugSourcePlan(profile,entry){',
    ' const plan=sourcePlan(profile,entry),show=originalAstFunction(profile,directory+\\'debug.rs\\',\\'show_substructure\\'),access=originalAstFunction(profile,generic,\\'create_struct_field_access_fields\\'),parser=originalAstFunction(profile,\\'compiler/rustc_parse/src/parser/item.rs\\',\\'parse_tuple_struct_body\\');',
    ' contains(show,\\'Struct(vdata, fields) => (substr.type_ident, *vdata, fields)\\',\\'ast::VariantData::Tuple(..) => (false, 1)\\',\\'format!(\"debug_tuple_field{}_finish\", fields.len())\\',\\'sym::debug_tuple_fields_finish\\');',
    ' contains(access,\\'self.create_fields(struct_def, |i, struct_field, sp|\\',\\'Ident::from_str_and_span(&i.to_string(), struct_field.span)\\');',
    ' contains(parser,\\'self.parse_paren_comma_seq\\',\\'p.parse_outer_attributes()?\\',\\'let lo = p.token.span\\',\\'p.parse_visibility(FollowedByType::Yes)\\',\\'p.parse_ty()?\\');',
    ' return {...plan,recipes:[...plan.recipes,show,access,parser]};',
    '}',
   ].join('\\n');
   const copies=[];
   for(const name of ['liftBuiltinDebugAstRoute','compileBuiltinDebugEnclosingNamespaceModel']){
    const selected=selectedFunction(ts,path,before,name),replacementName=name==='liftBuiltinDebugAstRoute'?'liftBuiltinDebugTupleAstRoute':'compileBuiltinDebugTupleEnclosingNamespaceModel';
    let copied=once(selected.source,'function '+name+'(','function '+replacementName+'(');
    copied=once(copied,'sourcePlan(profile,entry)','tupleDebugSourcePlan(profile,entry)');
    copied=once(copied,'fresh=builtinDebugDataInputs(','fresh=builtinCloneDataInputs(');
    copied=once(copied,\" if(input.style==='payload-enum')\"+(name==='liftBuiltinDebugAstRoute'?'return liftPayloadEnum(profile,plan,original,certificate,input);':'return null;'),\" if(input.style!=='tuple-struct')throw new TypeError('Tuple Debug requires its explicit source input style');\");
    copied=once(copied,'closeBranches(plan,branches,input,fields)','closeTupleDebugBranches(plan,branches,input,fields)');
    copied=once(copied,\"originalFormat:'debug_struct_field{}_finish'\",\"originalFormat:'debug_tuple_field{}_finish'\");
    copied=once(copied,'...fields.flatMap((field,index)=>[string(field.name),last(fieldExpressions[index],index)])','...fieldExpressions.map(last)');
    copied=once(copied,\"statements:[local('names',namesTy,names),local('values',valuesTy,values)]\",\"statements:[local('values',valuesTy,values)]\");
    copied=once(copied,\"'debug_struct_fields_finish'\",\"'debug_tuple_fields_finish'\");
    copied=once(copied,\"[fmt,name,path(['names']),path(['values'])]\",\"[fmt,name,path(['values'])]\");
    selections.push({...selected,name,copiedAs:replacementName,replacement:copied});copies.push(copied);
   }
   language=before+'\\n// Explicit tuple Debug paths retain every original public source entry.\\n'+sourcePlan+'\\n'+closing+'\\n'+copies.join('\\n')+'\\n';
  }else fail('unknown source path');"""
source=once(source,old,new)
old="""   after=language.slice(0,at)+'builtinCloneDataInputs,'+language.slice(at);
  }"""
new="""   after=language.slice(0,at)+'builtinCloneDataInputs,'+language.slice(at);
   if(path.endsWith('/builtin-derive-bang-footprints.mjs')){
    const bound=parsed(ts,path,after),routes=bound.statements.filter(node=>ts.isImportDeclaration(node)&&node.moduleSpecifier.text==='./builtin-debug-ast-route.mjs');
    if(routes.length!==1||!ts.isNamedImports(routes[0].importClause.namedBindings))fail('one native Debug route import required');
    const at=routes[0].importClause.namedBindings.getStart(bound)+1;
    after=after.slice(0,at)+'liftBuiltinDebugTupleAstRoute,compileBuiltinDebugTupleEnclosingNamespaceModel,'+after.slice(at);
   }
  }"""
source=once(source,old,new)
source=source.replace("tuple-derive-source-preparation-v1","tuple-derive-source-preparation-v2")
(p/'prepare-tuple-derive.mjs').write_text(source)
test=(p/'tuple-clone.test.mjs').read_text().replace("../prepare-tuple-clone.mjs","../prepare-tuple-derive.mjs").replace("prepareTupleClone","prepareTupleDerive").replace("plan.files.length,3","plan.files.length,4")
(p/'tuple-derive.test.mjs').write_text(test)
print('draft producer and six complete original Clone cases written; Debug cases pending')

