#!/usr/bin/env node
/**
 * GitHub Merge Queue Library
 *
 * Provides utilities for the /merge command including:
 * - Label management (create/check 'ready' label)
 * - Fetching PRs with 'ready' label
 * - CI/CD status monitoring
 * - Sequential merge execution
 *
 * @see https://github.com/link-assistant/hive-mind/issues/1143
 */

import { promisify } from 'util';
import { exec as execCallback } from 'child_process';

const execRaw = promisify(execCallback);

import { parseGitHubUrl } from './github.lib.mjs';
import { githubLimits } from './config.lib.mjs';
import { ghWithRateLimitRetry } from './github-rate-limit.lib.mjs';
import { getTerminalGitHubEntityErrorMessage, isTerminalGitHubEntityError } from './github-terminal-state.lib.mjs';
import { cancellableSleep } from './interruptible-sleep.lib.mjs';
// Issue #2182: draft detection and merge-failure classification live in one
// pure module shared by every merge call site.
import { classifyMergeError, evaluatePullRequestMergeability } from './merge-error-classification.lib.mjs';
import { checkIssueLinksBeforeMerge, closeLinkedIssuesAfterMerge } from './issue-link-verification.lib.mjs';

// Issue #1722: gh api `--paginate --slurp` responses for repos with many
// historical workflow runs can easily exceed Node's default 1 MB exec buffer
// (observed 12.7 MB on this repo's main branch). Default to the configured
// githubLimits.bufferMaxSize (10 MB; HIVE_MIND_GITHUB_BUFFER_MAX_SIZE) for all
// gh calls in this file.
//
// Issue #1726: every gh call in the merge subsystem must be rate-limit safe.
// Wrapping the local `exec` shim ensures all 25+ call sites pick up retry
// behaviour without per-call changes. Non-rate-limit errors continue to throw
// so genuine failures (404, auth, malformed JSON downstream) surface to the
// caller — they MUST NOT be swallowed as in the original /merge bug where a
// rate-limit error was silently treated as "no workflows".
const exec = (cmd, opts = {}) =>
  ghWithRateLimitRetry(() => execRaw(cmd, { maxBuffer: githubLimits.bufferMaxSize, ...opts }), {
    label: `gh exec (${cmd.split(/\s+/).slice(0, 3).join(' ')})`,
  });

// Issue #1413: Import ready tag sync, timeline, and label constant from separate module
// to keep this file under the 1500 line limit
import { syncReadyTags, getLinkedPRsFromTimeline, READY_LABEL } from './github-merge-ready-sync.lib.mjs';
export { syncReadyTags, getLinkedPRsFromTimeline, READY_LABEL };

// Issue #1895: After merging into a non-default branch, close the linked issue
// explicitly (GitHub only auto-closes for default-branch merges). Extracted to a
// separate module to keep this file under the 1500-line limit.
import { closeLinkedIssueIfNotAutoClosed } from './github-merge-issue-close.lib.mjs';
export { closeLinkedIssueIfNotAutoClosed };

// Issue #2072: the long CI polling loops live in their own module (file size limit).
// Re-exported here so existing importers keep working.
import { waitForCI, waitForBranchCI } from './github-merge-ci-wait.lib.mjs';
export { waitForCI, waitForBranchCI };

/**
 * Check if 'ready' label exists in repository
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{exists: boolean, label: Object|null}>}
 */
export async function checkReadyLabelExists(owner, repo, verbose = false) {
  try {
    const { stdout } = await exec(`gh api repos/${owner}/${repo}/labels/${READY_LABEL.name} 2>/dev/null || echo ""`);
    if (stdout.trim()) {
      const label = JSON.parse(stdout.trim());
      // Check if the response is an error (404 Not Found returns JSON with "message" field)
      if (label.message === 'Not Found' || label.status === '404') {
        if (verbose) {
          console.log(`[VERBOSE] /merge: 'ready' label does not exist in ${owner}/${repo}`);
        }
        return { exists: false, label: null };
      }
      // Valid label has a 'name' field
      if (label.name) {
        if (verbose) {
          console.log(`[VERBOSE] /merge: 'ready' label exists in ${owner}/${repo}`);
        }
        return { exists: true, label };
      }
      // Unknown response format, treat as not found
      if (verbose) {
        console.log(`[VERBOSE] /merge: Unexpected response format when checking label in ${owner}/${repo}`);
      }
      return { exists: false, label: null };
    }
    if (verbose) {
      console.log(`[VERBOSE] /merge: 'ready' label does not exist in ${owner}/${repo}`);
    }
    return { exists: false, label: null };
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error checking label: ${error.message}`);
    }
    return { exists: false, label: null };
  }
}

/**
 * Create 'ready' label in repository
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{success: boolean, label: Object|null, error: string|null}>}
 */
export async function createReadyLabel(owner, repo, verbose = false) {
  try {
    // Use gh api with -f flags to pass fields directly (avoids shell heredoc compatibility issues)
    const { stdout } = await exec(`gh api repos/${owner}/${repo}/labels -X POST -H "Accept: application/vnd.github+json" -f name="${READY_LABEL.name}" -f description="${READY_LABEL.description}" -f color="${READY_LABEL.color}"`);
    const label = JSON.parse(stdout.trim());

    if (verbose) {
      console.log(`[VERBOSE] /merge: Created 'ready' label in ${owner}/${repo}`);
    }

    return { success: true, label, error: null };
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Failed to create label: ${error.message}`);
    }
    return { success: false, label: null, error: error.message };
  }
}

/**
 * Check if we have admin/write permissions to manage labels
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{canManageLabels: boolean, permission: string|null}>}
 */
export async function checkLabelPermissions(owner, repo, verbose = false) {
  try {
    const { stdout } = await exec(`gh api repos/${owner}/${repo} --jq .permissions`);
    const permissions = JSON.parse(stdout.trim());

    const canManageLabels = permissions.admin === true || permissions.push === true || permissions.maintain === true;

    if (verbose) {
      console.log(`[VERBOSE] /merge: Repository permissions for ${owner}/${repo}: ${JSON.stringify(permissions)}`);
      console.log(`[VERBOSE] /merge: Can manage labels: ${canManageLabels}`);
    }

    return {
      canManageLabels,
      permission: permissions.admin ? 'admin' : permissions.maintain ? 'maintain' : permissions.push ? 'push' : 'read',
    };
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error checking permissions: ${error.message}`);
    }
    return { canManageLabels: false, permission: null };
  }
}

/**
 * Ensure 'ready' label exists, creating it if we have permissions
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{success: boolean, created: boolean, error: string|null}>}
 */
export async function ensureReadyLabel(owner, repo, verbose = false) {
  // Check if label already exists
  const { exists } = await checkReadyLabelExists(owner, repo, verbose);
  if (exists) {
    return { success: true, created: false, error: null };
  }

  // Check permissions before trying to create
  const { canManageLabels } = await checkLabelPermissions(owner, repo, verbose);
  if (!canManageLabels) {
    return {
      success: false,
      created: false,
      error: `No permission to create labels in ${owner}/${repo}. Please ask a repository admin to create the 'ready' label.`,
    };
  }

  // Create the label
  const createResult = await createReadyLabel(owner, repo, verbose);
  if (createResult.success) {
    return { success: true, created: true, error: null };
  }

  return { success: false, created: false, error: createResult.error };
}

/**
 * Fetch all open PRs with 'ready' label
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<Array<Object>>} Array of PR objects sorted by creation date
 */
export async function fetchReadyPullRequests(owner, repo, verbose = false) {
  try {
    const { stdout } = await exec(`gh pr list --repo ${owner}/${repo} --label "${READY_LABEL.name}" --state open --json number,title,url,createdAt,headRefName,author,mergeable,mergeStateStatus --limit 100`);

    const prs = JSON.parse(stdout.trim() || '[]');

    if (verbose) {
      console.log(`[VERBOSE] /merge: Found ${prs.length} open PRs with 'ready' label in ${owner}/${repo}`);
    }

    // Sort by creation date (oldest first)
    prs.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));

    return prs;
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error fetching PRs: ${error.message}`);
    }
    return [];
  }
}

/**
 * Fetch all open issues with 'ready' label and find their linked PRs
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<Array<Object>>} Array of {issue, pr} objects sorted by creation date
 */
export async function fetchReadyIssuesWithPRs(owner, repo, verbose = false) {
  try {
    // Fetch open issues with 'ready' label
    const { stdout: issuesJson } = await exec(`gh issue list --repo ${owner}/${repo} --label "${READY_LABEL.name}" --state open --json number,title,url,createdAt --limit 100`);

    const issues = JSON.parse(issuesJson.trim() || '[]');

    if (verbose) {
      console.log(`[VERBOSE] /merge: Found ${issues.length} open issues with 'ready' label in ${owner}/${repo}`);
    }

    // For each issue, find linked PRs using the closing keyword search
    const result = [];
    for (const issue of issues) {
      try {
        // Search for PRs that reference this issue with closing keywords
        const { stdout: searchJson } = await exec(`gh pr list --repo ${owner}/${repo} --search "in:body closes #${issue.number} OR fixes #${issue.number} OR resolves #${issue.number}" --state open --json number,title,url,createdAt,headRefName,author,mergeable,mergeStateStatus --limit 5`);

        const linkedPRs = JSON.parse(searchJson.trim() || '[]');

        if (linkedPRs.length > 0) {
          // Take the first linked PR (oldest if multiple)
          linkedPRs.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
          result.push({
            issue,
            pr: linkedPRs[0],
            // Use minimum of issue and PR creation dates for sorting
            sortDate: new Date(Math.min(new Date(issue.createdAt), new Date(linkedPRs[0].createdAt))),
          });

          if (verbose) {
            console.log(`[VERBOSE] /merge: Issue #${issue.number} linked to PR #${linkedPRs[0].number}`);
          }
        } else if (verbose) {
          console.log(`[VERBOSE] /merge: Issue #${issue.number} has no linked open PR`);
        }
      } catch (err) {
        if (verbose) {
          console.log(`[VERBOSE] /merge: Error finding linked PR for issue #${issue.number}: ${err.message}`);
        }
      }
    }

    // Sort by the minimum creation date
    result.sort((a, b) => a.sortDate - b.sortDate);

    return result;
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error fetching issues: ${error.message}`);
    }
    return [];
  }
}

/**
 * Get combined list of ready PRs (from both direct PR labels and issue labels)
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<Array<Object>>} Array of PR objects with optional issue reference, sorted by creation date
 */
export async function getAllReadyPRs(owner, repo, verbose = false) {
  // Fetch both direct PRs and issue-linked PRs in parallel
  const [directPRs, issueLinkedPRs] = await Promise.all([fetchReadyPullRequests(owner, repo, verbose), fetchReadyIssuesWithPRs(owner, repo, verbose)]);

  // Build a map to deduplicate by PR number
  const prMap = new Map();

  // Add direct PRs
  for (const pr of directPRs) {
    prMap.set(pr.number, {
      pr,
      issue: null,
      sortDate: new Date(pr.createdAt),
    });
  }

  // Add issue-linked PRs (may override if PR is already in map)
  for (const { issue, pr, sortDate } of issueLinkedPRs) {
    const existing = prMap.get(pr.number);
    if (existing) {
      // If PR exists, use the minimum of both sort dates
      existing.issue = issue;
      existing.sortDate = new Date(Math.min(existing.sortDate, sortDate));
    } else {
      prMap.set(pr.number, { pr, issue, sortDate });
    }
  }

  // Convert to array and sort by sortDate
  const result = Array.from(prMap.values());
  result.sort((a, b) => a.sortDate - b.sortDate);

  if (verbose) {
    console.log(`[VERBOSE] /merge: Total unique ready PRs: ${result.length}`);
    for (const { pr, issue } of result) {
      const issueInfo = issue ? ` (linked to issue #${issue.number})` : '';
      console.log(`[VERBOSE] /merge:   PR #${pr.number}: ${pr.title}${issueInfo}`);
    }
  }

  return result;
}

/**
 * Check CI/CD status for a PR
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} prNumber - Pull request number
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{status: string, checks: Array<Object>, allPassed: boolean, hasPending: boolean}>}
 */
export async function checkPRCIStatus(owner, repo, prNumber, verbose = false) {
  try {
    // Get the PR's head SHA
    const { stdout: prJson } = await exec(`gh pr view ${prNumber} --repo ${owner}/${repo} --json headRefOid`);
    const prData = JSON.parse(prJson.trim());
    const sha = prData.headRefOid;

    const { stdout: checksJson } = await exec(`gh api repos/${owner}/${repo}/commits/${sha}/check-runs --paginate --slurp`);
    const checkRuns = JSON.parse(checksJson.trim() || '[]').flatMap(page => page.check_runs || []);

    // Get commit statuses (some CI systems use status API instead of checks API)
    const { stdout: statusJson } = await exec(`gh api repos/${owner}/${repo}/commits/${sha}/status --jq '.statuses'`);
    const statuses = JSON.parse(statusJson.trim() || '[]');

    // Combine both check runs and statuses
    const allChecks = [
      ...checkRuns.map(check => ({
        name: check.name,
        status: check.status,
        conclusion: check.conclusion,
        type: 'check_run',
        description: check.output?.title || check.output?.summary || null,
      })),
      ...statuses.map(status => ({
        name: status.context,
        status: status.state === 'pending' ? 'in_progress' : 'completed',
        conclusion: status.state === 'pending' ? null : status.state === 'success' ? 'success' : status.state === 'failure' ? 'failure' : status.state,
        type: 'status',
        description: status.description || null,
      })),
    ];

    // Issue #1304: If no checks exist yet, treat as pending
    // This handles the race condition where CI hasn't started yet after a commit is pushed.
    // An empty array would otherwise pass all checks due to JavaScript's vacuous truth
    // ([].every(fn) returns true for any fn).
    if (allChecks.length === 0) {
      if (verbose) {
        // Issue #1712: Reword for clarity — empty check-runs API response, not "no CI configured".
        const commitUrl = `https://github.com/${owner}/${repo}/commit/${sha}`;
        console.log(`[VERBOSE] /merge: PR #${prNumber} HEAD ${commitUrl} has no check-runs/statuses registered yet — treating as pending`);
      }
      return {
        status: 'pending',
        checks: [],
        allPassed: false,
        hasPending: true,
      };
    }

    const hasPending = allChecks.some(c => c.status !== 'completed' || c.conclusion === null);
    const allPassed = !hasPending && allChecks.every(c => c.conclusion === 'success' || c.conclusion === 'skipped' || c.conclusion === 'neutral');
    const hasFailed = allChecks.some(c => c.conclusion === 'failure' || c.conclusion === 'error' || c.conclusion === 'cancelled' || c.conclusion === 'timed_out');

    let status;
    if (hasPending) {
      status = 'pending';
    } else if (allPassed) {
      status = 'success';
    } else if (hasFailed) {
      status = 'failure';
    } else {
      status = 'unknown';
    }

    if (verbose) {
      console.log(`[VERBOSE] /merge: PR #${prNumber} CI status: ${status}`);
      console.log(`[VERBOSE] /merge:   Checks: ${allChecks.length}, Passed: ${allPassed}, Pending: ${hasPending}`);
      for (const check of allChecks) {
        console.log(`[VERBOSE] /merge:     - ${check.name}: ${check.status}/${check.conclusion}`);
      }
    }

    return {
      status,
      checks: allChecks,
      allPassed,
      hasPending,
    };
  } catch (error) {
    if (isTerminalGitHubEntityError(error)) {
      const terminalError = getTerminalGitHubEntityErrorMessage(error);
      if (verbose) console.log(`[VERBOSE] /merge: Terminal GitHub entity error while checking CI status for PR #${prNumber}: ${terminalError}`);
      return {
        status: 'terminal_github_entity_error',
        checks: [],
        allPassed: false,
        hasPending: false,
        error: terminalError,
      };
    }
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error checking CI status: ${error.message}`);
    }
    return {
      status: 'unknown',
      checks: [],
      allPassed: false,
      hasPending: false,
    };
  }
}

/**
 * Check if PR is mergeable
 *
 * Issue #1339: GitHub computes mergeability asynchronously. The first request may return
 * mergeable: null and mergeStateStatus: 'UNKNOWN' while the computation is in progress.
 * We retry up to 3 times with a 5-second delay between attempts to handle this case.
 *
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} prNumber - Pull request number
 * @param {boolean} verbose - Whether to log verbose output
 * @param {Object} [options] - Extra options
 * @param {Function} [options.isCancelled] - Issue #2072: polled during the retry delay so a cancel aborts the wait
 * @returns {Promise<{mergeable: boolean, mergeableState?: string|null, mergeStateStatus?: string|null, reason: string|null, terminal?: boolean, cancelled?: boolean}>}
 */
export async function checkPRMergeable(owner, repo, prNumber, verbose = false, options = {}) {
  const { isCancelled = null } = options;
  // Issue #1339: GitHub computes mergeability asynchronously. When mergeStateStatus is
  // 'UNKNOWN', it means GitHub hasn't calculated the merge state yet. Retry a few times.
  const MAX_UNKNOWN_RETRIES = 3;
  const UNKNOWN_RETRY_DELAY_MS = 5000;

  for (let attempt = 0; attempt < MAX_UNKNOWN_RETRIES; attempt++) {
    if (isCancelled?.()) return { mergeable: false, reason: 'Operation was cancelled', cancelled: true };
    try {
      // Issue #2182: `isDraft` MUST be part of this query. GitHub answers
      // mergeable=MERGEABLE / mergeStateStatus=CLEAN for a draft pull request
      // with no other blockers, so without this field a draft PR was declared
      // mergeable and `gh pr merge` failed forever with
      // "Pull Request is still a draft".
      const { stdout } = await exec(`gh pr view ${prNumber} --repo ${owner}/${repo} --json isDraft,mergeable,mergeStateStatus`);
      const pr = JSON.parse(stdout.trim());

      // Issue #1339: If mergeStateStatus is 'UNKNOWN', GitHub is still computing.
      // Wait and retry instead of immediately skipping the PR.
      if (pr.mergeStateStatus === 'UNKNOWN' || pr.mergeable === null) {
        if (attempt < MAX_UNKNOWN_RETRIES - 1) {
          if (verbose) {
            console.log(`[VERBOSE] /merge: PR #${prNumber} mergeability is UNKNOWN (attempt ${attempt + 1}/${MAX_UNKNOWN_RETRIES}), retrying in ${UNKNOWN_RETRY_DELAY_MS / 1000}s...`);
          }
          await cancellableSleep(UNKNOWN_RETRY_DELAY_MS, isCancelled);
          continue;
        }
        // All retries exhausted, still UNKNOWN - treat as not mergeable
        if (verbose) {
          console.log(`[VERBOSE] /merge: PR #${prNumber} mergeability still UNKNOWN after ${MAX_UNKNOWN_RETRIES} attempts`);
        }
        return { mergeable: false, mergeableState: pr.mergeable, mergeStateStatus: pr.mergeStateStatus, reason: `Merge state: UNKNOWN (GitHub could not compute mergeability after ${MAX_UNKNOWN_RETRIES} attempts)` };
      }

      const evaluation = evaluatePullRequestMergeability(pr);

      if (verbose) {
        // Issue #2182: isDraft is logged explicitly. In the reported 4.5-day run
        // the log only ever showed "mergeable: true, state: CLEAN", which hid the
        // actual blocker.
        console.log(`[VERBOSE] /merge: PR #${prNumber} mergeable: ${evaluation.mergeable}, state: ${pr.mergeStateStatus}, isDraft: ${pr.isDraft === true}`);
      }

      return { mergeable: evaluation.mergeable, isDraft: evaluation.isDraft, mergeableState: evaluation.mergeableState, mergeStateStatus: evaluation.mergeStateStatus, reason: evaluation.reason };
    } catch (error) {
      if (isTerminalGitHubEntityError(error)) {
        const terminalError = getTerminalGitHubEntityErrorMessage(error);
        if (verbose) console.log(`[VERBOSE] /merge: Terminal GitHub entity error while checking mergeability for PR #${prNumber}: ${terminalError}`);
        return { mergeable: false, reason: terminalError, terminal: true };
      }

      if (verbose) {
        console.log(`[VERBOSE] /merge: Error checking mergeability: ${error.message}`);
      }
      return { mergeable: false, reason: error.message };
    }
  }

  // Should not reach here, but return safe default
  return { mergeable: false, reason: 'Merge state: UNKNOWN' };
}

/**
 * Check if the authenticated user has write/merge permissions on the repository
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{canMerge: boolean, permission: string|null}>}
 */
export async function checkMergePermissions(owner, repo, verbose = false) {
  try {
    const { stdout } = await exec(`gh api repos/${owner}/${repo} --jq '.permissions'`);
    const permissions = JSON.parse(stdout.trim());

    const canMerge = permissions.admin === true || permissions.maintain === true || permissions.push === true;

    if (verbose) {
      console.log(`[VERBOSE] /merge: Merge permissions for ${owner}/${repo}: push=${permissions.push}, admin=${permissions.admin}, maintain=${permissions.maintain}`);
      console.log(`[VERBOSE] /merge: Can merge: ${canMerge}`);
    }

    return {
      canMerge,
      permission: permissions.admin ? 'admin' : permissions.maintain ? 'maintain' : permissions.push ? 'push' : 'read',
    };
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error checking merge permissions: ${error.message}`);
    }
    return { canMerge: false, permission: null };
  }
}

/**
 * Merge a pull request
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} prNumber - Pull request number
 * @param {Object} options - Merge options
 * @param {string} options.mergeMethod - Merge method: 'merge', 'squash', or 'rebase' (default: 'merge'). Must specify one method non-interactively (Issue #1269).
 * @param {boolean} options.squash - DEPRECATED: Use mergeMethod: 'squash' instead
 * @param {boolean} options.deleteAfter - Whether to delete branch after merge (default: false)
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
export async function mergePullRequest(owner, repo, prNumber, options = {}, verbose = false) {
  const { mergeMethod = 'merge', squash = false, deleteAfter = false } = options;

  try {
    // Issue #2335: every merge entry point, including the queue, re-reads the
    // description and refuses to merge a pull request that does not close its issues.
    const links = await checkIssueLinksBeforeMerge({ owner, repo, prNumber, issueNumber: options.issueNumber, logger: async message => console.log(message), verbose });
    if (links.blocker) return { success: false, error: links.blocker.message, category: links.blocker.reason, terminal: true, recoverable: false, resolution: links.blocker.resolution, blocker: links.blocker };
    let mergeArgs = `--repo ${owner}/${repo}`;

    // Issue #1269: gh pr merge requires --merge, --squash, or --rebase when running non-interactively
    // We must always specify a merge method to prevent the command from hanging or failing
    if (squash || mergeMethod === 'squash') {
      mergeArgs += ' --squash';
    } else if (mergeMethod === 'rebase') {
      mergeArgs += ' --rebase';
    } else {
      // Default to --merge for standard merge commits
      mergeArgs += ' --merge';
    }

    if (deleteAfter) {
      mergeArgs += ' --delete-branch';
    }

    const { stdout } = await exec(`gh pr merge ${prNumber} ${mergeArgs}`);
    const unclosedIssues = await closeLinkedIssuesAfterMerge(links.snapshot, { logger: async message => console.warn(message) });

    if (verbose) {
      console.log(`[VERBOSE] /merge: Successfully merged PR #${prNumber}`);
      if (stdout) console.log(`[VERBOSE] /merge: stdout: ${stdout.trim()}`);
    }

    return { success: true, error: null, unclosedIssues };
  } catch (error) {
    // Issue #2182: classify the failure so watch loops can stop (or self-heal)
    // instead of retrying an impossible merge every 120 seconds forever.
    const classification = classifyMergeError(error.message);
    if (verbose) {
      console.log(`[VERBOSE] /merge: Failed to merge PR #${prNumber}: ${error.message}`);
      console.log(`[VERBOSE] /merge: Failure category: ${classification.category} (terminal=${classification.terminal}, recoverable=${classification.recoverable})`);
    }
    return { success: false, error: error.message, category: classification.category, terminal: classification.terminal, recoverable: classification.recoverable, resolution: classification.resolution };
  }
}

// Issue #2182: re-exported so merge call sites can import classification from
// the same module they already use for merging.
export { classifyMergeError, evaluatePullRequestMergeability, MERGE_ERROR_CATEGORIES, MAX_CONSECUTIVE_MERGE_FAILURES } from './merge-error-classification.lib.mjs';

/**
 * Parse and validate a repository URL for the merge command
 * @param {string} url - Repository URL
 * @returns {{valid: boolean, owner: string|null, repo: string|null, error: string|null}}
 */
export function parseRepositoryUrl(url) {
  const parsed = parseGitHubUrl(url);

  if (!parsed.valid) {
    return { valid: false, owner: null, repo: null, error: parsed.error };
  }

  // Accept repo, issues_list, pulls_list, or organization URLs
  if (parsed.type === 'repo' || parsed.type === 'issues_list' || parsed.type === 'pulls_list') {
    return { valid: true, owner: parsed.owner, repo: parsed.repo, error: null };
  }

  if (parsed.type === 'user' || parsed.type === 'organization') {
    return {
      valid: false,
      owner: parsed.owner,
      repo: null,
      error: 'URL points to a user/organization. Please provide a specific repository URL.',
    };
  }

  return {
    valid: false,
    owner: parsed.owner,
    repo: parsed.repo,
    error: `URL type '${parsed.type}' is not supported for merge queue. Please provide a repository URL.`,
  };
}

/**
 * Statuses we treat as "still running" / "not yet finished".
 * Issue #1722: be exhaustive — GitHub uses several non-completed statuses.
 */
const ACTIVE_RUN_STATUSES = ['in_progress', 'queued', 'waiting', 'requested', 'pending'];

/**
 * Get active workflow runs on a specific branch
 * Issue #1307: Used to check if there are any in-progress or queued runs on the target branch
 * Issue #1722: Filter on the server side per status, otherwise the unfiltered
 * `--paginate --slurp` response can overflow exec maxBuffer on busy repos
 * (observed 12.7 MB on link-assistant/hive-mind main). Also: errors are now
 * surfaced rather than swallowed as `hasActiveRuns: false`, which previously
 * caused /merge to merge on top of a still-running CI run.
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {string} branch - Branch name (default: main)
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{runs: Array<Object>, hasActiveRuns: boolean, count: number}>}
 */
export async function getActiveBranchRuns(owner, repo, branch = 'main', verbose = false) {
  const seen = new Set();
  const runs = [];
  for (const status of ACTIVE_RUN_STATUSES) {
    const { stdout } = await exec(`gh api "repos/${owner}/${repo}/actions/runs?branch=${branch}&status=${status}&per_page=100" --paginate --slurp`);
    const pages = JSON.parse(stdout.trim() || '[]');
    for (const page of pages) {
      for (const run of page.workflow_runs || []) {
        if (seen.has(run.id)) continue;
        seen.add(run.id);
        runs.push({
          id: run.id,
          name: run.name,
          status: run.status,
          created_at: run.created_at,
          html_url: run.html_url,
        });
      }
    }
  }

  if (verbose) {
    console.log(`[VERBOSE] /merge: Found ${runs.length} active runs on ${owner}/${repo} branch ${branch}`);
    for (const run of runs) {
      console.log(`[VERBOSE] /merge:   - Run #${run.id}: ${run.name} (${run.status})`);
    }
  }

  return {
    runs,
    hasActiveRuns: runs.length > 0,
    count: runs.length,
  };
}

/**
 * Get the default branch for a repository
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<string>} Default branch name (e.g., 'main' or 'master')
 */
export async function getDefaultBranch(owner, repo, verbose = false) {
  try {
    const { stdout } = await exec(`gh api repos/${owner}/${repo} --jq '.default_branch'`);
    const branch = stdout.trim();

    if (verbose) {
      console.log(`[VERBOSE] /merge: Default branch for ${owner}/${repo}: ${branch}`);
    }

    return branch || 'main';
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error getting default branch, falling back to 'main': ${error.message}`);
    }
    return 'main';
  }
}

/**
 * Get annotations for a check run
 * Issue #1314: Used to detect billing limit errors
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} checkRunId - Check run ID
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<Array<Object>>} Array of annotation objects
 */
export async function getCheckRunAnnotations(owner, repo, checkRunId, verbose = false) {
  try {
    const { stdout } = await exec(`gh api repos/${owner}/${repo}/check-runs/${checkRunId}/annotations --paginate 2>/dev/null || echo "[]"`);
    const annotations = JSON.parse(stdout.trim() || '[]');

    if (verbose) {
      console.log(`[VERBOSE] /merge: Check run ${checkRunId} has ${annotations.length} annotations`);
    }

    return annotations;
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error fetching annotations for check run ${checkRunId}: ${error.message}`);
    }
    return [];
  }
}

/**
 * Check if repository is private
 * Issue #1314: Used to determine behavior when billing limits are reached
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{isPrivate: boolean, visibility: string|null}>}
 */
export async function getRepoVisibility(owner, repo, verbose = false) {
  try {
    const { stdout } = await exec(`gh api repos/${owner}/${repo} --jq '{isPrivate: .private, visibility: .visibility}'`);
    const info = JSON.parse(stdout.trim());

    if (verbose) {
      console.log(`[VERBOSE] /merge: Repository ${owner}/${repo} visibility: ${info.visibility}, private: ${info.isPrivate}`);
    }

    return {
      isPrivate: info.isPrivate === true,
      visibility: info.visibility || null,
    };
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error checking repository visibility: ${error.message}`);
    }
    // Assume private if we can't determine (safer default)
    return { isPrivate: true, visibility: null };
  }
}

/**
 * Known billing limit error message pattern
 * Issue #1314: This is the exact message GitHub uses for billing/spending limit errors
 */
export const BILLING_LIMIT_ERROR_PATTERN = 'The job was not started because recent account payments have failed or your spending limit needs to be increased';

/**
 * Check if CI failure is due to billing/spending limits
 * Issue #1314: Detects when GitHub Actions jobs fail due to billing issues rather than code problems
 *
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} prNumber - Pull request number
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{isBillingLimitError: boolean, message: string|null, affectedJobs: string[], allJobsAffected: boolean}>}
 */
export async function checkForBillingLimitError(owner, repo, prNumber, verbose = false) {
  try {
    const { stdout: prJson } = await exec(`gh pr view ${prNumber} --repo ${owner}/${repo} --json headRefOid`);
    const prData = JSON.parse(prJson.trim());
    const sha = prData.headRefOid;

    const { stdout: runsJson } = await exec(`gh api "repos/${owner}/${repo}/actions/runs?head_sha=${sha}&per_page=100" --paginate --slurp`);
    const runIds = JSON.parse(runsJson.trim() || '[]')
      .flatMap(page => page.workflow_runs || [])
      .map(run => run.id);

    if (verbose) {
      console.log(`[VERBOSE] /merge: Found ${runIds.length} workflow runs for PR #${prNumber} at SHA ${sha.substring(0, 7)}`);
    }

    const affectedJobs = [];
    let totalJobs = 0;

    for (const runId of runIds) {
      try {
        const { stdout: jobsJson } = await exec(`gh api repos/${owner}/${repo}/actions/runs/${runId}/jobs --paginate --slurp`);
        const jobs = JSON.parse(jobsJson.trim() || '[]').flatMap(page => page.jobs || []);

        for (const job of jobs) {
          totalJobs++;

          // Check for billing limit indicators:
          // 1. Conclusion is failure
          // 2. Steps array is empty (no steps were executed)
          // 3. Runner ID is 0 or null (no runner was assigned)
          const hasNoSteps = !job.steps || job.steps.length === 0;
          const hasNoRunner = job.runner_id === 0 || job.runner_id === null;

          if (job.conclusion === 'failure' && hasNoSteps && hasNoRunner) {
            // Fetch annotations to confirm billing limit error
            const annotations = await getCheckRunAnnotations(owner, repo, job.id, verbose);

            const billingAnnotation = annotations.find(a => a.message?.includes(BILLING_LIMIT_ERROR_PATTERN));

            if (billingAnnotation) {
              affectedJobs.push(job.name);

              if (verbose) {
                console.log(`[VERBOSE] /merge: Job "${job.name}" (ID: ${job.id}) failed due to billing limits`);
              }
            }
          }
        }
      } catch (error) {
        if (verbose) {
          console.log(`[VERBOSE] /merge: Error checking jobs for run ${runId}: ${error.message}`);
        }
      }
    }

    const isBillingLimitError = affectedJobs.length > 0;
    const allJobsAffected = totalJobs > 0 && affectedJobs.length === totalJobs;

    if (verbose && isBillingLimitError) {
      console.log(`[VERBOSE] /merge: Billing limit detected - ${affectedJobs.length}/${totalJobs} jobs affected`);
    }

    return {
      isBillingLimitError,
      message: isBillingLimitError ? BILLING_LIMIT_ERROR_PATTERN : null,
      affectedJobs,
      allJobsAffected,
    };
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error checking for billing limit: ${error.message}`);
    }
    return {
      isBillingLimitError: false,
      message: null,
      affectedJobs: [],
      allJobsAffected: false,
    };
  }
}

/**
 * Re-run all jobs in a workflow run
 * Issue #1314: Used to re-trigger CI jobs that were cancelled or not started
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} runId - Workflow run ID
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
export async function rerunWorkflowRun(owner, repo, runId, verbose = false) {
  try {
    await exec(`gh api repos/${owner}/${repo}/actions/runs/${runId}/rerun -X POST`);
    // GitHub returns 201 on success
    if (verbose) {
      console.log(`[VERBOSE] /merge: Successfully triggered re-run for workflow ${runId}`);
    }
    return { success: true, error: null };
  } catch (error) {
    // exec throws when command exits non-zero (e.g., 404 Not Found)
    const errorMessage = error.stderr?.trim() || error.stdout?.trim() || error.message;
    if (verbose) {
      console.log(`[VERBOSE] /merge: Failed to re-run workflow ${runId}: ${errorMessage}`);
    }
    return { success: false, error: errorMessage };
  }
}

/**
 * Re-run only failed jobs in a workflow run
 * Issue #1314: More targeted than full re-run, only retries failed jobs
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} runId - Workflow run ID
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
export async function rerunFailedJobs(owner, repo, runId, verbose = false) {
  try {
    await exec(`gh api repos/${owner}/${repo}/actions/runs/${runId}/rerun-failed-jobs -X POST`);
    // GitHub returns 201 on success
    if (verbose) {
      console.log(`[VERBOSE] /merge: Successfully triggered re-run of failed jobs for workflow ${runId}`);
    }
    return { success: true, error: null };
  } catch (error) {
    const errorMessage = error.stderr?.trim() || error.stdout?.trim() || error.message;
    if (verbose) {
      console.log(`[VERBOSE] /merge: Failed to re-run failed jobs for workflow ${runId}: ${errorMessage}`);
    }
    return { success: false, error: errorMessage };
  }
}

/**
 * Get detailed CI status for a PR, distinguishing between different non-success states
 * Issue #1314: Enhanced version that separates cancelled, queued, and billing-limited states
 *
 * Possible returned statuses:
 * - 'success': All checks passed
 * - 'failure': Some checks failed (genuine code failures, timed_out, or action_required)
 * - 'cancelled': Some checks were cancelled or stale (need re-triggering)
 * - 'pending': Some checks are still running, queued, waiting, or requested
 * - 'billing_limit': Failures are due to billing/spending limits (determined by caller)
 * - 'no_checks': No CI checks found yet (race condition after push)
 * - 'unknown': Unable to determine status
 *
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number} prNumber - Pull request number
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<Object>} Detailed CI status object
 */
export async function getDetailedCIStatus(owner, repo, prNumber, verbose = false) {
  try {
    // Get the PR's head SHA
    const { stdout: prJson } = await exec(`gh pr view ${prNumber} --repo ${owner}/${repo} --json headRefOid`);
    const prData = JSON.parse(prJson.trim());
    const sha = prData.headRefOid;

    const { stdout: checksJson } = await exec(`gh api repos/${owner}/${repo}/commits/${sha}/check-runs --paginate --slurp`);
    const checkRuns = JSON.parse(checksJson.trim() || '[]').flatMap(page => page.check_runs || []);

    // Get commit statuses
    const { stdout: statusJson } = await exec(`gh api repos/${owner}/${repo}/commits/${sha}/status --jq '.statuses'`);
    const statuses = JSON.parse(statusJson.trim() || '[]');

    // Build detailed checks list
    // Issue #1712: Include html_url so the user-facing waiting message can include
    // a clickable link for each pending/failing check.
    const allChecks = [
      ...checkRuns.map(check => ({
        name: check.name,
        status: check.status, // queued, in_progress, completed
        conclusion: check.conclusion, // success, failure, cancelled, timed_out, skipped, neutral, action_required, stale, null
        type: 'check_run',
        id: check.id,
        description: check.output?.title || check.output?.summary || null,
        html_url: check.html_url || check.details_url || null,
      })),
      ...statuses.map(status => ({
        name: status.context,
        status: status.state === 'pending' ? 'in_progress' : 'completed',
        conclusion: status.state === 'pending' ? null : status.state === 'success' ? 'success' : status.state === 'failure' ? 'failure' : status.state,
        type: 'status',
        id: null,
        description: status.description || null,
        html_url: status.target_url || null,
      })),
    ];

    // No checks yet
    if (allChecks.length === 0) {
      if (verbose) {
        // Issue #1712: Reword to avoid "no CI checks" sounding like "no CI configured".
        // We are inspecting the GitHub `/commits/{sha}/check-runs` and `/commits/{sha}/status` endpoints;
        // an empty result means no check-runs/statuses are registered yet for this commit, NOT that the
        // repository has no CI/CD workflows. The caller (`getMergeBlockers`) decides between race
        // condition vs. "no CI configured" based on additional API calls.
        const commitUrl = `https://github.com/${owner}/${repo}/commit/${sha}`;
        console.log(`[VERBOSE] /merge: PR #${prNumber} HEAD ${commitUrl} has no check-runs or commit statuses registered yet (status=no_checks; race vs. no-CI distinction is decided downstream)`);
      }
      return {
        status: 'no_checks',
        checks: [],
        sha,
        hasFailures: false,
        hasCancelled: false,
        hasStale: false,
        hasPending: false,
        hasQueued: false,
        allPassed: false,
        failedChecks: [],
        cancelledChecks: [],
        staleChecks: [],
        pendingChecks: [],
        queuedChecks: [],
        passedChecks: [],
      };
    }

    // Categorize checks
    // Note: GitHub check run conclusions include: success, failure, cancelled, timed_out, skipped,
    // neutral, action_required, stale, null (not yet completed)
    // GitHub check run statuses include: queued, in_progress, completed, waiting, requested, pending
    const passedChecks = allChecks.filter(c => c.conclusion === 'success' || c.conclusion === 'skipped' || c.conclusion === 'neutral');
    const failedChecks = allChecks.filter(c => c.conclusion === 'failure' || c.conclusion === 'error' || c.conclusion === 'timed_out' || c.conclusion === 'action_required');
    const cancelledChecks = allChecks.filter(c => c.conclusion === 'cancelled');
    const staleChecks = allChecks.filter(c => c.conclusion === 'stale');
    const pendingChecks = allChecks.filter(c => (c.status === 'in_progress' || c.status === 'waiting' || c.status === 'requested' || c.status === 'pending') && c.conclusion === null);
    const queuedChecks = allChecks.filter(c => c.status === 'queued' && c.conclusion === null);

    const hasFailures = failedChecks.length > 0;
    const hasCancelled = cancelledChecks.length > 0;
    const hasStale = staleChecks.length > 0;
    const hasPending = pendingChecks.length > 0;
    const hasQueued = queuedChecks.length > 0;
    const allPassed = !hasFailures && !hasCancelled && !hasStale && !hasPending && !hasQueued && passedChecks.length === allChecks.length;

    // Determine overall status
    let status;
    if (allPassed) {
      status = 'success';
    } else if (hasPending || hasQueued) {
      // Some checks are still running, queued, or waiting for a runner - wait for completion
      status = 'pending';
    } else if (hasStale && !hasFailures && !hasCancelled) {
      // Stale checks need to be re-triggered (similar to cancelled)
      status = 'cancelled';
    } else if (hasFailures && !hasCancelled && !hasStale) {
      status = 'failure';
    } else if ((hasCancelled || hasStale) && !hasFailures) {
      status = 'cancelled';
    } else if (hasFailures && (hasCancelled || hasStale)) {
      // Mixed: some failed, some cancelled/stale - report as failure (the failures need attention)
      status = 'failure';
    } else {
      status = 'unknown';
    }

    if (verbose) {
      console.log(`[VERBOSE] /merge: PR #${prNumber} detailed CI status: ${status}`);
      console.log(`[VERBOSE] /merge:   Total: ${allChecks.length}, Passed: ${passedChecks.length}, Failed: ${failedChecks.length}, Cancelled: ${cancelledChecks.length}, Stale: ${staleChecks.length}, Pending: ${pendingChecks.length}, Queued: ${queuedChecks.length}`);
    }

    return {
      status,
      checks: allChecks,
      sha,
      hasFailures,
      hasCancelled,
      hasStale,
      hasPending,
      hasQueued,
      allPassed,
      failedChecks,
      cancelledChecks,
      staleChecks,
      pendingChecks,
      queuedChecks,
      passedChecks,
    };
  } catch (error) {
    if (isTerminalGitHubEntityError(error)) {
      const terminalError = getTerminalGitHubEntityErrorMessage(error);
      if (verbose) console.log(`[VERBOSE] /merge: Terminal GitHub entity error while getting detailed CI status for PR #${prNumber}: ${terminalError}`);
      return {
        status: 'terminal_github_entity_error',
        checks: [],
        sha: null,
        hasFailures: false,
        hasCancelled: false,
        hasStale: false,
        hasPending: false,
        hasQueued: false,
        allPassed: false,
        failedChecks: [],
        cancelledChecks: [],
        staleChecks: [],
        pendingChecks: [],
        queuedChecks: [],
        passedChecks: [],
        error: terminalError,
      };
    }
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error getting detailed CI status: ${error.message}`);
    }
    return {
      status: 'unknown',
      checks: [],
      sha: null,
      hasFailures: false,
      hasCancelled: false,
      hasStale: false,
      hasPending: false,
      hasQueued: false,
      allPassed: false,
      failedChecks: [],
      cancelledChecks: [],
      staleChecks: [],
      pendingChecks: [],
      queuedChecks: [],
      passedChecks: [],
    };
  }
}

/**
 * Get workflow run IDs for a specific commit SHA
 * Issue #1314: Helper to find workflow runs to re-trigger
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {string} sha - Commit SHA
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<Array<{id: number, status: string, conclusion: string|null, name: string, html_url: string, path: string}>>}
 */
export async function getWorkflowRunsForSha(owner, repo, sha, verbose = false) {
  try {
    const { stdout } = await exec(`gh api "repos/${owner}/${repo}/actions/runs?head_sha=${sha}&per_page=100" --paginate --slurp`);
    const runs = JSON.parse(stdout.trim() || '[]')
      .flatMap(page => page.workflow_runs || [])
      .map(run => ({ id: run.id, status: run.status, conclusion: run.conclusion, name: run.name, html_url: run.html_url, path: run.path }));

    if (verbose) {
      // Issue #1712: Include the commit URL (not just SHA) and the workflow run html_url
      // so the user can click through to GitHub instead of pasting IDs into a URL by hand.
      // The run html_url already encodes the run ID, so we don't repeat it as a separate field.
      const commitUrl = `https://github.com/${owner}/${repo}/commit/${sha}`;
      console.log(`[VERBOSE] /merge: Found ${runs.length} workflow run(s) for ${commitUrl}`);
      for (const run of runs) {
        const concPart = run.conclusion ? `/${run.conclusion}` : '';
        console.log(`[VERBOSE] /merge:   - ${run.name} [${run.status}${concPart}]: ${run.html_url}`);
      }
    }

    return runs;
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error fetching workflow runs for SHA ${sha}: ${error.message}`);
    }
    return [];
  }
}

/**
 * Get the job count for a specific workflow run.
 *
 * Issue #1690: Used to detect "invalid workflow file" failures. When a workflow file
 * has a syntax error (e.g., `Unrecognized named-value: 'env'`), GitHub creates a
 * workflow_run with `status=completed, conclusion=failure` but never instantiates
 * any jobs — `total_count: 0`. Such workflow runs will never produce check-runs.
 *
 * Distinguishing this from a real failure (where check-runs exist for the failed jobs)
 * lets the auto-merge loop break out of "waiting for check-runs to appear" and
 * propagate the error to the AI solver as a real failure.
 *
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {number|string} runId - Workflow run ID
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<number|null>} - Total job count, or null on error
 */
export async function getWorkflowRunJobsCount(owner, repo, runId, verbose = false) {
  try {
    // Issue #1690: We only need the total_count field, so a single page is sufficient and
    // adding --paginate would defeat the --jq selector. Use --silent to bypass the
    // pagination linter rule because total_count comes from the response root.
    /* eslint-disable-next-line gh-paginate/require-gh-paginate */
    const { stdout } = await exec(`gh api "repos/${owner}/${repo}/actions/runs/${runId}/jobs?per_page=1" --jq '.total_count'`);
    const count = parseInt(stdout.trim(), 10);
    if (Number.isNaN(count)) {
      if (verbose) {
        console.log(`[VERBOSE] /merge: Could not parse job count for workflow run ${runId} (got: "${stdout.trim()}")`);
      }
      return null;
    }
    if (verbose) {
      console.log(`[VERBOSE] /merge: Workflow run ${runId} has ${count} job(s)`);
    }
    return count;
  } catch (error) {
    if (verbose) {
      console.log(`[VERBOSE] /merge: Error fetching jobs for workflow run ${runId}: ${error.message}`);
    }
    return null;
  }
}

/**
 * Get the count of active (enabled) GitHub Actions workflows in a repository
 * Issue #1363: Used to distinguish between "no CI configured" and "CI hasn't started yet"
 *
 * When a repo has NO workflows, no_checks means no CI configured.
 * When a repo HAS workflows, no_checks means CI checks haven't started yet (race condition).
 *
 * Issue #1399: GitHub Pages deployment workflows (path: "dynamic/pages/...") are excluded
 * because they only run on the default branch after merge, never on PR branches. Counting
 * them as "CI workflows" causes an infinite loop waiting for check-runs that never appear.
 *
 * @param {string} owner - Repository owner
 * @param {string} repo - Repository name
 * @param {boolean} verbose - Whether to log verbose output
 * @returns {Promise<{count: number, hasWorkflows: boolean, workflows: Array<{id: number, name: string, state: string, path: string}>}>}
 */
export async function getActiveRepoWorkflows(owner, repo, verbose = false) {
  // Issue #1726: this function previously swallowed every error as "no workflows",
  // including GitHub API rate-limit responses. The /merge command then thought CI
  // was unconfigured and proceeded as if checks had passed — a hard failure mode
  // visible in the original case-study log where errors were thrown but the
  // process exited 0.
  //
  // Rate-limit errors are now retried inside the local exec() wrapper. After
  // retries are exhausted, the error MUST propagate so callers can decide
  // whether to abort or continue — never default to "no workflows".
  const { stdout } = await exec(`gh api "repos/${owner}/${repo}/actions/workflows" --paginate --slurp`);
  const allWorkflows = JSON.parse(stdout.trim() || '[]')
    .flatMap(page => page.workflows || [])
    .filter(workflow => workflow.state === 'active')
    .map(workflow => ({ id: workflow.id, name: workflow.name, state: workflow.state, path: workflow.path }));

  // GitHub Pages workflows only run after merge and never produce PR check-runs.
  const workflows = allWorkflows.filter(wf => !wf.path.startsWith('dynamic/pages/'));

  if (verbose) {
    console.log(`[VERBOSE] /merge: Found ${allWorkflows.length} active workflows in ${owner}/${repo} (${workflows.length} PR-relevant after filtering out GitHub Pages deployment workflows)`);
    for (const wf of allWorkflows) {
      const filtered = wf.path.startsWith('dynamic/pages/');
      console.log(`[VERBOSE] /merge:   - ${wf.name} (${wf.id}): ${wf.state}, path=${wf.path}${filtered ? ' [excluded: GitHub Pages deployment]' : ''}`);
    }
  }

  return {
    count: workflows.length,
    hasWorkflows: workflows.length > 0,
    workflows,
  };
}

// Issue #1690: Re-export CI signal helpers from separate module to keep this file under 1500 lines
import { getCommitDate, checkPreviousPRCommitsHadCI, checkWorkflowsHavePRTriggers } from './github-merge-ci-signals.lib.mjs';
export { getCommitDate, checkPreviousPRCommitsHadCI, checkWorkflowsHavePRTriggers };

// Issue #1341: Re-export post-merge CI functions from separate module
// Issue #1807: getPRStatus is used by the sequential auto-resolve pass to poll PR lifecycle state.
import { waitForCommitCI, checkBranchCIHealth, getMergeCommitSha, getPRStatus } from './github-merge-ci.lib.mjs';
export { waitForCommitCI, checkBranchCIHealth, getMergeCommitSha, getPRStatus };

import { getAllActiveRepoRuns, waitForAllRepoActions, checkCIConsensus, checkAllPRCommitsCI, getPRCommitShas, getActivePRWorkflowRuns } from './github-merge-repo-actions.lib.mjs'; // Issue #1503, #1712
export { getAllActiveRepoRuns, waitForAllRepoActions, checkCIConsensus, checkAllPRCommitsCI, getPRCommitShas, getActivePRWorkflowRuns };

export default {
  READY_LABEL,
  checkReadyLabelExists,
  createReadyLabel,
  checkLabelPermissions,
  ensureReadyLabel,
  fetchReadyPullRequests,
  fetchReadyIssuesWithPRs,
  getAllReadyPRs,
  syncReadyTags, // Issue #1367: Sync 'ready' tags between linked PRs and issues
  checkPRCIStatus,
  checkPRMergeable,
  checkMergePermissions,
  mergePullRequest,
  waitForCI,
  parseRepositoryUrl,
  getActiveBranchRuns, // Issue #1307: New exports for target branch CI waiting
  waitForBranchCI,
  getDefaultBranch,
  closeLinkedIssueIfNotAutoClosed, // Issue #1895: close linked issue after merge into non-default branch
  // Issue #1314: Billing limit detection and enhanced CI status and re-run capabilities
  getCheckRunAnnotations,
  getRepoVisibility,
  checkForBillingLimitError,
  BILLING_LIMIT_ERROR_PATTERN,
  getDetailedCIStatus,
  rerunWorkflowRun,
  rerunFailedJobs,
  getWorkflowRunsForSha,
  getWorkflowRunJobsCount, // Issue #1690: detect invalid workflow files (no jobs created)
  waitForCommitCI,
  checkBranchCIHealth,
  getMergeCommitSha,
  getPRStatus, // Issue #1807: sequential auto-resolve PR lifecycle polling
  getActiveRepoWorkflows,
  getCommitDate,
  checkPreviousPRCommitsHadCI,
  checkWorkflowsHavePRTriggers,
  getLinkedPRsFromTimeline,
  getAllActiveRepoRuns,
  waitForAllRepoActions,
  checkCIConsensus, // Issue #1503
  getActivePRWorkflowRuns, // Issue #1712: list active runs across ALL PR commits
};
