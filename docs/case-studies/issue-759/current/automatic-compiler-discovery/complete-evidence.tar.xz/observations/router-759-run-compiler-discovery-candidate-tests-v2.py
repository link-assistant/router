import subprocess
files=['tools/translation/test/compiler-source-inputs.test.mjs', 'tools/translation/test/source-profile-inputs.test.mjs', 'tools/translation/test/compilation-matrix.test.mjs', 'tools/translation/test/matrix-bulk.test.mjs']
for engine in ("node","bun"):
 command=(["node","--test","--test-concurrency=2"] if engine=="node" else ["bun","test"])+files
 result=subprocess.run(["python3","/tmp/router-759-run-isolated-candidate-diagnostic-v3.py","--root","/private/tmp/router-759-e68eea368-next-compiler","--prefix","/tmp/router-759-compiler-discovery-candidate-"+engine+"-v2","--cap","300","--"]+command)
 if result.returncode:raise SystemExit(result.returncode)
