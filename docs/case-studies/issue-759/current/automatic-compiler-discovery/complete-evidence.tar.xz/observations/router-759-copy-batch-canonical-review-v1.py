from pathlib import Path
import collections,hashlib,json,subprocess
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
head='6daf6cd49';base=Path('/tmp/router-759-cohort-v3-canonical-'+head)
receipt=json.loads(Path(str(base)+'.json').read_text());assert receipt['exitCode']==0 and not receipt['timedOut'] and receipt['sourceInputsUnchanged'] and receipt['headAfter']==receipt['sourceHead']
sha=lambda b:hashlib.sha256(b).hexdigest();inputs=json.loads(Path(str(base)+'-inputs.json').read_text())['inputs'];by_path={row['path']:row for row in inputs}
baseline=json.loads(Path('/tmp/router-759-copy-batch-canonical-baseline-v1.json').read_text())['completeOriginalInventory'];path=root/'parity/rust-source-inventory.json';inventory=json.loads(path.read_text());roots=['tools/translation/meta','packages/javascript/generated/rust-draft','packages/typescript/generated/rust-draft','tools/translation/projects','packages/javascript/generated/rust-project','packages/typescript/generated/rust-project'];outputs=[]
for directory in roots:
 for f in (root/directory).rglob('*'):
  if f.is_file():
   assert not f.is_symlink();b=f.read_bytes();outputs.append({'path':f.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)})
b=path.read_bytes();outputs.append({'path':path.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)});outputs.sort(key=lambda row:row['path']);allowed={row['path'] for row in outputs}
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,timeout=30).decode();changed=sorted(set(git('diff','--name-only','-z').split('\0')+git('ls-files','--others','--exclude-standard','-z').split('\0'))-{''});assert all(name in allowed for name in changed),'Unexpected source changes'
originals=[]
for row in inventory['sources']:
 expected=by_path[row['source']];assert expected['bytes']==row['bytes'] and expected['sha256']==row['sha256'];assert all(target in allowed for target in row['targets'].values());originals.append(expected)
assert len(originals)==804 and len(set(row['path'] for row in originals))==804
for row in inputs:
 if row['path'].endswith('.rs') or row['path'] in ['Cargo.toml','Cargo.lock']:assert sha((root/row['path']).read_bytes())==row['sha256']
fingerprints=[]
for name,digest in inventory['implementationHashes'].items():assert sha((root/name).read_bytes())==digest;fingerprints.append({'path':name,'sha256':digest})
missing_root_modules=[]
for f in sorted((root/'tools/translation').glob('*.mjs')):
 if f.relative_to(root).as_posix() not in inventory['implementationHashes']:missing_root_modules.append({'path':f.relative_to(root).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
events=[]
for line in Path(str(base)+'-time.log').read_text().splitlines():
 try:events.append(json.loads(line))
 except ValueError:pass
library=json.loads((root/'tools/translation/projects/src/lib.meta.json').read_text());categories=collections.Counter((row.get('kind'),row.get('message')) for row in library['refused'])
result={'schema':'complete-original-copy-layout-canonical-review-v1','producer':receipt,'fullOriginalRustInputs':originals,'allOriginalRustAndCargoBytesUnchanged':True,'oldTotals':baseline['totals'],'freshTotals':inventory['totals'],'totalChanges':{key:value-baseline['totals'][key] for key,value in inventory['totals'].items()},'projects':inventory['projects'],'fullFunctionCoverage':inventory['functionCoverage'],'allGeneratedOutputs':outputs,'outputFiles':len(outputs),'outputBytes':sum(row['bytes'] for row in outputs),'allChangedPaths':changed,'changedOutputFiles':len(changed),'changedOutputBytes':sum((root/name).stat().st_size for name in changed),'actualCompilerFingerprints':fingerprints,'unlistedRootCompilerModules':missing_root_modules,'compilerDiscoveryRepairStillRequired':bool(missing_root_modules),'originalLibraryRefusalCategories':[{'kind':kind,'message':message,'count':count} for (kind,message),count in categories.most_common()],'allProgressEventsRetained':True,'lastProgressEvent':events[-1] if events else None,'runtimeParity':False,'rustExecutions':0,'fullGatePass':False}
out=Path('/tmp/router-759-copy-batch-canonical-review-v1.json');assert not out.exists();out.write_text(json.dumps(result,separators=(',',':'))+'\n');print(json.dumps({key:result[key] for key in ['outputFiles','outputBytes','changedOutputFiles','oldTotals','freshTotals','totalChanges','projects','compilerDiscoveryRepairStillRequired']}))
