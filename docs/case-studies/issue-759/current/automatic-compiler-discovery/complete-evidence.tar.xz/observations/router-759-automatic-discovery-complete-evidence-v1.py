from pathlib import Path
import argparse, hashlib, io, json, subprocess, tarfile

p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');a=p.parse_args()
r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
tmp=Path('/tmp');sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=r)
head=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain'),'Complete evidence requires committed unchanged implementation'
prefixes=[
 'router-759-compiler-discovery-',
 'router-759-copy-batch-canonical-',
 'router-759-copy-batch-emitted-original-goldens-',
 'router-759-copy-timeout-batch-integrated-',
 'router-759-ci-artifact-api-json-compaction-',
 'router-759-cohort-v3-canonical-6daf6cd49',
 'router-759-run-compiler-discovery-candidate-tests-',
]
explicit=[
 'router-759-copy-timeout-batch-integration-v1.json',
 'router-759-copy-batch-emitted-original-goldens-v1.mjs',
 'router-759-bounded-cohort-producer-v5.py',
 'router-759-coordinated-repair-diagnostic-v1.py',
 'router-759-run-isolated-candidate-diagnostic-v3.py',
 'router-759-generic-boundary-direct-git-v1.json',
 'router-759-ci-api-json-compaction-after-measurements-v1.json',
 'router-759-ci-api-json-compaction-after-measurement-v1-inputs.json',
 Path(__file__).name,
]
found=set()
for f in tmp.iterdir():
 if any(f.name.startswith(prefix) for prefix in prefixes) and f.is_file():found.add(f)
for name in explicit:
 f=tmp/name;assert f.is_file(),f;found.add(f)
required=[
 'router-759-copy-timeout-batch-integrated-node-v1',
 'router-759-copy-timeout-batch-integrated-bun-v1',
 'router-759-copy-batch-canonical-strict-typescript-v1',
 'router-759-copy-batch-canonical-typed-fixtures-v1',
 'router-759-copy-batch-emitted-original-goldens-node-v1',
 'router-759-copy-batch-emitted-original-goldens-bun-v1',
 'router-759-compiler-discovery-candidate-node-v3',
 'router-759-compiler-discovery-candidate-bun-v3',
 'router-759-compiler-discovery-integrated-node-v1',
 'router-759-compiler-discovery-integrated-bun-v1',
 'router-759-ci-artifact-api-json-compaction-after-measurement-v1',
 'router-759-ci-artifact-api-json-compaction-after-measurement-v2',
]
for name in required:
 receipt=json.loads((tmp/(name+'.json')).read_text())
 assert receipt['exitCode']==0 and not receipt['timedOut']
 assert receipt.get('inputsUnchanged',receipt.get('candidateInputsUnchanged')) is True
 for suffix in ('.json','.raw.log','-inputs.json'):assert tmp/(name+suffix) in found
producer=json.loads((tmp/'router-759-cohort-v3-canonical-6daf6cd49.json').read_text())
assert producer['exitCode']==0 and producer['sourceInputsUnchanged'] and not producer['timedOut']
review=json.loads((tmp/'router-759-copy-batch-canonical-review-v1.json').read_text())
direct=json.loads((tmp/'router-759-copy-batch-canonical-direct-git-v1.json').read_text())
assert direct['allCommittedGeneratedBytesMatchObservedProducer'] and review['outputFiles']==2653
continuity=json.loads((tmp/'router-759-ci-artifact-api-json-compaction-complete-input-continuity-v1.json').read_text())
assert continuity['allOtherOriginalCiBytesUnchanged'] and continuity['allOriginalCiFilesCompared']==28585
comparison=json.loads((tmp/'router-759-ci-artifact-api-json-compaction-measurement-verification-v3.json').read_text())
assert comparison['allReportFieldsEqualAfterArchiveLocationNormalization']
files=[('observations/'+f.name,f.read_bytes()) for f in sorted(found)]
implementation=[
 'AGENTS.md','tools/translation/tracked-inputs.mjs',
 'tools/translation/source-profile-inputs.mjs',
 'tools/translation/compiler-source-inputs.mjs',
 'tools/translation/bulk.mjs','tools/translation/test/compiler-source-inputs.test.mjs',
 'tools/translation/README.md',
 'changelog.d/20261013_000016_issue_759_lossless_artifact_api_json.md',
 'changelog.d/20261013_000017_issue_759_compiler_discovery.md',
 'docs/case-studies/issue-759/raw/ci/lossless-artifact-api-json-archives.json',
]
for name in implementation:
 b=(r/name).read_bytes();assert git('show',head+':'+name)==b
 files.append(('implementation/'+name,b))
archive=tmp/'router-759-automatic-discovery-complete-evidence-v1.tar.xz'
receipt_path=tmp/'router-759-automatic-discovery-complete-evidence-v1.packet.json'
assert not archive.exists() and not receipt_path.exists()
rows=[];dedup={}
with tarfile.open(archive,'w:xz',preset=9) as t:
 for name,b in files:
  digest=sha(b);row={'path':name,'bytes':len(b),'sha256':digest}
  e=tarfile.TarInfo(name);e.mtime,e.mode=0,0o644
  if digest in dedup and dedup[digest][1]==b:
   e.type,e.linkname=tarfile.LNKTYPE,dedup[digest][0];row['storedAsHardlink']=e.linkname;t.addfile(e)
  else:e.size=len(b);t.addfile(e,io.BytesIO(b));dedup[digest]=(name,b)
  rows.append(row)
with tarfile.open(archive) as t:
 for row,(_,b) in zip(rows,files):assert t.extractfile(row['path']).read()==b
packet={'schema':'complete-automatic-compiler-discovery-evidence-v1','sourceHead':head,
 'canonicalProducerHead':producer['sourceHead'],'canonicalCommittedHead':direct['sourceHead'],
 'archive':'complete-evidence.tar.xz','archiveBytes':archive.stat().st_size,
 'archiveSha256':sha(archive.read_bytes()),'members':rows,
 'allDecodedOriginalsVerified':True,'completeOriginalBytes':sum(row['bytes'] for row in rows),
 'canonicalOutputs':2653,'originalRustInputs':804,'copyBatchIntegratedTestsPerEngine':89,
 'compilerDiscoveryFinalCandidateTestsPerEngine':32,'compilerDiscoveryIntegratedTestsPerEngine':32,
 'runtimeParity':False,'fullGatePass':False,'rustExecutions':0}
receipt_path.write_text(json.dumps(packet,indent=2)+'\n')
def allocated():
 seen=set();total=0
 for directory in ('docs/case-studies/issue-759','dev/log/issues/759'):
  for f in (r/directory).rglob('*'):
   if f.is_file():
    s=f.stat();key=(s.st_dev,s.st_ino)
    if key not in seen:seen.add(key);total+=s.st_blocks*512
 return total
before=allocated()
print(json.dumps({'archiveBytes':packet['archiveBytes'],'members':len(rows),'allocatedBytesBefore':before,'remainingBytesBefore':500000000-before}),flush=True)
if a.apply:
 target=r/'docs/case-studies/issue-759/current/automatic-compiler-discovery';assert not target.exists()
 text='''# Automatic compiler discovery and complete canonical verification

The original 804 Rust files and both Cargo inputs remain unchanged. At source `6daf6cd495ff6b76848b0a77cb737439367596b1`, the complete bounded canonical producer finished in 983.063 seconds and emitted 2,653 files (85,417,878 bytes). Its complete input vector, progress stream, output hashes, old and fresh inventories, every changed path and item, and direct Git verification are retained. Commit `007be69e38b9de8b6c3b4b668ba06ddf5619e11a` contains all verified output bytes. The fresh drafts contain 681 executable items, including 124 functions and 381 constants, and retain 11,994 carried items. The complete library project contains 120 functions, 391 constants and 58 checked methods. These totals do not establish full runtime parity.

Strict compilation of the actual emitted TypeScript and all typed fixtures passed. Both Node and Bun imported the actual complete JavaScript library and the strictly compiled complete TypeScript library: each target passed 23 goldens and rejected five invalid inputs. Original token-source spans and hashes were checked. Both engines also passed the integrated 89-case Copy-layout and timeout batch. Every execution retains its entire raw output, full immutable input vector, finite deadline and actual receipt. Recorded maximum waited-child RSS is not aggregate process memory or physical footprint.

Compiler discovery now fingerprints complete tracked production translator modules and descriptors. It shares the original bounded Git-index and checked-out-byte reader with source-profile discovery, while preserving every field of all 333 original profile entries. The actual original-profile equivalence probe and complete discovered input list are retained. Discovery grants freshness evidence only. The isolated final candidate and integrated implementation each passed all 32 cases in Node and Bun. Initial 31-case passes, the excluded-symlink regression and generated-tree regression failures, each exact implementation snapshot, corrected 32-case runs and initial setup diagnostic remain retained in full.

Twenty-eight complete repository artifact-list API responses were compressed losslessly; all decoded lengths, SHA256 hashes and original Git bytes passed. All 28,585 original CI files were compared against the earlier full input vector: 28 changed storage location, the others retained exact bytes, and only the new provenance map was added. This reclaimed 2,220,032 allocated bytes. Every field of the two complete CI reports matches after exact archive-path normalization and exclusion of the new provenance input. The first comparison used the broader raw directory rather than the original CI directory; its complete reports, difference inventory and harness are preserved. A second comparison setup changed the historical before filename accidentally; its source and failure record are preserved. The corrected comparison uses the same CI scope and the unchanged historical report. No corpus speed improvement is inferred from different scopes or input vectors.

`receipt.json` maps every full TAR member to its original length and SHA256. Exact duplicate originals may use ordinary TAR hardlinks. The preceding 113-member archive's independent direct-Git verification is retained. Complete profile regeneration and the mandatory seven-stage strict gate remain required for the combined worker changes. No Rust build ran, no green stamp was written, and this packet does not certify a completed Router conversion.
'''
 estimate=sum(((n+4095)//4096)*4096 for n in (archive.stat().st_size,receipt_path.stat().st_size,len(text.encode())))
 assert before+estimate<500000000,'Fixed complete evidence allocation exceeded'
 target.mkdir();(target/'complete-evidence.tar.xz').write_bytes(archive.read_bytes())
 (target/'receipt.json').write_bytes(receipt_path.read_bytes());(target/'README.md').write_text(text)
 after=allocated();assert after<500000000
 result={'sourceHead':head,'target':target.relative_to(r).as_posix(),'originalMembers':len(rows),'archiveSha256':packet['archiveSha256'],'allocatedBytesBefore':before,'allocatedBytesAfter':after,'remainingBytes':500000000-after}
 f=tmp/'router-759-automatic-discovery-complete-evidence-v1.applied.json';assert not f.exists();f.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
