from pathlib import Path
import subprocess,json,base64,hashlib
root=Path('/tmp/router-759-core-trait-sources-v2');root.mkdir(exist_ok=False);rows=[]
for path in ['library/core/src/ops/arith.rs','library/core/src/ops/bit.rs','library/core/src/cmp.rs']:
 label=path.replace('/','-');raw=subprocess.check_output(['gh','api','repos/rust-lang/rust/contents/'+path+'?ref=1.89.0'],timeout=30);(root/(label+'.response.json')).write_bytes(raw);r=json.loads(raw);assert r['encoding']=='base64';data=base64.b64decode(r['content']);assert len(data)<4000000;blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert blob==r['sha'];(root/(label+'.rs')).write_bytes(data);rows.append({'repository':'rust-lang/rust','ref':'1.89.0','path':path,'file':label+'.rs','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlobSha':blob,'url':'https://github.com/rust-lang/rust/blob/1.89.0/'+path});print(json.dumps(rows[-1]),flush=True)
(root/'receipt.json').write_text(json.dumps({'sources':rows,'rustExecutions':0,'namespaceAuthority':False},indent=2)+'\n')
