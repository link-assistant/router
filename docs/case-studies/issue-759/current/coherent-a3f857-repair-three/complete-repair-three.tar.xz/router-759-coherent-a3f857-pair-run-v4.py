#!/usr/bin/env python3
# SOURCE_ONLY_UNRUN: only /root may grant and execute the frozen pair.
import argparse,datetime,hashlib,json,os,re,resource,shutil,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
PLAN_PATH=Path('/tmp/router-759-coherent-a3f857-repair-plan.json')
INPUT_PATH=Path('/tmp/router-759-coherent-a3f857-repair-inputs.json')
PLAN_SHA='2bfbaf86191868362aa966e9cfa7cba8826fe4eca1145a91e3f426a12b2602f9'
INPUT_SHA='58c756759e7de93a139f993a7167ba6bd620939436c5e2041ea5eae07ea095e0'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(path,data):
 with path.open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,timeout=30)
def state():return {'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain').decode().strip()}
def snapshot(head):
 rows=[]
 names=git('ls-files','-z','--','tools/translation','*.rs','Cargo.toml','Cargo.lock','packages/javascript/src','packages/javascript/package.json','packages/javascript/package-lock.json','package-lock.json','scripts','AGENTS.md').decode().split('\0')
 for name in sorted(set(filter(None,names))):
  if name.startswith(('tools/translation/meta/','tools/translation/projects/')):continue
  path=ROOT/name
  if path.is_symlink():raise RuntimeError('Tracked source symlink: '+name)
  raw=path.read_bytes() if path.is_file() else git('show',head+':'+name)
  rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'readBasis':'worktree' if path.is_file() else 'exact-head-blob'})
 return rows
def parse_counts(engine,text):
 clean=re.sub(r'\x1b\[[0-9;]*m','',text)
 if engine=='node':return {key:(int(m[-1]) if (m:=re.findall(r'^# '+key+r' (\d+)\s*$',clean,re.M)) else None) for key in ['tests','pass','fail','cancelled','skipped','todo']}
 counts={}
 for key,label in [('pass','pass'),('fail','fail'),('skipped','skip')]:
  hits=re.findall(r'^\s*(\d+) '+label+r'\s*$',clean,re.M);counts[key]=int(hits[-1]) if hits else (0 if key=='skipped' else None)
 counts['tests']=sum(counts.values()) if all(v is not None for v in counts.values()) else None
 counts['cancelled']=None;counts['todo']=None;return counts

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--phase',required=True);args=parser.parse_args()
 if not re.fullmatch('[a-z][a-z0-9-]{0,48}',args.phase):raise RuntimeError('Safe unique phase required')
 if sha(PLAN_PATH.read_bytes())!=PLAN_SHA or sha(INPUT_PATH.read_bytes())!=INPUT_SHA:raise RuntimeError('Immutable plan/input bytes changed')
 plan=json.loads(PLAN_PATH.read_text());frozen=json.loads(INPUT_PATH.read_text());head=plan['sourceHead'];assert plan['testFiles']==75 and plan['expectedCases']==682
 before=state();assert before=={'head':head,'status':''},'Exact clean frozen HEAD required'
 rows=snapshot(head);assert rows==frozen['files'],'Full immutable input rows changed'
 runner_sha=sha(Path(__file__).read_bytes());files=frozen['testPaths'];prefix=Path('/tmp/router-759-coherent-'+head[:9]+'-'+args.phase)
 outputs=[Path(str(prefix)+suffix) for suffix in ['-preflight.json','-node.raw.log','-node-receipt.json','-bun.raw.log','-bun-receipt.json','-summary.json']]
 if any(p.exists() for p in outputs):raise RuntimeError('Evidence exists; retain it and choose a new phase')
 if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('2 GiB free floor required')
 versions={name:subprocess.check_output([name,'--version'],cwd=ROOT,text=True,timeout=30).strip() for name in ['node','bun']}
 write(outputs[0],{'schema':'router-759-coherent-initial-pair-preflight-v1','head':head,'phase':args.phase,'planSha256':PLAN_SHA,'inputManifestSha256':INPUT_SHA,'sourceInputSha256':frozen['sourceInputSha256'],'runnerSha256':runner_sha,'versions':versions,'freeBytes':shutil.disk_usage(ROOT).free,'executables':{name:shutil.which(name) for name in ['node','bun','tsc']},'expectedCases':682,'files':files,'engineSeconds':1800,'noRust':True,'noRepositoryCorpusProducer':True})
 receipts=[]
 for engine in ['node','bun']:
  if state()!=before or snapshot(head)!=rows:raise RuntimeError('Source changed before '+engine+'; no new engine started')
  free_before=shutil.disk_usage(ROOT).free
  if free_before<2*1024**3:raise RuntimeError('2 GiB free floor required before '+engine)
  command=['node','--test','--test-concurrency=1',*files] if engine=='node' else ['bun','test','--max-concurrency','1','--timeout','15000',*files]
  command=['/usr/bin/time','-p',*command];rawpath=Path(str(prefix)+'-'+engine+'.raw.log');receiptpath=Path(str(prefix)+'-'+engine+'-receipt.json')
  waited_before=resource.getrusage(resource.RUSAGE_CHILDREN);started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat();started=time.monotonic();timed_out=False
  with rawpath.open('xb') as stream:
   child=subprocess.Popen(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=1800)
   except subprocess.TimeoutExpired:
    timed_out=True;os.killpg(child.pid,signal.SIGTERM)
    try:code=child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
  waited_elapsed=time.monotonic()-started;after_resource=resource.getrusage(resource.RUSAGE_CHILDREN);raw=rawpath.read_bytes();counts=parse_counts(engine,raw.decode(errors='replace'));state_after=None;rows_same=False;post_error=None
  try:state_after=state();rows_same=snapshot(head)==rows
  except Exception as error:post_error=type(error).__name__+': '+str(error)
  receipt={'schema':'router-759-coherent-initial-pair-terminal-v1','phase':args.phase,'engine':engine,'engineVersion':versions[engine],'command':command,'sourceHead':head,'sourceInputs':len(rows),'inputDigest':frozen['sourceInputSha256'],'sourceStateAfter':state_after,'stateUnchanged':state_after==before,'inputsUnchanged':rows_same,'postVerificationError':post_error,'runnerUnchanged':sha(Path(__file__).read_bytes())==runner_sha,'planUnchanged':sha(PLAN_PATH.read_bytes())==PLAN_SHA,'inputManifestUnchanged':sha(INPUT_PATH.read_bytes())==INPUT_SHA,'startedUtc':started_utc,'elapsedWaitedEngineSeconds':waited_elapsed,'exitCode':code,'timedOut':timed_out,'timeoutSeconds':1800,'counts':counts,'expectedCases':682,'expectedTestFiles':75,'raw':{'path':str(rawpath),'bytes':len(raw),'sha256':sha(raw)},'freeBytesBefore':free_before,'freeBytesAfter':shutil.disk_usage(ROOT).free,'resource':{'userCpuSeconds':after_resource.ru_utime-waited_before.ru_utime,'systemCpuSeconds':after_resource.ru_stime-waited_before.ru_stime,'maxRecordedChildRss':after_resource.ru_maxrss,'units':'bytes on Darwin; KiB on Linux','scope':'RUSAGE_CHILDREN terminated harness children; not aggregate concurrent process-tree peak'},'rustRuns':0,'repositoryCorpusProducerRuns':0,'fullGateRuns':0,'fixtureProducers':'Authored tests may create bounded isolated temporary fixture outputs; not repository corpus generation','authority':'focused source behavior only; no parity promotion'}
  receipt['passed']=code==0 and not timed_out and counts['tests']==682 and counts['pass']==682 and counts['fail']==0 and counts['skipped']==0 and (engine!='node' or counts['cancelled']==0) and all(receipt[k] for k in ['stateUnchanged','inputsUnchanged','runnerUnchanged','planUnchanged','inputManifestUnchanged'])
  write(receiptpath,receipt);receipts.append(receipt);print('TERMINAL',engine,json.dumps({k:receipt[k] for k in ['exitCode','timedOut','elapsedWaitedEngineSeconds','counts','passed']}),flush=True)
  if not receipt['stateUnchanged'] or not rows_same or post_error:raise SystemExit('Source state changed; full current raw/receipt retained. Second engine not started on changed source.')
 summary={'schema':'router-759-coherent-initial-pair-summary-v1','head':head,'phase':args.phase,'bothTerminal':True,'passed':all(r['passed'] for r in receipts),'receipts':receipts,'nextStep':'Inventory every paired failure before any source edits; archive losslessly and independently verify Git bytes before owned temp cleanup.'};write(outputs[-1],summary)
 print('PAIRED TERMINAL',summary['passed'],flush=True);return 0 if summary['passed'] else 1
if __name__=='__main__':sys.exit(main())
