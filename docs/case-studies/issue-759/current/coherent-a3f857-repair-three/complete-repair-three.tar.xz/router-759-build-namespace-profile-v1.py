from pathlib import Path
import json,gzip,hashlib,tarfile,shutil
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');target=root/'tools/translation/source-profiles/primitive-from-namespace';target.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();download=Path('/tmp/router-759-namespace-originals-v1');rows=[]
for pin in json.loads((download/'receipt.json').read_text())['sources']:
 if pin['repository']!='rust-lang/rust':continue
 data=(download/pin['file']).read_bytes();assert sha(data)==pin['sha256'];encoded=gzip.compress(data,mtime=0);name=pin['path'].replace('/','-')+'.gz';(target/name).write_bytes(encoded);rows.append({**{k:pin[k] for k in ['repository','ref','path','bytes','sha256','gitBlobSha','url']},'archive':name,'archiveBytes':len(encoded),'archiveSha256':sha(encoded)})
archive=Path('/tmp/router-759-stdarch-1.89-complete-source.tar.gz');data=archive.read_bytes();assert sha(data)=='11b7b7c9e38040c360db0068c929c4f5be044983cba60f40001e34422047e8dd';(target/'stdarch-complete-original.tar.gz').write_bytes(data)
verification=json.loads(Path('/tmp/router-759-stdarch-1.89-full-git-verify-v2.json').read_text());archRows=[p for p in verification['files'] if p['path'].startswith('crates/core_arch/src/') and p['path'].endswith('.rs')];assert len(archRows)==135
licenses=[]
with tarfile.open(archive,'r:gz') as stream:
 for member in stream:
  path=member.name.split('/',1)[-1]
  if path not in ['LICENSE-MIT','LICENSE-APACHE']:continue
  data=stream.extractfile(member).read();(target/path).write_bytes(data);licenses.append({'path':path,'bytes':len(data),'sha256':sha(data),'gitBlobSha':next(p['gitBlobSha'] for p in verification['files'] if p['path']==path)})
assert len(licenses)==2
manifest={'schema':'original-rust-primitive-from-namespace-sources-v1','rust':'1.89.0','coreSources':rows,'stdarch':{'repository':'rust-lang/stdarch','ref':'8099c08d501ec80214d7bfe3f85002dec7d79655','rustGitlinkPath':'library/stdarch','archive':'stdarch-complete-original.tar.gz','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'allOriginalArchiveBytes':verification['originalBytes'],'allOriginalArchiveFiles':len(verification['files']),'namespaceSourceFiles':archRows,'licenses':licenses},'sourceScope':'Original namespace inputs only; no bodies, layouts, traits, cfg selection or runtime semantics are authorized by this manifest','namespaceComplete':False,'runtimeParity':False,'rustExecutions':0}
raw=(json.dumps(manifest,indent=2)+'\n').encode();assert raw.count(b'\n')<1000;(target/'manifest.json').write_bytes(raw)
(target/'NOTICE.md').write_text('# Original primitive conversion namespace inputs\n\nComplete official Rust 1.89 core source files and its pinned stdarch submodule source archive are retained under the accompanying MIT and Apache-2.0 licenses. All 306 archive files were independently checked against official Git blob identities before capture; the manifest also pins every one of the 135 core_arch Rust source files.\n\nThese are original source inputs for bounded namespace analysis. Their capture alone grants no trait selection, target configuration, macro expansion, type layout, formatter equivalence, or runtime parity. No Rust compiler or Cargo build ran.\n')
print(json.dumps({'manifestSha256':sha(raw),'manifestLines':raw.count(b'\n'),'sourceFiles':len(rows),'coreArchFiles':len(archRows),'archiveBytes':archive.stat().st_size,'rustExecutions':0}))
