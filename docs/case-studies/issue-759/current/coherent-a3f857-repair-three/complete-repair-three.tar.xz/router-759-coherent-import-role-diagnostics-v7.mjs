import {readFileSync} from 'node:fs';
const root='file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/';const mod=p=>import(root+'tools/translation/'+p);
const {numericSourceInputsFromFiles,compileNumericSourceStages}=await mod('serialization-schema/numeric-source-stage.mjs');
const input=numericSourceInputsFromFiles({manifest:readFileSync(new URL('Cargo.toml',root),'utf8'),lock:readFileSync(new URL('Cargo.lock',root),'utf8')});
const stage=compileNumericSourceStages(input,{candidateConfiguration:{flags:{test:false},values:{feature:[]},closedKeys:['feature']}});
console.log(JSON.stringify({label:'original-full-formatter-meta',failure:stage.translationFailure,executables:stage.meta?.executable.map(i=>i.name),wideAdd:stage.meta?.refused.filter(i=>i.name==='umul128_add_hi64'),runtimeParity:stage.runtimeParity}));
const {translateProject}=await mod('project.mjs');
for(const [label,source]of [
 ['anonymous-competitor','mod m{pub trait Hijack{fn from(value:bool)->Self;}}use crate::m::Hijack as _;pub fn bad(value:bool)->u64{u64::from(value)}'],
 ['anonymous-missing','use missing::Hijack as _;pub fn bad(value:bool)->u64{u64::from(value)}'],
 ['anonymous-copy-closure','mod m{pub trait Quiet:Copy{const VALUE:u32;}}use crate::m::Quiet as _;pub fn original(value:bool)->u64{u64::from(value)}'],
 ['wrong-core-alias','use core::clone::Copy as _;pub fn bad(value:bool)->u64{u64::from(value)}']]){
 const result=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source});console.log(JSON.stringify({label,executable:result.meta.executable.map(i=>i.name),refused:result.meta.refused.map(i=>({name:i.name,diagnostic:i.diagnostic}))}));
}
