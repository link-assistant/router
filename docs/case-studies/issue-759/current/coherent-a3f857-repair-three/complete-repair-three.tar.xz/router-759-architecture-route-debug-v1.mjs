import {readFileSync} from 'node:fs';
const root=new URL('file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/extensions/');
let source=readFileSync(new URL('primitive-import-roles.mjs',root),'utf8');
source=source.replace(/from '([^']+)'/g,(_,path)=>'from '+JSON.stringify(new URL(path,root).href));
source=source.replace('if(!pin)return [];','if(!pin)throw new Error("missing-route:"+key);');
source+='\nexport {architectureRouteFiles};';
const {architectureRouteFiles}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
for(const family of ['x86','x86_64','aarch64'])try{console.log(JSON.stringify({family,files:architectureRouteFiles(family)}));}catch(e){console.log(JSON.stringify({family,message:e.message}));}
