import hashlib,json,pathlib,subprocess

root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
tmp=pathlib.Path('/tmp')
head='682e35cffa0f6cd7237e60f61255d56c31c5674e'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
files={}
prefixes=[
 'router-759-cohort-v3-canonical-69ca4df41',
 'router-759-cohort-v3-canonical-7dfe543a4',
 'router-759-actual-canonical-7dfe-',
 'router-759-canonical-8de7-direct-git-',
 'router-759-captured-metadata-text-',
 'router-759-captured-metadata-compaction-',
 'router-759-namespace-const-integrated-',
 'router-759-post-const-refusal-candidate-',
 'router-759-native-artifacts-v2-db1318963',
 'router-759-native-artifacts-v2-d141d8e44',
 'router-759-reusable-evidence-packet-',
 'router-759-mid-sized-log-',
 'router-759-mid-log-compaction-',
 'router-759-readonly-ci-integrity-',
 'router-759-prepare-readonly-ci-integrity-',
 'router-759-complete-case-allocation-7dfe543a4-',
 'router-759-translator-source-batch-direct-git-',
 'router-759-translator-source-batch-apply-verified-',
]
for file in tmp.iterdir():
 if file.is_file() and any(file.name.startswith(prefix) for prefix in prefixes):
  files['observations/'+file.name]=file
for name in [
 'router-759-derive-cycle-20261013-next-v1',
 'router-759-derive-cycle-20261013-scalar-v1',
 'router-759-option-borrow-cycle-20261013-v1',
]:
 directory=tmp/name;assert directory.is_dir()
 for file in directory.rglob('*'):
  if file.is_file():files['workers/'+name+'/'+file.relative_to(directory).as_posix()]=file
directory=tmp/'router-759-mid-sized-log-compaction-v1'
for file in directory.iterdir():
 if file.is_file() and not file.name.endswith('.xz'):
  files['observations/mid-log-compaction/'+file.name]=file
for number in ['07','08','09']:
 receipt=tmp/('router-759-reverse-cycle-final-inputs-'+number+'.json')
 data=json.loads(receipt.read_text())
 files['workers/reverse/'+receipt.name]=receipt
 for item in data['evidence']:
  path=item['path'] if isinstance(item,dict) else item
  file=pathlib.Path(path)
  assert file.is_file(),file
  if isinstance(item,dict):
   raw=file.read_bytes()
   assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],file
  files['workers/reverse/'+file.name]=file
for name in ['router-759-bounded-cohort-producer-v5.py','router-759-bounded-native-artifacts-v2.py','router-759-coordinated-repair-diagnostic-v1.py','router-759-run-source-scope-cache-candidate-v1.py']:
 file=tmp/name;assert file.is_file();files['harnesses/'+name]=file
changed=subprocess.check_output(['git','diff','--name-only','69ca4df41aa34945d1af10bb1b55617903599b13',head,'--','tools/translation','tools/evidence','scripts/test/capture-evidence-packet.test.mjs'],cwd=root).decode().splitlines()
for name in changed:
 if name.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/')):continue
 file=root/name
 if file.is_file():
  raw=file.read_bytes();assert subprocess.check_output(['git','show',head+':'+name],cwd=root)==raw
  files['implementation/'+name]=file
rows=[]
for name,file in files.items():
 raw=file.read_bytes()
 rows.append({'path':name,'originalPath':str(file),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
output=tmp/'router-759-coherent-source-successor-packet-v1.manifest.json'
assert not output.exists()
output.write_text(json.dumps({'members':rows},indent=2)+'\n')
print(json.dumps({'sourceHead':head,'completeMembers':len(rows),'completeOriginalBytes':sum(row['bytes'] for row in rows),'manifest':str(output),'rustExecuted':False,'fullGateAuthority':False}))
