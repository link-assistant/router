import {readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {loadDeriveDependencyProof} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-derive-cycle/tools/translation/derive-dependencies.mjs';
import {proveClapValueEnumSourceOutput} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-derive-cycle/tools/translation/derive-clap-value-enum.mjs';
import {sourceItems} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-derive-cycle/tools/translation/rust-structure.mjs';
import {translateProject} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-derive-cycle/tools/translation/project.mjs';
import {PRODUCTION_PROFILE} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-derive-cycle/tools/translation/cfg-profile.mjs';
const base='/tmp/router-759-derive-cycle-20261013-next-v1/',hash=value=>createHash('sha256').update(value).digest('hex'),manifest=readFileSync('Cargo.toml','utf8'),lock=readFileSync('Cargo.lock','utf8'),dependencies=loadDeriveDependencyProof({manifest,lock});
writeFileSync(base+'Cargo.toml',manifest);writeFileSync(base+'Cargo.lock',lock);writeFileSync(base+'derive-source-manifest.json',readFileSync('tools/translation/source-profiles/derive/manifest.json'));
const paths=execFileSync('git',['ls-files','*.rs'],{encoding:'utf8'}).trim().split('\n');writeFileSync(base+'original-rust-paths.json',JSON.stringify(paths));
const census=[];
for(const path of ['src/subscription_usage_types.rs','src/deploy_config.rs','src/cli.rs','src/cli/deploy_args.rs','src/cli/client_ops.rs','src/cli/auth_ops.rs','src/tunnel_command.rs','src/clients.rs']) {
  const source=readFileSync(path,'utf8');writeFileSync(base+path.replaceAll('/','-'),source);
  for(const item of sourceItems(source).filter(item=>item.term==='enum'&&item.tokens.some(token=>token.text==='ValueEnum'))){let output;try{output=proveClapValueEnumSourceOutput({dependencies,source:source.slice(item.start,item.end)});writeFileSync(base+item.name+'.source-output.json.gz',gzipSync(JSON.stringify(output)));}catch(error){output={unsupported:error.message};}
    census.push({source:path,sourceSha256:hash(source),owner:item.name,span:{start:item.start,end:item.end},success:!!output.digest,digest:output.digest??null,unsupported:output.unsupported??null});}
}
const coverage=[];
for(const path of ['src/subscription_usage_types.rs','src/deploy_config.rs']) {
  const name=path.replaceAll('/','-'),before=JSON.parse(gunzipSync(readFileSync(base+name+'.before.json.gz'))),result=translateProject({entry:path,paths,readSource:path=>readFileSync(path,'utf8'),cargoManifest:manifest,deriveDependencies:dependencies,compilationProfile:PRODUCTION_PROFILE});
  writeFileSync(base+name+'.after-final.json.gz',gzipSync(JSON.stringify(result)));
  coverage.push({entry:path,before:{certificates:before.meta.deriveNamespaceFootprints.certificates.map(row=>row.name),executable:before.meta.executable.map(row=>row.name),methods:before.meta.checkedMethods.map(row=>row.name),refused:before.meta.refused.length},after:{certificates:result.meta.deriveNamespaceFootprints.certificates.map(row=>row.name),executable:result.meta.executable.map(row=>row.name),methods:result.meta.checkedMethods.map(row=>row.name),refused:result.meta.refused.length,runtimeParity:result.meta.runtimeParity}});
}
const library=gunzipSync(readFileSync(base+'lib.meta.json.gz'));if(hash(library)!=='1d05ce48f9b7d35290f4eaf6a54bbd3c3e24dc30ca1fcc28128d15a751633110')throw new Error('saved full inventory input changed');unlinkSync(base+'lib.meta.json');
const receipt={schema:'router-759-original-derive-document-cycle-v1',integrationHead:'1d80a44078bc170b3dd7fef3a200664fb313341e',head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),runtime:{node:process.version,bun:execFileSync('bun',['--version'],{encoding:'utf8'}).trim()},dependencyDigest:dependencies.digest,originalInputs:{manifestSha256:hash(manifest),lockSha256:hash(lock),rustFiles:paths.length,fullSavedInventorySha256:hash(library)},census,coverage,node:{cases:42,pass:42,fail:0,log:'node-final-v2.log',wholeLibraryContextIncluded:true,elapsedMs:162259.973667,resourceMeasurement:'one observed original-context child RSS=161712KiB at159s; no complete peak measurement; ps initially sandbox denied'},bun:{boundedFiles:5,cases:32,log:'bun-final-v2.log',resourceLog:'ROUTER_DERIVE_RESOURCE_RECEIPT'},failuresPreserved:['node-existing-first.log obsolete doc negative 5pass1fail','node-final.log missing adjacent quote test filename, no tests executed','bun-final.log32pass0fail then time-l sandbox sysctl wrapper failure'],notes:['Existing whole-library Node context test inadvertently selected once, root informed; no repeat and no bulk output writes.','Two manual metadata inspection commands had syntax errors and made no source/output mutations.','No Rust/Cargo build, original inputs unchanged, no push, no generated or case-study writes.'],resourceUsage:process.resourceUsage()};
writeFileSync(base+'receipt.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify({census,coverage,resourceUsage:process.resourceUsage()},null,2));
