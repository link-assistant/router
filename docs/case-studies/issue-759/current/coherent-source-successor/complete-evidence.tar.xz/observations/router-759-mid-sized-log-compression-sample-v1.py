import gzip, hashlib, json, lzma, pathlib, time

root = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
inventory = json.loads(pathlib.Path('/tmp/router-759-complete-case-allocation-7dfe543a4-v1.json').read_text())
rows = sorted((row for row in inventory['files']
               if row['path'].startswith('docs/case-studies/issue-759/raw/ci/')
               and row['path'].endswith('.txt.gz') and 4096 < row['bytes'] <= 51200),
              key=lambda row: row['bytes'], reverse=True)[:64]
output = pathlib.Path('/tmp/router-759-mid-sized-log-compression-sample-v1.json')
assert not output.exists()
result = []
started = time.monotonic()
for row in rows:
    original = (root / row['path']).read_bytes()
    decoded = gzip.decompress(original)
    assert len(decoded) <= 4 * 1024 * 1024
    packed = lzma.compress(decoded, preset=6)
    assert lzma.decompress(packed) == decoded
    result.append({**row, 'originalGzipSha256': hashlib.sha256(original).hexdigest(),
                   'decodedBytes': len(decoded), 'decodedSha256': hashlib.sha256(decoded).hexdigest(),
                   'xzBytes': len(packed), 'xzSha256': hashlib.sha256(packed).hexdigest(),
                   'projectedXzAllocatedBytes': ((len(packed) + 4095) // 4096) * 4096})
report = {'schema': 'mid-sized-complete-log-storage-sample-v1',
          'head': inventory['head'], 'rows': result, 'sampleSize': len(rows),
          'allDecodedBytesEqual': True,
          'originalAllocatedBytes': sum(row['allocated'] for row in rows),
          'projectedXzAllocatedBytes': sum(row['projectedXzAllocatedBytes'] for row in result),
          'elapsedSeconds': time.monotonic() - started, 'sourceMutations': [], 'rustExecuted': False,
          'wholePopulationReclaimProved': False, 'semanticAuthority': False}
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'rows'}))
