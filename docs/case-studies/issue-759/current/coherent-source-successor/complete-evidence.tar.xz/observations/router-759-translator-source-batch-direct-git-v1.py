import hashlib, io, json, pathlib, subprocess, tarfile, time

root = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
head = '7dfe543a4167840040064be15c86c84db10898a6'
base = 'docs/case-studies/issue-759/current/translator-source-batch/'
output = pathlib.Path('/tmp/router-759-translator-source-batch-direct-git-v1.json')
assert not output.exists()
def git_bytes(path):
    return subprocess.check_output(['git', 'show', head + ':' + base + path], cwd=root, timeout=30)
receipt = json.loads(git_bytes('receipt.json'))
archive = git_bytes(receipt['archive'])
assert len(archive) == receipt['archiveBytes']
assert hashlib.sha256(archive).hexdigest() == receipt['archiveSha256']
expected = {entry['path']: entry for entry in receipt['members']}
assert len(expected) == len(receipt['members'])
decoded = {}
started = time.monotonic()
with tarfile.open(fileobj=io.BytesIO(archive), mode='r|xz') as tar:
    for member in tar:
        assert member.name in expected and member.name not in decoded
        assert member.isfile() or member.islnk()
        if member.islnk():
            assert member.linkname in decoded
            actual = dict(decoded[member.linkname])
        else:
            stream = tar.extractfile(member)
            digest = hashlib.sha256()
            size = 0
            while chunk := stream.read(1024 * 1024):
                size += len(chunk)
                digest.update(chunk)
            actual = {'bytes': size, 'sha256': digest.hexdigest()}
        assert actual == {key: expected[member.name][key] for key in actual}, member.name
        decoded[member.name] = actual
assert set(decoded) == set(expected)
assert sum(entry['bytes'] for entry in decoded.values()) == receipt['completeOriginalBytes']
result = {'schema': 'translator-source-batch-direct-git-v1', 'committedHead': head,
          'capturedSourceHead': receipt['sourceHead'], 'archiveSha256': receipt['archiveSha256'],
          'allCompleteOriginalsVerifiedFromCommittedGit': True, 'decodedMembers': len(decoded),
          'completeOriginalBytes': receipt['completeOriginalBytes'],
          'allDecodedOriginalMetadata': decoded, 'elapsedSeconds': time.monotonic() - started,
          'rustExecuted': False, 'fullGateAuthority': False}
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'allDecodedOriginalMetadata'}))
