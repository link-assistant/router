from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
tmp=Path('/tmp');sha=lambda raw:hashlib.sha256(raw).hexdigest()
archive=tmp/'router-759-translator-source-batch-complete-evidence-v1.tar.xz'
receipt_path=tmp/'router-759-translator-source-batch-complete-evidence-v1.packet.json'
receipt=json.loads(receipt_path.read_text());assert sha(archive.read_bytes())==receipt['archiveSha256']
with tarfile.open(archive) as tar:
 for row in receipt['members']:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
 source=tar.extractfile('observations/router-759-translator-source-batch-complete-evidence-v1.py').read().decode()
 texts=[node.value.value for node in ast.walk(ast.parse(source)) if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='text' for target in node.targets) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str)]
 assert len(texts)==1;readme=texts[0]
def allocated():
 seen=set();total=0
 for directory in ['docs/case-studies/issue-759','dev/log/issues/759']:
  for f in (root/directory).rglob('*'):
   if f.is_file():
    state=f.stat();key=state.st_dev,state.st_ino
    if key not in seen:seen.add(key);total+=state.st_blocks*512
 return total
target=root/'docs/case-studies/issue-759/current/translator-source-batch';assert not target.exists()
before=allocated();estimate=sum(((size+4095)//4096)*4096 for size in [archive.stat().st_size,receipt_path.stat().st_size,len(readme.encode())])
assert before+estimate<500000000
target.mkdir();(target/'complete-evidence.tar.xz').write_bytes(archive.read_bytes());(target/'receipt.json').write_bytes(receipt_path.read_bytes());(target/'README.md').write_text(readme)
after=allocated();assert after<500000000
result={'schema':'apply-verified-complete-translator-source-packet-v1','capturedSourceHead':receipt['sourceHead'],'appliedSourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'archiveSha256':receipt['archiveSha256'],'completeMembers':len(receipt['members']),'allDecodedOriginalsVerified':True,'completeOriginalBytes':receipt['completeOriginalBytes'],'allocatedBytesBefore':before,'allocatedBytesAfter':after,'remainingBytes':500000000-after,'rustExecuted':False,'semanticAuthority':False,'fullGateAuthority':False}
out=tmp/'router-759-translator-source-batch-apply-verified-packet-v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
