import hashlib, json, pathlib, re, subprocess, time

root = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
head = '8de7c1a48402c3e173ed853e66f678d2373568de'
report_path = pathlib.Path('/tmp/router-759-actual-canonical-7dfe-draft-review-v1-complete-report.json')
output = pathlib.Path('/tmp/router-759-canonical-8de7-direct-git-v1.json')
assert not output.exists()
report_bytes = report_path.read_bytes()
report = json.loads(report_bytes)
expected = report['reviewInputs']
assert len({row['path'] for row in expected}) == len(expected)
assert all('\n' not in row['path'] and '\0' not in row['path'] for row in expected)
started = time.monotonic()
result = subprocess.run(['git','cat-file','--batch'],cwd=root,
                        input=''.join(head+':'+row['path']+'\n' for row in expected).encode(),
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180,check=True)
offset = 0
verified = []
for row in expected:
    end = result.stdout.index(b'\n',offset)
    header = result.stdout[offset:end]
    match = re.fullmatch(rb'([a-f0-9]{40}) blob (\d+)',header)
    assert match, row['path']
    size = int(match[2]);offset=end+1
    blob = result.stdout[offset:offset+size];offset+=size
    assert result.stdout[offset:offset+1] == b'\n';offset+=1
    assert len(blob) == row['bytes'] and hashlib.sha256(blob).hexdigest() == row['sha256'],row['path']
    verified.append({**row,'gitBlobSha':match[1].decode()})
assert offset == len(result.stdout)
proof = {'schema':'complete-canonical-draft-direct-git-v1','committedHead':head,
         'capturedCompilerHead':report['headSha'],'reviewReportSha256':hashlib.sha256(report_bytes).hexdigest(),
         'allReviewedOriginalInputsAndOutputsMatchCommittedGit':True,'verifiedFiles':len(verified),
         'generatedOutputFiles':len(report['outputs']),'originalRustFiles':len(report['originalRustInputs']),
         'originalCargoFiles':len(report['originalCargoInputs']),'verified':verified,
         'elapsedSeconds':time.monotonic()-started,'rustExecuted':False,
         'regressionsStillPresent':True,'fullGateAuthority':False}
output.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({key:value for key,value in proof.items() if key!='verified'}))
