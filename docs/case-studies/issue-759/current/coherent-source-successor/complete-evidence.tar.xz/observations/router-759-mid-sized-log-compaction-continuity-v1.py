import gzip,hashlib,json,lzma,pathlib

root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
base=pathlib.Path('/tmp/router-759-mid-sized-log-compaction-v1')
plan=json.loads((base/'plan.json').read_text())
before_path=pathlib.Path('/tmp/router-759-mid-log-compaction-before-ci-measurements-v1-inputs.json')
after_path=pathlib.Path('/tmp/router-759-mid-log-compaction-after-ci-measurements-v1-inputs.json')
before={row['path']:row for row in json.loads(before_path.read_text())['inputs']}
after={row['path']:row for row in json.loads(after_path.read_text())['inputs']}
logs={row['originalPath']:row for row in plan['logs']}
manifests={row['path']:row for row in plan['manifests']}
sha=lambda data:hashlib.sha256(data).hexdigest()
changed=[];renamed=[]
for path,old in before.items():
    if path in logs:
        row=logs[path]
        assert old['sha256']==row['originalGzipSha256'] and old['bytes']==row['originalGzipBytes']
        assert path not in after
        assert after[row['storedPath']]['sha256']==row['xzSha256']
        decoded=lzma.decompress((root/row['storedPath']).read_bytes())
        assert len(decoded)==row['decodedBytes'] and sha(decoded)==row['decodedSha256']
        renamed.append({'original':old,'stored':after[row['storedPath']],
                        'decodedBytes':len(decoded),'decodedSha256':sha(decoded)})
    elif path in manifests:
        row=manifests[path]
        assert old['sha256']==row['originalSha256'] and old['bytes']==row['originalBytes']
        assert after[path]['sha256']==row['candidateSha256'] and after[path]['bytes']==row['candidateBytes']
        original=pathlib.Path(row['originalPath']).read_bytes()
        assert sha(original)==old['sha256']
        changed.append({'original':old,'stored':after[path]})
    else:
        assert after[path]==old,path
added=set(after)-set(before)-{row['storedPath'] for row in plan['logs']}
assert added=={'docs/case-studies/issue-759/raw/lossless-mid-sized-log-archives.json'}
before_report=pathlib.Path('/tmp/router-759-mid-log-compaction-before-ci-complete-report-v1.json')
after_report=pathlib.Path('/tmp/router-759-mid-log-compaction-after-ci-complete-report-v1.json')
assert json.loads(before_report.read_text())==json.loads(after_report.read_text())
proof={'schema':'complete-mid-sized-log-compaction-input-continuity-v1',
       'sourceHead':'8de7c1a48402c3e173ed853e66f678d2373568de','originalInputs':len(before),
       'allOriginalInputsAccountedFor':True,'allOtherOriginalFileBytesUnchanged':True,
       'completeRenamedLogs':renamed,'completeChangedManifestInputs':changed,
       'soleNewProvenanceInput':after[next(iter(added))],
       'beforeFullInputReceipt':{'path':str(before_path),'sha256':sha(before_path.read_bytes())},
       'afterFullInputReceipt':{'path':str(after_path),'sha256':sha(after_path.read_bytes())},
       'beforeCompleteMeasurementReport':{'path':str(before_report),'bytes':before_report.stat().st_size,'sha256':sha(before_report.read_bytes())},
       'afterCompleteMeasurementReport':{'path':str(after_report),'bytes':after_report.stat().st_size,'sha256':sha(after_report.read_bytes())},
       'everyCompleteMeasurementFieldEqualWithoutNormalization':True,
       'originalRustCargoInputs':[row for row in before.values() if row['path'].endswith('.rs') or row['path'] in ['Cargo.toml','Cargo.lock']],
       'rustExecuted':False,'fullGateAuthority':False}
output=base/'complete-continuity.json';assert not output.exists()
output.write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({key:value for key,value in proof.items() if key not in ['completeRenamedLogs','completeChangedManifestInputs','originalRustCargoInputs']}))
