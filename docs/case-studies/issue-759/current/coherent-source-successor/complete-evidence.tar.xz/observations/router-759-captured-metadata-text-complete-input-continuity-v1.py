from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
tmp=Path('/tmp');sha=lambda raw:hashlib.sha256(raw).hexdigest()
plan=json.loads((tmp/'router-759-captured-metadata-text-compaction-v1.plan.json').read_text())
before_path=tmp/'router-759-captured-metadata-compaction-before-measurements-v1-inputs.json'
after_path=tmp/'router-759-captured-metadata-compaction-after-measurements-v1-inputs.json'
before=json.loads(before_path.read_text());after=json.loads(after_path.read_text())
assert before['sourceHead']==after['sourceHead']==plan['sourceHead']
old={row['path']:row for row in before['inputs']};new={row['path']:row for row in after['inputs']}
replaced={row['logicalOriginalPath']:row for row in plan['entries']}
citations={row['path']:row for row in plan['citationUpdates']}
manifest='docs/case-studies/issue-759/raw/lossless-captured-metadata-text-archives.json'
assert set(new)==(set(old)-set(replaced))|{row['archivePath'] for row in replaced.values()}|{manifest}
checks=[];citation_checks=[]
for name,row in old.items():
 if name in replaced:
  record=replaced[name];encoded=(root/record['archivePath']).read_bytes();raw=gzip.decompress(encoded)
  original=subprocess.check_output(['git','show',plan['sourceHead']+':'+name],cwd=root,timeout=30)
  assert raw==original and len(raw)==row['bytes']==record['originalBytes'] and sha(raw)==row['sha256']==record['originalSha256']
  assert len(encoded)==new[record['archivePath']]['bytes']==record['archiveBytes'] and sha(encoded)==new[record['archivePath']]['sha256']==record['archiveSha256']
  checks.append({'logicalOriginalPath':name,'currentPath':record['archivePath'],'decodedBytes':len(raw),'decodedSha256':sha(raw),'archiveBytes':len(encoded),'archiveSha256':sha(encoded),'originalGitBytesEqual':True})
 elif name in citations:
  record=citations[name];raw=(root/name).read_bytes()
  assert row['sha256']==record['oldSha256'] and new[name]['sha256']==record['newSha256']==sha(raw)
  assert raw==Path(record['preparedPath']).read_bytes()
  citation_checks.append({'path':name,'before':row,'after':new[name],'matchesPreparedArchiveLinkUpdate':True})
 else:
  assert row==new[name],name
  raw=(root/name).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],name
  if name.startswith('docs/case-studies/issue-759/raw/'):
   checks.append({'logicalOriginalPath':name,'currentPath':name,'bytes':len(raw),'sha256':sha(raw),'byteIdentical':True})
assert not any(name.endswith('.rs') or name in ['Cargo.toml','Cargo.lock'] for name in replaced)
rust=[row for name,row in old.items() if name.endswith('.rs')]
cargo=[old[name] for name in ['Cargo.toml','Cargo.lock']]
result={'schema':'captured-metadata-text-complete-input-continuity-v1','sourceHead':plan['sourceHead'],'beforeInputVector':{'path':str(before_path),'sha256':sha(before_path.read_bytes()),'count':len(old)},'afterInputVector':{'path':str(after_path),'sha256':sha(after_path.read_bytes()),'count':len(new)},'completeOriginalRawInputs':checks,'archiveReplacements':len(replaced),'citationUpdates':citation_checks,'soleAddedProvenanceInput':new[manifest],'everyOtherInputByteIdentical':True,'allDecodedOriginalGitBytesEqual':True,'originalRustInputs':rust,'originalCargoInputs':cargo,'rustAndCargoInputsByteIdentical':True,'rustExecuted':False,'semanticAuthority':False,'fullGateAuthority':False}
out=tmp/'router-759-captured-metadata-text-complete-input-continuity-v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['completeOriginalRawInputs','originalRustInputs','originalCargoInputs','citationUpdates']}))
print(json.dumps({'completeOriginalRawInputCount':len(checks),'originalRustInputCount':len(rust),'originalCargoInputCount':len(cargo),'citationUpdates':len(citation_checks)}))
