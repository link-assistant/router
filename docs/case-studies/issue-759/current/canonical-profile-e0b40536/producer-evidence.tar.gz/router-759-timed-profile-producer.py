import datetime,hashlib,json,os,pathlib,re,subprocess,sys,time
root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
expected=sys.argv[1]; mode=sys.argv[2] if len(sys.argv)>2 else 'write'
assert re.fullmatch('[a-f0-9]{40}',expected) and mode in ['write','check']
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==expected
paths=subprocess.check_output(['git','ls-files','-z','--','*.rs','Cargo.toml','Cargo.lock','tools/translation','scripts/translate-router.mjs'],cwd=root).decode().split('\0')
paths=[p for p in paths if p and not p.startswith(('tools/translation/meta/','tools/translation/projects/'))]
def inputs():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if (root/p).is_file()}
before=inputs(); statusBefore=git('status','--porcelain')
free=os.statvfs(root);freebytes=free.f_bavail*free.f_frsize
assert freebytes>=2*1024**3,'Resource hold: less than 2 GiB free'
base=pathlib.Path('/tmp/router-759-profile-'+mode+'-'+expected[:9]);out=pathlib.Path(str(base)+'.log');err=pathlib.Path(str(base)+'-time.log')
assert not out.exists() and not err.exists(),'Refusing duplicate measurement/overwrite'
argv=['/usr/bin/time','-l','node','scripts/translate-router.mjs','--profile-matrix']+(['--check'] if mode=='check' else [])
started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
with out.open('wb') as o,err.open('wb') as e:result=subprocess.run(argv,cwd=root,stdout=o,stderr=e)
after=inputs();receipt={'argv':argv,'sourceHeadSha':expected,'mode':mode,'startedAtUtc':started,'elapsedSeconds':round(time.monotonic()-clock,3),'exitCode':result.returncode,'headShaAfter':git('rev-parse','HEAD'),'sourceInputFiles':len(before),'sourceInputSha256':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'sourceInputsUnchanged':before==after,'stdoutPath':str(out),'stderrAndResourcePath':str(err),'stdoutSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256(err.read_bytes()).hexdigest(),'statusBefore':statusBefore,'statusAfter':git('status','--porcelain'),'freeBytesBefore':freebytes,'freeBytesAfter':os.statvfs(root).f_bavail*os.statvfs(root).f_frsize}
for line in err.read_text().splitlines():
 for label,key in [('maximum resident set size','maximumResidentSetSizeBytes'),('peak memory footprint','peakMemoryFootprintBytes')]:
  match=re.match(r'\s*(\d+)\s+'+label+'$',line)
  if match:receipt[key]=int(match[1])
pathlib.Path(str(base)+'.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if not k.startswith('status')}),flush=True)
sys.exit(result.returncode or (0 if before==after and receipt['headShaAfter']==expected else 2))
