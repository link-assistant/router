import datetime,hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
expected=sys.argv[1]
assert re.fullmatch('[a-f0-9]{40}',expected)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==expected and git('status','--porcelain')=='', 'Producer requires exact clean frozen source'
free=__import__('os').statvfs(root); freebytes=free.f_bavail*free.f_frsize
assert freebytes>=2*1024**3,'Producer resource hold: less than 2 GiB free'
base=pathlib.Path('/tmp/router-759-generation-'+expected[:9]); out=pathlib.Path(str(base)+'.log'); err=pathlib.Path(str(base)+'-time.log')
assert not out.exists() and not err.exists(),'Refusing duplicate producer/overwrite of existing evidence'
argv=['/usr/bin/time','-l','node','scripts/translate-router.mjs']; started=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
with out.open('wb') as o,err.open('wb') as e:result=subprocess.run(argv,cwd=root,stdout=o,stderr=e)
receipt={'argv':argv,'sourceHeadSha':expected,'cleanBefore':True,'startedAtUtc':started,'elapsedSeconds':round(time.monotonic()-clock,3),'exitCode':result.returncode,'headShaAfter':git('rev-parse','HEAD'),'stdoutPath':str(out),'stderrAndResourcePath':str(err),'stdoutSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256(err.read_bytes()).hexdigest(),'freeBytesBefore':freebytes}
for line in err.read_text().splitlines():
 match=re.match(r'\s*(\d+)\s+maximum resident set size$',line)
 if match:receipt['maximumResidentSetSizeBytes']=int(match[1])
 match=re.match(r'\s*(\d+)\s+peak memory footprint$',line)
 if match:receipt['peakMemoryFootprintBytes']=int(match[1])
pathlib.Path(str(base)+'.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
sys.exit(result.returncode or (0 if receipt['headShaAfter']==expected else 2))
