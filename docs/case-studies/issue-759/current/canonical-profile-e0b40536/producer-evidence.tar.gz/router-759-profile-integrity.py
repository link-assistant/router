from pathlib import Path
import hashlib,json,subprocess,sys,gzip
r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head=sys.argv[1];phase=sys.argv[2]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=['packages/javascript/generated/rust-draft','packages/javascript/generated/rust-project','packages/typescript/generated/rust-draft','packages/typescript/generated/rust-project','tools/translation/meta','tools/translation/projects']
files=sorted([p for root in roots for p in (r/root).rglob('*') if p.is_file()]+[r/'parity/rust-source-inventory.json'])
hashes={str(p.relative_to(r)):sha(p) for p in files};snapshot=Path('/tmp/router-759-profile-canonical-before-'+head[:9]+'.json.gz')
if phase=='before':
 assert not snapshot.exists();snapshot.write_bytes(gzip.compress(json.dumps(hashes,sort_keys=True,separators=(',',':')).encode(),mtime=0));print(json.dumps({'snapshot':str(snapshot),'canonicalFiles':len(hashes),'canonicalHash':hashlib.sha256(json.dumps(hashes,sort_keys=True,separators=(',',':')).encode()).hexdigest()}));sys.exit(0)
assert phase=='after';before=json.loads(gzip.decompress(snapshot.read_bytes()));errors=[]
if before!=hashes:errors.append('Canonical outputs changed during independent matrix write')
manifests=list((r/'profiles').glob('matrix-*.json'));assert len(manifests)==1, 'Exactly one declared matrix manifest is required for this candidate'
m=json.loads(manifests[0].read_text());assert m['schema']=='independent-profile-bulk-inventory-v1'
expected={'neutral','unix-family','windows-family'}
if set(m['requiredProfiles'])!=expected or {p['name'] for p in m['profiles']}!=expected:errors.append('Declared profile set differs')
sourceRows=m['sources'];paths=subprocess.check_output(['git','ls-files','-z','--','*.rs'],cwd=r).decode().split(chr(0));paths=sorted(p for p in paths if p)
if sorted(s['source'] for s in sourceRows)!=paths:errors.append('Matrix source set differs from tracked original Rust')
for s in sourceRows+m['cargo']:
 if not s.get('available',True):errors.append('Actual Cargo input is unavailable: '+s['source']);continue
 p=r/s['source']
 if not p.is_file() or sha(p)!=s['sha256'] or p.stat().st_size!=s['bytes']:errors.append('Original input changed: '+s['source'])
canon=json.loads((r/'parity/rust-source-inventory.json').read_text());reports=[]
for profile in m['profiles']:
 inventory=json.loads((r/profile['inventory']).read_text())
 if inventory['implementationHashes']!=canon['implementationHashes']:errors.append('Profile implementation pins differ: '+profile['name'])
 if inventory['compilationProfile']!=profile['compilationProfile']:errors.append('Profile settings differ: '+profile['name'])
 if inventory['runtimeParity'] is not False:errors.append('Profile parity flag differs: '+profile['name'])
 if sorted((s['source'],s['sha256'],s['bytes']) for s in inventory['sources'])!=sorted((s['source'],s['sha256'],s['bytes']) for s in sourceRows):errors.append('Profile original source pins differ: '+profile['name'])
 for p,digest in inventory['implementationHashes'].items():
  if sha(r/p)!=digest:errors.append('Stale implementation source: '+p)
 for item in inventory['sources']+inventory['projects']:
  for target in item['targets'].values():
   if not (r/target).is_file():errors.append('Missing target: '+target)
 reports.append({'name':profile['name'],'directory':profile['directory'],'profileSha256':profile['profileSha256'],'totals':inventory['totals'],'production':inventory['functionCoverage']['production'],'projects':inventory['projects'],'implementationPins':len(inventory['implementationHashes']),'runtimeParity':False})
report={'sourceHead':head,'matrixPath':str(manifests[0].relative_to(r)),'matrixSha256':m['matrixSha256'],'sourceSetSha256':m['sourceSetSha256'],'sourceFiles':len(sourceRows),'profiles':reports,'canonicalFiles':len(hashes),'canonicalOutputsUnchanged':hashes==before,'platformDomainComplete':m['platformDomainComplete'],'commonExecutableOutput':m['commonExecutableOutput'],'runtimeParity':m['runtimeParity'],'errors':errors}
Path('/tmp/router-759-profile-integrity-'+head[:9]+'.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(bool(errors))
