from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head=sys.argv[1];oldhead='7bfc51aa447c8929f7b88540986b18f50554ef3d'
x=json.loads((root/'parity/rust-source-inventory.json').read_text());old=json.loads(subprocess.check_output(['git','show',oldhead+':parity/rust-source-inventory.json'],cwd=root));errors=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=sorted(p for p in subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines() if p.endswith('.rs'))
if tracked!=sorted(p['source'] for p in x['sources']):errors.append('tracked Rust source set differs')
for row in x['sources']:
 p=root/row['source']
 if sha(p)!=row['sha256'] or p.stat().st_size!=row['bytes']:errors.append(row['source']+': source bytes/hash differs')
 for target in row['targets'].values():
  if not (root/target).is_file():errors.append(target+': missing output')
 meta=json.loads((root/row['targets']['meta']).read_text())
 if meta.get('runtimeParity') is not False:errors.append(row['source']+': dishonest parity flag')
for p,digest in x['implementationHashes'].items():
 if sha(root/p)!=digest:errors.append(p+': implementation hash differs')
for project in x['projects']:
 for target in project['targets'].values():
  if not (root/target).is_file():errors.append(target+': missing project output')
report={'sourceHeadSha':head,'sourceFiles':len(x['sources']),'implementationPins':len(x['implementationHashes']),'totals':x['totals'],'priorTotals':old['totals'],'functionCoverage':x['functionCoverage'],'projects':x['projects'],'priorProjects':old['projects'],'runtimeParity':x['runtimeParity'],'errors':errors}
p=Path('/tmp/router-759-generated-'+head[:9]+'-integrity.json');p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(bool(errors))
