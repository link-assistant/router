from pathlib import Path
import datetime,gzip,hashlib,json,ast,subprocess

r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
expected='e0b405361ed24f9eedb035b1dec84a6047e845c1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==expected
paths=['docs/case-studies/issue-759/raw/sources/formal-ai/paths.txt','docs/case-studies/issue-759/raw/ci/source-manifest.jsonl','docs/case-studies/issue-759/raw/ci/metadata-compression-provenance.jsonl','docs/case-studies/issue-759/raw/ci/log-compression-migrations.jsonl']
receipt=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in paths:
 p=r/name;q=Path(str(p)+'.gz');assert p.is_file() and not q.exists()
 original=p.read_bytes();packed=gzip.compress(original,compresslevel=9,mtime=0)
 assert gzip.decompress(packed)==original and len(packed)<len(original)
 receipt.append({'originalPath':name,'storedPath':str(q.relative_to(r)),'originalBytes':len(original),'originalSha256':sha(original),'originalAllocatedBytes':p.stat().st_blocks*512,'storedBytes':len(packed),'storedSha256':sha(packed)})
 q.write_bytes(packed)
 assert gzip.decompress(q.read_bytes())==original and sha(q.read_bytes())==receipt[-1]['storedSha256']
 receipt[-1]['storedAllocatedBytes']=q.stat().st_blocks*512
 p.unlink()

ci=r/'docs/case-studies/issue-759/raw/ci'
replacements={
 'archive-ci.py':[("(ROOT/'source-manifest.jsonl').open('a')","gzip.open(ROOT/'source-manifest.jsonl.gz','at')")],
 'compress-completed-metadata.py':[("(m.ROOT/'metadata-compression-provenance.jsonl').open('a')","gzip.open(m.ROOT/'metadata-compression-provenance.jsonl.gz','at')")],
 'deduplicate-json-variants.py':[("(m.ROOT/'metadata-compression-provenance.jsonl').open('a')","gzip.open(m.ROOT/'metadata-compression-provenance.jsonl.gz','at')")],
 'migrate-large-logs-to-xz.py':[("(m.ROOT/'log-compression-migrations.jsonl').open('a')","gzip.open(m.ROOT/'log-compression-migrations.jsonl.gz','at')")],
 'verify-archive.py':[("(ROOT/'metadata-compression-provenance.jsonl').open()","gzip.open(ROOT/'metadata-compression-provenance.jsonl.gz','rt')")],
}
for name,pairs in replacements.items():
 p=ci/name;s=p.read_text()
 for before,after in pairs:assert before in s;s=s.replace(before,after)
 ast.parse(s);p.write_text(s)
for p in [r/'docs/case-studies/issue-759/README.md',ci/'README.md']:
 s=p.read_text()
 for name in paths:
  rel=name.removeprefix('docs/case-studies/issue-759/')
  s=s.replace(rel,rel+'.gz').replace(Path(name).name+'`',Path(name).name+'.gz`')
 p.write_text(s)
main=r/'docs/case-studies/issue-759/README.md'
s=main.read_text().replace('`raw/sources/formal-ai/paths.txt.gz`; no stored case file exceeds this size','Originally `raw/sources/formal-ai/paths.txt`; its exact decoded bytes are now retained in `paths.txt.gz`')
main.write_text(s)
out=r/'docs/case-studies/issue-759/raw/current-task/historical-text-compaction.json'
report={'schema':'lossless-historical-evidence-compaction-v1','sourceHead':expected,'compactedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':receipt,'allocatedBytesSaved':sum(x['originalAllocatedBytes']-x['storedAllocatedBytes'] for x in receipt),'method':'Deterministic gzip, reopened exact original bytes before plaintext replacement. Cumulative JSONL writers append gzip members; readers decode all members. Every historical entry and original byte remains recoverable. No logs or original Rust inputs removed.'}
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
