from pathlib import Path
from collections import Counter
import gzip,hashlib,json,subprocess,sys
root=Path(sys.argv[4]) if len(sys.argv)>4 else Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head=sys.argv[1]
checkoutHead=sys.argv[2] if len(sys.argv)>2 else head
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==checkoutHead
inventory=json.loads((root/'parity/rust-source-inventory.json').read_text());rows=[];metaInputs=[]
for original in inventory['sources']:
 if not original['source'].startswith('src/'):continue
 metaPath=original['targets']['meta'];raw=(root/metaPath).read_bytes();meta=json.loads(raw)
 assert meta['sourcePath']==original['source'] and meta['sourceSha256']==original['sha256']
 metaInputs.append({'path':metaPath,'sha256':hashlib.sha256(raw).hexdigest()})
 for item in meta['items']:
  if item.get('status')!='executable':rows.append({**item,'sourceFile':original['source'],'sourceSha256':original['sha256'],'metadataFile':metaPath})
projects=[]
for original in inventory['projects']:
 metaPath=original['targets']['meta'];raw=(root/metaPath).read_bytes();meta=json.loads(raw)
 projects.append({'entry':original['entry'],'metadataFile':metaPath,'metadataSha256':hashlib.sha256(raw).hexdigest(),'refused':meta.get('refused',[]),'unloweredItems':meta.get('unloweredItems',[]),'moduleDiagnostics':meta.get('moduleDiagnostics',[]),'bindingDiagnostics':meta.get('bindingEvidence',{}).get('diagnostics',[])})
report={'schema':'complete-original-source-gaps-v2','sourceHead':head,'scope':'every non-executable item in original src/ per-file metadata, separately from complete project refusals/unlowered/module/binding diagnostics; this is not only production functions','sourceTextField':'rows[].source retains original item text; rows[].sourceFile identifies its original file','metadataInputs':metaInputs,'rows':rows,'projects':projects}
encoded=json.dumps(report,separators=(',',':'),ensure_ascii=False).encode();prefix=sys.argv[3] if len(sys.argv)>3 else '/tmp/router-759-complete-gaps-'+head[:9];path=Path(prefix+'.json.gz');assert not path.exists();compressed=gzip.compress(encoded,mtime=0);path.write_bytes(compressed);assert gzip.decompress(path.read_bytes())==encoded
summary={'sourceHead':head,'path':str(path),'files':len(metaInputs),'nonExecutableRows':len(rows),'rowStatuses':dict(Counter(row['status'] for row in rows)),'decodedBytes':len(encoded),'compressedBytes':len(compressed),'compressedSha256':hashlib.sha256(compressed).hexdigest(),'projects':[{k:p[k] for k in ['entry','metadataFile','metadataSha256']}|{k:len(p[k]) for k in ['refused','unloweredItems','moduleDiagnostics','bindingDiagnostics']} for p in projects],'durableSource':'All original per-file and project metadata are generated repository artifacts; raw convenience dataset is temporary pending measured archive capacity.'}
Path(prefix+'-receipt.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
