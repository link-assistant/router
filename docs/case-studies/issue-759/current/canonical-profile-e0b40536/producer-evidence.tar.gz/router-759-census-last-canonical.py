from pathlib import Path
import json,subprocess,collections,sys
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
oldhead='e0b405361ed24f9eedb035b1dec84a6047e845c1';head=sys.argv[1]
old=json.loads(subprocess.check_output(['git','show',oldhead+':parity/rust-source-inventory.json'],cwd=root));new=json.loads((root/'parity/rust-source-inventory.json').read_text())
batch=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def prior(path):
 batch.stdin.write((oldhead+':'+path+'\n').encode());batch.stdin.flush();header=batch.stdout.readline().decode().split();assert len(header)==3 and header[1]=='blob';data=batch.stdout.read(int(header[2]));assert batch.stdout.read(1)==b'\n';return json.loads(data)
def key(item):return (item['term'],item['name'],json.dumps(item.get('span'),sort_keys=True))
changes=[];reasons=collections.Counter();samples={};sourceErrors=[]
for s,o in zip(new['sources'],old['sources'],strict=True):
 assert s['source']==o['source'];p=s['targets']['meta'];n=json.loads((root/p).read_text());previous=prior(p)
 if s['sha256']!=o['sha256']:sourceErrors.append(s['source'])
 if s['source'].startswith('src/') and 'tests' not in s['source'] and 'test_support' not in s['source']:
  for i in n['items']:
   if i['term']=='fn' and i['status']=='carried':
    d=i.get('diagnostic');reason=json.dumps({k:d.get(k) for k in ['kind','message']},sort_keys=True) if isinstance(d,dict) else str(d);reasons[reason]+=1;samples.setdefault(reason,{'source':s['source'],'name':i['name'],'span':i.get('span')})
 before={key(i):i for i in previous['items'] if i['status']=='executable'};after={key(i):i for i in n['items'] if i['status']=='executable'};entries={key(i):i for i in n['items']}
 for term,name,span in after.keys()-before.keys():changes.append({'source':s['source'],'term':term,'name':name,'span':json.loads(span),'change':'added'})
 for term,name,span in before.keys()-after.keys():changes.append({'source':s['source'],'term':term,'name':name,'span':json.loads(span),'change':'removed','diagnostic':entries.get((term,name,span),{}).get('diagnostic')})
oldproject=prior('tools/translation/projects/src/lib.meta.json');project=json.loads((root/'tools/translation/projects/src/lib.meta.json').read_text());batch.stdin.close();batch.wait();before={(i['term'],i['name']):i for i in oldproject['executable']};after={(i['term'],i['name']):i for i in project['executable']};projectChanges=[]
for term,name in after.keys()-before.keys():projectChanges.append({'term':term,'name':name,'change':'added'})
for term,name in before.keys()-after.keys():projectChanges.append({'term':term,'name':name,'change':'removed','diagnostics':[r for r in project['refused'] if r.get('name')==name or '.'.join([*r.get('module',[]),r.get('name','')])==name]})
methodKey=lambda i:(i['source'],i['name'],json.dumps(i.get('span'),sort_keys=True));beforeMethods={methodKey(i):i for i in oldproject['checkedMethods']};afterMethods={methodKey(i):i for i in project['checkedMethods']}
report={'publishedBaseline':oldhead,'sourceHead':head,'originalRustHashDifferences':sourceErrors,'totals':new['totals'],'productionFunctions':new['functionCoverage']['production'],'perFileExecutableChanges':sorted(changes,key=lambda c:(c['source'],c['term'],c['name'],str(c['span']))),'projects':new['projects'],'projectExecutableChanges':sorted(projectChanges,key=lambda c:(c['term'],c['name'])),'projectCheckedMethodsBefore':len(beforeMethods),'projectCheckedMethodsAfter':len(afterMethods),'projectMethodChanges':[dict(afterMethods[k],change='added')for k in sorted(afterMethods.keys()-beforeMethods.keys())]+[dict(beforeMethods[k],change='removed')for k in sorted(beforeMethods.keys()-afterMethods.keys())],'productionTopRefusalMessages':[{'count':count,'diagnostic':reason,'sample':samples[reason]}for reason,count in reasons.most_common(25)],'projectTopRefusalMessages':collections.Counter((r['kind'],r['message']) for r in project['refused']).most_common(25)}
path=Path('/tmp/router-759-census-vs-last-canonical-'+head[:9]+'.json');path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(path),'totals':new['totals'],'production':report['productionFunctions'],'perFileAdded':sum(c['change']=='added' for c in changes),'perFileRemoved':sum(c['change']=='removed' for c in changes),'methodChanges':report['projectMethodChanges'],'rustHashDifferences':sourceErrors}))
