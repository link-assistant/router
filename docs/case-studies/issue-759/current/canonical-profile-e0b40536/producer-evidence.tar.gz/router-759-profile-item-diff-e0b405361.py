import collections, hashlib, json
from pathlib import Path

ROOT = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
INTEGRITY = Path('/tmp/router-759-profile-integrity-e0b405361.json')
OUTPUT = Path('/tmp/router-759-profile-items-against-neutral-e0b405361.json')
receipt = json.loads(INTEGRITY.read_bytes())
assert not receipt['errors']
profiles, inputs = {}, []
assert not OUTPUT.exists(), 'No overwriting earlier evidence'
spanErrors=[]
for profile in receipt['profiles']:
    path = ROOT / profile['directory'] / 'parity/rust-source-inventory.json'
    raw = path.read_bytes(); inventory = json.loads(raw)
    inputs.append({'profile':profile['name'],'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(raw).hexdigest()})
    facts, counts = {}, collections.Counter()
    for source in inventory['sources']:
        meta_path = ROOT / source['targets']['meta']
        original = meta_path.read_bytes(); meta = json.loads(original)
        assert meta['sourceSha256'] == source['sha256']
        inputs.append({'profile':profile['name'],'path':meta_path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(original).hexdigest()})
        for item in meta['items']:
            if item['status'] != 'executable': continue
            assert item['term'] in ['fn','const','struct','enum','type'], item['term']
            key = (source['source'],item['term'],item['name'],item['span']['start'],item['span']['end'])
            assert key not in facts
            facts[key] = {'sourceFile':source['source'],'term':item['term'],'name':item['name'],'span':item['span'],'itemSha256':item['sha256'],'sourceSha256':source['sha256']}
            counts[item['term']] += 1
            actual=(ROOT/source['source']).read_text().encode('utf-16-le')[item['span']['start']*2:item['span']['end']*2].decode('utf-16-le')
            if hashlib.sha256(actual.encode()).hexdigest()!=item['sha256']:spanErrors.append(key)
    assert len(facts) == inventory['totals']['executable']
    profiles[profile['name']] = {'facts':facts,'counts':counts,'directory':profile['directory'],'profileSha256':profile['profileSha256']}
neutral = profiles['neutral']['facts']
result = {'schema':'source-profile-executable-item-diff-v1','sourceHead':receipt['sourceHead'],'matrixSha256':receipt['matrixSha256'],'sourceSetSha256':receipt['sourceSetSha256'],
    'scope':'all original per-file fn/const/layout item admission changes; source bodies remain unchanged; constructor helpers and project methods are excluded',
    'namespaceAuthority':False,'commonExecutableOutput':False,'platformDomainComplete':False,'runtimeParity':False,'compilerRuns':0,'producerRuns':0,'rustBuilds':0,'profiles':[],'inputs':inputs}
for name, profile in profiles.items():
    facts = profile['facts']
    result['profiles'].append({'name':name,'directory':profile['directory'],'profileSha256':profile['profileSha256'],'executableItems':len(facts),'termCounts':dict(profile['counts']),
        'addedAgainstNeutral':[facts[k] for k in sorted(facts.keys()-neutral.keys())],
        'removedAgainstNeutral':[neutral[k] for k in sorted(neutral.keys()-facts.keys())],
        'changedOriginalSourceHashes':[facts[k] for k in sorted(facts.keys()&neutral.keys()) if facts[k]['sourceSha256']!=neutral[k]['sourceSha256'] or facts[k]['itemSha256']!=neutral[k]['itemSha256']]})
result['originalItemSpanErrors']=spanErrors
assert not spanErrors, spanErrors[:3]
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
for profile in result['profiles']:
    print(json.dumps({key:profile[key] for key in ['name','executableItems','termCounts','addedAgainstNeutral','removedAgainstNeutral','changedOriginalSourceHashes']}))
print(json.dumps({'output':str(OUTPUT),'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),'bytes':OUTPUT.stat().st_size,'readOnlyInputs':len(inputs)}))
