import {translateSource} from "/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/translate.mjs";
const source='// é 😀\npub fn plain()->u8{7u8}\npub fn select(v:Option<u8>)->u8{if let Some(n)=v && n>0u8{return n;}0u8}';
const cargoManifest='[package]\nname="fixture"\nversion="0.1.0"\nedition="2024"\n';
try { const result=translateSource(source,'src/lib.rs',{cargoManifest});console.log(JSON.stringify(result.ir.counts)); } catch(error){console.error(error.stack);process.exitCode=1;}
