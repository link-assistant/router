import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate';
const {translateSource}=await import(root+'/tools/translation/translate.mjs');
const paths=execFileSync('git',['ls-files','-z','--','*.rs'],{cwd:root,encoding:'utf8'}).split('\0').filter(Boolean).sort();
for(const [index,path]of paths.entries()){
 if(index<64||index>=96)continue;
 console.log(JSON.stringify({state:'start',index,path}));
 try{const result=translateSource(readFileSync(root+'/'+path,'utf8'),path);console.log(JSON.stringify({state:'complete',index,path,counts:result.ir.counts}));}
 catch(error){console.log(JSON.stringify({state:'failure',index,path,name:error.name,message:error.message,stack:error.stack}));}
}
