from pathlib import Path
import datetime,gzip,hashlib,io,json,re,subprocess,sys,tarfile
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
head=sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}',head)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
prefix='router-759-final-preflight-'+head[:8]
receipt_path=Path('/tmp')/(prefix+'.json')
receipt=json.loads(receipt_path.read_bytes())
assert receipt['headShaBefore']==receipt['headShaAfter']==head and receipt['cleanBefore'] and receipt['cleanAfter']
assert receipt['stagesStarted']==['lint','node-tests','bun-tests','typescript','parity','translation','reverse-translation']
log=Path('/tmp')/(prefix+'.log');raw=log.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(raw)==receipt['stdoutBytes'] and sha(raw)==receipt['stdoutSha256']
assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',raw)
base=root/'docs/case-studies/issue-759/current'/('frozen-preflight-'+head[:8])
assert not base.exists()
files={log.name:raw,receipt_path.name:receipt_path.read_bytes(),'frozen-preflight-runner.py':Path('/tmp/router-759-final-preflight-measured.py').read_bytes(),'archive-recipe.py':Path(__file__).read_bytes()}
buf=io.BytesIO();members=[]
with gzip.GzipFile(filename='',mode='wb',fileobj=buf,mtime=0,compresslevel=9) as gz:
 with tarfile.open(fileobj=gz,mode='w|') as tar:
  for name,data in sorted(files.items()):
   t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
pack=buf.getvalue();assert len(pack)<2_000_000
with tarfile.open(fileobj=io.BytesIO(pack),mode='r|gz') as tar:
 for m,t in zip(members,tar,strict=True):assert t.name==m['path'] and sha(tar.extractfile(t).read())==m['sha256']
summary={'schema':'frozen-preflight-evidence-v1','testedHead':head,'sourceAndGeneratedArtifactsHead':head,'createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allSevenTerminal':True,'preflight':receipt,'archive':{'path':'preflight-evidence.tar.gz','bytes':len(pack),'sha256':sha(pack),'members':members,'reopenedErrors':0},'rustExecuted':False,'fullParityClaimed':False,'publicationHead':None,'publicationNote':'This evidence commit follows the exact tested commit; remote CI must attest the eventual published commit independently.'}
summary_bytes=(json.dumps(summary,indent=2)+'\n').encode()
case_paths=[root/'docs/case-studies/issue-759',root/'dev/log/issues/759']
before=sum(p.stat().st_blocks*512 for base_path in case_paths if base_path.exists() for p in base_path.rglob('*') if p.is_file())
assert before+len(pack)+len(summary_bytes)+32768<500_000_000
base.mkdir(parents=True)
(base/'preflight-evidence.tar.gz').write_bytes(pack)
(base/'receipt.json').write_bytes(summary_bytes)
(base/'README.md').write_text(f'# Frozen JavaScript preflight {head[:8]}\n\nAll seven stages completed on clean commit `{head}`. The archive preserves the complete raw output, exact terminal receipt, measured runner, and archive recipe. Stage intervals include command and marker buffering; they are not isolated command timings.\n\nThe terminal receipt records every failed command and the strict native inventory. Executable checks and remaining parity obligations must be read separately; no Rust was executed and no full parity is claimed. The evidence commit follows this tested commit, and the eventual published commit requires its own remote CI results.\n')
after=sum(p.stat().st_blocks*512 for base_path in case_paths if base_path.exists() for p in base_path.rglob('*') if p.is_file())
assert after<500_000_000
print(json.dumps({'evidencePath':str(base),'archiveBytes':len(pack),'archiveSha256':sha(pack),'members':len(members),'allocatedCaseBytes':after,'remainingCaseBytes':500_000_000-after}))
