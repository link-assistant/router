from pathlib import Path
import json,io,hashlib,tarfile
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');destination=root/'docs/case-studies/issue-759/current/coherent-2b5a2c-repair-nine'
names=['router-759-coherent-repair-packet-builder-v10.py','router-759-coherent-2b5a2c-pair-run-v10.py','router-759-coherent-2b5a2c-repair-plan.json','router-759-coherent-2b5a2c-repair-inputs.json','router-759-coherent-2b5a2c-repair-fingerprints.json','router-759-coherent-2b5a2c-direct-source-audit.json','router-759-coherent-2b5a2c-complete-failures-v1.json','router-759-coherent-repair-eight-direct-git-v1.json','router-759-canonical-be19f5-direct-git-v1.json','router-759-coherent-repair-nine-archive-v1.py']
names += ['router-759-corrected-let-chain-focused-v1.raw.log','router-759-corrected-let-chain-focused-v1.json']
names += ['router-759-coherent-2b5a2c5b4-repair-nine-'+suffix for suffix in ['preflight.json','node.raw.log','node-receipt.json','bun.raw.log','bun-receipt.json','summary.json']]
for name in names:assert (Path('/tmp')/name).is_file(),name
summary=json.loads((Path('/tmp')/names[-1]).read_text());assert summary['bothTerminal'];assert not destination.exists();sha=lambda b:hashlib.sha256(b).hexdigest();temporary=Path('/tmp/router-759-complete-repair-nine-v1.tar.xz');assert not temporary.exists();members=[]
with tarfile.open(temporary,'x:xz',preset=6) as stream:
 for name in names:
  path=Path('/tmp')/name;data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;stream.addfile(info,io.BytesIO(data));members.append({'name':name,'bytes':len(data),'sha256':sha(data),'originalPath':str(path)})
receipt={'schema':'router-759-coherent-complete-repair-pair-archive-v1','testedHead':summary['head'],'casesPerEngine':682,'counts':{engine:summary['receipts'][index]['counts'] for index,engine in enumerate(['node','bun'])},'passed':summary['passed'],'bothTerminal':True,'timedOut':any(r['timedOut'] for r in summary['receipts']),'sourceInputs':1910,'sourceInputsUnchanged':all(r['inputsUnchanged'] for r in summary['receipts']),'runtimeParity':False,'rustExecutions':0,'members':members,'archive':{'path':str((destination/'complete-repair-nine.tar.xz').relative_to(root)),'bytes':temporary.stat().st_size,'sha256':sha(temporary.read_bytes())},'directGitFullBytesVerification':'required after commit before any original cleanup'}
data=(json.dumps(receipt,indent=2)+'\n').encode();seen=set();allocated=0
for directory in ['docs/case-studies/issue-759','dev/log/issues/759']:
 for path in (root/directory).rglob('*'):
  if not path.is_file():continue
  stat=path.stat();key=(stat.st_dev,stat.st_ino)
  if key not in seen:seen.add(key);allocated+=stat.st_blocks*512
projected=allocated+((temporary.stat().st_size+4095)//4096)*4096+((len(data)+4095)//4096)*4096;assert projected<500000000,(allocated,projected)
destination.mkdir(parents=True);(destination/'complete-repair-nine.tar.xz').write_bytes(temporary.read_bytes());(destination/'receipt.json').write_bytes(data)
print(json.dumps({'archive':receipt['archive'],'members':len(members),'combinedAllocatedBefore':allocated,'combinedAllocatedProjected':projected,'passed':summary['passed']}))
