import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path

root = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '74aab6e1881348f61ad721f8e89ecf104bf483fb'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root)
out = root / 'docs/case-studies/issue-759/current/source-string-bytes-74aab6e1'
out.mkdir(parents=True, exist_ok=True)
archive = out / 'router-759-string-bytes-74aab6e1.tar.gz'
receipt = out / 'router-759-string-bytes-74aab6e1-receipt.json'
assert not archive.exists() and not receipt.exists()
paths, attempts = [], []
phases = [
    ('v1', 'initial', 192, 4, 21, 1478, '0683e2ddb45665c2d74d68f90ad80d18a691f14e'),
    ('v2', 'repair', 209, 7, 24, 1485, 'a6d87a87d3b0831b2a3a74464d4c2aceb5fffd67'),
    ('v2', 'staged', 209, 1, 24, 1485, '75e198602ef6948b0dc96ae89ecb99ad068e3536'),
    ('v2', 'final', 209, 0, 24, 1485, head),
]
for version, phase, tests, failures, files, inputs_count, source_head in phases:
    pair = []
    for engine in ['node', 'bun']:
        stem = Path('/tmp') / ('router-759-core-string-bytes-' + version + '-' + phase + '-' + engine)
        records = [Path(str(stem) + extension) for extension in ['.log', '.json', '.inputs.json']]
        data = json.loads(records[1].read_bytes())
        inputs = json.loads(records[2].read_bytes())
        raw = records[0].read_bytes()
        assert hashlib.sha256(raw).hexdigest() == data['logSha256']
        assert len(raw) == data['logBytes']
        assert hashlib.sha256(records[2].read_bytes()).hexdigest() == data['inputManifestSha256']
        assert data['sourceHeadBefore'] == data['sourceHeadAfter'] == source_head
        assert data['trackedStatusBefore'] == data['trackedStatusAfter'] == ''
        assert data['sourceHeadUnchanged'] and data['sourceInputsUnchanged']
        assert data['inputFiles'] == len(inputs['files']) == inputs_count
        assert data['sourceInputSha256Before'] == data['sourceInputSha256After'] == inputs['sha256']
        assert data['testFiles'] == files and not data['timedOut']
        assert data['timeoutSeconds'] == data['testStageTimeoutSeconds'] == 360
        assert data['producerRuns'] == data['rustBuilds'] == data['fullGateRuns'] == 0
        assert data['counts']['tests'] == tests
        assert data['counts']['fail'] == failures
        assert data['counts']['pass'] == tests - failures
        assert data['counts']['skipped'] == 0
        assert data['exitCode'] == (1 if failures else 0)
        if engine == 'node': assert data['counts']['cancelled'] == 0
        pair.append(data)
        attempts.append(data)
        paths += records
    for key in ['sourceHeadBefore', 'sourceInputSha256Before', 'inputManifestSha256']:
        assert pair[0][key] == pair[1][key]
paths += [Path('/tmp/' + name) for name in [
    'router-759-core-string-bytes-focused-v1.py',
    'router-759-core-string-bytes-focused-v2.py',
    'router-759-core-string-bytes-initial-failures.json',
    'router-759-core-string-bytes-repair-failures.json',
    'router-759-core-string-bytes-staged-failures.json',
    'router-759-rust-target-rescan-string-bytes.json',
]]
paths.append(Path(__file__))
members, duplicates = [], {}
with archive.open('xb') as encoded:
    with gzip.GzipFile(fileobj=encoded, mode='wb', filename='', mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as packed:
            for path in sorted(paths, key=lambda path: path.name):
                raw = path.read_bytes()
                digest = hashlib.sha256(raw).hexdigest()
                info = tarfile.TarInfo(path.name)
                info.mode, info.mtime, info.uid, info.gid = 0o644, 0, 0, 0
                member = {'name': path.name, 'originalPath': str(path), 'bytes': len(raw), 'sha256': digest}
                if digest in duplicates:
                    info.type, info.linkname = tarfile.LNKTYPE, duplicates[digest]
                    member['hardlinkTo'] = info.linkname
                    packed.addfile(info)
                else:
                    info.size = len(raw)
                    packed.addfile(info, io.BytesIO(raw))
                    duplicates[digest] = path.name
                members.append(member)
with tarfile.open(archive, 'r:gz') as packed:
    assert len(packed.getmembers()) == len(members)
    for member in members:
        raw = packed.extractfile(member['name']).read()
        assert len(raw) == member['bytes']
        assert hashlib.sha256(raw).hexdigest() == member['sha256']
assert not subprocess.check_output(['git', 'diff', '--name-only', 'f962a03bf38ccb5da198f55cd1d1ccf467d65cb5', head, '--', '*.rs', 'Cargo.toml', 'Cargo.lock'], cwd=root)
data = {
    'schema': 'paired-source-string-bytes-focused-evidence-v1',
    'sourceHead': head,
    'status': 'FOCUSED_PASS_NOT_FULL_GATE',
    'scope': 'Ten new actual borrowed str UTF8 Bytes and cooked u8 literal source cases through original callers and the shared checked meta, JavaScript and strict TypeScript pipeline, plus 199 range/pattern/iterator/ownership/source/numeric/const regressions across 24 files',
    'sourceQueue': ['7125548171442a8e0b5455c4706df161642bc7d4', '0683e2ddb45665c2d74d68f90ad80d18a691f14e', 'a6d87a87d3b0831b2a3a74464d4c2aceb5fffd67', '75e198602ef6948b0dc96ae89ecb99ad068e3536', head],
    'initialFailureSet': ['Four new byte loops/callbacks required original cooked byte literal parsing; all 184 earlier cases passed'],
    'repairFailureSet': ['Six source byte proofs confused raw num and checked lit stages', 'One authored global-name fixture contradicted preserved reserved ml_ source-prefix refusal'],
    'stagedFailureSet': ['One authored lazy arithmetic fixture expected division by zero instead of the actual RangeError message attempt to divide by zero; all 199 earlier cases passed'],
    'finalFixtureCorrection': 'Assert exact existing RangeError name and message with unchanged original Rust body; no compiler or application change after the 208/209 pair',
    'repair': 'Actual locked Rust lexer cooked-byte grammar with complete original parser/Cargo/escaper copies, exact primitive source identity, raw and checked proof staging and incomplete authority flags; standard UTF8 bridge remains source-inferred lowering',
    'applicationSourceChanged': False,
    'compilerSourceChanged': True,
    'attempts': attempts,
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(members), 'hardlinks': len(members) - len(duplicates), 'reopenedHashErrors': 0},
    'members': members,
    'verificationLimits': {'fullGate': False, 'canonicalProducer': False, 'profileMatrixProducer': False, 'corpusGain': False, 'fullParity': False, 'completeNamespace': False, 'completeTrait': False, 'completeCoreLibraryTranslation': False, 'utf8BridgeAutomaticallyCompiledFromCore': False, 'storedOrReverseCursors': False, 'ownedOrCustomDeref': False, 'constByteIteration': False, 'rustBuilds': 0, 'rssMeasurement': 'RUSAGE_CHILDREN maximum per terminated owned child, including setup Git; not sampled process-tree peak or footprint; Bun has no separate cancellation count'},
}
receipt.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'archiveBytes': archive.stat().st_size, 'archiveSha256': data['archive']['sha256'], 'receiptBytes': receipt.stat().st_size, 'receiptSha256': hashlib.sha256(receipt.read_bytes()).hexdigest(), 'members': len(members), 'hardlinks': data['archive']['hardlinks'], 'reopenedHashErrors': 0, 'allocatedBytes': sum(path.stat().st_blocks * 512 for path in [archive, receipt])}))
