import argparse,datetime,hashlib,json,os,pathlib,re,signal,subprocess,time,resource
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--head',required=True);p.add_argument('--mode',choices=['canonical','profile-write'],required=True);p.add_argument('--cap',type=int,required=True);a=p.parse_args();root=pathlib.Path(a.root)
assert re.fullmatch('[a-f0-9]{40}',a.head) and 60<=a.cap<=7200
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
assert git('rev-parse','HEAD')==a.head and not git('status','--porcelain'),'Requires exact clean frozen source'
base=pathlib.Path('/tmp/router-759-cohort-v3-'+a.mode+'-'+a.head[:9]);out=pathlib.Path(str(base)+'.log');err=pathlib.Path(str(base)+'-time.log');receipt=pathlib.Path(str(base)+'.json');inputs=pathlib.Path(str(base)+'-inputs.json')
assert not any(x.exists() for x in [out,err,receipt,inputs]),'Evidence path exists; never overwrite'
paths=subprocess.check_output(['git','ls-files','-z','--','*.rs','Cargo.toml','Cargo.lock','tools/translation','scripts/translate-router.mjs'],cwd=root).decode().split('\0');paths=sorted(x for x in paths if x and not x.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/')))
def snapshot():
 result=[]
 for path in paths:
  f=root/path;b=f.read_bytes() if f.is_file() else subprocess.check_output(['git','show',a.head+':'+path],cwd=root)
  result.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return result
before=snapshot();inputs.write_text(json.dumps({'head':a.head,'inputs':before},separators=(',',':'))+'\n');free=lambda:os.statvfs(root).f_bavail*os.statvfs(root).f_frsize;free_before=free();assert free_before>=2*1024**3
argv=['node','scripts/translate-router.mjs','--progress']+(['--profile-matrix'] if a.mode=='profile-write' else []);resources_before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();timed_out=False
with out.open('xb') as stdout,err.open('xb') as stderr:
 child=subprocess.Popen(argv,cwd=root,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=a.cap)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
  code=child.returncode
producer_elapsed=time.monotonic()-start;resources_after=resource.getrusage(resource.RUSAGE_CHILDREN);after=snapshot();j={'schema':'bounded-coherent-corpus-producer-v3','mode':a.mode,'sourceHead':a.head,'headAfter':git('rev-parse','HEAD'),'argv':argv,'capSeconds':a.cap,'startedUtc':started,'elapsedSeconds':round(producer_elapsed,3),'elapsedScope':'Direct waited producer including bounded termination; excludes post-input snapshot','wrapperElapsedSeconds':round(time.monotonic()-start,3),'exitCode':code,'timedOut':timed_out,'sourceInputFiles':len(before),'sourceInputSha256':hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'sourceInputsUnchanged':before==after,'inputReceipt':str(inputs),'freeBytesBefore':free_before,'freeBytesAfter':free(),'statusAfter':git('status','--porcelain'),'stdout':{'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},'stderr':{'path':str(err),'bytes':err.stat().st_size,'sha256':hashlib.sha256(err.read_bytes()).hexdigest()},'rustExecuted':False,'harnessSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'resource':{'scope':'Python waited producer children; max RSS is maximum recorded child, not aggregate concurrent memory or peak footprint','userCpuSeconds':resources_after.ru_utime-resources_before.ru_utime,'systemCpuSeconds':resources_after.ru_stime-resources_before.ru_stime,'maxRss':resources_after.ru_maxrss,'maxRssUnits':'bytes on Darwin; KiB on Linux','platform':os.uname().sysname}}
events=[]
for line in err.read_text(errors='replace').splitlines():
 try:event=json.loads(line)
 except (json.JSONDecodeError,ValueError):continue
 if isinstance(event,dict) and event.get('schema')=='rust-meta-translation-progress-v1':events.append(event)
j['progress']={'enabled':True,'events':len(events),'first':events[0] if events else None,'last':events[-1] if events else None,'completeRawRetained':True}
receipt.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items() if k!='statusAfter'}),flush=True)
raise SystemExit(code or (2 if timed_out or before!=after or j['headAfter']!=a.head else 0))
