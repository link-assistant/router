#!/usr/bin/env python3
import subprocess,os,time,json,hashlib,resource,signal,shutil,datetime,re,argparse
from pathlib import Path
ROOT=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
parser=argparse.ArgumentParser();parser.add_argument('--head',required=True);options=parser.parse_args();HEAD=options.head
assert re.fullmatch('[a-f0-9]{40}',HEAD)
PREFIX=Path('/tmp/router-759-publisher-progress-frame222-'+HEAD[:9])
NAMES=['source-method-transforms', 'source-method-parser', 'source-method-admission', 'source-method-project', 'matches-source-profile', 'source-macro-fragments', 'matches-source-bridge', 'ordered-matches', 'source-links', 'methods-translation', 'shared-method-receivers', 'parameter-patterns', 'pattern-bindings', 'tuple-bindings', 'source-namespaces', 'source-method-copy-origin', 'module-bindings', 'macro-subnamespaces', 'json-macro-lowering', 'method-namespace-registry', 'primitive-host-translation', 'json-capabilities', 'shared-match-field-origins', 'source-lifetimes', 'owned-result-lifetimes', 'source-lifetime-flow', 'local-lifetime-constraints', 'matches-immutable-context-cache', 'matches-parser-frame', 'translation-progress']
FILES=['tools/translation/test/'+name+'.test.mjs' for name in NAMES]
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True,timeout=30).strip()
def write(path,data):
 with open(path,'x') as f:json.dump(data,f,indent=2);f.write('\n')
def state(validate=True):
 h=git('rev-parse','HEAD');status=git('status','--porcelain')
 if validate and (h!=HEAD or status!=''):raise RuntimeError('Frozen source head/status changed: '+h+' '+status)
 return {'head':h,'status':status}
def inputs():
 rows=[]
 names=subprocess.check_output(['git','ls-files','-z','tools/translation','*.rs','Cargo.toml','Cargo.lock','packages/javascript/src','packages/javascript/package.json','packages/javascript/package-lock.json','package-lock.json','scripts'],cwd=ROOT,timeout=30).decode().split('\0')
 for name in sorted(set(filter(None,names))):
  if name.startswith(('tools/translation/meta/','tools/translation/projects/')):continue
  p=ROOT/name
  if p.is_file():b=p.read_bytes();rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
  else:b=subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT,timeout=30);rows.append({'path':name,'bytes':len(b),'sha256':sha(b)})
 return rows
def free_bytes():return shutil.disk_usage(ROOT).free
s=state();assert free_bytes()>=2*1024**3,'Free-space floor requires 2GiB';rows=inputs();
versions={engine:subprocess.check_output([engine,'--version'],cwd=ROOT,text=True,timeout=30).strip() for engine in ['node','bun']}
rows_digest=sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())
prep={'schema':'method-source-paired-focused-receipt-v1','phase':'publisher-progress-private-frame-composition222','startUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':s,'files':FILES,'authoredCases':222,'capSecondsPerEngine':600,'runnerSha256':sha(Path(__file__).read_bytes()),'inputsSha256':rows_digest,'inputs':rows,'generatedOutputDirectoriesExcluded':['tools/translation/meta','tools/translation/projects'],'environment':{key:os.environ.get(key) for key in ['PATH','ROUTER_TRANSLATION_TSC','NODE_OPTIONS','BUN_OPTIONS']},'executables':{key:shutil.which(key) for key in ['node','bun','tsc']},'runtimeParity':False,'admissionAuthority':False,'wholeReaderAuthority':False,'producerRun':False,'rustRun':False,'engineVersions':versions,'freeBytesBefore':free_bytes()}
write(str(PREFIX)+'-inputs.json',prep)
print('FROZEN',HEAD,len(rows),'inputs',rows_digest,flush=True)
receipts=[]
for engine in ['node','bun']:
 state();free_before=free_bytes();assert free_before>=2*1024**3,'Free-space floor requires 2GiB';before=resource.getrusage(resource.RUSAGE_CHILDREN);started=time.monotonic();timed_out=False
 args=['node','--test','--test-concurrency=1',*FILES] if engine=='node' else ['bun','test','--timeout','15000',*FILES]
 cmd=['/usr/bin/time','-p',*args]
 raw=Path(str(PREFIX)+'-'+engine+'.raw.log')
 with raw.open('xb') as out:
  child=subprocess.Popen(cmd,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=600)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
 after=resource.getrusage(resource.RUSAGE_CHILDREN);elapsed=time.monotonic()-started;data=raw.read_bytes();text=data.decode(errors='replace')
 unchanged=inputs()==rows
 receipt={'schema':prep['schema'],'phase':'publisher-progress-private-frame-composition222','engine':engine,'command':cmd,'exitCode':code,'timedOut':timed_out,'elapsedSeconds':elapsed,'stateAfter':state(False),'freeBytesBefore':free_before,'freeBytesAfter':free_bytes(),'engineVersion':versions[engine],'inputsUnchanged':unchanged,'inputsSha256':rows_digest,'runnerSha256':prep['runnerSha256'],'raw':{'path':str(raw),'bytes':len(data),'sha256':sha(data)},'resource':{'scope':'Python waited harness children; descendant accounting as provided by RUSAGE_CHILDREN; maximum RSS is maximum recorded child, not aggregate concurrent memory','userCpuSeconds':after.ru_utime-before.ru_utime,'systemCpuSeconds':after.ru_stime-before.ru_stime,'maxRss':after.ru_maxrss,'maxRssUnits':'bytes on Darwin; KiB on Linux','platform':os.uname().sysname},'nodeCounts':dict(re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)',text,re.M)) if engine=='node' else None,'bunSummary':[line for line in text.splitlines() if re.search(r'^\s*\d+ (?:pass|fail|skip)',line)],'authorityUnchanged':True}
 receipt['stateUnchanged']=receipt['stateAfter']==s
 receipts.append(receipt)
 write(str(PREFIX)+'-'+engine+'-receipt.json',receipt)
 print('TERMINAL',engine,json.dumps({k:receipt[k] for k in ['exitCode','timedOut','elapsedSeconds','inputsUnchanged','nodeCounts','bunSummary']}),flush=True)
 if not unchanged or not receipt['stateUnchanged']:raise SystemExit('Frozen compiler bytes/head/status changed; complete current raw/receipt retained')
print('PAIRED TERMINAL; complete publisher-progress-private-frame-composition222 raw logs retained',flush=True)

failed=any(r['exitCode']!=0 or r['timedOut'] or not r['inputsUnchanged'] or not r['stateUnchanged'] for r in receipts)
node=receipts[0]['nodeCounts'];bun=receipts[1]['bunSummary']
failed=failed or node.get('tests')!='222' or node.get('pass')!='222' or node.get('fail')!='0' or node.get('cancelled')!='0' or node.get('skipped')!='0'
failed=failed or not any(re.fullmatch(r'\s*222 pass\s*',line) for line in bun) or any(re.fullmatch(r'\s*[1-9]\d* (?:fail|skip)\s*',line) for line in bun)
raise SystemExit(1 if failed else 0)
