from pathlib import Path
import tarfile,lzma,json,hashlib,io,subprocess
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head='e68eea368e00626f6f0c7dc379da6ddc6514a40b';tmp=Path('/tmp');sha=lambda b:hashlib.sha256(b).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
complete=json.loads((tmp/'router-759-final-preflight-v4-e68eea368.json').read_text());assert complete['headBefore']==complete['headAfter']==head and complete['inputsUnchanged'] and not complete['timedOut'];assert len(complete['stages'])==7
rows={}
def add(p,name=None):
 p=Path(p);assert p.is_file() and not p.is_symlink();name=name or 'tmp/'+p.name;assert name not in rows;rows[name]=p
for p in sorted(tmp.glob('router-759-e68eea368-*')):
 if p.is_file() and p.name!='router-759-e68eea368-complete-gate-inputs-size-probe-v1.json.xz':add(p)
for prefix in ['router-759-final-preflight-v3-e68eea368','router-759-final-preflight-v4-e68eea368']:
 for suffix in ['.log','.json','-inputs.json']:add(tmp/(prefix+suffix))
for name in ['router-759-final-preflight-measured-v3.py','router-759-final-preflight-measured-v4.py','router-759-run-isolated-diagnostic-v1.py','router-759-run-isolated-candidate-diagnostic-v2.py','router-759-current-profile-validation-v1.py','router-759-matrix-direct-git-v1.py','router-759-matrix-5662-direct-git-v1.json','router-759-current-task-index-compaction-plan-v1.py','router-759-current-task-index-compaction-v1.plan.json','router-759-current-task-index-compaction-apply-v1.py','router-759-current-task-index-compaction-applied-v1.json','router-759-evidence-dedup-dry-plan-v2.py','router-759-evidence-dedup-dry-plan-v2.json','router-759-case-filesystem-compression-probe-v1.py','router-759-case-filesystem-compression-probe-v1.json','router-759-clap-4-6-7-original-source-acquisition-v1.json']:
 add(tmp/name)
for p in sorted((tmp/'router-759-clap-4-6-7-original-sources-v1').iterdir()):add(p,'clap-original/'+p.name)
review=json.loads((tmp/'router-759-e68eea368-isolated-derive-candidate-review-v1.json').read_text());candidate=Path(review['candidateRoot']);add(candidate/'translator-bundle.json','candidate/translator-bundle.json')
for row in review['productionAndTests']:
 p=candidate/row['path'];b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'];add(p,'candidate/'+row['path'])
add(Path(__file__),'tmp/'+Path(__file__).name)
archive=tmp/'router-759-e68-complete-gate-derive-evidence-v1.tar.xz';assert not archive.exists();first={};vector=[]
with lzma.open(archive,'xb',preset=6) as stream:
 with tarfile.open(fileobj=stream,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for name,p in sorted(rows.items()):
   b=p.read_bytes();h=sha(b);info=tarfile.TarInfo(name);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644;ident=(len(b),h)
   if ident in first:info.type=tarfile.LNKTYPE;info.linkname=first[ident];info.size=0;tar.addfile(info)
   else:info.size=len(b);tar.addfile(info,io.BytesIO(b));first[ident]=name
   vector.append({'path':name,'originalPath':str(p),'bytes':len(b),'sha256':h,'storedAsHardlink':info.type==tarfile.LNKTYPE})
expected={r['path']:r for r in vector};decoded={};verified=0
with tarfile.open(archive,'r:xz') as tar:
 for member in tar:
  assert member.name in expected and member.name not in decoded
  if member.islnk():assert member.linkname in decoded;b=decoded[member.linkname]
  else:assert member.isfile();b=tar.extractfile(member).read()
  row=expected[member.name];assert len(b)==row['bytes'] and sha(b)==row['sha256'] and b==Path(row['originalPath']).read_bytes();decoded[member.name]=b;verified+=1
assert verified==len(vector)
receipt={'schema':'router-759-complete-frozen-gate-isolated-derive-evidence-v1','sourceHead':head,'storedBytes':archive.stat().st_size,'storedSha256':sha(archive.read_bytes()),'members':vector,'memberCount':len(vector),'allOriginalDecodedBytesVerified':True,'retainedFailures':{'sandboxInterruptedAttempt':True,'completeGateFailure':True,'modelCatalogFixtureFailedAttempt':True,'filesystemCompressionFailedProbe':True},'frozenGate':complete,'candidateReview':review,'completeOldIndexPreserved':True,'fullGatePass':False,'freshCandidateBulk':False,'rustExecutions':0}
out=tmp/'router-759-e68-complete-gate-derive-evidence-v1.receipt.json';assert not out.exists();out.write_text(json.dumps(receipt,separators=(',',':'))+'\n');print(json.dumps({'archive':str(archive),'storedBytes':archive.stat().st_size,'memberCount':len(vector),'hardlinks':sum(r['storedAsHardlink'] for r in vector),'originalBytes':sum(r['bytes'] for r in vector),'receiptBytes':out.stat().st_size,'verified':verified}))
