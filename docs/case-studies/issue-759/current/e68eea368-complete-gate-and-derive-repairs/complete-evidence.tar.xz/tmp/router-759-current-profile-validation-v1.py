from pathlib import Path
import argparse,subprocess,signal,os,json,time,hashlib
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--head',required=True);a=p.parse_args();root=Path(a.root);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==a.head and not subprocess.check_output(['git','status','--porcelain'],cwd=root);raw=Path('/tmp/router-759-'+a.head[:9]+'-profile-strict-typescript-v1.raw.log');receipt=Path('/tmp/router-759-'+a.head[:9]+'-profile-strict-typescript-v1.json');assert not raw.exists() and not receipt.exists();command=['node','scripts/check-profile-typescript.mjs'];start=time.monotonic();timed=False
with raw.open('xb') as stream:
 child=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=child.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
rows=[]
for line in raw.read_text().splitlines():
 try:v=json.loads(line)
 except ValueError:continue
 if isinstance(v,dict) and 'profile' in v:rows.append(v)
result={'sourceHead':a.head,'command':command,'capSeconds':900,'exitCode':code,'timedOut':timed,'elapsedSeconds':time.monotonic()-start,'profiles':rows,'allThreePassed':len(rows)==3 and all(r['exitCode']==0 and r['strict'] and r['noEmit'] for r in rows) and code==0 and not timed,'headUnchanged':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==a.head,'statusUnchanged':not subprocess.check_output(['git','status','--porcelain'],cwd=root),'rawPath':str(raw),'rawSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'harnessSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rustExecutions':0,'runtimeParity':False};receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['allThreePassed'] and result['headUnchanged'] and result['statusUnchanged'] else 1)
