from pathlib import Path
import json,hashlib,collections,subprocess
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');groups=collections.defaultdict(list);seen=set();allocated=0
for directory in ['docs/case-studies/issue-759','dev/log/issues/759']:
 for p in (root/directory).rglob('*'):
  if not p.is_file():continue
  s=p.stat();k=(s.st_dev,s.st_ino)
  if k in seen:continue
  seen.add(k);allocated+=s.st_blocks*512;groups[(s.st_size,s.st_mode&0o777)].append(p)
duplicates=[]
for (size,mode),paths in groups.items():
 if len(paths)<2:continue
 matching=collections.defaultdict(list)
 for p in paths:matching[hashlib.sha256(p.read_bytes()).hexdigest()].append(p)
 for sha,match in matching.items():
  if len(match)>1:duplicates.append({'bytes':size,'mode':mode,'sha256':sha,'paths':[str(p.relative_to(root)) for p in match],'allocatedSavings':sum(p.stat().st_blocks*512 for p in match[1:])})
result={'schema':'router-759-task-owned-evidence-identical-bytes-dedup-plan-v2','sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'repositoryChanged':False,'engineRuns':0,'allocatedBefore':allocated,'duplicateGroups':len(duplicates),'allocatedSavings':sum(g['allocatedSavings'] for g in duplicates),'requiredBeforeMutation':'Compare every retained and replaced complete file against its exact HEAD Git blob; preserve all names and byte content; fail on untracked or changed members. Only task-owned case evidence, no compiler inputs or caches.','groups':duplicates};p=Path('/tmp/router-759-evidence-dedup-dry-plan-v2.json');assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='groups'}))
