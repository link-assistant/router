import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {translateProject} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/project.mjs';
import {loadDeriveDependencyProof} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/derive-dependencies.mjs';
import {PRODUCTION_PROFILE} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/cfg-profile.mjs';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/',manifest=readFileSync(root+'Cargo.toml','utf8'),lock=readFileSync(root+'Cargo.lock','utf8');
const source="#[derive(Debug,Default,Clone)] pub struct Inputs<'a>{pub path:&'a str} #[derive(serde::Serialize)] pub struct State{pub ready:bool} pub fn echo<'a>(path:&'a str)->&'a str{path} pub fn enabled(path:&str)->bool{path==\"router\"}";
const sources=new Map([['src/lib.rs','pub mod model;'],['src/model.rs',source]]),result=translateProject({entry:'src/lib.rs',paths:[...sources.keys()],readSource:path=>sources.get(path),compilationProfile:PRODUCTION_PROFILE,cargoManifest:manifest,deriveDependencies:loadDeriveDependencyProof({manifest,lock})});
for(const name of ['echo','enabled']){assert.equal(result.meta.executable.some(item=>item.name===name),false);assert.ok(result.meta.refused.some(item=>item.name===name&&item.message.includes('shadowed borrowed str type')));}
const receipt={schema:'router-759-original-lifetime-derive-baseline-v1',sourceHead:'e68eea368e00626f6f0c7dc379da6ddc6514a40b',fixtureSource:source,fixtureSha256:createHash('sha256').update(source).digest('hex'),expectedNamespaceRefusalsConfirmed:true,runtimeParity:false,rustExecutions:0,result};writeFileSync('/tmp/router-759-e68eea368-lifetime-derive-baseline-result-v1.json',JSON.stringify(receipt)+'\n',{flag:'wx'});console.log(JSON.stringify({expectedNamespaceRefusalsConfirmed:true,refusals:result.meta.refused,certificates:result.meta.deriveNamespaceFootprints.certificates.length,rustExecutions:0}));
