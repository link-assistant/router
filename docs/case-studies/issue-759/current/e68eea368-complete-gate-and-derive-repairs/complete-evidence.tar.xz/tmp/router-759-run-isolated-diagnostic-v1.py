from pathlib import Path
import argparse,subprocess,os,time,json,hashlib,signal
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--prefix',required=True);p.add_argument('--cap',type=int,default=120);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();assert a.prefix.startswith('/tmp/router-759-') and 1<=a.cap<=180;command=a.command[1:] if a.command and a.command[0]=='--' else a.command;assert command;root=Path(a.root);raw=Path(a.prefix+'.raw.log');receipt=Path(a.prefix+'.json');assert not raw.exists() and not receipt.exists();start=time.monotonic();timed=False;env=dict(os.environ);env['ROUTER_TRANSLATION_TSC']='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/packages/javascript/node_modules/.bin/tsc'
with raw.open('xb') as stream:
 child=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 try:code=child.wait(timeout=a.cap)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
r={'baselineSourceHead':'e68eea368e00626f6f0c7dc379da6ddc6514a40b','diagnosticRoot':str(root),'command':command,'capSeconds':a.cap,'exitCode':code,'timedOut':timed,'elapsedSeconds':time.monotonic()-start,'rawPath':str(raw),'rawSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'harnessSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sourceFiles':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in ['tools/translation/derive-inputs.mjs','tools/translation/derive-footprints.mjs','tools/translation/test/derive-lifetime-parameters.test.mjs'] if (root/p).is_file()],'rustExecutions':0,'fullGateAuthority':False};receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(code)
