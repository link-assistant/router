from pathlib import Path
import gzip,json,hashlib,subprocess
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');source=root/'docs/case-studies/issue-759/raw/current-task/index.json';head='e68eea368e00626f6f0c7dc379da6ddc6514a40b';git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain')
raw=source.read_bytes();assert git('show',head+':'+str(source.relative_to(root)))==raw
original=json.loads(raw);compressed=gzip.compress(raw,compresslevel=9,mtime=0);assert gzip.decompress(compressed)==raw
sha=lambda b:hashlib.sha256(b).hexdigest()
assert original['totalMembers']==sum(len(p['members']) for p in original['packs'])
assert original['totalStoredPackBytes']==sum(p['storedBytes'] for p in original['packs'])
compact={k:v for k,v in original.items() if k!='packs'};compact['version']=2;compact['schema']='issue-759-current-task-full-member-index-reference-v2';compact['completeOriginalIndex']={'path':'index-v1.complete.json.gz','bytes':len(compressed),'sha256':sha(compressed),'decodedBytes':len(raw),'decodedSha256':sha(raw),'preservation':'Every original JSON byte, field and full member hash vector is preserved losslessly; this reference index changes no archive or decoded member bytes.'};compact['packs']=[{**{k:v for k,v in pack.items() if k!='members'},'memberCount':len(pack['members']),'originalPackPosition':i} for i,pack in enumerate(original['packs'])]
new=(json.dumps(compact,indent=2)+'\n').encode();base=Path('/tmp/router-759-current-task-index-compaction-v1');outputs={str(base)+'.json.gz':compressed,str(base)+'.reference.json':new}
for name,data in outputs.items():
 with Path(name).open('xb') as f:f.write(data)
 assert Path(name).read_bytes()==data
receipt={'schema':'router-759-task-owned-index-complete-original-compaction-plan-v1','sourceHead':head,'source':str(source.relative_to(root)),'originalBytes':len(raw),'originalSha256':sha(raw),'compressedBytes':len(compressed),'compressedSha256':sha(compressed),'referenceBytes':len(new),'referenceSha256':sha(new),'originalPacks':len(original['packs']),'originalMembers':original['totalMembers'],'completeOriginalDecodedBytesVerified':True,'completeOriginalDirectGitBytesVerified':True,'logicalSavings':len(raw)-len(compressed)-len(new),'repositoryChanged':False,'rustExecutions':0,'mustApplyOnlyAfterFrozenGateTerminal':True,'plannedOutputs':list(outputs)}
with Path(str(base)+'.plan.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
assert source.read_bytes()==raw and not git('status','--porcelain');print(json.dumps(receipt))
