from pathlib import Path
import json,gzip,hashlib,subprocess,os
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head='e68eea368e00626f6f0c7dc379da6ddc6514a40b';gate=json.loads(Path('/tmp/router-759-final-preflight-v4-e68eea368.json').read_text());assert gate['headAfter']==head and gate['cleanAfter'] and gate['inputsUnchanged'] and not gate['timedOut']
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
plan=json.loads(Path('/tmp/router-759-current-task-index-compaction-v1.plan.json').read_text());original=root/plan['source'];raw=original.read_bytes();assert len(raw)==plan['originalBytes'] and sha(raw)==plan['originalSha256'] and git('show',head+':'+plan['source'])==raw
packed=Path('/tmp/router-759-current-task-index-compaction-v1.json.gz').read_bytes();reference=Path('/tmp/router-759-current-task-index-compaction-v1.reference.json').read_bytes();assert sha(packed)==plan['compressedSha256'] and sha(reference)==plan['referenceSha256'] and gzip.decompress(packed)==raw
ref=json.loads(reference);old=json.loads(raw);assert ref['totalMembers']==old['totalMembers']==8451 and len(ref['packs'])==len(old['packs'])==29
for a,b in zip(ref['packs'],old['packs']):
 assert a['memberCount']==len(b['members']);assert {k:v for k,v in a.items() if k not in ('memberCount','originalPackPosition')}=={k:v for k,v in b.items() if k!='members'}
def allocated():
 seen=set();total=0
 for part in ['docs/case-studies/issue-759','dev/log/issues/759']:
  for p in (root/part).rglob('*'):
   if not p.is_file():continue
   st=p.stat();key=(st.st_dev,st.st_ino)
   if key not in seen:seen.add(key);total+=st.st_blocks*512
 return total
before=allocated();target=original.parent/'index-v1.complete.json.gz';assert not target.exists();target.write_bytes(packed);temp=original.with_suffix('.compaction-tmp');assert not temp.exists();temp.write_bytes(reference);os.replace(temp,original)
readme=original.parent/'README.md';text=readme.read_text();old1='[index.json](index.json) lists every pack member, original byte length, SHA256, published head, original final report, and log-object mapping.';new1='[index.json](index.json) lists all pack identities and points to [the complete original member index](index-v1.complete.json.gz). Decompress that file with `gzip -dc index-v1.complete.json.gz` to inspect every original member byte length, SHA256, published head, final report, and log-object mapping. Every byte of the original index is preserved; the reference records both stored and decoded checksums.';assert text.count(old1)==1;text=text.replace(old1,new1);old2='To inspect a pack, first verify its file SHA256 against `index.json`, then use `tar -tzf <pack>` or extract only the required member into a task-owned temporary directory.';new2='To inspect a pack, first verify its file SHA256 against `index.json`, then use `tar -tzf <pack>` or extract only the required member into a task-owned temporary directory. Verify individual members against the full vectors in `gzip -dc index-v1.complete.json.gz`.';assert text.count(old2)==1;readme.write_text(text.replace(old2,new2))
after=allocated();assert after<before and after<500000000;assert gzip.decompress(target.read_bytes())==raw and original.read_bytes()==reference
receipt={'schema':'router-759-lossless-task-index-compaction-applied-v1','originalSourceHead':head,'afterCompleteGate':True,'gateReceipt':'/tmp/router-759-final-preflight-v4-e68eea368.json','plan':plan,'originalIndexCompleteDecodedBytesVerified':True,'originalDirectGitBytesVerified':True,'packsChanged':0,'memberBytesDiscarded':0,'caseCapBytes':500000000,'caseAllocatedBefore':before,'caseAllocatedAfter':after,'allocatedBytesReclaimed':before-after,'rustExecutions':0};p=Path('/tmp/router-759-current-task-index-compaction-applied-v1.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
