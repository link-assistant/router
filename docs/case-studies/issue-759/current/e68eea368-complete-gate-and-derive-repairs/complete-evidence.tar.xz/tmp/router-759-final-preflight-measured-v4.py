import argparse,datetime,hashlib,json,os,pathlib,re,resource,selectors,signal,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--head',required=True);p.add_argument('--cap',type=int,default=21600);a=p.parse_args();root=pathlib.Path(a.root)
assert re.fullmatch('[a-f0-9]{40}',a.head) and 600<=a.cap<=21600
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
assert git('rev-parse','HEAD')==a.head and not git('status','--porcelain'),'Requires clean exact frozen source'
import socket
with socket.socket() as loopback:loopback.bind(('127.0.0.1',0))
base=pathlib.Path('/tmp/router-759-final-preflight-v4-'+a.head[:9]);log=pathlib.Path(str(base)+'.log');receipt=pathlib.Path(str(base)+'.json');inputs=pathlib.Path(str(base)+'-inputs.json')
assert not any(x.exists() for x in [log,receipt,inputs]),'Never overwrite earlier evidence'
paths=sorted(x for x in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if x)
def snapshot():
 rows=[]
 for path in paths:
  f=root/path;kind='deleted';b=b''
  if f.is_symlink():kind='symlink';b=os.readlink(f).encode()
  elif f.is_file():kind='executable' if f.stat().st_mode&0o111 else 'file';b=f.read_bytes()
  rows.append({'path':path,'kind':kind,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return rows
before=snapshot();inputs.write_text(json.dumps({'head':a.head,'inputs':before},separators=(',',':'))+'\n');start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();prior=resource.getrusage(resource.RUSAGE_CHILDREN);timed_out=False;pipe_drain_truncated=False;drain_deadline=None;stage_times=[];active=None;active_start=None;pending=b''
with log.open('xb') as output:
 child=subprocess.Popen(['node','scripts/check-js-first-local.mjs'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
 selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ)
 while selector.get_map():
  if not timed_out and time.monotonic()-start>a.cap:
   timed_out=True
   try:os.killpg(child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    child.wait(timeout=5)
   drain_deadline=time.monotonic()+5
  if child.poll() is not None and drain_deadline is None:drain_deadline=time.monotonic()+5
  if drain_deadline is not None and time.monotonic()>drain_deadline:
   pipe_drain_truncated=True
   for registered in list(selector.get_map().values()):selector.unregister(registered.fileobj)
   child.stdout.close()
   break
  for key,_ in selector.select(timeout=.5):
   chunk=os.read(key.fd,65536)
   if not chunk:selector.unregister(key.fileobj);continue
   output.write(chunk);output.flush();pending+=chunk
   while b'\n' in pending:
    line,pending=pending.split(b'\n',1);marker=re.match(rb'^JavaScript stage: ([a-z-]+)',line)
    if marker:
     now=time.monotonic()
     if active is not None:stage_times.append({'stage':active,'observedElapsedSeconds':round(now-active_start,3)})
     active=marker.group(1).decode();active_start=now
 code=child.wait(timeout=5)
if active is not None:stage_times.append({'stage':active,'observedElapsedSeconds':round(time.monotonic()-active_start,3)})
after=snapshot();resources=resource.getrusage(resource.RUSAGE_CHILDREN);data=log.read_bytes();text=data.decode('utf8','replace');stages=re.findall(r'^JavaScript stage: (.+)$',text,re.M);expected=['lint','node-tests','bun-tests','typescript','parity','translation','reverse-translation'];failure_block=text.split('JavaScript preflight failed (no green stamp written):\n')[-1] if 'JavaScript preflight failed (no green stamp written):\n' in text else '';failures=[line for line in failure_block.splitlines() if re.match('^[a-z-]+: ',line)];summaries=re.findall(r'Native parity inventory: (\d+) features; (\d+)/(\d+) operations; (\d+)/(\d+) OpenAPI routes; (\d+) draft gaps; (\d+) validation errors\.',text);strict=summaries[-1] if summaries else None;stamp=pathlib.Path('/tmp/router-js-first-gate.json');strict_only=bool(strict and int(strict[-1])==0 and int(strict[-2])>0 and failures==['parity: node scripts/check-router-parity.mjs --strict'] and code==1 and stages==expected and not timed_out and not pipe_drain_truncated)
r={'schema':'frozen-local-preflight-v4','loopbackListenPermissionVerified':True,'precedingSandboxAttempt':'/tmp/router-759-final-preflight-v3-'+a.head[:9]+'.json','precedingSandboxInterruption':'/tmp/router-759-'+a.head[:9]+'-gate-sandbox-interruption-v1.json','headBefore':a.head,'headAfter':git('rev-parse','HEAD'),'cleanAfter':not git('status','--porcelain'),'inputsUnchanged':before==after,'inputFiles':len(before),'inputReceipt':str(inputs),'startedUtc':started,'elapsedSeconds':round(time.monotonic()-start,3),'capSeconds':a.cap,'exitCode':code,'timedOut':timed_out,'pipeDrainTruncated':pipe_drain_truncated,'argv':['node','scripts/check-js-first-local.mjs'],'harnessSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'stageMeasurements':stage_times,'measurementScope':'Observed sequential stage-marker intervals including commands and buffering, not isolated timings.','stages':stages,'failures':failures,'strictSummary':strict,'strictOnlyBlockers':strict_only,'strictParityPass':code==0 and not failures and stages==expected and not timed_out and not pipe_drain_truncated,'greenStampExists':stamp.exists(),'stdout':{'path':str(log),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},'resources':{'scope':'Python waited gate child; max RSS is maximum recorded child and is not aggregate memory or peak footprint.','userCpuSeconds':resources.ru_utime-prior.ru_utime,'systemCpuSeconds':resources.ru_stime-prior.ru_stime,'maxRss':resources.ru_maxrss,'maxRssUnits':'bytes on Darwin; KiB on Linux'}}
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
raise SystemExit(2 if r['headAfter']!=a.head or not r['cleanAfter'] or not r['inputsUnchanged'] or timed_out or pipe_drain_truncated else code)
