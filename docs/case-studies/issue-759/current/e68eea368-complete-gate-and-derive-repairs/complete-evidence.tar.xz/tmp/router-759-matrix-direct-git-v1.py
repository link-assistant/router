from pathlib import Path
import argparse,subprocess,json,hashlib,tarfile,io,time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--head',required=True);p.add_argument('--output',required=True);a=p.parse_args();root=Path(a.root);output=Path(a.output);assert not output.exists();git=lambda *args:subprocess.check_output(['git',*args],cwd=root,timeout=30).decode().strip();assert git('rev-parse','HEAD')==a.head and not git('status','--porcelain');sha=lambda b:hashlib.sha256(b).hexdigest();review=json.loads(Path('/tmp/router-759-5662-matrix-complete-review-v1.json').read_text());started=time.monotonic();child=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def blob(path):
 assert '\n' not in path and '\0' not in path;child.stdin.write((a.head+':'+path+'\n').encode());child.stdin.flush();header=child.stdout.readline();fields=header.decode().split();assert len(fields)==3 and fields[1]=='blob',header;size=int(fields[2]);parts=[];remaining=size
 while remaining:
  b=child.stdout.read(min(remaining,1024*1024));assert b;parts.append(b);remaining-=len(b)
 assert child.stdout.read(1)==b'\n';return b''.join(parts)
for row in review['allGeneratedFiles']:
 b=blob(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256'] and b==(root/row['path']).read_bytes(),row['path']
packets=[]
for folder,archive_name in [('matrix-5662-fresh-bulk','complete-generation.tar.xz'),('rust-embed-8-12-source-only','complete-source.tar.xz')]:
 directory='docs/case-studies/issue-759/current/'+folder;receipt_path=directory+'/receipt.json';receipt_bytes=blob(receipt_path);assert receipt_bytes==(root/receipt_path).read_bytes();r=json.loads(receipt_bytes);archive_path=directory+'/'+archive_name;b=blob(archive_path);assert b==(root/archive_path).read_bytes() and sha(b)==r['archive']['sha256'];members=r['members']
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:xz') as stream:
  assert stream.getnames()==[m['name'] for m in members]
  for m in members:
   original=Path(m['originalPath']).read_bytes();stored=stream.extractfile(m['name']).read();assert len(stored)==m['bytes'] and sha(stored)==m['sha256'] and stored==original,m['name']
 packets.append({'path':archive_path,'membersVerified':len(members),'completeOriginalBytesMatchExactGitArchive':True,'archiveSha256':sha(b)})
child.stdin.close();assert child.wait(timeout=30)==0;assert git('rev-parse','HEAD')==a.head and not git('status','--porcelain');result={'schema':'router-759-complete-matrix-and-source-direct-git-byte-verification-v1','committedHead':a.head,'producerHead':review['producer']['sourceHead'],'allGeneratedFilesVerified':len(review['allGeneratedFiles']),'allGeneratedBytesVerified':sum(r['bytes'] for r in review['allGeneratedFiles']),'archivePackets':packets,'fullArchiveOriginalMembersVerified':sum(r['membersVerified'] for r in packets),'mismatches':0,'comparison':'Each complete Git blob compared directly with worktree bytes; each decoded original archive member compared directly with the entire retained original temporary file. No prefix or hash-only comparison.','elapsedSeconds':time.monotonic()-started,'harnessSha256':sha(Path(__file__).read_bytes()),'originalTemporaryFilesRemoved':0,'rustExecutions':0};output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
