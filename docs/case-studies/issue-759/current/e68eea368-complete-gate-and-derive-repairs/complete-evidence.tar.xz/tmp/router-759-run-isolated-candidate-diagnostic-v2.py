from pathlib import Path
import argparse,subprocess,os,time,json,hashlib,signal
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--prefix',required=True);p.add_argument('--cap',type=int,default=120);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();assert a.prefix.startswith('/tmp/router-759-') and 1<=a.cap<=180;command=a.command[1:] if a.command and a.command[0]=='--' else a.command;assert command;root=Path(a.root).resolve();assert root==Path('/private/tmp/router-759-e68eea368-next-compiler');raw=Path(a.prefix+'.raw.log');receipt=Path(a.prefix+'.json');inputs=Path(a.prefix+'-inputs.json');assert not any(p.exists() for p in [raw,receipt,inputs])
sha=lambda b:hashlib.sha256(b).hexdigest()
def snapshot():
 paths=sorted(p for p in root.rglob('*') if '.git' not in p.relative_to(root).parts and p.is_file());rows=[]
 for f in paths:
  assert not f.is_symlink();b=f.read_bytes();rows.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':sha(b)})
 return rows
before=snapshot();inputs.write_text(json.dumps({'baselineSourceHead':'e68eea368e00626f6f0c7dc379da6ddc6514a40b','candidateInputs':before},separators=(',',':'))+'\n');start=time.monotonic();timed=False;env=dict(os.environ);env['ROUTER_TRANSLATION_TSC']='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/packages/javascript/node_modules/.bin/tsc'
with raw.open('xb') as stream:
 child=subprocess.Popen(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 try:code=child.wait(timeout=a.cap)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
after=snapshot();r={'schema':'router-759-full-isolated-candidate-input-diagnostic-v2','baselineSourceHead':'e68eea368e00626f6f0c7dc379da6ddc6514a40b','diagnosticRoot':str(root),'command':command,'capSeconds':a.cap,'exitCode':code,'timedOut':timed,'elapsedSeconds':time.monotonic()-start,'rawPath':str(raw),'rawBytes':raw.stat().st_size,'rawSha256':sha(raw.read_bytes()),'harnessSha256':sha(Path(__file__).read_bytes()),'candidateInputReceipt':str(inputs),'candidateInputReceiptSha256':sha(inputs.read_bytes()),'candidateInputCount':len(before),'candidateInputBytes':sum(x['bytes'] for x in before),'candidateInputsUnchanged':before==after,'rustExecutions':0,'fullGateAuthority':False};receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(code if before==after and not timed else 2)
