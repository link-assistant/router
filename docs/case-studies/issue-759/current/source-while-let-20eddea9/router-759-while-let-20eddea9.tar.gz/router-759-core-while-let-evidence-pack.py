import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path

root = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
prefix = 'router-759-core-while-let-v4-'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '2fa254ac0970978592d6d09b8ca883778ab0fc9a'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root)
out = root / 'docs/case-studies/issue-759/current/source-while-let-2fa254ac'
out.mkdir(parents=True, exist_ok=True)
archive = out / 'router-759-while-let-2fa254ac.tar.gz'
receipt = out / 'router-759-while-let-2fa254ac-receipt.json'
assert not archive.exists() and not receipt.exists()
paths, attempts = [], []
for phase in ['initial-3dca23c0', 'fixed-2fa254ac0']:
    pair = []
    for engine in ['node', 'bun']:
        stem = Path('/tmp') / (prefix + phase + '-' + engine)
        records = [Path(str(stem) + extension) for extension in ['.log', '.json', '.inputs.json']]
        data = json.loads(records[1].read_bytes())
        inputs = json.loads(records[2].read_bytes())
        raw = records[0].read_bytes()
        assert hashlib.sha256(raw).hexdigest() == data['logSha256']
        assert len(raw) == data['logBytes']
        assert hashlib.sha256(records[2].read_bytes()).hexdigest() == data['inputManifestSha256']
        assert data['sourceHeadUnchanged'] and data['sourceInputsUnchanged']
        assert data['inputFiles'] == len(inputs['files']) == 1473
        assert data['sourceInputSha256Before'] == inputs['sha256']
        assert data['testFiles'] == 20 and not data['timedOut']
        assert data['producerRuns'] == data['rustBuilds'] == data['fullGateRuns'] == 0
        assert data['counts']['skipped'] == 0
        assert data['counts']['fail'] == (2 if phase == 'initial-3dca23c0' else 0)
        assert data['counts']['tests'] == 183
        if engine == 'node': assert data['counts']['cancelled'] == 0
        if phase == 'fixed-2fa254ac0': assert data['sourceHeadBefore'] == head
        pair.append(data)
        attempts.append(data)
        paths += records
    assert pair[0]['sourceHeadBefore'] == pair[1]['sourceHeadBefore']
    assert pair[0]['sourceInputSha256Before'] == pair[1]['sourceInputSha256Before']
    assert pair[0]['inputManifestSha256'] == pair[1]['inputManifestSha256']
paths += [Path('/tmp/router-759-core-while-let-focused-v4.py'), Path('/tmp/router-759-core-c6fa-baseline-equivalence.json'), Path('/tmp/router-759-core-while-let-initial-failures.json'), Path('/tmp/router-759-rust-target-rescan-while-let.json'), Path(__file__)]
members, duplicates = [], {}
with archive.open('xb') as encoded:
    with gzip.GzipFile(fileobj=encoded, mode='wb', filename='', mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as packed:
            for path in sorted(paths, key=lambda path: path.name):
                raw = path.read_bytes()
                digest = hashlib.sha256(raw).hexdigest()
                info = tarfile.TarInfo(path.name)
                info.mode, info.mtime, info.uid, info.gid = 0o644, 0, 0, 0
                member = {'name':path.name, 'originalPath':str(path), 'bytes':len(raw), 'sha256':digest}
                if digest in duplicates:
                    info.type, info.linkname = tarfile.LNKTYPE, duplicates[digest]
                    member['hardlinkTo'] = info.linkname
                    packed.addfile(info)
                else:
                    info.size = len(raw)
                    packed.addfile(info, io.BytesIO(raw))
                    duplicates[digest] = path.name
                members.append(member)
with tarfile.open(archive, 'r:gz') as packed:
    assert len(packed.getmembers()) == len(members)
    for member in members:
        raw = packed.extractfile(member['name']).read()
        assert len(raw) == member['bytes']
        assert hashlib.sha256(raw).hexdigest() == member['sha256']
assert not subprocess.check_output(['git', 'diff', '--name-only', 'f962a03bf38ccb5da198f55cd1d1ccf467d65cb5', head, '--', '*.rs', 'Cargo.toml', 'Cargo.lock'], cwd=root)
data = {
    'schema':'paired-source-while-let-focused-evidence-v1',
    'sourceHead':head,
    'status':'FOCUSED_PASS_NOT_FULL_GATE',
    'scope':'eight new while-let cases including selected constructor proof controls, plus 175 original range/pattern/iterator/ownership/source regressions across twenty files, through original Rust bodies and checked meta to JavaScript and strict TypeScript',
    'sourceQueue':['3dca23c0a765dfa30bbe6daf83c62dc8f2978f24',head],
    'initialFailureSet':['nested actual standard Result/Option/tuple pattern projection rejected intermediate variant layouts', 'same-file constant LIMIT was treated as a fresh per-file pattern binder'],
    'repair':'generic selected constructor/field/type projection paths retain ordered tag guards and reject forged or divergent paths; actual constants referenced by patterns enter per-file declaration closure selection',
    'applicationSourceChanged':False,
    'compilerSourceChanged':True,
    'baselineEquivalenceReceipt':'router-759-core-c6fa-baseline-equivalence.json',
    'attempts':attempts,
    'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(members),'hardlinks':len(members)-len(duplicates),'reopenedHashErrors':0},
    'members':members,
    'verificationLimits':{'fullGate':False,'canonicalProducer':False,'profileMatrixProducer':False,'corpusGain':False,'fullParity':False,'completeNamespace':False,'completeTrait':False,'dropSemanticsComplete':False,'mutableOrOwnedPatternBindings':False,'letChains':False,'labelledOrValueBreaks':False,'rustBuilds':0,'rssMeasurement':'RUSAGE_CHILDREN maximum per terminated owned child, including setup Git; not aggregate sampled process-tree peak or footprint; Bun has no separate cancellation count'},
}
receipt.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSha256':data['archive']['sha256'],'receiptBytes':receipt.stat().st_size,'receiptSha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'members':len(members),'hardlinks':data['archive']['hardlinks'],'reopenedHashErrors':0,'allocatedBytes':sum(path.stat().st_blocks*512 for path in [archive,receipt])}))
