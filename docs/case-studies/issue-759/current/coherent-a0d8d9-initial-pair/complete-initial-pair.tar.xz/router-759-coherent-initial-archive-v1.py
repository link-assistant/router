import hashlib,io,json,os,subprocess,tarfile
from pathlib import Path
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
sha=lambda b:hashlib.sha256(b).hexdigest()
destination=root/'docs/case-studies/issue-759/current/coherent-a0d8d9-initial-pair'
destination.mkdir(parents=True,exist_ok=False)
names=['router-759-coherent-a0d8d9-final-handoff.json','router-759-coherent-a0d8d9-initial682-run-v1.py','router-759-coherent-a0d8d9-final-plan.json','router-759-coherent-a0d8d9-final-inputs.json','router-759-coherent-a0d8d9-final-fingerprints.json','router-759-coherent-packet-builder-v1.py','router-759-coherent-inclusive-preliminary-union.json','router-759-coherent-initial-node-failures-v1.json','router-759-coherent-initial-paired-failures-v1.json','router-759-coherent-initial-paired-failures-v2.json','router-759-coherent-initial-diagnostics-v1.mjs','router-759-coherent-initial-diagnostics-v1.raw.log','router-759-coherent-initial-diagnostics-v1-receipt.json','router-759-core-lib-1.89-source-response.json','router-759-core-lib-1.89-original.rs','router-759-coherent-aada-root-source-audit-v2.json','router-759-coherent-initial-archive-v1.py']
names += ['router-759-coherent-a0d8d9bdc-initial-coherent-'+suffix for suffix in ['preflight.json','node.raw.log','node-receipt.json','bun.raw.log','bun-receipt.json','summary.json']]
members=[]
archive=destination/'complete-initial-pair.tar.xz'
with tarfile.open(archive,'x:xz',preset=6) as stream:
 for name in names:
  data=(Path('/tmp')/name).read_bytes()
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  stream.addfile(info,io.BytesIO(data));members.append({'name':name,'bytes':len(data),'sha256':sha(data),'originalPath':'/tmp/'+name})
receipt={'schema':'router-759-coherent-initial-pair-archive-v1','testedHead':'a0d8d9bdc17221a81086ab80066af48e0a460fba','node':{'tests':682,'pass':524,'fail':158,'skip':0,'timeout':False},'bun':{'tests':682,'pass':524,'fail':158,'skip':0,'timeout':False},'sourceInputs':1885,'sourceInputsUnchanged':True,'sameFailedTestNames':True,'failedInventoryAttempt':'v1 incorrectly counted Bun summary duplicates; v2 retains all 158 actual failures','diagnostic':'Same-head bounded diagnostic only; no corpus or full gate execution','rustExecutions':0,'runtimeParity':False,'members':members,'archive':{'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'directGitFullBytesVerification':'required after commit before any original cleanup'}
(destination/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'archive':receipt['archive'],'members':len(members),'developmentAllocatedBytes':sum(p.stat().st_blocks*512 for p in (root/'docs/case-studies/issue-759').rglob('*') if p.is_file())}))
