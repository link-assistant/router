import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
const root='file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/';
const mod=path=>import(root+'tools/translation/'+path);
const {translateProject}=await mod('project.mjs');
const {sourceItems,rustTokens}=await mod('rust-structure.mjs');
const {originalMacroTrees}=await mod('macro-token-trees.mjs');
const {loadPinnedFormatSourceStages}=await mod('format-source-profiles.mjs');
const {compileFormatCallbackDataflow}=await mod('format-builtin-dataflow.mjs');
const {compileBuiltinSourceControl}=await mod('builtin-source-control.mjs');
const {NUMERIC_SOURCE_STAGE_PROFILE,numericSourceInputsFromFiles,compileNumericSourceStages}=await mod('serialization-schema/numeric-source-stage.mjs');
const {parseRust,checkProgram}=await mod('extensions/host-contracts.mjs');
const row=(label,operation)=>{try{console.log(JSON.stringify({label,value:operation()},(_,v)=>typeof v==='bigint'?String(v):v));}catch(error){console.log(JSON.stringify({label,error:{name:error.name,message:error.reason??error.message,span:error.span??null}}));}};
for(const [label,source] of [
  ['primitive-high','pub fn high(x:u64,y:u64)->u64{((x as u128*y as u128)>>64)as u64}pub fn low(x:u128)->u64{x as u64}'],
  ['signed-branch','pub fn signed(x:i32)->i32{if x<0{x>>3}else{x+1}}pub fn chosen(x:u64,flag:bool)->u64{if flag{x>>1}else{x/10}}'],
  ['late-primitive-alias','pub fn keep(x:u64)->u64{x}type u64=u8;'],
  ['late-wrapping-alias','pub fn actual(x:u64)->u64{x.wrapping_add(1)}type u64=u8;'],
])row(label,()=>{const result=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source});return {refused:result.meta.refused,executables:result.meta.executable};});
const context=numericSourceInputsFromFiles({manifest:readFileSync(new URL('Cargo.toml',root),'utf8'),lock:readFileSync(new URL('Cargo.lock',root),'utf8')});
row('original-formatter',()=>{const stage=compileNumericSourceStages(context);return {failure:stage.translationFailure,refused:stage.meta?.refused,executables:stage.meta?.executable};});
for(const name of ['expand_format_args_impl','parse_args'])row(name,()=>{const data=compileFormatCallbackDataflow(loadPinnedFormatSourceStages(),'compiler/rustc_builtin_macros/src/format.rs',name);const control=compileBuiltinSourceControl(data);return {projected:control.controlSyntaxProjected,diagnostics:control.diagnostics};});
row('ordinary-slot-source',()=>{});
const num=gunzipSync(readFileSync(new URL('tools/translation/source-profiles/primitive-bool-from/library-core-src-convert-num.rs.gz',root))).toString('utf8');
row('original-metavariable-tokens',()=>rustTokens(num).filter(t=>t.type==='ident'&&t.text.startsWith('$')&&!/^\$(?:[A-Za-z_][A-Za-z0-9_]*)?$/u.test(t.text)));
row('original-num-token-tree',()=>({trees:originalMacroTrees(num).length}));
const convert=gunzipSync(readFileSync(new URL('tools/translation/source-profiles/json-macro/standard/library-core-src-convert-mod.rs.gz',root))).toString('utf8');
row('original-identity-members',()=>{const owner=sourceItems(convert).find(i=>i.term==='impl'&&i.tokens.map(t=>t.text).join('|').includes('From|<|T|>|for|T'));const t=owner.tokens.filter(t=>t.type!=='comment'),open=t.find(t=>t.text==='{');return sourceItems(convert.slice(open.end,t.at(-1).start)).map(i=>({term:i.term,name:i.name,comment:i.comment,start:i.start,end:i.end}));});
row('checked-let-chain-coordinates',()=>{const source='pub fn retained(value:Option<u8>)->u8{if let Some(v)=value && v>0u8{return v;}0u8}fn main(){}';const checked=checkProgram(parseRust(source,{cargoManifest:'[package]\nname="fixture"\nversion="0.1.0"\nedition="2024"\n'}));const found=[];function walk(node){if(!node||typeof node!=='object')return;if(node.patternControl?.kind==='let-chain')found.push(node.patternControl.sourceCondition);for(const [key,value]of Object.entries(node))if(!['type','patternControl'].includes(key)){if(Array.isArray(value))value.forEach(walk);else walk(value);}}walk(checked.declarations.get('retained').body);return found;});
