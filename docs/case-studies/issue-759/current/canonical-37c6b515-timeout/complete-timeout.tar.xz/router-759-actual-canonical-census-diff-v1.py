import argparse,subprocess,json,pathlib,hashlib,collections
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--baseline',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=pathlib.Path(a.root)
def old(path):return json.loads(subprocess.check_output(['git','show',a.baseline+':'+path],cwd=r))
path='parity/rust-source-inventory.json';before=old(path);after=json.loads((r/path).read_text());prev={x['source']:x for x in before['sources']};curr={x['source']:x for x in after['sources']};assert prev.keys()==curr.keys();assert all(prev[k]['sha256']==curr[k]['sha256'] and prev[k]['bytes']==curr[k]['bytes'] for k in prev)
changed=[]
for k in sorted(prev):
 fields=['executableFunctions','executableConstants','executableTypes','executableConstructors','carried','preserved'];delta={f:curr[k][f]-prev[k][f] for f in fields if curr[k][f]!=prev[k][f]}
 if delta:changed.append({'source':k,'sha256':curr[k]['sha256'],'delta':delta})
projects=[]
for b,n in zip(before['projects'],after['projects']):
 assert b['entry']==n['entry'];bm=old(b['targets']['meta']);nm=json.loads((r/n['targets']['meta']).read_text())
 def items(m,key):return {(v['source'],v['name'],v.get('term','method')):v for v in m[key]}
 row={'entry':n['entry'],'before':b,'after':n}
 for key in ['executable','checkedMethods']:
  bs=items(bm,key);ns=items(nm,key);row[key+'Gains']=[ns[k] for k in sorted(ns.keys()-bs.keys())];row[key+'Losses']=[bs[k] for k in sorted(bs.keys()-ns.keys())]
 row['refusalCounts']=dict(collections.Counter(v.get('message','unknown') for v in nm['refused']));projects.append(row)
result={'schema':'actual-unchanged-original-corpus-before-after-v1','baselineHead':a.baseline,'sourceHeadAfter':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'originalSourceCount':len(curr),'allOriginalSourceHashesUnchanged':True,'totalsBefore':before['totals'],'totalsAfter':after['totals'],'functionCoverageBefore':before['functionCoverage'],'functionCoverageAfter':after['functionCoverage'],'changedSources':changed,'projects':projects,'runtimeParity':after['runtimeParity']}
o=pathlib.Path(a.output);assert not o.exists();o.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['projects','changedSources','functionCoverageBefore','functionCoverageAfter']}));print('changedSources',len(changed));print('report',o)
