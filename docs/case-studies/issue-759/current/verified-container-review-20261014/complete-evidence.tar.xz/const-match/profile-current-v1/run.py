from pathlib import Path
import json,subprocess,hashlib,time,datetime,os,signal,resource,gzip
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match')
folder=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
assert head=='04318e0285fc10b81d847ccfeb814b6b1c2960a4'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
paths=subprocess.check_output(['git','ls-files','-z','--','*.rs','Cargo.toml','Cargo.lock','tools/translation','scripts'],cwd=root).decode().split('\0')
paths=sorted(p for p in paths if p and not p.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/')))
def snap():
 missing=[p for p in paths if not(root/p).is_file()]
 batch=subprocess.check_output(['git','cat-file','--batch'],input=''.join(head+':'+p+'\n' for p in missing).encode(),cwd=root,timeout=120)
 offset=0;objects={}
 for p in missing:
  end=batch.index(b'\n',offset);fields=batch[offset:end].split();assert len(fields)==3 and fields[1]==b'blob';length=int(fields[2]);offset=end+1;objects[p]=batch[offset:offset+length];assert batch[offset+length:offset+length+1]==b'\n';offset+=length+1
 assert offset==len(batch)
 result=[]
 for p in paths:
  raw=(root/p).read_bytes() if(root/p).is_file() else objects[p]
  result.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 return result
before=snap();(folder/'inputs.json').write_text(json.dumps({'head':head,'inputs':before},indent=2)+'\n')
command=['node','--cpu-prof','--cpu-prof-interval=10000','--cpu-prof-dir='+str(folder),'--cpu-prof-name=canonical.cpuprofile','scripts/translate-router.mjs','--check','--progress']
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();usage=resource.getrusage(resource.RUSAGE_CHILDREN);timed=False
with(folder/'stdout.raw.log').open('xb') as out,(folder/'stderr.raw.log').open('xb') as err:
 child=subprocess.Popen(command,cwd=root,stdout=out,stderr=err,start_new_session=True)
 (folder/'running.json').write_text(json.dumps({'pid':child.pid,'processGroup':child.pid,'head':head,'command':command,'startedUtc':started,'capSeconds':2400},indent=2)+'\n')
 try:code=child.wait(timeout=2400)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
elapsed=time.monotonic()-start;after=snap();endusage=resource.getrusage(resource.RUSAGE_CHILDREN)
logs=[]
for f in [folder/'stdout.raw.log',folder/'stderr.raw.log',folder/'canonical.cpuprofile']:
 if not f.exists():continue
 b=f.read_bytes();logs.append({'path':f.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
receipt={'schema':'bounded-canonical-cpu-profile-v1','head':head,'command':command,'capSeconds':2400,'exitCode':code,'elapsedSeconds':elapsed,'timedOut':timed,'inputsUnchanged':before==after,'headUnchanged':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head,'logs':logs,'maxWaitedChildRssBytes':endusage.ru_maxrss,'resourceScope':'RUSAGE_CHILDREN maximum recorded child on Darwin; not aggregate concurrent memory','userCpuSeconds':endusage.ru_utime-usage.ru_utime,'systemCpuSeconds':endusage.ru_stime-usage.ru_stime,'fullGatePass':False,'runtimeParity':False,'rustExecuted':False}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
raise SystemExit(code if code else (0 if receipt['inputsUnchanged'] and receipt['headUnchanged'] else 2))
