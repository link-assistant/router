import pathlib,subprocess,time,json,resource
p=pathlib.Path("packages/javascript/node_modules/.issue-759-verification/immutable-digest-benchmark-v1").resolve();rows=[]
for engine in ["node","bun"]:
 out=p/engine;out.mkdir();cmd=[engine,str(p/"benchmark.mjs"),str(out)];start=time.monotonic()
 with (out/"stdout.raw.log").open("wb") as a,(out/"stderr.raw.log").open("wb") as b:
  try:code=subprocess.run(cmd,stdout=a,stderr=b,timeout=180).returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 row={"command":cmd,"exitCode":code,"timedOut":timed,"elapsedSeconds":time.monotonic()-start,"capSeconds":180,"maxWaitedChildRssBytes":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rssScope":"process-lifetime RUSAGE_CHILDREN maximum, not concurrent total/per-engine reset"};rows.append(row);print(json.dumps(row),flush=True)
(p/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
