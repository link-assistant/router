import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root=process.cwd(),load=name=>import(pathToFileURL(path.join(root,'tools/translation',name)).href);
const {metadataDigest,copyMetadata}=await load('extensions/source-links.mjs');
const {loadDeriveDependencyProof}=await load('derive-dependencies.mjs');
const {createDeriveFootprintContext}=await load('derive-footprints.mjs');
const {createDefaultSourceContext,defaultSourceContextFacts}=await load('default-trait-source.mjs');
const {originalDefaultGeneratedMethod}=await load('default-source-ir.mjs');
const {captureSourceModuleViews,originalSourceModuleItems}=await load('source-module-views.mjs');
const {PRODUCTION_PROFILE}=await load('cfg-profile.mjs');
const {HostRustParser}=await load('extensions/host-contracts.mjs');
const source='#[derive(Default)]pub struct Payload{text:String,maybe:Option<u64>,values:Vec<String>,enabled:bool,count:u32,total:u64}';
const dependencies=loadDeriveDependencyProof({manifest:fs.readFileSync('Cargo.toml','utf8'),lock:fs.readFileSync('Cargo.lock','utf8')});
const views=captureSourceModuleViews({source,sourcePath:'src/lib.rs',compilationProfile:PRODUCTION_PROFILE}),modules=views.views.map(sourceView=>({file:'src/lib.rs',path:sourceView.modulePath,source,sourceView,compilationProfile:PRODUCTION_PROFILE,configurationCondition:sourceView.configurationCondition}));
const context=createDefaultSourceContext(createDeriveFootprintContext({modules,dependencies,compilationProfile:PRODUCTION_PROFILE})),module=defaultSourceContextFacts(context).modules[0],item=originalSourceModuleItems(module).find(row=>row.name==='Payload');
const surface=originalDefaultGeneratedMethod(context,module,item,HostRustParser),value=surface.impl.defaultSourceProof;
const legacy=value=>createHash('sha256').update(JSON.stringify(copyMetadata(value),(_,item)=>typeof item==='bigint'?{$integer:item.toString()}:item)).digest('hex');
const expected=legacy(value);assert.equal(metadataDigest(value),expected);
const out=process.argv[2];fs.writeFileSync(path.join(out,'complete-original-proof.json'),JSON.stringify(value)+'\n');fs.writeFileSync(path.join(out,'fixture.rs'),source);
const trials=[];
for(let trial=0;trial<5;trial++){
 const row={trial,iterations:20};
 for(const [label,compute]of trial%2?[['cached',metadataDigest],['legacy',legacy]]:[['legacy',legacy],['cached',metadataDigest]]){
  const start=performance.now();for(let iteration=0;iteration<20;iteration++)assert.equal(compute(value),expected);row[label+'Milliseconds']=performance.now()-start;
 }
 trials.push(row);
}
console.log(JSON.stringify({engine:process.versions.bun?'bun':'node',source,completeProofBytes:Buffer.byteLength(JSON.stringify(value)),digest:expected,trials,claimScope:'microbenchmark of identical private frozen original generated Default proof only; no corpus or memory-saving claim'}));
