import pathlib,subprocess,time,json,hashlib,resource
root=pathlib.Path.cwd();out=root/"packages/javascript/node_modules/.issue-759-verification/immutable-digest-complete-v2"
files=["tools/translation/test/immutable-metadata-digest.test.mjs","tools/translation/test/source-links.test.mjs","tools/translation/test/default-container-source.test.mjs","tools/translation/test/default-unit-methods.test.mjs","tools/translation/test/default-source-methods.test.mjs","tools/translation/test/clone-source-methods.test.mjs","tools/translation/test/clone-unit-methods.test.mjs"]
for f in files:assert pathlib.Path(f).is_file(),f
source_files=sorted(set(files+["tools/translation/extensions/source-links.mjs","tools/translation/extensions/immutable-metadata-digest.mjs"]))
def vector():
 return [{"path":f,"bytes":len((b:=pathlib.Path(f).read_bytes())),"sha256":hashlib.sha256(b).hexdigest()} for f in source_files]
before=vector();(out/"inputs.json").write_text(json.dumps(before,indent=2)+"\n")
for f in source_files:
 dst=out/"source-snapshots"/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(pathlib.Path(f).read_bytes())
rows=[]
for label,cmd in [("node",["node","--test","--test-concurrency=1",*files]),("bun",["bun","test",*files])]:
 start=time.monotonic()
 with (out/(label+".stdout.raw.log")).open("wb") as a,(out/(label+".stderr.raw.log")).open("wb") as b:
  try:code=subprocess.run(cmd,stdout=a,stderr=b,timeout=300).returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 row={"command":cmd,"wholeFiles":len(files),"exitCode":code,"timedOut":timed,"elapsedSeconds":time.monotonic()-start,"capSeconds":300,"maxWaitedChildRssBytes":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rssScope":"RUSAGE_CHILDREN process-lifetime high-water, not concurrent sum or per-engine reset","inputsUnchanged":vector()==before};rows.append(row);print(json.dumps(row),flush=True)
(out/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
