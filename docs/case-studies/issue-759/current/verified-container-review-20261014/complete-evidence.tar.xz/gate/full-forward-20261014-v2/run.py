from pathlib import Path
import json,subprocess,hashlib,time,datetime,os,signal,resource
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
folder=Path(__file__).parent
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root).decode().strip()
assert head=='e3b9b3cafe0151fa7e4595fc6ff573795abac452'
assert not subprocess.check_output(["git","status","--porcelain"],cwd=root)
paths=subprocess.check_output(['git','ls-files','-z','--','*.rs','Cargo.toml','Cargo.lock','tools/translation','scripts'],cwd=root).decode().split('\0')
paths=sorted(p for p in paths if p and not p.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/')))
def snap():
 missing=[p for p in paths if not(root/p).is_file()]
 batch=subprocess.check_output(['git','cat-file','--batch'],input=''.join(head+':'+p+'\n' for p in missing).encode(),cwd=root,timeout=120)
 offset=0;objects={}
 for p in missing:
  end=batch.index(b'\n',offset);fields=batch[offset:end].split();assert len(fields)==3 and fields[1]==b'blob';length=int(fields[2]);offset=end+1;objects[p]=batch[offset:offset+length];assert batch[offset+length:offset+length+1]==b'\n';offset+=length+1
 assert offset==len(batch)
 result=[]
 for p in paths:
  raw=(root/p).read_bytes() if(root/p).is_file() else objects[p]
  result.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 return result
before=snap();(folder/'inputs.json').write_text(json.dumps({'head':head,'inputs':before},indent=2)+'\n')
files=json.loads((folder/'files.json').read_text());receipts=[]
for engine,command in [('node',['node','--test','--test-concurrency=2']+files),('bun',['bun','test']+files)]:
 start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN);timed=False
 with(folder/(engine+'.stdout.raw.log')).open('xb') as out,(folder/(engine+'.stderr.raw.log')).open('xb') as err:
  child=subprocess.Popen(command,cwd=root,stdout=out,stderr=err,start_new_session=True)
  (folder/'running.json').write_text(json.dumps({'head':head,'pid':child.pid,'processGroup':child.pid,'engine':engine,'command':command,'capSeconds':2400},indent=2)+'\n')
  try:code=child.wait(timeout=2400)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
 endusage=resource.getrusage(resource.RUSAGE_CHILDREN);after=snap();logs=[]
 for name in [engine+'.stdout.raw.log',engine+'.stderr.raw.log']:
  f=folder/name;b=f.read_bytes();logs.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 receipt={'head':head,'command':command,'wholeTestFiles':len(files),'exitCode':code,'elapsedSeconds':time.monotonic()-start,'capSeconds':2400,'timedOut':timed,'inputsUnchanged':before==after,'headUnchanged':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head,'maxWaitedChildRssBytes':endusage.ru_maxrss,'rssScope':'RUSAGE_CHILDREN maximum across all completed children at observation; not aggregate concurrent memory or per-engine isolation','userCpuSeconds':endusage.ru_utime-usage.ru_utime,'systemCpuSeconds':endusage.ru_stime-usage.ru_stime,'logs':logs,'fullGatePass':False,'rustExecuted':False};receipts.append(receipt);(folder/'receipt.json').write_text(json.dumps(receipts,indent=2)+'\n');print(json.dumps(receipt),flush=True)
