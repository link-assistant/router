import pathlib,json,subprocess,hashlib,shutil,time,importlib.util
root=pathlib.Path.cwd();out=root/"packages/javascript/node_modules/.issue-759-verification/complete-packet-install-v1";case=root/"docs/case-studies/issue-759"
source=root.parent/"issue-759-reverse-cycle/packages/javascript/node_modules/.issue-759-verification/combined-evidence-pack-v1"
plan=json.loads((source/"reviewable-case-install/migration-plan.json").read_text());cap=500000000
def allocated():
 seen=set();total=0
 for p in case.rglob("*"):
  if p.is_symlink():raise ValueError("Linked case file")
  if not p.is_file():continue
  s=p.stat();key=(s.st_dev,s.st_ino)
  if key not in seen:seen.add(key);total+=s.st_blocks*512
 return total
def facts(p):
 h=hashlib.sha256();size=0
 with p.open("rb") as f:
  while b:=f.read(1048576):h.update(b);size+=len(b)
 return size,h.hexdigest()
def command(label,argv,timeout):
 start=time.monotonic()
 with (out/(label+".stdout.raw.log")).open("xb") as a,(out/(label+".stderr.raw.log")).open("xb") as b:r=subprocess.run(argv,cwd=root,stdout=a,stderr=b,timeout=timeout)
 record={"label":label,"command":argv,"exitCode":r.returncode,"elapsedSeconds":time.monotonic()-start,"capSeconds":timeout};(out/(label+".command.json")).write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(record),flush=True)
 if r.returncode:raise RuntimeError("Mandatory migration check failed: "+label)
old=case/plan["oldArchive"]["casePath"];pin=plan["oldArchive"]["index"]["archives"][plan["oldArchive"]["casePath"]]
assert facts(old)==(pin["bytes"],pin["sha256"]);before=allocated();assert before<=cap
(out/"initial-allocation.json").write_text(json.dumps({"allocatedBytes":before,"capBytes":cap,"oldArchiveAllocatedBytes":old.stat().st_blocks*512},indent=2)+"\n")
index=case/"packet-git-index.json";assert not index.exists();index.write_bytes((source/"reviewable-case-install/packet-git-index.json").read_bytes());assert allocated()<=cap
receipt=case/"raw/current-task/source-variants-batch-v3/original-capture-receipt.json.gz"
base=["python3","tools/evidence/packet.py","--case-root",str(case),"--repository-root",str(root),"--packet",plan["oldArchive"]["casePath"],"--members-receipt",str(receipt)]
command("old-present",base,120)
command("ci-before",["python3","docs/case-studies/issue-759/raw/ci/verify-archive.py","--root",str(case/"raw/ci"),"--git-root",str(root),"--output",str(out/"ci-before.json")],600)
command("measure-before",["node","scripts/measure-js-first.mjs",str(case/"raw"),"--output",str(out/"measure-before.json")],600)
# Verified reachable immutable bytes and unchanged complete receipts precede removal.
old_allocated=old.stat().st_blocks*512;old.unlink();command("old-absent",base,120)
command("ci-absent",["python3","docs/case-studies/issue-759/raw/ci/verify-archive.py","--root",str(case/"raw/ci"),"--git-root",str(root),"--output",str(out/"ci-absent.json")],600)
command("measure-absent",["node","scripts/measure-js-first.mjs",str(case/"raw"),"--output",str(out/"measure-absent.json")],600)
a=json.loads((out/"measure-before.json").read_text());b=json.loads((out/"measure-absent.json").read_text());assert a==b
for row in plan["newCompletePhysicalFiles"]:
 src=pathlib.Path(row["from"]);assert facts(src)==(row["bytes"],row["sha256"]);dst=case/row["to"];assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True)
 assert allocated()+src.stat().st_blocks*512+plan["metadataReserveBytes"]<=cap
 tmp=dst.with_name(dst.name+".installing");shutil.copyfile(src,tmp);assert facts(tmp)==(row["bytes"],row["sha256"]);tmp.replace(dst);assert allocated()<=cap
# Reopen every complete newly installed member using the producer's exact verifier.
spec=importlib.util.spec_from_file_location("capture",root/"tools/evidence/capture-packet.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for prefix in ["", "supplement-"]:
 arc=case/"current/verified-container-review-20261014"/("complete-evidence.tar.xz" if not prefix else "supplement-complete.tar.xz")
 rec=case/"current/verified-container-review-20261014"/("capture-receipt.json" if not prefix else "supplement-capture-receipt.json")
 rows=json.loads(rec.read_text())["members"];m.verify_archive(arc,rows,time.monotonic()+600)
command("ci-installed",["python3","docs/case-studies/issue-759/raw/ci/verify-archive.py","--root",str(case/"raw/ci"),"--git-root",str(root),"--output",str(out/"ci-installed.json")],600)
command("measure-installed",["node","scripts/measure-js-first.mjs",str(case/"raw"),"--output",str(out/"measure-installed.json")],600)
assert json.loads((out/"measure-installed.json").read_text())==a
report={"schema":"root-verified-complete-packet-install-v1","sourceHead":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root).decode().strip(),"caseCapBytes":cap,"beforeAllocatedBytes":before,"oldCaseAllocationRetiredBytes":old_allocated,"afterAllocatedBytes":allocated(),"allOldMembersRecoveredFromGit":True,"allNewCompleteMembersReopened":True,"originalReceiptsRewritten":False,"allCIIntegrityChecksPassed":True,"wholeMeasurementsIdentical":True,"volumeDiskReclamationClaim":False,"runtimeParity":False,"fullGatePass":False,"rustExecuted":False,"pushExecuted":False}
(out/"installation-receipt.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report),flush=True)
