import pathlib,subprocess,json,time
base=pathlib.Path.cwd();p=base/"packages/javascript/node_modules/.issue-759-verification/nested-implementation-baseline-v1";root=base.parent/"issue-759-gate";cmd=["node",str(p/"probe.mjs"),str(p)];start=time.monotonic()
with (p/"stdout.raw.log").open("wb") as a,(p/"stderr.raw.log").open("wb") as b:r=subprocess.run(cmd,cwd=root,stdout=a,stderr=b,timeout=180)
(p/"receipt.json").write_text(json.dumps({"command":cmd,"sourceRoot":str(root),"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root).decode().strip(),"exitCode":r.returncode,"capSeconds":180,"elapsedSeconds":time.monotonic()-start},indent=2)+"\n");print(r.returncode)
