import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const load=name=>import(pathToFileURL(path.join(process.cwd(),'tools/translation',name)).href);
const {translateProject}=await load('project.mjs');const {loadDeriveDependencyProof}=await load('derive-dependencies.mjs');const {PRODUCTION_PROFILE}=await load('cfg-profile.mjs');
const dependencies=loadDeriveDependencyProof({manifest:fs.readFileSync('Cargo.toml','utf8'),lock:fs.readFileSync('Cargo.lock','utf8')}),out=process.argv[2],cases=JSON.parse(fs.readFileSync(path.join(out,'cases.json'),'utf8'));
const observed=[];
for(const [index,[label,text,method,caller]]of cases.entries()){
 const source=text+'pub fn value()->u8{9}',r=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source,deriveDependencies:dependencies,compilationProfile:PRODUCTION_PROFILE});
 fs.writeFileSync(path.join(out,index+'.complete-meta.json'),JSON.stringify(r.meta)+'\n');fs.writeFileSync(path.join(out,index+'.complete-javascript.mjs'),r.javascript);fs.writeFileSync(path.join(out,index+'.complete-typescript.ts'),r.typescript);
 observed.push({label,method,caller,generated:(r.meta.checkedGeneratedMethods??[]).map(row=>row.name),originalExecutable:r.meta.executable.map(row=>row.name),refused:r.meta.refused.map(row=>({name:row.name,message:row.message}))});
}
console.log(JSON.stringify({sourceRoot:process.cwd(),observed,claimScope:'Read-only original baseline translation, no Rust build or behavioral parity claim'}));
