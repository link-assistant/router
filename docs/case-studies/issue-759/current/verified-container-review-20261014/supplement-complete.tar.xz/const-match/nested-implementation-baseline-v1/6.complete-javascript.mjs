function rp_6d616b65() {
  return rp_6d6c5f696d706c5f36333732363137343635326535303631373936633666363136345f3634363536363631373536633734();
}

function rp_76616c7565() {
  return 9n;
}

function rp_6d6c5f696d706c5f36333732363137343635326535303631373936633666363136345f3634363536363631373536633734() {
  const ml_record1 = 0n;
  return Object.freeze({ $: "Payload", ["value"]: ml_record1 });
}
export const translated = Object.freeze({ ["make"]: rp_6d616b65, ["value"]: rp_76616c7565 });
export const provenance = {"entry":"src/lib.rs","runtimeParity":false,"moduleCount":1,"executableFunctions":2,"executableConstants":0};
