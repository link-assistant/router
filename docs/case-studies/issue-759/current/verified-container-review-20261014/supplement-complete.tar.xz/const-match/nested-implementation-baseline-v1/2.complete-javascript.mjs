import { validateRustValue as ml_validate_rust_value } from "../runtime/type-layout-runtime.mjs";

import { assertImmutableCopy as ml_assert_immutable_copy } from "../runtime/copy-runtime.mjs";

const ml_host_value_schema_ba5245ea3dc77bf390387aaf2bf8f7e089432f10cb17d7c7814eaccf3942d5eb = {"schemaVersion":1,"types":{"rp_5061796c6f6164":{"kind":"data","name":"rp_5061796c6f6164","ctors":[{"name":"A","fields":[]},{"name":"B","fields":[]}]}}};

const ml_host_value_refinements_ba5245ea3dc77bf390387aaf2bf8f7e089432f10cb17d7c7814eaccf3942d5eb = new Map([]);

function rp_6475706c6963617465(x) {
  ml_validate_rust_value(x, {"kind":"data","name":"rp_5061796c6f6164"}, ml_host_value_schema_ba5245ea3dc77bf390387aaf2bf8f7e089432f10cb17d7c7814eaccf3942d5eb, { refinements: ml_host_value_refinements_ba5245ea3dc77bf390387aaf2bf8f7e089432f10cb17d7c7814eaccf3942d5eb });
  return rp_6d6c5f696d706c5f36333732363137343635326535303631373936633666363136345f36333663366636653635(x);
}

function rp_76616c7565() {
  return 9n;
}

function rp_6d6c5f696d706c5f36333732363137343635326535303631373936633666363136345f36333663366636653635(ml_clone_self) {
  ml_assert_immutable_copy(ml_clone_self);
  ml_validate_rust_value(ml_clone_self, {"kind":"data","name":"rp_5061796c6f6164"}, ml_host_value_schema_ba5245ea3dc77bf390387aaf2bf8f7e089432f10cb17d7c7814eaccf3942d5eb, { refinements: ml_host_value_refinements_ba5245ea3dc77bf390387aaf2bf8f7e089432f10cb17d7c7814eaccf3942d5eb });
  return ml_clone_self;
}
export const translated = Object.freeze({ ["duplicate"]: rp_6475706c6963617465, ["value"]: rp_76616c7565 });
export const provenance = {"entry":"src/lib.rs","runtimeParity":false,"moduleCount":1,"executableFunctions":2,"executableConstants":0};
