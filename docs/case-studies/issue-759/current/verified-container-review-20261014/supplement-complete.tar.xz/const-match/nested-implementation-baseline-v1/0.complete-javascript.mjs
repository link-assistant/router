import { validateRustValue as ml_validate_rust_value } from "../runtime/type-layout-runtime.mjs";

import { assertImmutableCopy as ml_assert_immutable_copy } from "../runtime/copy-runtime.mjs";

const ml_host_value_schema_78d233d65209cb105af562ff03a9a9633c827b03abc368bd747edec802b93160 = {"schemaVersion":1,"types":{"rp_5061796c6f6164":{"kind":"data","name":"rp_5061796c6f6164","ctors":[{"name":"Payload","fields":[{"name":"value","type":{"kind":"fixed","bits":32,"signed":false}}]}]}}};

const ml_host_value_refinements_78d233d65209cb105af562ff03a9a9633c827b03abc368bd747edec802b93160 = new Map([]);

function rp_6475706c6963617465(x) {
  ml_validate_rust_value(x, {"kind":"data","name":"rp_5061796c6f6164"}, ml_host_value_schema_78d233d65209cb105af562ff03a9a9633c827b03abc368bd747edec802b93160, { refinements: ml_host_value_refinements_78d233d65209cb105af562ff03a9a9633c827b03abc368bd747edec802b93160 });
  return rp_6d6c5f696d706c5f36333732363137343635326535303631373936633666363136345f36333663366636653635(x);
}

function rp_76616c7565() {
  return 9n;
}

function rp_6d6c5f696d706c5f36333732363137343635326535303631373936633666363136345f36333663366636653635(ml_clone_self) {
  ml_assert_immutable_copy(ml_clone_self);
  ml_validate_rust_value(ml_clone_self, {"kind":"data","name":"rp_5061796c6f6164"}, ml_host_value_schema_78d233d65209cb105af562ff03a9a9633c827b03abc368bd747edec802b93160, { refinements: ml_host_value_refinements_78d233d65209cb105af562ff03a9a9633c827b03abc368bd747edec802b93160 });
  return (() => {
    const ml_record1 = (ml_clone_self).value;
    return Object.freeze({ $: "Payload", ["value"]: ml_record1 });
  })();
}
export const translated = Object.freeze({ ["duplicate"]: rp_6475706c6963617465, ["value"]: rp_76616c7565 });
export const provenance = {"entry":"src/lib.rs","runtimeParity":false,"moduleCount":1,"executableFunctions":2,"executableConstants":0};
