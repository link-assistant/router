import fs from 'node:fs';
import {loadJsonMacroSourceProof,jsonMacroOriginalSource} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match/tools/translation/json-macro-inputs.mjs';
import {compileDeclarativeMacro,expandDeclarativeMacro,declarativeSubInput} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match/tools/translation/declarative-token-macros.mjs';
import {originalMacroInvocation,originalMacroTreeText} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match/tools/translation/macro-token-trees.mjs';
const dependencies=loadJsonMacroSourceProof({manifest:fs.readFileSync('Cargo.toml','utf8'),lock:fs.readFileSync('Cargo.lock','utf8')}),source=jsonMacroOriginalSource(dependencies,'serde_json','src/macros.rs');
const definitions=Object.fromEntries(['json','json_internal','json_unexpected','json_expect_expr_comma'].map(name=>[name,compileDeclarativeMacro(source.source,{name,owner:['serde_json'],...(name==='json_internal'?{maxRules:37}:{})})]));
const rows=[];
for(const text of ['json!(null)','json!(true)','json!({})','json!({"reason":"max_output_tokens"})','json!({"type":"response.incomplete","response":response})']){
 try{
  const invocation=originalMacroInvocation(text),root=expandDeclarativeMacro(definitions.json,invocation.trees),trace=[root];
  function walk(expansion,trees=expansion.trees,path=[]){
   for(let i=0;i<trees.length;i++){
    const tree=trees[i];
    if(tree.kind==='owner'&&trees[i+1]?.text==='::'&&definitions[trees[i+2]?.text]&&trees[i+3]?.text==='!'&&trees[i+4]?.kind==='group'){
     if(trace.length>=128)throw Error('full expansion trace cap');
     const child=expandDeclarativeMacro(definitions[trees[i+2].text],declarativeSubInput(expansion,[...path,i+4]));trace.push(child);walk(child);i+=4;continue;
    }
    if(tree.kind==='group')walk(expansion,tree.children,[...path,i]);
   }
  }
  walk(root);
  rows.push({source:text,trace:trace.map(e=>({rule:e.rule,digest:e.digest,trees:e.trees})),human:trace.at(-1).trees.map(originalMacroTreeText).join(' ')});
 }catch(error){rows.push({source:text,error:error.message});}
}
fs.writeFileSync(process.argv[2],JSON.stringify({sourceSha256:source.sha256,rows})+'\n');
console.log(JSON.stringify(rows.map(row=>({source:row.source,expansions:row.trace?.length,error:row.error,human:row.human?.slice(0,1000)}))));
