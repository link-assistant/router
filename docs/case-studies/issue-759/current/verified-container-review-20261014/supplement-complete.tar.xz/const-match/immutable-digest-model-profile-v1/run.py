import pathlib,subprocess,time,json,hashlib,resource
base=pathlib.Path.cwd();p=base/"packages/javascript/node_modules/.issue-759-verification/immutable-digest-model-profile-v1"
roots={"baseline":base.parent/"issue-759-gate","candidate":base};rows=[]
for label,root in roots.items():
 vector=[]
 names=subprocess.check_output(["git","ls-files","-z","--","tools/translation","Cargo.toml","Cargo.lock","src/model_contract.rs"],cwd=root).decode().split("\0")
 names.extend(["tools/translation/extensions/immutable-metadata-digest.mjs","tools/translation/test/immutable-metadata-digest.test.mjs"])
 for name in sorted(set(filter(None,names))):
  file=root/name
  if not file.is_file():continue
  b=file.read_bytes();vector.append({"path":name,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
 (p/(label+"-inputs.json")).write_text(json.dumps(vector,indent=2)+"\n")
for engine in ["node","bun"]:
 for label,root in roots.items():
  out=p/(label+"-"+engine);out.mkdir();cmd=[engine,str(p/"profile.mjs"),str(out)];start=time.monotonic()
  with (out/"stdout.raw.log").open("wb") as a,(out/"stderr.raw.log").open("wb") as b:
   try:code=subprocess.run(cmd,cwd=root,stdout=a,stderr=b,timeout=300).returncode;timed=False
   except subprocess.TimeoutExpired:code=None;timed=True
  row={"sourceRoot":str(root),"label":label,"command":cmd,"exitCode":code,"timedOut":timed,"elapsedSeconds":time.monotonic()-start,"capSeconds":300,"maxWaitedChildRssBytes":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rssScope":"process-lifetime RUSAGE_CHILDREN maximum, not per-command reset/concurrent sum"};rows.append(row);print(json.dumps(row),flush=True)
(p/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
