import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {copyMetadata,metadataDigest} from '../extensions/source-links.mjs';
import {createImmutableMetadataDigester,IMMUTABLE_DIGEST_CACHE_LIMIT} from '../extensions/immutable-metadata-digest.mjs';

const legacy=value=>createHash('sha256').update(JSON.stringify(copyMetadata(value),(_,item)=>typeof item==='bigint'?{$integer:item.toString()}:item)).digest('hex');
const freeze=value=>{if(value!==null&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}return value;};
function measured(){let calls=0;return {digest:createImmutableMetadataDigester(value=>{calls++;return legacy(value);}),calls:()=>calls};}
test('complete immutable metadata reuses the identical legacy digest without issuing source authority',()=>{
 const value=freeze({z:[1n,{field:'original'}],copyCertificate:{z:2,a:1},a:null}),run=measured();
 const expected=legacy(value);assert.equal(run.digest(value),expected);assert.equal(run.digest(value),expected);assert.equal(run.calls(),1);
 assert.equal(metadataDigest(value),expected);assert.equal(metadataDigest(value),expected);
 const copied=structuredClone(value);assert.equal(run.digest(copied),expected);assert.equal(run.digest(copied),expected);assert.equal(run.calls(),3);
 const foreign=createImmutableMetadataDigester(()=> 'caller digest');assert.equal(foreign(value),'caller digest');assert.equal(metadataDigest(value),expected);
});
test('mutable descendants are rechecked and their changed bytes affect the digest',()=>{
 const child={value:1},value=Object.freeze({child}),run=measured(),first=run.digest(value);
 child.value=2;assert.notEqual(run.digest(value),first);assert.equal(run.calls(),2);
 Object.freeze(child);const immutable=run.digest(value);assert.equal(run.digest(value),immutable);assert.equal(run.calls(),3);
});
test('fixed cache turnover never retains strong original graph keys or changes digest bytes',()=>{
 const run=measured(),first=freeze({first:1});run.digest(first);
 for(let index=0;index<IMMUTABLE_DIGEST_CACHE_LIMIT;index++)assert.equal(run.digest(freeze({index})),legacy({index}));
 assert.equal(run.calls(),IMMUTABLE_DIGEST_CACHE_LIMIT+1);assert.equal(run.digest(first),legacy(first));assert.equal(run.calls(),IMMUTABLE_DIGEST_CACHE_LIMIT+2);
});
test('a frozen root with a mutable child cannot be cached through caller WeakSet method overrides',()=>{
 const savedHas=WeakSet.prototype.has,savedAdd=WeakSet.prototype.add,child={value:1},value=Object.freeze({child}),run=measured();
 try{
  WeakSet.prototype.has=()=>true;WeakSet.prototype.add=()=>{throw new Error('caller method must not execute');};
  const first=run.digest(value);child.value=2;assert.notEqual(run.digest(value),first);assert.equal(run.calls(),2);
 }finally{WeakSet.prototype.has=savedHas;WeakSet.prototype.add=savedAdd;}
});
test('cached metadata still observes changed ambient JSON serialization and restores exact behavior',()=>{
 const value=freeze({value:[1n]}),run=measured(),expected=run.digest(value),saved=Object.getOwnPropertyDescriptor(JSON,'stringify');
 try{
  Object.defineProperty(JSON,'stringify',{...saved,value:()=> 'ambient serializer'});
  assert.equal(run.digest(value),legacy(value));assert.notEqual(run.digest(value),expected);assert.equal(run.calls(),3);
 }finally{Object.defineProperty(JSON,'stringify',saved);}
 assert.equal(run.digest(value),expected);assert.equal(run.calls(),3);
});
for(const prototype of [Object.prototype,Array.prototype,BigInt.prototype])test('cached metadata rechecks inherited toJSON on '+(prototype===Object.prototype?'objects':prototype===Array.prototype?'arrays':'integers'),()=>{
 const value=freeze({values:[1n]}),run=measured(),expected=run.digest(value),saved=Object.getOwnPropertyDescriptor(prototype,'toJSON');let called=0;
 try{
  Object.defineProperty(prototype,'toJSON',{configurable:true,value:function(){called++;return 'changed '+called;}});
  assert.notEqual(run.digest(value),expected);assert.notEqual(run.digest(value),expected);assert.equal(run.calls(),3);assert.ok(called>=2);
 }finally{if(saved)Object.defineProperty(prototype,'toJSON',saved);else delete prototype.toJSON;}
 assert.equal(run.digest(value),expected);assert.equal(run.calls(),3);
});
test('frozen proxies accessors cycles hidden properties and original budgets keep their complete refusals',()=>{
 let accessed=0;const accessor=Object.freeze(Object.defineProperty({},'value',{enumerable:true,get(){accessed++;return 1;}}));
 const cycle={};cycle.self=cycle;Object.freeze(cycle);
 const hidden=Object.freeze(Object.defineProperty({},'hidden',{value:1}));
 const symbol=Object.freeze({[Symbol('field')]:1});
 for(const value of [new Proxy(Object.freeze({value:1}),{}),accessor,cycle,hidden,symbol,freeze({value:1.5}),freeze({text:'x'.repeat(4194305)}),freeze(Array.from({length:200000},()=>0))]){
  for(let repeat=0;repeat<2;repeat++)assert.throws(()=>metadataDigest(value),/source links:/);
 }
 assert.equal(accessed,0);
});
