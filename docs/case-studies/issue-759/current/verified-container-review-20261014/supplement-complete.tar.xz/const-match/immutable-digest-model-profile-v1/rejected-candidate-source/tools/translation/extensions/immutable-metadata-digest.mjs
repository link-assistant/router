// Digest reuse is only a computation cache, never a source/proof issuer.
// An accepted key is complete immutable data already checked by copyMetadata.
import {types} from 'node:util';
import {Buffer} from 'node:buffer';

const getDescriptors=Object.getOwnPropertyDescriptors,getDescriptor=Object.getOwnPropertyDescriptor;
const getPrototype=Object.getPrototypeOf,isFrozen=Object.isFrozen,ownKeys=Reflect.ownKeys;
const mapGet=WeakMap.prototype.get,mapSet=WeakMap.prototype.set;
const NativeWeakMap=WeakMap,NativeWeakSet=WeakSet,setHas=WeakSet.prototype.has,setAdd=WeakSet.prototype.add;
const nativeText=Function.prototype.toString;
const parents=[Object.prototype,Array.prototype,BigInt.prototype].map(value=>[value,getPrototype(value)]);
const intrinsicRows=[
 [JSON,'stringify'],[Object,'getOwnPropertyDescriptors'],[Object,'getOwnPropertyDescriptor'],
 [Object,'getPrototypeOf'],[Object,'create'],[Object,'defineProperty'],[Object,'isFrozen'],
 [Reflect,'ownKeys'],[Array,'isArray'],[Array,'from'],[Array.prototype,'sort'],
 [Function.prototype,'call'],
 [Buffer,'byteLength'],[types,'isProxy'],[BigInt.prototype,'toString'],
 [Object.prototype,'toJSON'],[Array.prototype,'toJSON'],[BigInt.prototype,'toJSON'],
].map(([owner,key])=>[owner,key,getDescriptor(owner,key)]);
const sameDescriptor=(left,right)=>left===undefined?right===undefined:right!==undefined&&
 left.value===right.value&&left.get===right.get&&left.set===right.set&&
 left.enumerable===right.enumerable&&left.configurable===right.configurable&&left.writable===right.writable;
function stableIntrinsics(){
 for(let index=0;index<parents.length;index++)if(getPrototype(parents[index][0])!==parents[index][1])return false;
 for(let index=0;index<intrinsicRows.length;index++){
  const row=intrinsicRows[index];
  if(!sameDescriptor(getDescriptor(row[0],row[1]),row[2]))return false;
  // Inherited serializers can be stateful even when their descriptor is stable.
  if(row[1]==='toJSON'&&row[2]!==undefined)return false;
 }
 const serializer=intrinsicRows[0][2]?.value;
 return typeof serializer==='function'&&!types.isProxy(serializer)&&nativeText.call(serializer).includes('[native code]');
}
export const IMMUTABLE_DIGEST_CACHE_LIMIT=1024;
function immutable(value,seen=new NativeWeakSet()){
 if(value===null||typeof value!=='object')return true;
 if(types.isProxy(value)||!isFrozen(value))return false;
 if(setHas.call(seen,value))return true;
 setAdd.call(seen,value);
 const prototype=getPrototype(value);
 if(prototype!==null&&prototype!==Object.prototype&&prototype!==Array.prototype)return false;
 const descriptors=getDescriptors(value);
 for(const key of ownKeys(descriptors)){
  const descriptor=descriptors[key];
  if(typeof key!=='string'||!('value'in descriptor)||!immutable(descriptor.value,seen))return false;
 }
 return true;
}
// Call only after the unchanged complete copier and serializer have succeeded.
// Reset at the fixed entry cap; no queue or strong original graph is retained.
export function createImmutableMetadataDigester(compute){
 let cache=new NativeWeakMap(),entries=0;
 return value=>{
  const eligible=value!==null&&typeof value==='object'&&!types.isProxy(value)&&isFrozen(value)&&stableIntrinsics();
  const cached=eligible?mapGet.call(cache,value):undefined;
  if(cached!==undefined)return cached;
  const digest=compute(value);
  if(eligible&&stableIntrinsics()&&immutable(value)){
   if(entries===IMMUTABLE_DIGEST_CACHE_LIMIT){cache=new NativeWeakMap();entries=0;}
   mapSet.call(cache,value,digest);entries++;
  }
  return digest;
 };
}
