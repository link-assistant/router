import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root=process.cwd(),load=name=>import(pathToFileURL(path.join(root,'tools/translation',name)).href);
const {translateProject}=await load('project.mjs');
const {loadDeriveDependencyProof}=await load('derive-dependencies.mjs');
const {loadJsonMacroSourceProof}=await load('json-macro-inputs.mjs');
const {PRODUCTION_PROFILE}=await load('cfg-profile.mjs');
const input={manifest:fs.readFileSync('Cargo.toml','utf8'),lock:fs.readFileSync('Cargo.lock','utf8')},deriveDependencies=loadDeriveDependencyProof(input),jsonMacroDependencies=loadJsonMacroSourceProof(input);
const file='src/model_contract.rs',source=fs.readFileSync(file,'utf8'),out=process.argv[2];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const rows=[];let expected;
for(let trial=0;trial<5;trial++){
 const start=performance.now(),result=translateProject({entry:file,paths:[file],readSource:()=>source,deriveDependencies,jsonMacroDependencies,compilationProfile:PRODUCTION_PROFILE}),elapsedMilliseconds=performance.now()-start;
 const outputs={meta:JSON.stringify(result.meta),javascript:result.javascript,typescript:result.typescript};
 const hashes=Object.fromEntries(Object.entries(outputs).map(([key,text])=>[key,{bytes:Buffer.byteLength(text),sha256:hash(text)}]));
 if(expected)assert.deepEqual(hashes,expected);else{expected=hashes;for(const [key,text]of Object.entries(outputs))fs.writeFileSync(path.join(out,key+'.complete'),text);}
 rows.push({trial,elapsedMilliseconds,functions:result.meta.executable.filter(row=>row.term==='fn').length,writtenMethods:result.meta.checkedMethods.length,generatedMethods:result.meta.checkedGeneratedMethods.length,refused:result.meta.refused.length});
}
console.log(JSON.stringify({engine:process.versions.bun?'bun':'node',sourceSha256:hash(source),sourceBytes:Buffer.byteLength(source),outputs:expected,trials:rows,claimScope:'five translations of one unchanged complete Model source, no corpus or controlled infrastructure/memory savings claim'}));
