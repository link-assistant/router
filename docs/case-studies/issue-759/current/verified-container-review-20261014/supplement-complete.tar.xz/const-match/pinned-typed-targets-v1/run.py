import pathlib,subprocess,json,hashlib,time,resource
p=pathlib.Path("packages/javascript/node_modules/.issue-759-verification/pinned-typed-targets-v1");files=["tools/translation/test/typed-target-compiler.test.mjs","tools/translation/test/derive-helper-originals.test.mjs"];inputs=files+["tools/translation/test/typed-targets.mjs","packages/javascript/node_modules/typescript/package.json"];rows=[]
def vector():return [{"path":n,"bytes":len((b:=pathlib.Path(n).read_bytes())),"sha256":hashlib.sha256(b).hexdigest()} for n in inputs]
before=vector();(p/"inputs.json").write_text(json.dumps(before,indent=2)+"\n")
for name in inputs:
 dst=p/"source-snapshots"/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(pathlib.Path(name).read_bytes())
for label,cmd in [("node",["node","--test","--test-concurrency=1",*files]),("bun",["bun","test",*files])]:
 start=time.monotonic()
 with (p/(label+".stdout.raw.log")).open("wb") as a,(p/(label+".stderr.raw.log")).open("wb") as b:
  try:code=subprocess.run(cmd,stdout=a,stderr=b,timeout=180).returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 row={"command":cmd,"wholeFiles":len(files),"exitCode":code,"timedOut":timed,"elapsedSeconds":time.monotonic()-start,"capSeconds":180,"inputsUnchanged":vector()==before,"maxWaitedChildRssBytes":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rssScope":"lifetime RUSAGE_CHILDREN max, not per-engine reset/concurrent sum"};rows.append(row);print(json.dumps(row),flush=True)
(p/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
