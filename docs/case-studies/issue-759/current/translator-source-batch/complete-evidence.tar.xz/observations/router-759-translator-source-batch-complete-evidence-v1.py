from pathlib import Path
import argparse, hashlib, io, json, subprocess, tarfile

p=argparse.ArgumentParser()
p.add_argument('--plan-only',action='store_true')
p.add_argument('--apply',action='store_true')
a=p.parse_args()
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
tmp=Path('/tmp')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,timeout=30)
head=git('rev-parse','HEAD').decode().strip()
source_prefixes=[
 'router-759-reusable-draft-review-',
 'router-759-reverse-gate-discovery-',
 'router-759-native-artifacts-v2-5c83e7451',
 'router-759-native-artifacts-v2-cebe907e5',
 'router-759-native-runtime-harness-',
 'router-759-reverse-complete-integrated-',
 'router-759-clientkind-forward-integrated-',
 'router-759-ci-job-compaction-',
 'router-759-ci-job-api-json-compaction-',
 'router-759-source-scope-cache-',
]
worker_directories=[
 'router-759-option-cycle-20261013',
 'router-759-option-cycle-20261013-static-v1',
 'router-759-derive-cycle-20261013-v1',
 'router-759-derive-cycle-20261013-clap-v1',
 'router-759-derive-cycle-20261013-args-v1',
]
files={}
for f in tmp.iterdir():
 if any(f.name.startswith(prefix) for prefix in source_prefixes) and f.is_file():
  files['observations/'+f.name]=f
 # Reverse worker's cycle-seven outputs are still active and are captured by
 # their successor packet after the complete immutable batch is committed.
 if f.name.startswith('router-759-reverse-cycle-') and not any(mark in f.name for mark in ['-07','-08','-aggregate','-payload']) and f.is_file():
  files['workers/reverse/'+f.name]=f
for name in worker_directories:
 directory=tmp/name
 assert directory.is_dir(),directory
 for f in directory.rglob('*'):
  if f.is_file():files['workers/'+name+'/'+f.relative_to(directory).as_posix()]=f
explicit=[Path(__file__).name,
 'router-759-translator-source-batch-evidence-initial-setup-failure-v1.py',
 'router-759-translator-source-batch-evidence-initial-setup-failure-v1.json',
 'router-759-coordinated-repair-diagnostic-v1.py',
 'router-759-bounded-native-artifacts-v2.py',
 'router-759-bounded-cohort-producer-v5.py',
 'router-759-run-source-scope-cache-candidate-v1.py',
 'router-759-bulk-integrated-syntax-v1.json',
 'router-759-bulk-integrated-syntax-v1.raw.log',
 'router-759-bulk-integrated-syntax-v1-inputs.json',
]
for name in explicit:
 f=tmp/name;assert f.is_file(),f;files['observations/'+name]=f
required=[
 'router-759-reusable-draft-review-node-v3',
 'router-759-reusable-draft-review-bun-v3',
 'router-759-reverse-gate-discovery-node-v2',
 'router-759-reverse-gate-discovery-bun-v2',
 'router-759-native-runtime-harness-node-v3',
 'router-759-native-runtime-harness-bun-v3',
 'router-759-clientkind-forward-integrated-node-v1',
 'router-759-clientkind-forward-integrated-bun-v1',
 'router-759-ci-job-compaction-before-measurements-v1',
 'router-759-ci-job-compaction-after-measurements-v1',
 'router-759-source-scope-cache-candidate-node-v3',
 'router-759-source-scope-cache-candidate-bun-v3',
 'router-759-source-scope-cache-original-corpus-review-run-v1',
]
for name in required:
 receipt=json.loads((tmp/(name+'.json')).read_text())
 assert receipt['exitCode']==0 and not receipt['timedOut'],name
 assert receipt.get('inputsUnchanged',receipt.get('candidateInputsUnchanged')) is True,name
 for suffix in ('.json','.raw.log','-inputs.json'):
  assert 'observations/'+name+suffix in files,(name,suffix)
assert json.loads((tmp/'router-759-ci-job-api-json-compaction-measurement-verification-v1.json').read_text())['allReportFieldsEqualAfterArchiveLocationNormalization']
continuity=json.loads((tmp/'router-759-ci-job-api-json-compaction-complete-input-continuity-v1.json').read_text())
assert continuity['everyOtherInputByteIdentical'] and continuity['allDecodedOriginalGitBytesEqual']
assert len(continuity['completeCiInputs'])==28586
native=json.loads((tmp/'router-759-native-artifacts-v2-cebe907e5-terminal.json').read_text())
assert native['complete'] and all(not stage['generatedRustMutationPaths'] and not stage['unexpectedMutationPaths'] and stage['sourceInputsUnchanged'] for stage in native['stages'])
scope=json.loads((tmp/'router-759-source-scope-cache-original-corpus-review-v1.json').read_text())
assert scope['completeResolverOutputsEqual'] and scope['originalInputsUnchanged'] and scope['resolvedOriginalScopes']==391
assert all(state['allFieldsEqual'] for state in scope['states'])
names=git('diff','--name-only','e162a0470b166fa4525a5f498fac0147fca02021',head).decode().splitlines()
implementation=[]
for name in names:
 if name.startswith(('docs/case-studies/','dev/log/','packages/typescript/native/','tools/translation/js-to-rust/generated/')) or name=='parity/js-first-translation.json':continue
 file=root/name
 if not file.is_file():continue
 raw=file.read_bytes();assert git('show',head+':'+name)==raw,name
 files['implementation/'+name]=file;implementation.append(name)
for name in ['tools/translation/module-bindings.mjs','tools/translation/source-scopes.mjs','tools/translation/test/source-scope-templates.test.mjs']:
 files['candidate-implementation/'+name]=tmp/'router-759-source-scope-cache-candidate-v1'/name

def allocated():
 seen=set();total=0
 for directory in ['docs/case-studies/issue-759','dev/log/issues/759']:
  for f in (root/directory).rglob('*'):
   if f.is_file():
    state=f.stat();key=state.st_dev,state.st_ino
    if key not in seen:seen.add(key);total+=state.st_blocks*512
 return total

rows=[]
for name,file in files.items():
 assert file.is_file() and not file.is_symlink(),file
 raw=file.read_bytes();rows.append({'path':name,'originalPath':str(file),'bytes':len(raw),'sha256':sha(raw)})
# Put complete input vectors together so the XZ dictionary can retain their
# repeated unchanged originals. Logical member paths and bytes are preserved.
rows.sort(key=lambda row:(0 if 'inputs' in row['path'] else 1,row['path']))
summary={'sourceHead':head,'completeMembers':len(rows),'completeOriginalBytes':sum(row['bytes'] for row in rows),'allocatedBytesBefore':allocated(),'remainingBytesBefore':500000000-allocated()}
print(json.dumps(summary),flush=True)
if a.plan_only:
 plan=tmp/'router-759-translator-source-batch-complete-evidence-v1.plan.json'
 assert not plan.exists();plan.write_text(json.dumps({**summary,'members':rows},indent=2)+'\n');raise SystemExit(0)
archive=tmp/'router-759-translator-source-batch-complete-evidence-v1.tar.xz'
receipt_path=tmp/'router-759-translator-source-batch-complete-evidence-v1.packet.json'
assert not archive.exists() and not receipt_path.exists()
dedup={}
with tarfile.open(archive,'w:xz',preset=9) as tar:
 for row in rows:
  file=Path(row['originalPath']);raw=file.read_bytes()
  assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],file
  entry=tarfile.TarInfo(row['path']);entry.mode=0o644;entry.mtime=0
  key=row['sha256'],row['bytes']
  if key in dedup:
   original_name,original_file=dedup[key];assert original_file.read_bytes()==raw
   entry.type=tarfile.LNKTYPE;entry.linkname=original_name;row['storedAsHardlink']=original_name;tar.addfile(entry)
  else:
   entry.size=len(raw);tar.addfile(entry,io.BytesIO(raw));dedup[key]=row['path'],file
with tarfile.open(archive) as tar:
 for row in rows:
  raw=tar.extractfile(row['path']).read();assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
assert git('rev-parse','HEAD').decode().strip()==head
packet={'schema':'complete-translator-source-batch-evidence-v1','sourceHead':head,'archive':'complete-evidence.tar.xz','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive.read_bytes()),'members':rows,'allDecodedOriginalsVerified':True,'originalRustInputs':804,'completeOriginalBytes':summary['completeOriginalBytes'],'semanticAuthority':False,'runtimeParity':False,'fullGatePass':False,'rustExecutions':0}
receipt_path.write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'archiveBytes':packet['archiveBytes'],'members':len(rows),'allocatedBytesBefore':allocated(),'remainingBytesBefore':500000000-allocated()}),flush=True)
if a.apply:
 assert not git('status','--porcelain'),'Apply only after immutable production batch is committed'
 target=root/'docs/case-studies/issue-759/current/translator-source-batch';assert not target.exists()
 text='''# Complete translator source batch evidence

This packet preserves complete passed and failed worker/source checks, immutable input vectors, tested source snapshots, native regeneration and source review. The actual source batch uses automated Rust → meta-language → JavaScript/TypeScript and JavaScript → meta-language → target lowering. These bounded checks do not establish complete runtime parity or authorize Rust verification or publication.

The corrected reverse gate discovers the complete test directory under both Node and Bun. The actual integrated forward cohort passed 96 cases in each engine. All nine affected native TypeScript tests passed in both engines, including execution of 229 shared runtime expectations. Native regeneration at `cebe907e5a17eb9475231913d13148dfda1b7db5` left all 59 TypeScript modules and generated Rust unchanged; its complete reverse census records 49 translated and 739 refused native declarations.

Every byte of all 28,586 original CI inputs remains available. The 259 compressed job API responses decode to their original Git bytes. Complete before/after CI measurements agree after exact archive-path normalization and exclusion of the added provenance input. This reclaimed 897,024 allocated bytes within the unchanged 500 MB evidence budget.

The separate namespace template candidate passed 44 focused cases in each engine. Its complete resolver results agree across the actual 391-module graph, and every complete parser field agrees for the original root, clients and verification scopes. All complete before/after configurations and alternating measured setup trials are preserved. The isolated setup measurement does not establish corpus throughput, CI resource savings or new semantic admission. The first two test attempts lacked an original-source fixture dependency; their complete failures and input vectors are preserved before the corrected runs.

`receipt.json` records every complete TAR member's original length and SHA256. Exact duplicate originals use ordinary TAR hardlinks. Complete canonical and profile generation, independent target execution and the complete strict gate remain separate requirements. No Rust build or publication ran.
'''
 estimate=sum(((size+4095)//4096)*4096 for size in [archive.stat().st_size,receipt_path.stat().st_size,len(text.encode())])
 assert allocated()+estimate<500000000,'Fixed complete evidence budget exceeded'
 target.mkdir();(target/'complete-evidence.tar.xz').write_bytes(archive.read_bytes());(target/'receipt.json').write_bytes(receipt_path.read_bytes());(target/'README.md').write_text(text)
 assert allocated()<500000000
 result={'target':target.relative_to(root).as_posix(),'sourceHead':head,'archiveSha256':packet['archiveSha256'],'allocatedBytesAfter':allocated(),'remainingBytes':500000000-allocated()}
 applied=tmp/'router-759-translator-source-batch-complete-evidence-v1.applied.json';assert not applied.exists();applied.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
