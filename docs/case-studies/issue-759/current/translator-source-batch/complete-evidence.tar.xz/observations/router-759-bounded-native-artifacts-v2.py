import argparse, datetime, hashlib, json, os, pathlib, resource, signal, subprocess, time

p = argparse.ArgumentParser()
p.add_argument('--root', required=True)
p.add_argument('--head', required=True)
a = p.parse_args()
root = pathlib.Path(a.root)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root).decode().strip()
assert len(a.head) == 40 and git('rev-parse', 'HEAD') == a.head
assert not git('status', '--porcelain'), 'Requires frozen clean source'
base = pathlib.Path('/tmp/router-759-native-artifacts-v2-' + a.head[:9])
def write(path, value):
    with pathlib.Path(path).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def allowed(path):
    return path.startswith(('packages/typescript/native/', 'packages/typescript/portable/',
        'packages/typescript/schemas/', 'tools/translation/js-to-rust/generated/native-typescript/')) or path in {
        'packages/typescript/index.ts', 'packages/typescript/testing.ts', 'packages/typescript/catalog.json',
        'packages/typescript/package.json', 'packages/typescript/tsconfig.native.json', 'packages/typescript/.gitignore',
        'tools/translation/js-to-rust/generated/policy.lino', 'src/generated_js_first/policy.rs',
        'src/generated_js_first/mod.rs', 'parity/js-first-translation.json'}
paths = subprocess.check_output(['git', 'ls-files', '-z', '--', '*.rs', 'Cargo.toml', 'Cargo.lock',
    'packages/javascript', 'tools/translation/js-to-rust', 'scripts/regenerate-native-typescript.mjs',
    'scripts/regenerate-js-first.mjs', 'scripts/check-native-typescript.mjs',
    'parity/fixtures/js-first'], cwd=root).decode().split('\0')
paths = sorted(path for path in paths if path and not allowed(path))
def snapshot():
    rows = []
    for path in paths:
        file = root / path
        raw = file.read_bytes() if file.is_file() else subprocess.check_output(['git', 'show', a.head + ':' + path], cwd=root)
        rows.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw)})
    return rows
def outputs():
    found = set(filter(None, subprocess.check_output(['git', 'ls-files', '-z', '--', 'packages/typescript',
        'tools/translation/js-to-rust/generated', 'src/generated_js_first', 'parity/js-first-translation.json'], cwd=root).decode().split('\0')))
    for directory in ['packages/typescript', 'tools/translation/js-to-rust/generated/native-typescript']:
        for file in (root / directory).rglob('*'):
            relative = file.relative_to(root).as_posix()
            if file.is_file() and '/node_modules/' not in relative and '/dist/' not in relative:
                found.add(relative)
    return [{'path': path, 'bytes': (root/path).stat().st_size, 'sha256': sha((root/path).read_bytes())}
        for path in sorted(found) if allowed(path) and (root/path).is_file()]
before = snapshot()
old_outputs = outputs()
write(str(base) + '-inputs.json', {'head': a.head, 'inputs': before, 'outputsBefore': old_outputs,
    'harnessSha256': sha(pathlib.Path(__file__).read_bytes())})
def free_bytes():
    stats = os.statvfs(root)
    return stats.f_bavail * stats.f_frsize
free_before = free_bytes()
assert free_before >= 2 * 1024**3, 'Requires at least 2GiB available disk space'
stages = []
for name, script, cap in [('native-typescript', 'scripts/regenerate-native-typescript.mjs', 180),
                          ('portable-reverse-manifest', 'scripts/regenerate-js-first.mjs', 60)]:
    log = pathlib.Path(str(base) + '-' + name + '.log')
    assert not log.exists(), 'Never overwrite attempt evidence'
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    started = time.monotonic()
    timed_out = False
    with log.open('xb') as stream:
        child = subprocess.Popen(['node', script], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = child.wait(timeout=cap)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait(timeout=5)
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    status = git('status', '--porcelain')
    changes = git('diff', '--name-only').splitlines()
    untracked = git('ls-files', '--others', '--exclude-standard').splitlines()
    inputs_unchanged = snapshot() == before
    unexpected = [path for path in changes + untracked if not allowed(path)]
    rust_changes = [path for path in changes if path.endswith('.rs')]
    stage = {'name': name, 'argv': ['node', script], 'capSeconds': cap, 'exitCode': code,
        'elapsedSeconds': round(time.monotonic()-started, 3), 'timedOut': timed_out,
        'sourceInputsUnchanged': inputs_unchanged, 'headUnchanged': git('rev-parse', 'HEAD') == a.head,
        'unexpectedMutationPaths': unexpected, 'generatedRustMutationPaths': rust_changes,
        'statusAfter': status, 'outputsAfter': outputs(),
        'freeBytesBefore': free_before, 'freeBytesAfter': free_bytes(),
        'raw': {'path': str(log), 'bytes': log.stat().st_size, 'sha256': sha(log.read_bytes())},
        'resources': {'scope': 'waited producer children, maximum recorded child, not concurrent aggregate',
            'userCpuSeconds': usage_after.ru_utime-usage_before.ru_utime,
            'systemCpuSeconds': usage_after.ru_stime-usage_before.ru_stime,
            'maxRss': usage_after.ru_maxrss, 'maxRssUnits': 'bytes on Darwin; KiB on Linux'}}
    stages.append(stage)
    write(str(base) + '-' + name + '.receipt.json', stage)
    print(json.dumps({key:value for key,value in stage.items() if key not in ['outputsAfter','statusAfter']}), flush=True)
    if code or timed_out or not inputs_unchanged or unexpected or rust_changes or not stage['headUnchanged']:
        write(str(base) + '-terminal.json', {'head': a.head, 'stages': stages, 'complete': False, 'rustRun': False})
        raise SystemExit(code or 2)
write(str(base) + '-terminal.json', {'head': a.head, 'stages': stages, 'outputsBefore': old_outputs,
    'outputsAfter': outputs(), 'complete': True, 'rustRun': False,
    'harnessSha256': sha(pathlib.Path(__file__).read_bytes()), 'completedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
