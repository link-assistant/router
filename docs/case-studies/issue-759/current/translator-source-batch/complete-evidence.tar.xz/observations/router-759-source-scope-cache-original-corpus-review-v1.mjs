import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const original='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate';
const candidate='/tmp/router-759-source-scope-cache-candidate-v1';
const output='/tmp/router-759-source-scope-cache-original-corpus-review-v1.json';
const sha=raw=>createHash('sha256').update(raw).digest('hex');
const names=execFileSync('git',['ls-files','-z','--','*.rs','Cargo.toml','Cargo.lock'],{cwd:original,encoding:'utf8'}).split('\0').filter(Boolean).sort();
const before=names.map(name=>{const raw=fs.readFileSync(path.join(original,name));return {path:name,bytes:raw.length,sha256:sha(raw)};});
const rust=names.filter(name=>name.endsWith('.rs'));
const inspect=value=>value instanceof Map?{map:[...value].map(([key,item])=>[key,inspect(item)])}:value instanceof Set?{set:[...value]}:Array.isArray(value)?value.map(inspect):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).map(([key,item])=>[key,inspect(item)])):value;
const implementations=[];
for(const root of [original,candidate]){
  const load=name=>import(pathToFileURL(path.join(root,'tools/translation',name)));
  const [{resolveModuleGraph},{resolveModuleBindings},{configureParserSourceScope},{PRODUCTION_PROFILE},{registeredStandardHostBindings}]=await Promise.all(['project.mjs','module-bindings.mjs','source-scopes.mjs','cfg-profile.mjs','standard-host-bindings.mjs'].map(load));
  const graph=resolveModuleGraph({entry:'src/lib.rs',paths:rust,readSource:name=>fs.readFileSync(path.join(original,name),'utf8'),compilationProfile:PRODUCTION_PROFILE});
  const registry=resolveModuleBindings({modules:graph.modules,compilationProfile:graph.compilationProfile,externalModules:registeredStandardHostBindings()});
  implementations.push({root,registry,configureParserSourceScope});
}
assert.deepEqual(implementations[0].registry,implementations[1].registry);
const scopes=implementations[0].registry.scopes,states=[];
for(const name of ['', 'clients', 'verification']){
  const snapshots=implementations.map(implementation=>{
    const scope=implementation.registry.scopes.find(scope=>scope.path.join('.')===name);assert.ok(scope);
    return inspect(implementation.configureParserSourceScope({},scope,implementation.registry.scopes));
  });
  assert.deepEqual(snapshots[0],snapshots[1]);states.push({consumingModule:name,completeOriginal:snapshots[0],completeCandidate:snapshots[1],allFieldsEqual:true});
}
const trials=[];
for(let turn=0;turn<4;turn++)for(const index of turn%2?[1,0]:[0,1]){
  const implementation=implementations[index],scope=implementation.registry.scopes.find(scope=>scope.path.join('.')==='clients');
  const start=performance.now();let bindings=0;
  for(let count=0;count<128;count++){
    const configured=implementation.configureParserSourceScope({},scope,implementation.registry.scopes);
    bindings+=configured.sourceNamespaceBindingEvidence.size;
  }
  trials.push({turn,implementation:index===0?'original':'candidate',iterations:128,configuredScopeReferences:bindings,elapsedMilliseconds:performance.now()-start});
}
const after=names.map(name=>{const raw=fs.readFileSync(path.join(original,name));return {path:name,bytes:raw.length,sha256:sha(raw)};});assert.deepEqual(before,after);
const report={schema:'source-scope-template-original-corpus-review-v1',sourceHead:execFileSync('git',['rev-parse','HEAD'],{cwd:original,encoding:'utf8'}).trim(),originalInputs:before,originalInputsUnchanged:true,resolvedOriginalScopes:scopes.length,completeResolverOutputsEqual:true,states,trials,method:'Alternating warm parser setup on the same original clients scope and complete 391-module source graph; concurrent task work may affect wall time. This is not corpus throughput, runtime parity or CI savings.',scriptSha256:sha(fs.readFileSync(new URL(import.meta.url))),runtimeParity:false,fullGateAuthority:false,rustExecuted:false};
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,originalSources:rust.length,resolvedOriginalScopes:scopes.length,completeResolverOutputsEqual:true,completeConfiguredStatesEqual:states.length,trials,runtimeParity:false}));
