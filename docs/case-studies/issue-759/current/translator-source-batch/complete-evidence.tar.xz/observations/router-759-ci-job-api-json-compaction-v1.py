from pathlib import Path
import argparse, gzip, hashlib, json, os, re, subprocess

p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');a=p.parse_args()
r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
prefix=Path('/tmp/router-759-ci-job-api-json-compaction-v1');prepared=Path(str(prefix)+'-prepared');plan_path=Path(str(prefix)+'.plan.json')
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=r);head=git('rev-parse','HEAD').decode().strip()
def allocated():
 seen=set();size=0
 for name in ('docs/case-studies/issue-759','dev/log/issues/759'):
  for f in (r/name).rglob('*'):
   if f.is_file():
    st=f.stat();key=(st.st_dev,st.st_ino)
    if key not in seen:seen.add(key);size+=st.st_blocks*512
 return size
if not a.apply:
 assert not plan_path.exists() and not prepared.exists();prepared.mkdir();entries=[]
 for f in sorted((r/'docs/case-studies/issue-759/raw/ci').rglob('*.json')):
  if not (f.name=='jobs-all.json' or re.fullmatch(r'jobs-page-[0-9]+\.json',f.name)):continue
  b=f.read_bytes()
  if len(b)<4096 or f.stat().st_blocks*512<=4096:continue
  name=f.relative_to(r).as_posix();assert git('show',head+':'+name)==b;json.loads(b)
  encoded=gzip.compress(b,compresslevel=9,mtime=0);assert gzip.decompress(encoded)==b
  if (len(encoded)+4095)//4096*4096>=f.stat().st_blocks*512:continue
  destination=name+'.gz';assert not (r/destination).exists();temporary=prepared/(str(len(entries))+'.json.gz');temporary.write_bytes(encoded)
  entries.append({'logicalOriginalPath':name,'archivePath':destination,'originalBytes':len(b),'originalSha256':sha(b),'originalGitBlob':git('rev-parse',head+':'+name).decode().strip(),'archiveBytes':len(encoded),'archiveSha256':sha(encoded),'preparedPath':str(temporary),'originalAllocatedBytes':f.stat().st_blocks*512})
 citations=[]
 for f in sorted((r/'docs/case-studies/issue-759').rglob('*.md')):
  if '/raw/sources/' in f.as_posix():continue
  old=f.read_text();new=old
  for entry in entries:
   rel=os.path.relpath(r/entry['logicalOriginalPath'],f.parent);new=new.replace(']('+rel+')',']('+rel+'.gz)')
  if new!=old:
   temporary=prepared/('citation-'+str(len(citations))+'.md');temporary.write_text(new);citations.append({'path':f.relative_to(r).as_posix(),'oldSha256':sha(old.encode()),'newSha256':sha(new.encode()),'preparedPath':str(temporary)})
 plan={'schema':'router-759-original-ci-job-api-json-lossless-compaction-v1','sourceHead':head,'combinedEvidenceCapBytes':500000000,'allocatedBytesBefore':allocated(),'entries':entries,'citationUpdates':citations,'allOriginalGitBytesVerified':True,'allDecodedOriginalsByteIdentical':True,'scope':'Complete original paged or combined CI job API responses only; log payloads, downloaded artifacts, original source snapshots and historical receipt vectors remain unchanged','semanticAuthority':False}
 plan_path.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan':str(plan_path),'files':len(entries),'citations':len(citations),'originalBytes':sum(e['originalBytes'] for e in entries),'archiveBytes':sum(e['archiveBytes'] for e in entries),'allocatedBytesBefore':plan['allocatedBytesBefore']}))
else:
 plan=json.loads(plan_path.read_text());assert not git('status','--porcelain')
 # Other evidence-only commits may advance HEAD; every original byte and blob
 # is still checked against both the captured commit and the current commit.
 for entry in plan['entries']:
  b=(r/entry['logicalOriginalPath']).read_bytes();encoded=Path(entry['preparedPath']).read_bytes()
  assert sha(b)==entry['originalSha256'] and sha(encoded)==entry['archiveSha256'] and gzip.decompress(encoded)==b
  assert git('show',plan['sourceHead']+':'+entry['logicalOriginalPath'])==b and git('show',head+':'+entry['logicalOriginalPath'])==b
  assert not (r/entry['archivePath']).exists()
 for citation in plan['citationUpdates']:
  assert sha((r/citation['path']).read_bytes())==citation['oldSha256'] and sha(Path(citation['preparedPath']).read_bytes())==citation['newSha256']
 before=allocated()
 for entry in plan['entries']:
  (r/entry['archivePath']).write_bytes(Path(entry['preparedPath']).read_bytes())
  assert gzip.decompress((r/entry['archivePath']).read_bytes())==git('show',head+':'+entry['logicalOriginalPath'])
  (r/entry['logicalOriginalPath']).unlink()
 for citation in plan['citationUpdates']:(r/citation['path']).write_bytes(Path(citation['preparedPath']).read_bytes())
 manifest={key:value for key,value in plan.items() if key not in ('entries','citationUpdates')}
 manifest['appliedSourceHead']=head
 manifest['entries']=[{key:value for key,value in entry.items() if key!='preparedPath'} for entry in plan['entries']]
 manifest['citationUpdates']=[{key:value for key,value in citation.items() if key!='preparedPath'} for citation in plan['citationUpdates']]
 manifest['decode']='gzip -dc ARCHIVE.json.gz; verify complete decoded length and SHA256 against entries'
 path=r/'docs/case-studies/issue-759/raw/ci/lossless-job-api-json-archives.json';assert not path.exists();path.write_text(json.dumps(manifest,indent=2)+'\n')
 after=allocated();assert after<before and after<500000000
 result={'schema':'router-759-ci-job-api-json-compaction-applied-v1','capturedSourceHead':plan['sourceHead'],'appliedSourceHead':head,'allocatedBytesBefore':before,'allocatedBytesAfter':after,'allocatedBytesReclaimed':before-after,'remainingBytes':500000000-after,'entries':len(plan['entries']),'allDecodedOriginalsByteIdentical':True,'allOriginalGitBytesVerified':True,'manifest':path.relative_to(r).as_posix(),'manifestSha256':sha(path.read_bytes()),'planSha256':sha(plan_path.read_bytes()),'harnessSha256':sha(Path(__file__).read_bytes())}
 applied=Path(str(prefix)+'.applied.json');assert not applied.exists();applied.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
