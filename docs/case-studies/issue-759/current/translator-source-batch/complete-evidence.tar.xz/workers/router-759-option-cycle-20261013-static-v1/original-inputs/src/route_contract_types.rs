use http::Method;

pub use crate::api_error::ApiDialect;

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum RouteClass {
    Neutral,
    Management,
    Service(ServiceKind),
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum ServiceKind {
    Anthropic,
    OpenAi,
    Codex,
    Qwen,
    Gemini,
    Vertex,
    Bedrock,
    GitHub,
    Git,
    ActivityPub,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum ListenerKind {
    Combined,
    InferenceOnly,
    Admin,
    GitHubAdapter,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum RouteAuth {
    None,
    Client,
    Admin,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum RouteMethod {
    Get,
    Post,
    Put,
    Patch,
    Delete,
    Any,
}

impl RouteMethod {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Get => "GET",
            Self::Post => "POST",
            Self::Put => "PUT",
            Self::Patch => "PATCH",
            Self::Delete => "DELETE",
            Self::Any => "ANY",
        }
    }

    pub(super) fn matches(self, method: &Method) -> bool {
        self == Self::Any
            || matches!(
                (self, method),
                (Self::Get, &Method::GET | &Method::HEAD)
                    | (Self::Post, &Method::POST)
                    | (Self::Put, &Method::PUT)
                    | (Self::Patch, &Method::PATCH)
                    | (Self::Delete, &Method::DELETE)
            )
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub enum RouteId {
    // Append new variants so numeric casts and derived ordering stay stable.
    Health,
    AggregateModels,
    SubscriptionUsage,
    SubscriptionUsageProvider,
    Tokens,
    ClientTokens,
    RunLease,
    RevokeToken,
    RotateToken,
    RotateClientToken,
    Providers,
    Provider,
    Login,
    LoginSession,
    LoginCode,
    Usage,
    Accounts,
    AccountPause,
    AccountResume,
    CredentialStatus,
    AuthDiagnostics,
    EmergencyAuthStatus,
    EmergencyAuthDisable,
    SubscriptionHealth,
    Metrics,
    AdminStatus,
    AdminBootstrap,
    AdminBootstrapConfirm,
    AdminRotate,
    AdminSummary,
    AnthropicMessages,
    AnthropicCountTokens,
    AnthropicModels,
    AnthropicModel,
    OpenAiChatCompletions,
    OpenAiChatCompletion,
    OpenAiChatCompletionMessages,
    OpenAiResponses,
    OpenAiResponse,
    OpenAiResponseCancel,
    OpenAiResponseInputItems,
    OpenAiConversations,
    OpenAiConversation,
    OpenAiConversationItems,
    OpenAiConversationItem,
    OpenAiModels,
    OpenAiModel,
    CodexChatCompletions,
    CodexChatCompletion,
    CodexChatCompletionMessages,
    CodexResponses,
    CodexResponse,
    CodexResponseCancel,
    CodexResponseInputItems,
    CodexConversations,
    CodexConversation,
    CodexConversationItems,
    CodexConversationItem,
    CodexModels,
    CodexModel,
    QwenChatCompletions,
    QwenChatCompletion,
    QwenChatCompletionMessages,
    QwenResponses,
    QwenResponse,
    QwenResponseCancel,
    QwenResponseInputItems,
    QwenConversations,
    QwenConversation,
    QwenConversationItems,
    QwenConversationItem,
    QwenModels,
    QwenModel,
    GeminiModels,
    GeminiModel,
    Vertex,
    AnthropicVertex,
    BedrockInvoke,
    BedrockInvokeStream,
    GitHubRest,
    GitHubGraphql,
    Git,
    GitHubAdapterRest,
    GitHubAdapterGraphql,
    GitHubAdapterGit,
    ActivityPubActor,
    ActivityPubInbox,
    ActivityPubOutbox,
    ActivityPubFollowers,
    ActivityPubFollowProblemsets,
    NativeOpenAi,
    NativeAnthropic,
    NativeCodex,
    NativeCodexBackend,
    AccountPolicy,
    RequestLog,
    ErrorLogs,
    ErrorLog,
    ClearLogs,
    Logging,
    UsageQueue,
    LatestVersion,
    ModelDefinitions,
    Routing,
    CooldownReset,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RouteSpec {
    pub id: RouteId,
    pub method: RouteMethod,
    pub template: &'static str,
    pub class: RouteClass,
    pub auth: RouteAuth,
    pub dialect: ApiDialect,
    pub listeners: &'static [ListenerKind],
}

/// Pre-`/api/...` paths a serving Router must answer with 404.
///
/// They stay unclassified on purpose. The deploy verifier probes every one of
/// them against a candidate (issue #683).
pub const REMOVED_ROUTES: &[(&str, &str)] = &[
    ("GET", "/health"),
    ("GET", "/health/subscriptions"),
    ("POST", "/v1/messages"),
    ("POST", "/v1/chat/completions"),
    ("GET", "/v1/models"),
    ("POST", "/api/anthropic/v1/messages"),
    ("POST", "/api/openai/v1/responses"),
    ("POST", "/api/codex/v1/responses"),
    ("POST", "/api/qwen/v1/chat/completions"),
    ("GET", "/api/gemini/v1beta/models"),
    (
        "POST",
        "/api/vertex/v1/projects/p/locations/l/models/m:rawPredict",
    ),
    ("POST", "/invoke"),
    ("GET", "/api/tokens"),
    ("GET", "/api/providers"),
    ("POST", "/api/login"),
    ("GET", "/api/admin/status"),
    ("GET", "/metrics"),
    ("GET", "/user"),
    ("GET", "/actor/code"),
];
