//! Canonical HTTP route classification and endpoint construction.
//!
//! Every network route belongs to exactly one class. Server listeners and
//! clients consume this inventory instead of maintaining path-shaped policy in
//! separate string tables.

use http::Method;
use std::sync::OnceLock;

#[path = "route_contract_types.rs"]
mod types;
pub use types::{
    ApiDialect, ListenerKind, REMOVED_ROUTES, RouteAuth, RouteClass, RouteId, RouteMethod,
    RouteSpec, ServiceKind,
};

#[path = "route_contract_native.rs"]
mod native;
use native::NATIVE_ROUTES;
#[path = "route_contract_observability.rs"]
mod observability;
#[path = "route_contract_routing.rs"]
mod routing;

const COMBINED_AND_INFERENCE: &[ListenerKind] =
    &[ListenerKind::Combined, ListenerKind::InferenceOnly];
const COMBINED_AND_ADMIN: &[ListenerKind] = &[ListenerKind::Combined, ListenerKind::Admin];
const COMBINED_ONLY: &[ListenerKind] = &[ListenerKind::Combined];
const GITHUB_ADAPTER_ONLY: &[ListenerKind] = &[ListenerKind::GitHubAdapter];

const fn neutral(id: RouteId, method: RouteMethod, template: &'static str) -> RouteSpec {
    RouteSpec {
        id,
        method,
        template,
        class: RouteClass::Neutral,
        auth: RouteAuth::None,
        dialect: ApiDialect::Anthropic,
        listeners: COMBINED_AND_INFERENCE,
    }
}

const fn client_neutral(id: RouteId, method: RouteMethod, template: &'static str) -> RouteSpec {
    RouteSpec {
        auth: RouteAuth::Client,
        ..neutral(id, method, template)
    }
}

const fn management(id: RouteId, method: RouteMethod, template: &'static str) -> RouteSpec {
    RouteSpec {
        id,
        method,
        template,
        class: RouteClass::Management,
        auth: RouteAuth::Admin,
        dialect: ApiDialect::Anthropic,
        listeners: COMBINED_AND_ADMIN,
    }
}

const fn open_management(id: RouteId, method: RouteMethod, template: &'static str) -> RouteSpec {
    RouteSpec {
        auth: RouteAuth::None,
        ..management(id, method, template)
    }
}

const fn ai_service(
    id: RouteId,
    method: RouteMethod,
    template: &'static str,
    service: ServiceKind,
    dialect: ApiDialect,
) -> RouteSpec {
    RouteSpec {
        id,
        method,
        template,
        class: RouteClass::Service(service),
        auth: RouteAuth::Client,
        dialect,
        listeners: COMBINED_AND_INFERENCE,
    }
}

const fn private_service(
    id: RouteId,
    method: RouteMethod,
    template: &'static str,
    service: ServiceKind,
    dialect: ApiDialect,
) -> RouteSpec {
    RouteSpec {
        id,
        method,
        template,
        class: RouteClass::Service(service),
        auth: RouteAuth::Client,
        dialect,
        listeners: COMBINED_ONLY,
    }
}

const fn public_private_service(
    id: RouteId,
    method: RouteMethod,
    template: &'static str,
    service: ServiceKind,
    dialect: ApiDialect,
) -> RouteSpec {
    RouteSpec {
        auth: RouteAuth::None,
        ..private_service(id, method, template, service, dialect)
    }
}

const fn github_adapter_service(
    id: RouteId,
    method: RouteMethod,
    template: &'static str,
    service: ServiceKind,
) -> RouteSpec {
    RouteSpec {
        id,
        method,
        template,
        class: RouteClass::Service(service),
        auth: RouteAuth::Client,
        dialect: ApiDialect::GitHub,
        listeners: GITHUB_ADAPTER_ONLY,
    }
}

const ROUTES: &[RouteSpec] = &[
    neutral(RouteId::Health, RouteMethod::Get, "/api/health"),
    client_neutral(RouteId::AggregateModels, RouteMethod::Get, "/api/models"),
    client_neutral(RouteId::SubscriptionUsage, RouteMethod::Get, "/api/usage"),
    client_neutral(RouteId::RunLease, RouteMethod::Post, "/api/run-lease"),
    client_neutral(
        RouteId::SubscriptionUsageProvider,
        RouteMethod::Get,
        "/api/usage/{provider}",
    ),
    management(RouteId::Tokens, RouteMethod::Get, "/api/management/tokens"),
    management(RouteId::Tokens, RouteMethod::Post, "/api/management/tokens"),
    management(
        RouteId::ClientTokens,
        RouteMethod::Post,
        "/api/management/tokens/client",
    ),
    management(
        RouteId::RevokeToken,
        RouteMethod::Post,
        "/api/management/tokens/revoke",
    ),
    management(
        RouteId::RotateToken,
        RouteMethod::Post,
        "/api/management/tokens/rotate",
    ),
    management(
        RouteId::RotateClientToken,
        RouteMethod::Post,
        "/api/management/tokens/rotate-client",
    ),
    management(
        RouteId::Providers,
        RouteMethod::Get,
        "/api/management/providers",
    ),
    routing::MODEL_DEFINITIONS,
    management(
        RouteId::Providers,
        RouteMethod::Post,
        "/api/management/providers",
    ),
    management(
        RouteId::Provider,
        RouteMethod::Get,
        "/api/management/providers/{name}",
    ),
    management(
        RouteId::Provider,
        RouteMethod::Delete,
        "/api/management/providers/{name}",
    ),
    management(RouteId::Login, RouteMethod::Post, "/api/management/login"),
    management(
        RouteId::LoginSession,
        RouteMethod::Get,
        "/api/management/login/{id}",
    ),
    management(
        RouteId::LoginSession,
        RouteMethod::Delete,
        "/api/management/login/{id}",
    ),
    management(
        RouteId::LoginCode,
        RouteMethod::Post,
        "/api/management/login/{id}/code",
    ),
    management(RouteId::Usage, RouteMethod::Get, "/api/management/usage"),
    management(
        RouteId::Accounts,
        RouteMethod::Get,
        "/api/management/accounts",
    ),
    management(
        RouteId::AccountPause,
        RouteMethod::Post,
        "/api/management/accounts/{name}/pause",
    ),
    management(
        RouteId::AccountResume,
        RouteMethod::Post,
        "/api/management/accounts/{name}/resume",
    ),
    management(
        RouteId::AccountPolicy,
        RouteMethod::Get,
        "/api/management/accounts/{name}/policy",
    ),
    management(
        RouteId::AccountPolicy,
        RouteMethod::Post,
        "/api/management/accounts/{name}/policy",
    ),
    management(
        RouteId::CredentialStatus,
        RouteMethod::Get,
        "/api/management/auth/status",
    ),
    management(
        RouteId::AuthDiagnostics,
        RouteMethod::Get,
        "/api/management/auth/diagnostics",
    ),
    management(
        RouteId::EmergencyAuthStatus,
        RouteMethod::Get,
        "/api/management/emergency-auth",
    ),
    management(
        RouteId::EmergencyAuthDisable,
        RouteMethod::Post,
        "/api/management/emergency-auth/disable",
    ),
    management(
        RouteId::SubscriptionHealth,
        RouteMethod::Get,
        "/api/management/health/subscriptions",
    ),
    management(
        RouteId::Metrics,
        RouteMethod::Get,
        "/api/management/metrics",
    ),
    open_management(
        RouteId::AdminStatus,
        RouteMethod::Get,
        "/api/management/admin/status",
    ),
    open_management(
        RouteId::AdminBootstrap,
        RouteMethod::Post,
        "/api/management/admin/bootstrap",
    ),
    open_management(
        RouteId::AdminBootstrapConfirm,
        RouteMethod::Post,
        "/api/management/admin/bootstrap/confirm",
    ),
    management(
        RouteId::AdminRotate,
        RouteMethod::Post,
        "/api/management/admin/rotate",
    ),
    management(
        RouteId::AdminSummary,
        RouteMethod::Get,
        "/api/management/admin/summary",
    ),
    ai_service(
        RouteId::AnthropicMessages,
        RouteMethod::Post,
        "/api/services/anthropic/v1/messages",
        ServiceKind::Anthropic,
        ApiDialect::Anthropic,
    ),
    ai_service(
        RouteId::AnthropicCountTokens,
        RouteMethod::Post,
        "/api/services/anthropic/v1/messages/count_tokens",
        ServiceKind::Anthropic,
        ApiDialect::Anthropic,
    ),
    ai_service(
        RouteId::AnthropicModels,
        RouteMethod::Get,
        "/api/services/anthropic/v1/models",
        ServiceKind::Anthropic,
        ApiDialect::Anthropic,
    ),
    ai_service(
        RouteId::AnthropicModel,
        RouteMethod::Get,
        "/api/services/anthropic/v1/models/{model_id}",
        ServiceKind::Anthropic,
        ApiDialect::Anthropic,
    ),
    ai_service(
        RouteId::OpenAiChatCompletions,
        RouteMethod::Post,
        "/api/services/openai/v1/chat/completions",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiChatCompletions,
        RouteMethod::Get,
        "/api/services/openai/v1/chat/completions",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiChatCompletion,
        RouteMethod::Get,
        "/api/services/openai/v1/chat/completions/{completion_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiChatCompletion,
        RouteMethod::Post,
        "/api/services/openai/v1/chat/completions/{completion_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiChatCompletion,
        RouteMethod::Delete,
        "/api/services/openai/v1/chat/completions/{completion_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiChatCompletionMessages,
        RouteMethod::Get,
        "/api/services/openai/v1/chat/completions/{completion_id}/messages",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiResponses,
        RouteMethod::Post,
        "/api/services/openai/v1/responses",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiResponses,
        RouteMethod::Get,
        "/api/services/openai/v1/responses",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiResponse,
        RouteMethod::Get,
        "/api/services/openai/v1/responses/{response_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiResponse,
        RouteMethod::Delete,
        "/api/services/openai/v1/responses/{response_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiResponseCancel,
        RouteMethod::Post,
        "/api/services/openai/v1/responses/{response_id}/cancel",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiResponseInputItems,
        RouteMethod::Get,
        "/api/services/openai/v1/responses/{response_id}/input_items",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversations,
        RouteMethod::Post,
        "/api/services/openai/v1/conversations",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversation,
        RouteMethod::Get,
        "/api/services/openai/v1/conversations/{conversation_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversation,
        RouteMethod::Patch,
        "/api/services/openai/v1/conversations/{conversation_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversation,
        RouteMethod::Delete,
        "/api/services/openai/v1/conversations/{conversation_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversationItems,
        RouteMethod::Post,
        "/api/services/openai/v1/conversations/{conversation_id}/items",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversationItems,
        RouteMethod::Get,
        "/api/services/openai/v1/conversations/{conversation_id}/items",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversationItem,
        RouteMethod::Get,
        "/api/services/openai/v1/conversations/{conversation_id}/items/{item_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiConversationItem,
        RouteMethod::Delete,
        "/api/services/openai/v1/conversations/{conversation_id}/items/{item_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiModels,
        RouteMethod::Get,
        "/api/services/openai/v1/models",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::OpenAiModel,
        RouteMethod::Get,
        "/api/services/openai/v1/models/{model_id}",
        ServiceKind::OpenAi,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexChatCompletions,
        RouteMethod::Post,
        "/api/services/codex/v1/chat/completions",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexChatCompletions,
        RouteMethod::Get,
        "/api/services/codex/v1/chat/completions",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexChatCompletion,
        RouteMethod::Get,
        "/api/services/codex/v1/chat/completions/{completion_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexChatCompletion,
        RouteMethod::Post,
        "/api/services/codex/v1/chat/completions/{completion_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexChatCompletion,
        RouteMethod::Delete,
        "/api/services/codex/v1/chat/completions/{completion_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexChatCompletionMessages,
        RouteMethod::Get,
        "/api/services/codex/v1/chat/completions/{completion_id}/messages",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexResponses,
        RouteMethod::Post,
        "/api/services/codex/v1/responses",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexResponses,
        RouteMethod::Get,
        "/api/services/codex/v1/responses",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexResponse,
        RouteMethod::Get,
        "/api/services/codex/v1/responses/{response_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexResponse,
        RouteMethod::Delete,
        "/api/services/codex/v1/responses/{response_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexResponseCancel,
        RouteMethod::Post,
        "/api/services/codex/v1/responses/{response_id}/cancel",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexResponseInputItems,
        RouteMethod::Get,
        "/api/services/codex/v1/responses/{response_id}/input_items",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversations,
        RouteMethod::Post,
        "/api/services/codex/v1/conversations",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversation,
        RouteMethod::Get,
        "/api/services/codex/v1/conversations/{conversation_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversation,
        RouteMethod::Patch,
        "/api/services/codex/v1/conversations/{conversation_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversation,
        RouteMethod::Delete,
        "/api/services/codex/v1/conversations/{conversation_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversationItems,
        RouteMethod::Post,
        "/api/services/codex/v1/conversations/{conversation_id}/items",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversationItems,
        RouteMethod::Get,
        "/api/services/codex/v1/conversations/{conversation_id}/items",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversationItem,
        RouteMethod::Get,
        "/api/services/codex/v1/conversations/{conversation_id}/items/{item_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexConversationItem,
        RouteMethod::Delete,
        "/api/services/codex/v1/conversations/{conversation_id}/items/{item_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexModels,
        RouteMethod::Get,
        "/api/services/codex/v1/models",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::CodexModel,
        RouteMethod::Get,
        "/api/services/codex/v1/models/{model_id}",
        ServiceKind::Codex,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenChatCompletions,
        RouteMethod::Post,
        "/api/services/qwen/v1/chat/completions",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenChatCompletions,
        RouteMethod::Get,
        "/api/services/qwen/v1/chat/completions",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenChatCompletion,
        RouteMethod::Get,
        "/api/services/qwen/v1/chat/completions/{completion_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenChatCompletion,
        RouteMethod::Post,
        "/api/services/qwen/v1/chat/completions/{completion_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenChatCompletion,
        RouteMethod::Delete,
        "/api/services/qwen/v1/chat/completions/{completion_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenChatCompletionMessages,
        RouteMethod::Get,
        "/api/services/qwen/v1/chat/completions/{completion_id}/messages",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenResponses,
        RouteMethod::Post,
        "/api/services/qwen/v1/responses",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenResponses,
        RouteMethod::Get,
        "/api/services/qwen/v1/responses",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenResponse,
        RouteMethod::Get,
        "/api/services/qwen/v1/responses/{response_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenResponse,
        RouteMethod::Delete,
        "/api/services/qwen/v1/responses/{response_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenResponseCancel,
        RouteMethod::Post,
        "/api/services/qwen/v1/responses/{response_id}/cancel",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenResponseInputItems,
        RouteMethod::Get,
        "/api/services/qwen/v1/responses/{response_id}/input_items",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversations,
        RouteMethod::Post,
        "/api/services/qwen/v1/conversations",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversation,
        RouteMethod::Get,
        "/api/services/qwen/v1/conversations/{conversation_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversation,
        RouteMethod::Patch,
        "/api/services/qwen/v1/conversations/{conversation_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversation,
        RouteMethod::Delete,
        "/api/services/qwen/v1/conversations/{conversation_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversationItems,
        RouteMethod::Post,
        "/api/services/qwen/v1/conversations/{conversation_id}/items",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversationItems,
        RouteMethod::Get,
        "/api/services/qwen/v1/conversations/{conversation_id}/items",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversationItem,
        RouteMethod::Get,
        "/api/services/qwen/v1/conversations/{conversation_id}/items/{item_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenConversationItem,
        RouteMethod::Delete,
        "/api/services/qwen/v1/conversations/{conversation_id}/items/{item_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenModels,
        RouteMethod::Get,
        "/api/services/qwen/v1/models",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::QwenModel,
        RouteMethod::Get,
        "/api/services/qwen/v1/models/{model_id}",
        ServiceKind::Qwen,
        ApiDialect::OpenAi,
    ),
    ai_service(
        RouteId::GeminiModels,
        RouteMethod::Get,
        "/api/services/gemini/v1beta/models",
        ServiceKind::Gemini,
        ApiDialect::Gemini,
    ),
    ai_service(
        RouteId::GeminiModel,
        RouteMethod::Get,
        "/api/services/gemini/v1beta/models/{model}",
        ServiceKind::Gemini,
        ApiDialect::Gemini,
    ),
    ai_service(
        RouteId::GeminiModel,
        RouteMethod::Post,
        "/api/services/gemini/v1beta/models/{model}",
        ServiceKind::Gemini,
        ApiDialect::Gemini,
    ),
    ai_service(
        RouteId::AnthropicVertex,
        RouteMethod::Post,
        "/api/services/vertex/v1/projects/{project}/locations/{location}/publishers/anthropic/models/{*model_action}",
        ServiceKind::Vertex,
        ApiDialect::Anthropic,
    ),
    ai_service(
        RouteId::Vertex,
        RouteMethod::Post,
        "/api/services/vertex/v1/{*path}",
        ServiceKind::Vertex,
        ApiDialect::Gemini,
    ),
    ai_service(
        RouteId::BedrockInvoke,
        RouteMethod::Post,
        "/api/services/bedrock/invoke",
        ServiceKind::Bedrock,
        ApiDialect::Anthropic,
    ),
    ai_service(
        RouteId::BedrockInvokeStream,
        RouteMethod::Post,
        "/api/services/bedrock/invoke-with-response-stream",
        ServiceKind::Bedrock,
        ApiDialect::Anthropic,
    ),
    private_service(
        RouteId::GitHubRest,
        RouteMethod::Any,
        "/api/services/github/api/v3/{*path}",
        ServiceKind::GitHub,
        ApiDialect::GitHub,
    ),
    private_service(
        RouteId::GitHubGraphql,
        RouteMethod::Post,
        "/api/services/github/api/graphql",
        ServiceKind::GitHub,
        ApiDialect::GitHub,
    ),
    private_service(
        RouteId::Git,
        RouteMethod::Any,
        "/api/services/github/git/{*path}",
        ServiceKind::Git,
        ApiDialect::GitHub,
    ),
    github_adapter_service(
        RouteId::GitHubAdapterRest,
        RouteMethod::Any,
        "/api/v3/{*path}",
        ServiceKind::GitHub,
    ),
    github_adapter_service(
        RouteId::GitHubAdapterGraphql,
        RouteMethod::Post,
        "/api/graphql",
        ServiceKind::GitHub,
    ),
    github_adapter_service(
        RouteId::GitHubAdapterGit,
        RouteMethod::Any,
        "/git/{*path}",
        ServiceKind::Git,
    ),
    public_private_service(
        RouteId::ActivityPubActor,
        RouteMethod::Get,
        "/api/services/activitypub/actor/code",
        ServiceKind::ActivityPub,
        ApiDialect::Anthropic,
    ),
    public_private_service(
        RouteId::ActivityPubInbox,
        RouteMethod::Post,
        "/api/services/activitypub/inbox/code",
        ServiceKind::ActivityPub,
        ApiDialect::Anthropic,
    ),
    public_private_service(
        RouteId::ActivityPubOutbox,
        RouteMethod::Get,
        "/api/services/activitypub/outbox/code",
        ServiceKind::ActivityPub,
        ApiDialect::Anthropic,
    ),
    public_private_service(
        RouteId::ActivityPubFollowers,
        RouteMethod::Get,
        "/api/services/activitypub/actors/code/followers",
        ServiceKind::ActivityPub,
        ApiDialect::Anthropic,
    ),
    public_private_service(
        RouteId::ActivityPubFollowProblemsets,
        RouteMethod::Get,
        "/api/services/activitypub/activities/follow-problemsets-code-001",
        ServiceKind::ActivityPub,
        ApiDialect::Anthropic,
    ),
];

#[must_use]
pub fn route_specs() -> &'static [RouteSpec] {
    static ALL: OnceLock<Vec<RouteSpec>> = OnceLock::new();
    ALL.get_or_init(|| {
        ROUTES
            .iter()
            .chain(NATIVE_ROUTES.iter())
            .chain(observability::ROUTES.iter())
            .chain(routing::ROUTES.iter())
            .copied()
            .collect()
    })
}

/// The canonical path template for a route id.
///
/// Multiple methods may share an id, but they must share this template.
#[must_use]
pub fn route_template(id: RouteId) -> &'static str {
    route_specs()
        .iter()
        .find(|spec| spec.id == id)
        .map(|spec| spec.template)
        .expect("unknown route id")
}

#[must_use]
pub fn route_for_path(method: &Method, path: &str) -> Option<&'static RouteSpec> {
    route_specs()
        .iter()
        .find(|spec| spec.method.matches(method) && template_matches(spec.template, path))
}

#[must_use]
pub fn dialect_for_path(path: &str) -> Option<ApiDialect> {
    route_specs()
        .iter()
        .find(|spec| template_matches(spec.template, path))
        .map(|spec| spec.dialect)
}

#[must_use]
pub fn endpoint_base(origin: &str, service: ServiceKind) -> String {
    format!(
        "{}{}",
        origin.trim_end_matches('/'),
        service_base_path(service)
    )
}

#[must_use]
pub const fn service_base_path(service: ServiceKind) -> &'static str {
    match service {
        ServiceKind::Anthropic => "/api/services/anthropic",
        ServiceKind::OpenAi => "/api/services/openai/v1",
        ServiceKind::Codex => "/api/services/codex/v1",
        ServiceKind::Qwen => "/api/services/qwen/v1",
        ServiceKind::Gemini => "/api/services/gemini",
        ServiceKind::Vertex => "/api/services/vertex/v1",
        ServiceKind::Bedrock => "/api/services/bedrock",
        ServiceKind::GitHub => "/api/services/github/api/v3",
        ServiceKind::Git => "/api/services/github/git",
        ServiceKind::ActivityPub => "/api/services/activitypub",
    }
}

#[must_use]
pub fn management_endpoint(origin: &str, id: RouteId) -> String {
    let template = route_specs()
        .iter()
        .find(|spec| spec.id == id && spec.class == RouteClass::Management)
        .map(|spec| spec.template)
        .expect("management endpoint requested for a non-management route");
    assert!(
        !template.contains('{'),
        "parameterized management endpoints require explicit substitution"
    );
    format!("{}{}", origin.trim_end_matches('/'), template)
}

fn template_matches(template: &str, path: &str) -> bool {
    let mut template_segments = template.trim_matches('/').split('/');
    let mut path_segments = path.trim_matches('/').split('/');

    loop {
        match (template_segments.next(), path_segments.next()) {
            (None, None) => return true,
            (Some(segment), _) if segment.starts_with("{*") && segment.ends_with('}') => {
                return true;
            }
            (Some(segment), Some(path_segment))
                if segment.starts_with('{')
                    && segment.ends_with('}')
                    && !path_segment.is_empty() => {}
            (Some(segment), Some(path_segment)) if segment == path_segment => {}
            _ => return false,
        }
    }
}
