import argparse,datetime,hashlib,json,tarfile,io,subprocess
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',required=True)
parser.add_argument('--verified-source-head',required=True)
parser.add_argument('--status',required=True,choices=['FOCUSED_PASS_NOT_FULL_GATE','FOCUSED_FAIL_NOT_FULL_GATE'])
args=parser.parse_args()
root=Path('/tmp')
owned_prefixes=('router-759-copied-shared-local-flow','router-759-source-lifetimes-mutable-draft','router-759-source-lifetime-flow-test-draft')
paths=sorted(p for p in root.iterdir() if p.name.startswith(owned_prefixes) and p.is_file() and not p.is_symlink())
if not paths:raise RuntimeError('No exact task-owned evidence')
output=Path(args.output_dir)
output.mkdir(parents=True,exist_ok=True)
archive=output/'router-759-copied-shared-local-flow.tar.xz'
receipt=output/'receipt.json'
readme=output/'README.md'
if any(p.exists() for p in (archive,receipt,readme)):raise RuntimeError('Retain prior archive; require a new output directory')
hash_bytes=lambda raw:hashlib.sha256(raw).hexdigest()
files=[];unique={};attempts=[]
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in paths:
  raw=p.read_bytes();sha=hash_bytes(raw);name=p.name
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.uid=info.gid=0
  duplicate=unique.get((len(raw),sha))
  if duplicate:info.type=tarfile.LNKTYPE;info.linkname=duplicate;tar.addfile(info)
  else:info.size=len(raw);tar.addfile(info,io.BytesIO(raw));unique[(len(raw),sha)]=name
  files.append({'originalPath':str(p),'member':name,'bytes':len(raw),'sha256':sha,'hardlink':duplicate})
  if p.suffix=='.json' and '.inputs.' not in name:
   try:d=json.loads(raw)
   except ValueError:continue
   if isinstance(d,dict) and 'engine' in d and 'sourceHeadBefore' in d:
    attempts.append({k:d.get(k) for k in ['phase','engine','evidenceStatus','sourceHeadBefore','sourceHeadAfter','sourceHeadUnchanged','sourceInputsUnchanged','sourceInputSha256Before','sourceInputSha256After','inputFiles','testFiles','timeoutSeconds','startedUtc','finishedUtc','elapsedSeconds','exitCode','timedOut','counts','log','logBytes','logSha256','measurement']})
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers()
 if len(members)!=len(files):raise RuntimeError('Archive logical member count differs')
 for record in files:
  raw=tar.extractfile(record['member']).read()
  if len(raw)!=record['bytes'] or hash_bytes(raw)!=record['sha256']:raise RuntimeError('Archive differs from complete original member')
  if Path(record['originalPath']).read_bytes()!=raw:raise RuntimeError('Original changed during archive')
d={'schemaVersion':1,'evidenceStatus':args.status,'verifiedImplementationHead':args.verified_source_head,'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Complete preserved attempted source-origin flow cohorts; actual original inline-zero source and JS/strict TS observations; does not establish whole-corpus/runtime/native parity','archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':hash_bytes(archive.read_bytes()),'compression':'XZ preset 6; 8 MiB dictionary setting, not a measured peak RSS','logicalMembers':len(files),'hardlinks':len(files)-len(unique),'logicalBytes':sum(r['bytes'] for r in files)},'files':files,'attempts':attempts,'integrity':{'allLogicalMembersReopened':True,'allOriginalBytesCompared':True,'errors':0},'limitations':['Focused tests are not the complete JavaScript gate','Full runtime parity remains unproved','No local Rust builds; no producers/full gate in these focused receipts','Bun has no separate cancellation count; exit and complete raw terminal summary retained','All raw logs remain unabridged; display-only data URL sanitization does not touch archives','Initial Bun failure inventory v1 double-counted repeated terminal summary; corrected v2 and failed v1 are both retained','Repair-one Bun failure inventory v1 included preceding pass/fail boundary text; corrected v2 starts after that boundary, keeps all six actual failures and preserves v1'],'cleanup':{'originalsRemoved':False,'requireCommittedArchiveAndGateDirectGitVerification':True}}
receipt.write_text(json.dumps(d,separators=(',',':'))+'\n')
readme.write_text('Complete task-owned raw logs, source/resource receipts, immutable harnesses, failures and source drafts are preserved in the XZ archive. Every logical member, including deduplicated hard links, was reopened and compared against its full original bytes.\n\nStatus: '+args.status+'. Implementation: `'+args.verified_source_head+'`. Focused observations do not establish complete corpus or runtime parity. No local Rust builds, producer runs or complete gate runs are included in these focused receipts. The receipt records every attempt and the prior Bun inventory parser correction.\n')
print(json.dumps({'archive':str(archive),'receipt':str(receipt),'readme':str(readme),'bytes':archive.stat().st_size,'sha256':d['archive']['sha256'],'members':len(files),'attempts':len(attempts),'errors':0}))
