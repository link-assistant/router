from pathlib import Path
import json,io,hashlib,tarfile,os
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
base='router-759-cohort-v3-canonical-ae1a481d5'
names=[base+suffix for suffix in ['.log','-time.log','-inputs.json','.json']]
names += ['router-759-bounded-cohort-producer-v5.py','router-759-canonical-ae1a-resource-point-v1-setup-failure.json','router-759-canonical-ae1a-resource-point-v2.py','router-759-canonical-ae1a-resource-point-v2-setup-failure.json','router-759-canonical-ae1a-resource-point-v3.py','router-759-canonical-ae1a-resource-point-v3.json','router-759-ae1a-trait-member-header-source-review-v1.json','router-759-ae1a-declaration-header-source-review-v2.json','router-759-ae1a-original-layout-refusal-source-review-v1.json','router-759-coherent-repair-four-direct-git-v1.json','router-759-canonical-ae1a-full-archive-v1.py']
receipt=json.loads((Path('/tmp')/(base+'.json')).read_text())
assert receipt['sourceInputsUnchanged'] and receipt['headAfter']==receipt['sourceHead'] and not receipt['rustExecuted']
destination=root/'docs/case-studies/issue-759/current/canonical-ae1a-original-refusals'
assert not destination.exists()
archive=Path('/tmp/router-759-canonical-ae1a-full-evidence-v1.tar.xz')
assert not archive.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
members=[]
with tarfile.open(archive,'x:xz',preset=6) as stream:
 for name in names:
  path=Path('/tmp')/name;data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;stream.addfile(info,io.BytesIO(data))
  members.append({'name':name,'bytes':len(data),'sha256':sha(data),'originalPath':str(path)})
seen=set();allocated=0
for dirname in ['docs/case-studies/issue-759','docs/development/case-studies/issue-759']:
 directory=root/dirname
 if not directory.exists():continue
 for path in directory.rglob('*'):
  if not path.is_file():continue
  stat=path.stat();key=(stat.st_dev,stat.st_ino)
  if key not in seen:allocated+=stat.st_blocks*512;seen.add(key)
packet={'schema':'router-759-complete-bounded-corpus-attempt-archive-v1','producer':receipt,'members':members,'archive':{'path':str((destination/'complete-attempt.tar.xz').relative_to(root)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'sourceReviewsAreUnrun':True,'singlePointRssIsNotPeak':True,'runtimeParity':False,'directGitFullBytesVerification':'required after commit before original cleanup'}
data=(json.dumps(packet,indent=2)+'\n').encode()
projected=allocated+((archive.stat().st_size+4095)//4096)*4096+((len(data)+4095)//4096)*4096
assert projected<500000000,(allocated,projected)
destination.mkdir(parents=True);(destination/'complete-attempt.tar.xz').write_bytes(archive.read_bytes());(destination/'receipt.json').write_bytes(data)
print(json.dumps({'members':len(members),'bytes':archive.stat().st_size,'allocatedBefore':allocated,'allocatedProjected':projected,'timedOut':receipt['timedOut'],'last':receipt['progress']['last']}))
