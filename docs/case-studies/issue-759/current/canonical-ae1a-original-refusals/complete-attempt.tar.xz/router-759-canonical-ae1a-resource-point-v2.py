from pathlib import Path
import subprocess,json,datetime
root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate'
head='ae1a481d566ea5db9651b5753299493aeccf338b'
pattern='^python3 /tmp/router-759-bounded-cohort-producer-v5.py --root '+root+' --head '+head+' --mode canonical --cap 1200$'
p=subprocess.run(['pgrep','-f',pattern],capture_output=True,text=True,timeout=10)
ids=[int(x) for x in p.stdout.split()];assert len(ids)==1,'Requires one exact task-owned harness'
data=subprocess.check_output(['ps','-axo','pid=,ppid=,rss=,comm='],text=True,timeout=10);rows=[]
for line in data.splitlines():
 parts=line.split(None,3)
 if len(parts)==4:
  pid,ppid,rss=map(int,parts[:3]);rows.append({'pid':pid,'ppid':ppid,'rssBytes':rss*1024,'executable':parts[3].split('/')[-1]})
known=set(ids);changed=True
while changed:
 changed=False
 for row in rows:
  if row['ppid'] in known and row['pid'] not in known:known.add(row['pid']);changed=True
selected=[row for row in rows if row['pid'] in known]
j={'schema':'router-759-resource-point-observation-v2','sourceHead':head,'observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'ps pid/ppid/rss/comm only; current descendants of the one exact task-owned corpus harness; no command arguments retained','harnessMatches':ids,'processes':selected,'sampledAggregateRssBytes':sum(row['rssBytes'] for row in selected),'scope':'single current RSS sample; sum can double-count shared memory; not a peak or full-run monitor','rustExecuted':False}
p=Path('/tmp/router-759-canonical-ae1a-resource-point-v2.json');p.write_text(json.dumps(j,indent=2)+'\n');print({'harnessMatches':len(ids),'processCount':len(selected),'sampledAggregateRssBytes':j['sampledAggregateRssBytes'],'isPeak':False})
