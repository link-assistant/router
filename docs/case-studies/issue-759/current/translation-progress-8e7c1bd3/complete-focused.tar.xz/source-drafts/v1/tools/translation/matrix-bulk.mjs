// Independent full-corpus compilation for explicitly selected profiles. The
// neutral baseline keeps its ordinary outputs; no common executable is minted.
import {execFileSync} from 'node:child_process';
import {existsSync,lstatSync,mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {types as utilTypes} from 'node:util';
import {compilationMatrixDescription} from './compilation-matrix.mjs';
import {captureSourceCorpus,sourceCorpusPaths,assertSourceCorpusSelection} from './source-corpus.mjs';
import {planRegeneration,validateRegenerationPlan,applyRegenerationPlan} from './bulk.mjs';
import {json,sha256} from './translate.mjs';
import {translationProgressReporter} from './translation-progress.mjs';
export const MATRIX_BULK_LIMITS=Object.freeze({entries:16,expectedBytes:1024*1024*1024});

function entryPaths(input,tracked){
  if(!Array.isArray(input)||utilTypes.isProxy(input)||Object.getPrototypeOf(input)!==Array.prototype)throw new TypeError('matrix bulk entries require an ordinary data array');
  const length=Object.getOwnPropertyDescriptor(input,'length').value;
  if(length>MATRIX_BULK_LIMITS.entries)throw new TypeError('matrix bulk entry budget exceeds sixteen');
  const result=[];
  for(const key of Reflect.ownKeys(input))if(key!=='length'&&(typeof key!=='string'||!(/^(0|[1-9][0-9]*)$/).test(key)||Number(key)>=length))throw new TypeError('matrix entries have incidental properties');
  for(let index=0;index<length;index++){
    const descriptor=Object.getOwnPropertyDescriptor(input,String(index));
    if(!descriptor||!('value'in descriptor)||!descriptor.enumerable||!tracked.has(descriptor.value))throw new TypeError('matrix entries must be original tracked Rust source paths');
    result.push(descriptor.value);
  }
  if(new Set(result).size!==result.length)throw new TypeError('matrix entries must be distinct');
  return result.sort();
}
function manifestPath(root,matrix){
  const relative=`profiles/matrix-${matrix.sha256}.json`;
  for(const path of ['profiles',relative]){
    try{if(lstatSync(join(root,path)).isSymbolicLink())throw new TypeError('matrix manifest cannot follow a symbolic link');}
    catch(error){if(error.code!=='ENOENT')throw error;}
  }
  return relative;
}
export function regenerateCompilationMatrix({root,matrix,check=false,sources,entries,sourceCorpus,progress:progressInput}={}){
  root=resolve(root);
  const progress=translationProgressReporter(progressInput);
  const description=compilationMatrixDescription(matrix);
  const corpus=sourceCorpus??captureSourceCorpus({root,paths:sources??execFileSync('git',['ls-files','-z','--','*.rs'],{cwd:root,encoding:'utf8'}).split('\0').filter(Boolean)});
  const paths=sourceCorpusPaths(corpus,root),tracked=new Set(paths);
  if(sourceCorpus&&sources!==undefined)assertSourceCorpusSelection(corpus,root,sources);
  entries=entryPaths(entries??['src/lib.rs','src/main.rs'].filter(path=>tracked.has(path)),tracked);
  const outputPlans=[];let expectedBytes=0;
  // Every profile constructs fresh invocation, binding, type and effect
  // contexts. All plans finish and all output paths validate before any write.
  for(const member of description.profiles){
    progress({stage:'profile',state:'start',profile:member.name});
    const plan=planRegeneration({root,sources:paths,entries,compilationProfile:member.compilationProfile,outputPrefix:member.directory,sourceCorpus:corpus,matrix,progress:progressInput});
    expectedBytes+=plan.expectedBytes;
    if(expectedBytes>MATRIX_BULK_LIMITS.expectedBytes)throw new TypeError('matrix output plans exceed the 1073741824 byte aggregate budget');
    outputPlans.push({member,plan});
    progress({stage:'profile',state:'end',profile:member.name,outputs:plan.outputs.length,bytes:plan.expectedBytes});
  }
  const implementations=new Set(outputPlans.map(({plan})=>sha256(json(plan.manifest.implementationHashes))));
  if(implementations.size!==1)throw new TypeError('translator implementation changed between matrix profile plans');
  const relative=manifestPath(root,matrix);
  outputPlans.forEach(({plan})=>validateRegenerationPlan(plan));
  const manifest={schema:'independent-profile-bulk-inventory-v1',matrixSha256:matrix.sha256,requiredProfiles:description.requiredProfiles,sourceSetSha256:corpus.sourceSetSha256,sources:corpus.sources,cargo:corpus.cargo,translatorImplementationSha256:[...implementations][0],entries,expectedBytes,limits:MATRIX_BULK_LIMITS,
    profiles:outputPlans.map(({member,plan})=>({name:member.name,profileSha256:member.sha256,compilationProfile:member.compilationProfile,directory:member.directory,inventory:`${member.directory}/parity/rust-source-inventory.json`,outputPlanSha256:sha256(json(plan.outputs)),outputFiles:plan.outputs.length,expectedBytes:plan.expectedBytes,totals:plan.manifest.totals,functionCoverage:plan.manifest.functionCoverage,projects:plan.manifest.projects,runtimeParity:false})),
    canonicalNeutralOutputsChanged:false,platformDomainComplete:false,commonExecutableOutput:false,runtimeParity:false,
    obligations:[{kind:'profile-domain-incomplete',message:'Explicit profiles do not cover all Rust targets, Cargo features, build modes or residual platform families.'},{kind:'native-parity-unproved',message:'Independent draft outputs preserve all refusals and do not establish complete native behavior.'},{kind:'common-executable-unproved',message:'No merged output or profile-independent executable is emitted.'}]};
  const failures=[];
  for(const {plan}of outputPlans)failures.push(...applyRegenerationPlan(plan,{check}).failures);
  const target=join(root,relative),content=json(manifest);
  if(check){
    if(!existsSync(target))failures.push(`missing: ${relative}`);
    else if(readFileSync(target,'utf8')!==content)failures.push(`stale: ${relative}`);
  }else{mkdirSync(join(root,'profiles'),{recursive:true});writeFileSync(target,content);}
  return {manifest,failures};
}
