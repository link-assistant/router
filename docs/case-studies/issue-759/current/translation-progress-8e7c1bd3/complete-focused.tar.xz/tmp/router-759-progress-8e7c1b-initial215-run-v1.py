#!/usr/bin/env python3
import argparse,datetime,hashlib,json,os,re,resource,shutil,signal,subprocess,time
from pathlib import Path
ROOT=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
HEAD='8e7c1bd3177e97fe8354afed87ddfbacb90f7dcc'
FREEZE=Path('/tmp/router-759-progress-8e7c1b-initial215-freeze-v1.json')
PREFIX=Path('/tmp/router-759-progress-8e7c1b-initial215')
parser=argparse.ArgumentParser();parser.add_argument('--engine',choices=['node','bun'],required=True);args=parser.parse_args()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,timeout=30).decode().strip()
def state():
    head=git('rev-parse','HEAD');status=git('status','--porcelain','--untracked-files=no')
    if head!=HEAD or status:raise RuntimeError('Exact source head or tracked bytes changed')
    return {'head':head,'trackedStatus':status}
def inputs():
    names=subprocess.check_output(['git','ls-files','-z','--','tools/translation','scripts/translate-router.mjs','*.rs','Cargo.toml','Cargo.lock','packages/javascript/package.json','packages/javascript/package-lock.json'],cwd=ROOT,timeout=30).decode().split('\0');rows=[]
    for name in sorted(set(filter(None,names))):
        if name.startswith(('tools/translation/meta/','tools/translation/projects/')):continue
        p=ROOT/name;raw=p.read_bytes()if p.is_file()else subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT,timeout=30)
        rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
    return rows
freeze=json.loads(FREEZE.read_text());before=state();rows=inputs();digest=sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())
if freeze.get('schema')!='router-759-progress-215-input-freeze-v1'or freeze.get('head')!=HEAD or freeze.get('expectedCases')!=215 or rows!=freeze.get('inputs')or digest!=freeze.get('sourceInputsSha256'):raise RuntimeError('Source differs from complete immutable freeze')
if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('2GiB disk floor required')
files=freeze['testPaths'];command=['node','--test','--test-concurrency=1',*files]if args.engine=='node'else ['bun','test','--timeout','15000',*files]
rawPath=Path(str(PREFIX)+'-'+args.engine+'.raw.log');receiptPath=Path(str(PREFIX)+'-'+args.engine+'-receipt.json');manifestPath=Path(str(PREFIX)+'-'+args.engine+'-inputs.json')
for path in [rawPath,receiptPath,manifestPath]:
    if path.exists():raise RuntimeError('Attempt evidence already exists; retain it and author a new phase')
manifest={'head':HEAD,'sourceInputsSha256':digest,'files':rows};manifestPath.write_text(json.dumps(manifest,indent=2)+'\n')
engineVersion=subprocess.check_output([args.engine,'--version'],cwd=ROOT,timeout=30,text=True).strip();startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat();started=time.monotonic();usageBefore=resource.getrusage(resource.RUSAGE_CHILDREN);timedOut=False
with rawPath.open('xb')as output:
    child=subprocess.Popen(['/usr/bin/time','-p',*command],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    try:code=child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timedOut=True;os.killpg(child.pid,signal.SIGTERM)
        try:code=child.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
elapsed=round(time.monotonic()-started,3);usageAfter=resource.getrusage(resource.RUSAGE_CHILDREN);finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat();raw=rawPath.read_bytes();clean=re.sub(r'\x1b\[[0-9;]*m','',raw.decode(errors='replace'))
if args.engine=='node':
    counts={key:int(match.group(1))if(match:=re.search(r'^# '+key+r' (\d+)\s*$',clean,re.M))else None for key in ['tests','pass','fail','cancelled','skipped','todo']}
else:
    def count(label):
        matches=re.findall(r'^\s*(\d+) '+label+r'\s*$',clean,re.M);return int(matches[-1])if matches else None
    counts={'tests':None,'pass':count('pass'),'fail':count('fail'),'skipped':count('skip')or 0,'cancelled':None,'todo':None}
    if counts['pass']is not None and counts['fail']is not None:counts['tests']=counts['pass']+counts['fail']+counts['skipped']
after=state();unchanged=inputs()==rows
passed=code==0 and not timedOut and unchanged and counts['tests']==215 and counts['pass']==215 and counts['fail']==0 and counts['skipped']==0 and(args.engine=='bun'or counts['cancelled']==0)
receipt={'schema':'router-759-progress-focused-215-receipt-v1','phase':'initial215','engine':args.engine,'engineVersion':engineVersion,'command':command,'wrapper':['/usr/bin/time','-p'],'capSeconds':600,'testFiles':len(files),'expectedCases':215,'startedUtc':startedUtc,'finishedUtc':finishedUtc,'elapsedSeconds':elapsed,'exitCode':code,'timedOut':timedOut,'counts':counts,'stateBefore':before,'stateAfter':after,'sourceInputsUnchanged':unchanged,'sourceInputsCount':len(rows),'sourceInputsSha256':digest,'inputManifest':str(manifestPath),'inputManifestSha256':sha(manifestPath.read_bytes()),'freeze':str(FREEZE),'freezeSha256':sha(FREEZE.read_bytes()),'runnerSha256':sha(Path(__file__).read_bytes()),'raw':{'path':str(rawPath),'bytes':len(raw),'sha256':sha(raw)},'passed':passed,'evidenceStatus':'FOCUSED_PASS_NOT_FULL_GATE'if passed else 'FOCUSED_FAIL_NOT_FULL_GATE','futureCargo413Included':False,'repositoryCorpusProducersRun':0,'fixtureProducerObservation':'actual bounded temporary canonical/profile producer/check children exist in four authored diagnostic controls; individual child intervals are not separately measured','rustBuilds':0,'fullGateRuns':0,'cancellationObservation':'TAP count'if args.engine=='node'else 'Bun exit and unabridged summary; no independent cancellation count','resource':{'userCpuSeconds':usageAfter.ru_utime-usageBefore.ru_utime,'systemCpuSeconds':usageAfter.ru_stime-usageBefore.ru_stime,'maximumRecordedChildRss':usageAfter.ru_maxrss,'maximumRecordedChildRssUnit':'bytes on Darwin, KiB on Linux','rssScope':'RUSAGE_CHILDREN maximum of recorded waited children, includes earlier Git/version children; not aggregate concurrent process-tree RSS','cpuScope':'RUSAGE_CHILDREN delta around time/engine wrapper execution; accounting of descendants as provided by OS'}}
with receiptPath.open('x')as output:json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({key:receipt[key]for key in ['engine','elapsedSeconds','exitCode','timedOut','counts','sourceInputsUnchanged','sourceInputsCount','passed']}),flush=True)
print(re.sub(r'data:text/javascript;base64,[A-Za-z0-9+/=]+','<data-module>',clean)[-2500:],flush=True)
raise SystemExit(0 if passed else 1)
