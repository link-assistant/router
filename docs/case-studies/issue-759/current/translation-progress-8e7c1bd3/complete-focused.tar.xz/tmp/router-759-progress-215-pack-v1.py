#!/usr/bin/env python3
import datetime,hashlib,io,json,lzma,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
HEAD='8e7c1bd3177e97fe8354afed87ddfbacb90f7dcc'
BASE='69ca313dd04c728ea2025947ff5c1f7f92e23a92'
DEST=ROOT/'docs/case-studies/issue-759/current/translation-progress-8e7c1bd3'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,timeout=30)
if git('rev-parse','HEAD').decode().strip()!=HEAD:raise RuntimeError('Source head changed before archiving')
if git('status','--porcelain','--untracked-files=no').strip():raise RuntimeError('Tracked source changed before archiving')
members=[]
def member(path,name=None):
 raw=path.read_bytes();members.append((name or 'tmp/'+path.name,path,raw))
for version in range(1,6):
 folder=Path(f'/tmp/router-759-progress-source-draft-v{version}')
 for path in sorted(folder.rglob('*')):
  if path.is_file():member(path,'source-drafts/v'+str(version)+'/'+path.relative_to(folder).as_posix())
for name in ['router-759-progress-own-source-install-v1.json','router-759-root-progress-69ca-own-head-hydration.json','router-759-progress-8e7c1b-initial215-run-v1.py','router-759-progress-8e7c1b-initial215-freeze-v1.json','router-759-progress-8e7c1b-initial215-plan-v1.json']:
 member(Path('/tmp')/name)
receipts={}
for engine in ['node','bun']:
 prefix=Path('/tmp/router-759-progress-8e7c1b-initial215-'+engine)
 for suffix in ['.raw.log','-receipt.json','-inputs.json']:member(Path(str(prefix)+suffix))
 receipt=json.loads(Path(str(prefix)+'-receipt.json').read_text())
 if not receipt['passed'] or receipt['stateBefore']['head']!=HEAD or receipt['stateAfter']['head']!=HEAD or not receipt['sourceInputsUnchanged'] or receipt['sourceInputsCount']!=1783 or receipt['counts']['pass']!=215 or receipt['counts']['fail'] or receipt['counts']['skipped'] or receipt['timedOut'] or receipt['exitCode']:
  raise RuntimeError('Incomplete paired evidence')
 raw=Path(receipt['raw']['path']).read_bytes()
 if len(raw)!=receipt['raw']['bytes'] or sha(raw)!=receipt['raw']['sha256']:raise RuntimeError('Raw log receipt mismatch')
 receipts[engine]=receipt
if receipts['node']['sourceInputsSha256']!=receipts['bun']['sourceInputsSha256']:raise RuntimeError('Different paired source inputs')
patch=Path('/tmp/router-759-progress-8e7c1b-complete-source.patch')
if patch.exists():raise RuntimeError('Preserve prior source patch instead of overwriting')
patch.write_bytes(git('diff','--binary',BASE,HEAD,'--'))
member(patch);member(Path(__file__))
if len({name for name,_,_ in members})!=len(members):raise RuntimeError('Duplicate archive member')
DEST.mkdir(parents=True,exist_ok=True)
archive=DEST/'complete-focused.tar.xz'
if archive.exists() or (DEST/'receipt.json').exists():raise RuntimeError('Evidence destination already exists')
with lzma.open(archive,'xb',preset=6) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for name,_,raw in members:
   info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
rows=[{'member':name,'originalPath':str(path),'bytes':len(raw),'sha256':sha(raw)} for name,path,raw in members]
errors=[]
with tarfile.open(archive,'r:xz') as tar:
 names=tar.getnames()
 if names!=[row['member'] for row in rows]:errors.append('member sequence')
 for row in rows:
  raw=tar.extractfile(row['member']).read()
  if len(raw)!=row['bytes'] or sha(raw)!=row['sha256'] or raw!=Path(row['originalPath']).read_bytes():errors.append(row['member'])
if errors:raise RuntimeError('Archive is not lossless: '+repr(errors))
archiveRaw=archive.read_bytes()
receipt={
 'schema':'router-759-translation-progress-215-complete-evidence-v1',
 'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceHead':HEAD,'sourceBaseline':BASE,
 'archive':{'path':archive.relative_to(ROOT).as_posix(),'bytes':len(archiveRaw),'sha256':sha(archiveRaw),'members':len(rows),'uncompressedMemberBytes':sum(row['bytes'] for row in rows)},
 'members':rows,'reopenedAgainstEveryOriginalErrors':errors,
 'pairedInputsCount':1783,'pairedInputsSha256':receipts['node']['sourceInputsSha256'],
 'testFiles':29,'casesPerEngine':215,
 'engines':{engine:{key:r[key] for key in ['engineVersion','elapsedSeconds','exitCode','timedOut','counts','sourceInputsUnchanged','passed','resource','cancellationObservation']}for engine,r in receipts.items()},
 'sourceOnlyDrafts':{'versions':[1,2,3,4,5],'status':'UNRUN source draft history preserved; only final own source HEAD above is exercised'},
 'newControls':4,'newControlCoverage':['bounded frozen scalar event descriptors with zero hostile callbacks','full project meta/JavaScript/strict TypeScript byte equality and actual execution','complete fixture plans byte equality and identical actual TranslationError callback failure without writes','actual canonical and all three profile fixture CLIs with monotonic stderr, identical stdout/artifact bytes, genuine original cfg identities and check freshness'],
 'repositoryCorpusProducersRun':0,'fixtureProducerObservation':receipts['node']['fixtureProducerObservation'],
 'futureCargo413Included':False,'fullGateRuns':0,'rustBuilds':0,'runtimeParity':False,'productionPerformanceGainMeasured':False,
 'limits':['Focused paired regression verification is not complete Router parity or the seven-stage gate.','Progress opt-in does not change outputs for the same compiler; introducing the helper changes the compiler fingerprint itself.','CPU/RSS retain the exact OS accounting scope in engine receipts; no aggregate process-tree peak or disk-cause inference.','Bun has no independent cancellation counter.'],
 'originalTemporaryFilesRetained':True,
}
(DEST/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(DEST/'README.md').write_text('# Optional translation progress: paired focused verification\n\nAt source `'+HEAD+'`, Node passed all 215 cases across 29 files in 83.074 seconds; Bun passed the same 215 in 59.833 seconds. All 1,783 frozen source inputs remained identical. Four added controls verify bounded scalar descriptors, exact project and plan output equality, propagated callback failure without partial writes, and actual temporary canonical plus all three profile CLI write/check cycles with original cfg identities and monotonic stderr.\n\n`complete-focused.tar.xz` preserves every original source-only draft v1–v5, setup and hydration receipt, complete binary source patch, exact runner and plan, frozen input inventory, both full raw logs, both complete runtime receipts and per-engine input manifests. `receipt.json` lists every original path, byte length and SHA256. Reopening the pack against every original produced zero differences. Temporary originals are retained until the gate owner independently checks committed Git bytes.\n\nThese are focused checks. No repository-wide canonical/profile regeneration, native/full gate, Rust build or measured production performance gain is claimed. Complete runtime parity remains unproved. Opting into progress preserves outputs for a fixed compiler; adding a new fingerprinted compiler helper necessarily changes the compiler fingerprint.\n')
fragment=ROOT/'.changes/issue-759-translation-progress-draft.md'
fragment.write_text('Add optional bounded scalar stage progress to Rust → meta → JavaScript/TypeScript bulk translation and all three profile CLIs. Diagnostics use stderr with monotonic elapsed observations and preserve generated bytes for the same compiler. Four added output-equivalence, descriptor, callback-failure and actual CLI controls pass within the frozen 215-case suite on Node and Bun. No full parity or measured production speedup is claimed.\n')
doc=ROOT/'docs/development/javascript-first.md'
doc.parent.mkdir(parents=True,exist_ok=True)
original=git('show',HEAD+':docs/development/javascript-first.md').decode()
anchor='Both gates also check the original-source native affinity descriptor'
at=original.index(anchor)
paragraph='Add `--progress` to canonical or `--profile-matrix` translation commands to write newline-delimited JSON diagnostics to stderr. Each bounded scalar record identifies the stage and monotonic elapsed milliseconds; source text and private proofs are omitted. Stdout and generated bytes are unchanged by the flag for the same compiler. The library APIs also accept an optional `progress(record)` callback. A callback error propagates before any regeneration-plan artifacts are written; it does not grant admission or change a refused item.\n\n'
doc.write_text(original[:at]+paragraph+original[at:])
print(json.dumps({'archiveBytes':len(archiveRaw),'archiveSha256':sha(archiveRaw),'members':len(rows),'originalBytes':sum(row['bytes'] for row in rows),'errors':len(errors),'receiptBytes':(DEST/'receipt.json').stat().st_size,'newCaseBytes':sum(p.stat().st_size for p in DEST.iterdir()if p.is_file())}))
