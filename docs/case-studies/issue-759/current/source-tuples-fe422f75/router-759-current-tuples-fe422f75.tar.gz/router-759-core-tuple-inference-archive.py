import argparse, gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--cwd',required=True)
parser.add_argument('--phases',nargs='+',required=True)
parser.add_argument('--final',required=True)
parser.add_argument('--output-prefix',required=True)
args=parser.parse_args()
root=Path(args.cwd)
if args.phases[-1]!=args.final or len(set(args.phases))!=len(args.phases):
    raise RuntimeError('Keep distinct complete phases, with the final phase last')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root):
    raise RuntimeError('Evidence requires the final clean source tree')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=[Path('/tmp/router-759-core-tuple-inference-focused.py'),Path(__file__)]
attempts=[]
for phase in args.phases:
    for engine in ['node','bun']:
        base=Path('/tmp/router-759-core-tuple-inference-'+phase+'-'+engine)
        path=base.with_suffix('.json');d=json.loads(path.read_text())
        if d['phase']!=phase or d['engine']!=engine or not d['sourceInputsUnchanged'] or not d['sourceHeadUnchanged'] or d['trackedStatusAfter']:
            raise RuntimeError('Attempt provenance does not describe a frozen source tree')
        raw=base.with_suffix('.log').read_bytes()
        inputs=base.with_suffix('.inputs.json').read_bytes()
        if len(raw)!=d['logBytes'] or sha(raw)!=d['logSha256'] or len(inputs)!=d['inputManifestBytes'] or sha(inputs)!=d['inputManifestSha256']:
            raise RuntimeError('Raw log or input manifest changed')
        if phase==args.final and (d['sourceHeadBefore']!=head or d['evidenceStatus']!='FOCUSED_PASS_NOT_FULL_GATE' or d['sourceTableCheckRuns']!=0 or d['sourceTableCheckExitCode'] is not None or d['counts']['fail']!=0 or d['counts']['skipped']!=0):
            raise RuntimeError('Final focused verification is incomplete')
        attempts.append(d);paths.extend([path,base.with_suffix('.log'),base.with_suffix('.inputs.json')])
final=[d for d in attempts if d['phase']==args.final]
if len(final)!=2 or final[0]['counts']['pass']!=final[1]['counts']['pass'] or final[0]['testFiles']!=final[1]['testFiles'] or final[0]['sourceInputSha256Before']!=final[1]['sourceInputSha256Before']:
    raise RuntimeError('Final engines did not verify the same source and complete test set')
contents={path.name:path.read_bytes() for path in paths}
if len(contents)!=len(paths):raise RuntimeError('Archive member collision')
records=[{'name':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in contents.items()]
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0,filename='') as gz:
    with tarfile.open(fileobj=gz,mode='w|') as tar:
        identical={};hardlinks=0
        for name,raw in contents.items():
            info=tarfile.TarInfo(name);info.mtime=0;info.mode=0o644
            digest=sha(raw);previous=identical.get((len(raw),digest))
            if previous is not None and contents[previous]==raw:
                info.type=tarfile.LNKTYPE;info.linkname=previous;info.size=0
                tar.addfile(info);hardlinks+=1
            else:
                info.size=len(raw);tar.addfile(info,io.BytesIO(raw));identical[(len(raw),digest)]=name
packed=buffer.getvalue()
if len(packed)>1_000_000:raise RuntimeError('Focused archive exceeds its compact evidence budget')
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
    if len(tar.getmembers())!=len(records):raise RuntimeError('Archive omitted a member')
    for record in records:
        raw=tar.extractfile(record['name']).read()
        if len(raw)!=record['bytes'] or sha(raw)!=record['sha256']:raise RuntimeError('Reopened evidence differs')
prefix=Path(args.output_prefix)
archive=Path(str(prefix)+'.tar.gz');receipt=Path(str(prefix)+'-receipt.json')
if archive.exists() or receipt.exists():raise RuntimeError('Preserve existing evidence; use a distinct output prefix')
archive.write_bytes(packed)
document={'schemaVersion':1,'kind':'complete-focused-tuple-unit-match-and-scalar-inference-source-evidence','status':'FOCUSED_PASS_NOT_FULL_GATE','testedSourceHead':head,'testFiles':final[0]['testFiles'],'finalCountsPerEngine':final[0]['counts'],'sourceInputSha256':final[0]['sourceInputSha256Before'],'attempts':attempts,'archive':{'path':archive.name,'bytes':len(packed),'sha256':sha(packed),'members':records,'reopenedMembers':len(records),'reopenErrors':0,'identicalContentHardlinks':hardlinks,'hardlinkExtractionVerified':True},'measurementLimitations':['Owned terminated-child max RSS includes git and version queries; it is neither aggregate process-tree peak nor physical footprint.','Focused execution supplies no canonical full-corpus gain or cross-language whole-runtime parity.'],'verificationLimits':{'canonicalProducerRuns':0,'profileProducerRuns':0,'fullGateRuns':0,'rustBuilds':0,'strictParityGapsCleared':0,'completeTranslation':False,'nativeParity':False}}
receipt.write_text(json.dumps(document,indent=2)+'\n')
print(json.dumps({'archiveBytes':len(packed),'archiveSha256':sha(packed),'members':len(records),'receiptBytes':receipt.stat().st_size,'receiptSha256':sha(receipt.read_bytes()),'testedHead':head,'attempts':[{'phase':d['phase'],'engine':d['engine'],'elapsedSeconds':d['elapsedSeconds'],'counts':d['counts']} for d in attempts]}))
