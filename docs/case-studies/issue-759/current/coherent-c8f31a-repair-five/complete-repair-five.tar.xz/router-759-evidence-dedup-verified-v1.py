from pathlib import Path
import json,subprocess,hashlib,os,time
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');plan=json.loads(Path('/tmp/router-759-evidence-dedup-dry-plan-v1.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip();assert head==plan['sourceHead'];listing=subprocess.check_output(['git','ls-files','-s','-z','--','docs/case-studies/issue-759','dev/log/issues/759'],cwd=root);blobs={}
for row in listing.split(b'\0'):
 if not row:continue
 metadata,path=row.split(b'\t',1);mode,oid,stage=metadata.decode().split();assert stage=='0';blobs[path.decode()]=oid
child=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);verified=[];start=time.monotonic()
for group in plan['groups']:
 paths=group['paths'];assert all(p.startswith(('docs/case-studies/issue-759/','dev/log/issues/759/')) for p in paths);ids={blobs[p] for p in paths};assert len(ids)==1;oid=next(iter(ids));child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().decode().strip().split();assert header[0]==oid and header[1]=='blob';raw=child.stdout.read(int(header[2]));assert child.stdout.read(1)==b'\n';assert hashlib.sha256(raw).hexdigest()==group['sha256']
 for p in paths:assert (root/p).read_bytes()==raw,p
 verified.append({'gitBlob':oid,'sha256':group['sha256'],'bytes':len(raw),'paths':paths,'completeOriginalBytesEqual':True})
child.stdin.close();assert child.wait(timeout=30)==0
replaced=0
for group in verified:
 source=root/group['paths'][0]
 for name in group['paths'][1:]:
  target=root/name;assert source.read_bytes()==target.read_bytes();temporary=target.with_name(target.name+'.router-759-link-tmp');assert not temporary.exists();os.link(source,temporary);os.replace(temporary,target);assert source.stat().st_ino==target.stat().st_ino;replaced+=1
seen=set();allocated=0
for directory in ['docs/case-studies/issue-759','dev/log/issues/759']:
 for p in (root/directory).rglob('*'):
  if not p.is_file():continue
  stat=p.stat();key=(stat.st_dev,stat.st_ino)
  if key not in seen:seen.add(key);allocated+=stat.st_blocks*512
result={'schema':'router-759-task-owned-lossless-duplicate-storage-verification-v1','sourceHead':head,'directGitCompleteOriginalByteComparisons':sum(len(g['paths']) for g in verified),'failures':0,'groups':verified,'replacedNamesWithIdenticalHardLinks':replaced,'allocatedBefore':plan['allocatedBefore'],'allocatedAfter':allocated,'reclaimedAllocatedBytes':plan['allocatedBefore']-allocated,'elapsedSeconds':time.monotonic()-start,'rustExecutions':0,'compilerInputsChanged':False,'namesAndCompleteBytesRetained':True,'gitContentChanged':False};p=Path('/tmp/router-759-evidence-dedup-verified-v1.json');assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='groups'}));assert allocated<500000000
