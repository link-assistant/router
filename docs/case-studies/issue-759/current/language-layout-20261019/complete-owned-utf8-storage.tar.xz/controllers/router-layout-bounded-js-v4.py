from pathlib import Path
import argparse,subprocess,os,signal,time,json,shutil,gzip,hashlib
p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--timeout',required=True,type=int);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.command[1:]if a.command[:1]==['--']else a.command
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');out=Path('/private/tmp')/('router-layout-check-'+a.label);out.mkdir();assert shutil.disk_usage(root).free>=3*1024**3
(out/'command.json').write_text(json.dumps({'command':cmd,'cwd':str(root),'seconds':a.timeout,'rssBytes':3*1024**3,'evidenceBytes':384*1024**2,'reserveBytes':2*1024**3,'rustExecuted':False})+'\n')
temporary=out/'temporary';temporary.mkdir()
def evidence_size(folder):
 total=0
 for path in folder.rglob('*'):
  try:
   if path.is_file():
    state=path.stat();total+=max(state.st_size,state.st_blocks*512)
  except FileNotFoundError:
   # A test removed its owned temporary entry before this fresh sample.
   continue
 return total
start=time.monotonic();peak=0;failure=None
with(out/'stdout.log').open('xb')as stdout,(out/'stderr.log').open('xb')as stderr:
 child=subprocess.Popen(cmd,cwd=root,stdout=stdout,stderr=stderr,start_new_session=True,env={**os.environ,'PATH':'/Users/konard/.nvm/versions/node/v20.19.4/bin:/Users/konard/.bun/bin:'+os.environ['PATH'],'TMPDIR':str(temporary),'TMP':str(temporary),'TEMP':str(temporary)})
 try:
  while child.poll()is None:
   elapsed=time.monotonic()-start
   if elapsed>a.timeout:failure='wall deadline';break
   r=subprocess.run(['ps','-axo','pid=,ppid=,rss='],capture_output=True,text=True,check=True,timeout=2);rows={int(v[0]):(int(v[1]),int(v[2])*1024)for l in r.stdout.splitlines()if len(v:=l.split())==3};selected={child.pid,os.getpid()}
   while(more:={pid for pid,(parent,rss)in rows.items()if parent in selected}-selected):selected|=more
   rss=sum(rows[pid][1]for pid in selected if pid in rows);peak=max(peak,rss);free=shutil.disk_usage(root).free;evidence=evidence_size(out)
   with(out/'resources.jsonl').open('a')as f:f.write(json.dumps({'seconds':elapsed,'rss':rss,'free':free,'evidence':evidence})+'\n')
   if rss>3*1024**3 or free<2*1024**3 or evidence>384*1024**2:failure='resource bound';break
   time.sleep(.25)
 except Exception as error:
  failure='controller failure: '+type(error).__name__+': '+str(error)
 if failure:
  # Only this controller's currently observed descendants can own groups.
  observed=subprocess.run(['ps','-axo','pid=,ppid=,pgid='],capture_output=True,text=True,check=True,timeout=2)
  processes={int(v[0]):(int(v[1]),int(v[2])) for line in observed.stdout.splitlines() if len(v:=line.split())==3}
  owned={child.pid}
  while (more:={pid for pid,(parent,group) in processes.items() if parent in owned}-owned):owned|=more
  groups={group for pid,(parent,group) in processes.items() if pid in owned and group!=os.getpgrp()}
  for group in groups:
   try:os.killpg(group,signal.SIGTERM)
   except ProcessLookupError:pass
  graceful_end=time.monotonic()+3
  while child.poll() is None and time.monotonic()<graceful_end:time.sleep(.05)
  for pid in owned:
   try:
    if os.getpgid(pid) in groups:os.kill(pid,signal.SIGKILL)
   except ProcessLookupError:pass
 child.wait()
r={'exit':child.returncode,'failure':failure,'seconds':time.monotonic()-start,'peakAggregateRss':peak,'status':'PASS command exit only'if child.returncode==0 and failure is None else'RED','wholeGate':False,'rustExecuted':False}
for name in ['stdout.log','stderr.log']:
 q=out/name;raw=q.read_bytes()
 with gzip.GzipFile(filename='',fileobj=(out/(name+'.gz')).open('xb'),mode='wb',mtime=0,compresslevel=1)as f:f.write(raw)
 assert gzip.decompress((out/(name+'.gz')).read_bytes())==raw;q.unlink()
 if child.returncode!=0:print(name,raw.decode(errors='replace')[-7000:])
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'output':str(out),**r}));raise SystemExit(0 if child.returncode==0 and failure is None else 1)
