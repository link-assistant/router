// Physical storage only. The complete logical metadata is reconstructed before
// its existing source/IR checks; a matching storage hash grants no authority.
import {createHash} from 'node:crypto';
import {posix} from 'node:path';
import {types} from 'node:util';
import {isCanonicalJsonText} from './canonical-json-text.mjs';
const schema='bounded-project-meta-storage-v1';
export const PROJECT_META_STORAGE_LIMITS=Object.freeze({fileBytes:64*1024*1024,totalBytes:512*1024*1024});
const components=Object.freeze([
  Object.freeze({field:'checkedSemanticProgram',target:'checkedProgramMeta'}),
  Object.freeze({field:'targetSemanticProgram',target:'targetProgramMeta'}),
  Object.freeze({field:'concreteSyntaxMeta',target:'concreteSyntaxMeta'}),
]);
const hash=text=>createHash('sha256').update(text).digest('hex');
const size=text=>Buffer.byteLength(text,'utf8');
const fail=message=>{throw new TypeError('Project metadata storage: '+message);};
const json=value=>JSON.stringify(value)+'\n';
function limits(input={}){
  if(!input||typeof input!=='object'||Object.keys(input).some(key=>!Object.hasOwn(PROJECT_META_STORAGE_LIMITS,key)))fail('unknown storage limit');
  const result={...PROJECT_META_STORAGE_LIMITS,...input};
  for(const key of Object.keys(result))if(!Number.isSafeInteger(result[key])||result[key]<1||result[key]>PROJECT_META_STORAGE_LIMITS[key])fail('limits may only be lowered');
  return result;
}
function path(name){
  if(typeof name!=='string'||!name||name.includes('\\')||/[\x00-\x1f]/u.test(name)||posix.isAbsolute(name)||name.split('/').some(part=>!part||part==='.'||part==='..'))fail('escaping or malformed component path');
  return name;
}
const componentPath=(meta,field)=>path(meta)+'.parts/'+field+'.json';
function text(input,bound){
  if(typeof input==='string'){budget(input,bound);return input;}
  if(Buffer.isBuffer(input)){if(input.length>bound)throw new RangeError('Project metadata storage file byte budget');return new TextDecoder('utf-8',{fatal:true}).decode(input);}
  fail('complete original JSON bytes required');
}
function keys(value,expected){return value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===expected.length&&Object.keys(value).every((key,index)=>key===expected[index]);}
function budget(value,bound){if(size(value)>bound)throw new RangeError('Project metadata storage file byte budget');}
// Locate complete top-level values without reparsing the oversized document.
// Each independently bounded component is validated below. Source strings are
// opaque: their braces and escaped quotes never become structural separators.
function topFields(source){
  const white=()=>{while(/\s/u.test(source[at]??'')&&at<source.length)at++;};
  const string=()=>{const begin=at++;while(at<source.length){const ch=source[at++];if(ch==='\\'){at++;continue;}if(ch==='"')return source.slice(begin,at);}fail('unterminated JSON string');};
  let at=0;white();if(source[at++]!=='{')fail('complete project JSON object required');white();const fields=[],seen=new Set();
  while(source[at]!=='}'){
    if(source[at]!=='"')fail('original JSON field required');const name=JSON.parse(string());if(seen.has(name))fail('duplicate original JSON field');seen.add(name);white();if(source[at++]!==':')fail('original JSON colon required');white();const begin=at;
    if(source[at]==='"')string();
    else if(source[at]==='{'||source[at]==='['){
      let depth=0;
      do{const ch=source[at];if(ch==='"'){string();continue;}if(ch==='{'||ch==='[')depth++;else if(ch==='}'||ch===']')depth--;at++;if(at>source.length)fail('unterminated original JSON');}while(depth);
    }else {while(at<source.length&&![',','}'].includes(source[at]))at++;}
    const raw=source.slice(begin,at).trimEnd();if(!raw)fail('empty original JSON value');fields.push({name,raw});white();if(source[at]===','){at++;white();}else if(source[at]!=='}')fail('original JSON separator required');
  }
  at++;white();if(at!==source.length)fail('trailing original JSON');return fields;
}
function canonicalValue(raw){if(!isCanonicalJsonText(raw))fail('noncanonical component JSON');}
// Compare every code unit without constructing another complete project wire.
// A large joined rope would need flattening beside the original metadata and
// live checked programs. Only bounded comparison slices are temporary here.
function sameFragments(source,fragments){
  let cursor=0;
  for(const fragment of fragments){
    if(cursor+fragment.length>source.length)return false;
    for(let at=0;at<fragment.length;at+=65536){
      const end=Math.min(fragment.length,at+65536);
      if(source.slice(cursor+at,cursor+end)!==fragment.slice(at,end))return false;
    }
    cursor+=fragment.length;
  }
  return cursor===source.length;
}
/** Accept the already serialized json(meta), preserving its Map/BigInt/undefined
 * and property-order semantics rather than visiting the original object twice. */
export function planProjectMetaStorage(metaPath,serialized,{storageLimits}={}){
  path(metaPath);const bound=limits(storageLimits);serialized=text(serialized,bound.totalBytes);const bytes=size(serialized);
  if(bytes>bound.totalBytes)throw new RangeError('Project metadata storage aggregate byte budget');
  if(bytes<=bound.fileBytes)return {text:serialized,components:[],targets:{}};
  const fields=topFields(serialized),selected=new Map(fields.filter(row=>components.some(component=>component.field===row.name)).map(row=>[row.name,row.raw]));
  const canonicalNames=fields.map(row=>JSON.stringify(row.name));
  const fragments=['{'];
  for(let at=0;at<fields.length;at++){if(at)fragments.push(',');fragments.push(canonicalNames[at],':',fields[at].raw);}
  fragments.push('}\n');
  if(!sameFragments(serialized,fragments))fail('complete canonical json(meta) required');
  if(!selected.has('checkedSemanticProgram')||!selected.has('targetSemanticProgram'))fail('both complete semantic programs required');
  const rows=components.filter(component=>selected.has(component.field)).map(component=>{
    const content=selected.get(component.field)+'\n';budget(content,bound.fileBytes);canonicalValue(selected.get(component.field));
    return {...component,path:componentPath(metaPath,component.field),bytes:size(content),sha256:hash(content),text:content};
  });
  const rootRaw='{'+fields.filter(row=>!selected.has(row.name)).map(row=>JSON.stringify(row.name)+':'+row.raw).join(',')+'}';
  canonicalValue(rootRaw);
  const logical={bytes,sha256:hash(serialized),keys:fields.map(row=>row.name)};
  // Preserve each actual value as complete JSON, without string-escaping or
  // normalizing its evidence. The root never duplicates the program values.
  const descriptors=rows.map(({field,path,bytes,sha256})=>({field,path,bytes,sha256}));
  const stored='{"schema":'+JSON.stringify(schema)+',"logical":'+JSON.stringify(logical)+',"root":'+rootRaw+',"components":'+JSON.stringify(descriptors)+'}\n';
  budget(stored,bound.fileBytes);if(size(stored)+rows.reduce((sum,row)=>sum+row.bytes,0)>bound.totalBytes)throw new RangeError('Project metadata storage aggregate byte budget');
  return {text:stored,components:rows,targets:Object.fromEntries(rows.map(row=>[row.target,row.path]))};
}

/** Explicit owned-data producer. Serialize complete top-level fields separately
 * so a live compiler need not also retain and flatten the whole project wire.
 * serialize is the producer's fixed canonical field JSON serializer, including
 * its Map/BigInt representation. This is not arbitrary replacer/observer
 * equivalence and grants no semantic, source or ownership authority. */
export function planProjectMetaObjectStorage(metaPath,meta,{storageLimits,serialize}={}){
  path(metaPath);const bound=limits(storageLimits);
  if(!meta||typeof meta!=='object'||types.isProxy(meta)||![null,Object.prototype].includes(Object.getPrototypeOf(meta))||'toJSON'in meta||typeof serialize!=='function')fail('owned ordinary metadata and fixed field serializer required');
  const names=Object.keys(meta);if(names.length>4096)fail('owned top-level field bound');
  const fields=[];let bytes=3;
  for(const name of names){
    const descriptor=Object.getOwnPropertyDescriptor(meta,name);if(!descriptor||!Object.hasOwn(descriptor,'value'))fail('own data metadata fields required');
    // Keep a nested value's original native toJSON key argument. The actual
    // producer's value-only Map/BigInt replacer ignores this ordinary wrapper.
    const wrapped=serialize({[name]:descriptor.value});if(typeof wrapped!=='string')fail('canonical complete field JSON required');
    if(wrapped==='{}\n')continue;
    const prefix='{'+JSON.stringify(name)+':';
    if(!wrapped.startsWith(prefix)||!wrapped.endsWith('}\n'))fail('exact complete field wrapper required');
    const raw=wrapped.slice(prefix.length,-2);if(size(raw)+1>bound.fileBytes)throw new RangeError('Project metadata storage file byte budget');canonicalValue(raw);
    const key=JSON.stringify(name);bytes+=size(key)+1+size(raw)+(fields.length?1:0);
    if(bytes>bound.totalBytes)throw new RangeError('Project metadata storage aggregate byte budget');
    // Retain one flat complete value, rather than each large keyed wrapper
    // alongside a later flattened component. JSON canonicalization above
    // excludes unescaped lone surrogates; compare every UTF16 unit anyway.
    const fieldBuffer=Buffer.from(wrapped,'utf8'),start=size(prefix);fieldBuffer[fieldBuffer.length-2]=10;
    const text=fieldBuffer.subarray(start,fieldBuffer.length-1).toString('utf8'),ownedRaw=text.slice(0,-1);
    if(ownedRaw!==raw)fail('complete field UTF16/UTF8 inverse differs');
    fields.push({name,key,raw:ownedRaw,text});
  }
  const selected=new Map(fields.filter(row=>components.some(component=>component.field===row.name)).map(row=>[row.name,row]));
  // Object.keys supplies native integer-key order. Check the actual complete
  // key projection independently without joining the potentially huge values.
  canonicalValue('{'+fields.map(row=>row.key+':null').join(',')+'}');
  const digest=createHash('sha256');digest.update('{');
  for(let at=0;at<fields.length;at++){if(at)digest.update(',');digest.update(fields[at].key).update(':').update(fields[at].raw);}
  digest.update('}\n');const sha256=digest.digest('hex');
  if(bytes<=bound.fileBytes){
    const inline='{'+fields.map(row=>row.key+':'+row.raw).join(',')+'}\n';
    if(size(inline)!==bytes||hash(inline)!==sha256)fail('complete inline field inverse differs');
    return {text:inline,components:[],targets:{}};
  }
  if(!selected.has('checkedSemanticProgram')||!selected.has('targetSemanticProgram'))fail('both complete semantic programs required');
  const rows=components.filter(component=>selected.has(component.field)).map(component=>{
    const text=selected.get(component.field).text;return {...component,path:componentPath(metaPath,component.field),bytes:size(text),sha256:hash(text),text};
  });
  const rootRaw='{'+fields.filter(row=>!selected.has(row.name)).map(row=>row.key+':'+row.raw).join(',')+'}';
  budget(rootRaw,bound.fileBytes);canonicalValue(rootRaw);
  const logical={bytes,sha256,keys:fields.map(row=>row.name)},descriptors=rows.map(({field,path,bytes,sha256})=>({field,path,bytes,sha256}));
  const stored='{"schema":'+JSON.stringify(schema)+',"logical":'+JSON.stringify(logical)+',"root":'+rootRaw+',"components":'+JSON.stringify(descriptors)+'}\n';
  budget(stored,bound.fileBytes);if(size(stored)+rows.reduce((sum,row)=>sum+row.bytes,0)>bound.totalBytes)throw new RangeError('Project metadata storage aggregate byte budget');
  return {text:stored,components:rows,targets:Object.fromEntries(rows.map(row=>[row.target,row.path]))};
}
/** read must use the caller's existing bounded, source-rooted input reader.
 * targets is the exact current/baseline inventory row, never another graph. */
export function loadProjectMetaStorage(serialized,{metaPath,targets,read,storageLimits}={}){
  path(metaPath);const bound=limits(storageLimits);serialized=text(serialized,bound.fileBytes);
  if(size(serialized)>bound.totalBytes)throw new RangeError('Project metadata storage aggregate byte budget');
  const document=JSON.parse(serialized),listed=components.filter(component=>Object.hasOwn(targets??{},component.target));
  if(document?.schema!==schema){if(listed.length)fail('unexpected inventory components for inline metadata');return {meta:document,text:serialized,components:[]};}
  // The two semantic programs remain mandatory. The complete concrete source
  // array is an optional third component; legacy two-component wrappers keep
  // their exact format and are read without inventing a concrete document.
  const targetKeys=['meta','javascript','typescript',...listed.map(component=>component.target)];
  if(!keys(document,['schema','logical','root','components'])||!keys(document.logical,['bytes','sha256','keys'])||!Array.isArray(document.components)||document.components.length!==listed.length||listed.length<2||!listed.some(component=>component.field==='checkedSemanticProgram')||!listed.some(component=>component.field==='targetSemanticProgram')||targets.meta!==metaPath||Object.keys(targets).length!==targetKeys.length||!targetKeys.every(key=>typeof targets[key]==='string')||typeof read!=='function')fail('complete wrapper and inventory components required');
  // Reject a foreign inventory path before requesting any component bytes.
  // Per-component byte/aggregate checks retain their existing read order.
  if(!listed.every(component=>targets[component.target]===componentPath(metaPath,component.field)))fail('changed or escaping inventory component descriptor');
  const logical=document.logical;
  if(!Number.isSafeInteger(logical.bytes)||logical.bytes<1||logical.bytes>bound.totalBytes||!/^[a-f0-9]{64}$/u.test(logical.sha256)||!Array.isArray(logical.keys)||logical.keys.some(key=>typeof key!=='string')||new Set(logical.keys).size!==logical.keys.length||!document.root||typeof document.root!=='object'||Array.isArray(document.root))fail('invalid original logical metadata record');
  if(json(document)!==serialized)fail('noncanonical storage wrapper');
  const values=new Map(),loaded=[];let total=size(serialized);
  for(let index=0;index<listed.length;index++){
    const expected=listed[index],row=document.components[index],name=componentPath(metaPath,expected.field);
    if(!keys(row,['field','path','bytes','sha256'])||row.field!==expected.field||row.path!==name||targets[expected.target]!==name||!Number.isSafeInteger(row.bytes)||row.bytes<1||row.bytes>bound.fileBytes||!/^[a-f0-9]{64}$/u.test(row.sha256)||Object.hasOwn(document.root,row.field))fail('changed, escaping or incomplete component descriptor');
    total+=row.bytes;if(total>bound.totalBytes)throw new RangeError('Project metadata storage aggregate byte budget');
    const content=text(read(name),bound.fileBytes);
    if(size(content)!==row.bytes||hash(content)!==row.sha256)fail('complete component bytes/hash changed');
    const value=JSON.parse(content);if(json(value)!==content)fail('noncanonical complete component');values.set(row.field,value);loaded.push({...row});
  }
  const actualKeys=[...Object.keys(document.root),...values.keys()];if(actualKeys.length!==logical.keys.length||logical.keys.some(key=>!Object.hasOwn(document.root,key)&&!values.has(key)))fail('missing, extra or repeated logical field');
  const meta=Object.fromEntries(logical.keys.map(key=>[key,values.has(key)?values.get(key):document.root[key]])),complete=json(meta);
  if(size(complete)!==logical.bytes||hash(complete)!==logical.sha256)fail('original logical metadata bytes/hash changed');
  return {meta,text:complete,components:loaded};
}
