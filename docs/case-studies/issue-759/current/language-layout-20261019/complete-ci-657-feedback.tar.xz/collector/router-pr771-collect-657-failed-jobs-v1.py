import subprocess,pathlib,json,gzip,hashlib,concurrent.futures,re
R=pathlib.Path('/private/tmp/router-pr771-ci-feedback-657169fb-v1');R.mkdir(exist_ok=True)
D=json.loads(pathlib.Path('/private/tmp/router-pr771-ci-657169fb-status-v1/checks.json').read_text());rows=[x for x in D['statusCheckRollup']if x.get('conclusion')=='FAILURE'];previous={x['job']:x for x in json.loads((R/'index.json').read_text())['jobs']}if(R/'index.json').exists()else{}
def read(row):
 job=row['detailsUrl'].split('/')[-1];target=R/(job+'.log.gz')
 if target.exists():return previous[job]
 raw=R/(job+'.log');err=R/(job+'.stderr')
 with raw.open('xb')as out,err.open('xb')as e:r=subprocess.run(['gh','api','repos/link-assistant/router/actions/jobs/'+job+'/logs'],stdout=out,stderr=e,timeout=40)
 if raw.stat().st_size>64*1024*1024:raise RuntimeError('Job log evidence bound exceeded')
 h=hashlib.sha256();n=0;hints=[]
 with raw.open('rb')as inp,gzip.open(target,'xb',compresslevel=1)as packed:
  for chunk in iter(lambda:inp.read(65536),b''):h.update(chunk);n+=len(chunk);packed.write(chunk)
 with gzip.open(target,'rb')as f:
  for line in f:
   text=line.decode(errors='replace')
   if re.search(r'Error:|not ok |error TS|stale|FAIL|AssertionError',text)and len(hints)<12:hints.append(text[:350].strip())
 if hashlib.sha256(gzip.decompress(target.read_bytes())).hexdigest()!=h.hexdigest():raise RuntimeError('Complete log readback differs')
 raw.unlink();return {'job':job,'name':row['name'],'exit':r.returncode,'bytes':n,'sha256':h.hexdigest(),'hints':hints,'stderr':err.read_text()[:300]}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(read,rows))
(R/'index.json').write_text(json.dumps({'head':D['headRefOid'],'jobs':results,'fullCycleFinished':False},indent=2));print(json.dumps({'packet':str(R),'jobs':[{'job':x['job'],'name':x['name'],'bytes':x['bytes'],'hints':x['hints'][:5]}for x in results]}))
