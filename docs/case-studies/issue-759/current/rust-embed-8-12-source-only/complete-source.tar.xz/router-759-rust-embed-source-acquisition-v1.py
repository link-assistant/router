from pathlib import Path
import urllib.request,hashlib,json,re,tarfile,time
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');lock=(root/'Cargo.lock').read_bytes();blocks=lock.decode().split('[[package]]');receipts=[]
for name in ['rust-embed','rust-embed-impl','rust-embed-utils']:
 block=next(b for b in blocks if re.search(r'^name = "'+name+r'"$',b,re.M));version=re.search(r'^version = "([^"]+)"$',block,re.M).group(1);expected=re.search(r'^checksum = "([a-f0-9]+)"$',block,re.M).group(1);assert version=='8.12.0';url=f'https://static.crates.io/crates/{name}/{name}-{version}.crate';path=Path('/tmp/router-759-'+name+'-'+version+'-original-v1.crate');assert not path.exists();started=time.monotonic();request=urllib.request.Request(url,headers={'User-Agent':'router-issue-759-source-research'})
 with urllib.request.urlopen(request,timeout=30) as response:
  raw=response.read(2*1024**2+1);assert len(raw)<=2*1024**2;status=response.status
 assert hashlib.sha256(raw).hexdigest()==expected;path.write_bytes(raw);files=[];total=0
 with tarfile.open(path,'r:gz') as archive:
  for item in archive.getmembers():
   assert not item.issym() and not item.islnk() and item.name.startswith(name+'-'+version+'/') and '..' not in Path(item.name).parts
   if not item.isfile():continue
   total+=item.size;assert item.size<=4*1024**2 and total<=16*1024**2;data=archive.extractfile(item).read();assert len(data)==item.size;files.append({'path':item.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 row={'crate':name,'version':version,'url':url,'httpStatus':status,'archivePath':str(path),'archiveBytes':len(raw),'archiveSha256':expected,'cargoLockSha256':hashlib.sha256(lock).hexdigest(),'allCargoChecksumBytesVerified':True,'decodedBytes':total,'files':files,'elapsedSeconds':time.monotonic()-started,'sourceOnly':True,'rustExecutions':0,'namespaceAuthority':False};receipts.append(row);print(json.dumps({k:row[k] for k in ['crate','archiveBytes','decodedBytes','elapsedSeconds']}),flush=True)
p=Path('/tmp/router-759-rust-embed-source-acquisition-v1.json');assert not p.exists();p.write_text(json.dumps({'crates':receipts,'sourceOnly':True,'namespaceAuthority':False,'compilerOrRepositoryChanges':0,'harnessSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
