import gzip, hashlib, json, lzma, pathlib, subprocess, time

root = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
ci = root / 'docs/case-studies/issue-759/raw/ci'
head = '50b3cb43b790a57be255a54b6c7d4cf8a43f75c7'
base = pathlib.Path('/tmp/router-759-mid-sized-log-compaction-v5')
assert not base.exists()
base.mkdir()
started = time.monotonic()
digest = lambda data: hashlib.sha256(data).hexdigest()
def git_original(path):
    data = path.read_bytes()
    original = subprocess.check_output(['git','show',head+':'+path.relative_to(root).as_posix()],cwd=root,timeout=30)
    assert original == data
    return data

markdown_paths = subprocess.check_output(['git','ls-files','-z','--','*.md'],cwd=root,timeout=30).decode().split('\0')
markdown = []
for path in markdown_paths:
    if path and (root / path).is_file():
        markdown.append((root / path).read_text())
references = {}
manifests = {}
for path in ci.rglob('*manifest.json*'):
    if path.name not in ['expanded-log-manifest.json','expanded-log-manifest.json.gz','text-manifest.json','text-manifest.json.gz','direct-job-log-manifest.json','direct-job-log-manifest.json.gz']:
        continue
    if path.suffix == '.gz' and path.with_suffix('').exists():
        continue
    encoded = path.read_bytes()
    decoded = gzip.decompress(encoded) if path.suffix == '.gz' else encoded
    rows = json.loads(decoded)
    assert isinstance(rows,list)
    for row in rows:
        stored = ci / row['path']
        if stored.suffix == '.gz' and stored.is_file():
            size = stored.stat().st_size
            new = stored.with_suffix('.xz')
            if 4096 < size <= 512000 and not new.exists() and not any(row['path'] in text for text in markdown):
                references.setdefault(stored, []).append((path,row))
    manifests[path] = {'encoded':encoded,'decoded':decoded,'rows':rows}

selected = sorted(references, key=lambda path: (-path.stat().st_size,path.as_posix()))[:2048]
print(json.dumps({'eligibleReferencedLogs':len(references),'selectedCandidates':len(selected)}),flush=True)
assert len(selected)>0
records = []
changed_manifests = set()
for number,path in enumerate(selected):
    assert time.monotonic()-started < 600
    assert not path.is_symlink()
    encoded = git_original(path)
    decoded = gzip.decompress(encoded)
    assert len(decoded) <= 4*1024*1024
    packed = lzma.compress(decoded,preset=6)
    assert lzma.decompress(packed) == decoded
    allocated = path.stat().st_blocks*512
    projected = ((len(packed)+4095)//4096)*4096
    if projected >= allocated:
        continue
    new = path.with_suffix('.xz')
    candidate = base / (str(number)+'.xz')
    candidate.write_bytes(packed)
    record = {'originalPath':path.relative_to(root).as_posix(),'storedPath':new.relative_to(root).as_posix(),
              'originalGzipBytes':len(encoded),'originalGzipSha256':digest(encoded),'originalAllocatedBytes':allocated,
              'decodedBytes':len(decoded),'decodedSha256':digest(decoded),'xzBytes':len(packed),
              'xzSha256':digest(packed),'projectedAllocatedBytes':projected,'candidatePath':str(candidate),
              'manifestPaths':[manifest.relative_to(root).as_posix() for manifest,_ in references[path]]}
    records.append(record)
    for manifest,row in references[path]:
        assert row['sha256'] == digest(encoded)
        row.update({'original_gzip_sha256':digest(encoded),'path':new.relative_to(ci).as_posix(),
                    'sha256':digest(packed),'bytes':len(packed),'compression':'xz','decoded_sha256':digest(decoded)})
        changed_manifests.add(manifest)

manifest_changes = []
for number,path in enumerate(sorted(changed_manifests)):
    state = manifests[path]
    assert git_original(path) == state['encoded']
    proposed_decoded = (json.dumps(state['rows'],indent=2)+'\n').encode()
    proposed = gzip.compress(proposed_decoded,compresslevel=9,mtime=0) if path.suffix=='.gz' else proposed_decoded
    previous = base / ('manifest-'+str(number)+'-original.bin')
    candidate = base / ('manifest-'+str(number)+'-candidate.bin')
    previous.write_bytes(state['encoded']);candidate.write_bytes(proposed)
    manifest_changes.append({'path':path.relative_to(root).as_posix(),'originalBytes':len(state['encoded']),
                             'originalSha256':digest(state['encoded']),'originalDecodedSha256':digest(state['decoded']),
                             'candidateBytes':len(proposed),'candidateSha256':digest(proposed),
                             'candidateDecodedSha256':digest(proposed_decoded),'originalPath':str(previous),
                             'candidatePath':str(candidate)})

plan = {'schema':'verified-mid-sized-complete-log-compaction-plan-v1','capturedHead':head,
        'selectedCandidates':len(selected),'acceptedLogs':len(records),'logs':records,'manifests':manifest_changes,
        'allDecodedLogBytesEqual':True,'allChangedOriginalsMatchCommittedGit':True,
        'projectedPayloadAllocatedReclaim':sum(row['originalAllocatedBytes']-row['projectedAllocatedBytes'] for row in records),
        'elapsedSeconds':time.monotonic()-started,'sourceMutations':[],'rustExecuted':False,
        'actualWholeCaseReclaimProved':False}
(base / 'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({key:value for key,value in plan.items() if key not in ['logs','manifests']}))
