from pathlib import Path
import gzip,hashlib,json,subprocess,time
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head='9a17018d03504d648a746a758c37f32dfa4f50e4';sha=lambda b:hashlib.sha256(b).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
assert subprocess.check_output(['git','status','--porcelain'],cwd=root).decode().strip()==''
def allocated():
 seen=set();total=0
 for base in [root/'docs/case-studies/issue-759',root/'dev/log/issues/759']:
  for p in base.rglob('*'):
   if not p.is_file() or p.is_symlink():continue
   s=p.stat();identity=(s.st_dev,s.st_ino)
   if identity not in seen:seen.add(identity);total+=s.st_blocks*512
 return total
before=allocated();rows=[];tmp=Path('/tmp/router-759-migration-metadata-gzip-v1');tmp.mkdir(exist_ok=False)
for number in range(1,5):
 name='lossless-mid-sized-log-archives'+('' if number==1 else '-'+str(number))+'.json';p=root/'docs/case-studies/issue-759/raw'/name;b=p.read_bytes();assert subprocess.check_output(['git','show',head+':'+p.relative_to(root).as_posix()],cwd=root)==b
 candidate=gzip.compress(b,compresslevel=9,mtime=0);assert gzip.decompress(candidate)==b and json.loads(gzip.decompress(candidate))==json.loads(b);q=p.with_name(p.name+'.gz');assert not q.exists();(tmp/name).write_bytes(b);q.write_bytes(candidate);assert gzip.decompress(q.read_bytes())==b;p.unlink();rows.append({'originalPath':p.relative_to(root).as_posix(),'storedPath':q.relative_to(root).as_posix(),'originalBytes':len(b),'originalSha256':sha(b),'storedBytes':len(candidate),'storedSha256':sha(candidate),'originalGitHead':head,'completeOriginalBytesEqual':True})
after=allocated();assert after<before and after<=500000000
report={'schema':'complete-migration-metadata-lossless-gzip-v1','originalGitHead':head,'files':rows,'allocatedBefore':before,'allocatedAfter':after,'allocatedReclaimed':before-after,'allDecodedOriginalBytesEqual':True,'allOriginalContainersRetainedInGit':True,'rustExecuted':False,'fullGatePass':False};(tmp/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
