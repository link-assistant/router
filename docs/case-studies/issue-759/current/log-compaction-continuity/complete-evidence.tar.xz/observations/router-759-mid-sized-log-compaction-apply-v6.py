import copy, gzip, hashlib, json, os, pathlib, subprocess, time

root = pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
base = pathlib.Path('/tmp/router-759-mid-sized-log-compaction-v6')
plan_bytes = (base / 'plan.json').read_bytes()
plan = json.loads(plan_bytes)
output = base / 'applied.json'
assert not output.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,timeout=30).decode().strip()
assert git('status','--porcelain') == ''
head = git('rev-parse','HEAD')
assert head == '50b3cb43b790a57be255a54b6c7d4cf8a43f75c7'
def allocated():
    seen = set()
    total = 0
    for path in ['docs/case-studies/issue-759','dev/log/issues/759']:
        for file in (root/path).rglob('*'):
            if file.is_file() and not file.is_symlink():
                stat=file.stat();identity=(stat.st_dev,stat.st_ino)
                if identity not in seen:
                    seen.add(identity);total+=stat.st_blocks*512
    return total

started=time.monotonic()
before=allocated()
assert before <= 500000000
mapping={}
for row in plan['logs']:
    old=root/row['originalPath'];new=root/row['storedPath'];candidate=pathlib.Path(row['candidatePath'])
    assert old.is_file() and not old.is_symlink() and not new.exists()
    original=old.read_bytes();packed=candidate.read_bytes()
    assert len(original)==row['originalGzipBytes'] and sha(original)==row['originalGzipSha256']
    assert len(packed)==row['xzBytes'] and sha(packed)==row['xzSha256']
    import lzma
    decoded=gzip.decompress(original)
    assert lzma.decompress(packed)==decoded and sha(decoded)==row['decodedSha256']
    mapping[row['originalPath'].removeprefix('docs/case-studies/issue-759/raw/ci/')]=row
for row in plan['manifests']:
    old=root/row['path'];candidate=pathlib.Path(row['candidatePath'])
    assert sha(old.read_bytes())==row['originalSha256'] and sha(candidate.read_bytes())==row['candidateSha256']
    original=json.loads(gzip.decompress(old.read_bytes()) if old.suffix=='.gz' else old.read_bytes())
    proposed=json.loads(gzip.decompress(candidate.read_bytes()) if old.suffix=='.gz' else candidate.read_bytes())
    expected=copy.deepcopy(original)
    for entry in expected:
        replacement=mapping.get(entry.get('path'))
        if replacement:
            assert entry['sha256']==replacement['originalGzipSha256']
            if entry.get('decoded_sha256'):
                assert entry['decoded_sha256']==replacement['decodedSha256']
            entry.update({'original_gzip_sha256':replacement['originalGzipSha256'],
                          'path':replacement['storedPath'].removeprefix('docs/case-studies/issue-759/raw/ci/'),
                          'sha256':replacement['xzSha256'],'bytes':replacement['xzBytes'],
                          'compression':'xz','decoded_sha256':replacement['decodedSha256']})
    assert expected==proposed

materialized={}
for row in plan['logs']:
    old=root/row['originalPath'];new=root/row['storedPath']
    existing=materialized.get(row['xzSha256'])
    if existing is None:
        with new.open('xb') as stream:
            stream.write(pathlib.Path(row['candidatePath']).read_bytes())
        materialized[row['xzSha256']]=new
    else:
        assert sha(existing.read_bytes())==row['xzSha256']
        os.link(existing,new)
    assert sha(new.read_bytes())==row['xzSha256']
    # Complete originals were pinned against Git before any mutation. Replace
    # one verified container at a time to avoid staging all new disk allocation.
    assert sha(old.read_bytes())==row['originalGzipSha256']
    old.unlink()
for row in plan['manifests']:
    old=root/row['path'];temporary=old.with_name(old.name+'.mid-log-compaction.tmp')
    assert not temporary.exists()
    temporary.write_bytes(pathlib.Path(row['candidatePath']).read_bytes())
    os.replace(temporary,old)

provenance_path=root/'docs/case-studies/issue-759/raw/lossless-mid-sized-log-archives-4.json'
assert not provenance_path.exists()
record={'schema':'complete-mid-sized-log-storage-migration-v1','originalContainerGitHead':plan['capturedHead'],
        'appliedHead':head,'planSha256':sha(plan_bytes),
        'logs':[{key:value for key,value in row.items() if key!='candidatePath'} for row in plan['logs']],
        'manifests':[{key:value for key,value in row.items() if key not in ['originalPath','candidatePath']} for row in plan['manifests']],
        'allDecodedOriginalLogBytesVerified':True,'allOriginalContainersMatchCommittedGit':True,
        'allOtherManifestFieldsUnchanged':True,'originalCompressedContainersRetainedInNamedGitHead':True,
        'identicalNewContainerBodiesStoredAsVerifiedHardlinks':len(plan['logs'])-len(materialized),
        'rustExecuted':False,'semanticAuthority':False,'fullGateAuthority':False}
provenance_path.write_text(json.dumps(record,separators=(',',':'))+'\n')
after=allocated()
assert after<=500000000 and after<before
receipt={'schema':'complete-mid-sized-log-storage-migration-applied-v1','sourceHead':head,
         'capturedOriginalHead':plan['capturedHead'],'logs':len(plan['logs']),'changedManifests':len(plan['manifests']),
         'allocatedBytesBefore':before,'allocatedBytesAfter':after,'actualAllocatedBytesReclaimed':before-after,
         'remainingBytes':500000000-after,'provenancePath':provenance_path.relative_to(root).as_posix(),
         'provenanceBytes':provenance_path.stat().st_size,'provenanceSha256':sha(provenance_path.read_bytes()),
         'elapsedSeconds':time.monotonic()-started,'headUnchanged':git('rev-parse','HEAD')==head,
         'rustExecuted':False,'semanticAuthority':False,'fullGateAuthority':False}
assert receipt['headUnchanged']
output.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
