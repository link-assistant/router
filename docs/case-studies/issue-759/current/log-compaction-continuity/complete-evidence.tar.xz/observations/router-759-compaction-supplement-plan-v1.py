from pathlib import Path
import json,hashlib,subprocess
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');tmp=Path('/tmp');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip();assert head=='9a17018d03504d648a746a758c37f32dfa4f50e4';files={}
prefixes=['router-759-mid-sized-log-compaction-plan-v4','router-759-mid-sized-log-compaction-plan-v5','router-759-mid-sized-log-compaction-plan-v6','router-759-mid-sized-log-compaction-apply-v6','router-759-mid-sized-log-compaction-continuity-v6','router-759-mid-sized-log-compaction-continuity-v7','router-759-mid-log-compaction-before-ci-measurements-v6','router-759-mid-log-compaction-after-ci-measurements-v6','router-759-mid-log-compaction-before-ci-complete-report-v6','router-759-mid-log-compaction-after-ci-complete-report-v6','router-759-mid-log-compaction-complete-ci-integrity-v6','router-759-readonly-ci-integrity-v6','router-759-current-688-packet-capture-producer-v2','router-759-install-canonical-recovery-packet-v1','router-759-migration-metadata-gzip-v1','router-759-compaction-supplement-plan-v1']
for f in tmp.iterdir():
 if any(f.name.startswith(prefix) for prefix in prefixes) and f.is_file():files['observations/'+f.name]=f
for name in ['router-759-mid-sized-log-compaction-v6','router-759-migration-metadata-gzip-v1']:
 for f in (tmp/name).iterdir():
  if f.is_file() and not f.name.endswith('.xz'):files['observations/'+name+'/'+f.name]=f
# Every compressed candidate already exists byte-for-byte in the immutable
# compaction commit; preserve complete pins instead of storing duplicate bodies.
plan=json.loads((tmp/'router-759-mid-sized-log-compaction-v6/plan.json').read_text());witnesses=[]
for r in plan['logs']:
 f=Path(r['candidatePath']);b=f.read_bytes();assert len(b)==r['xzBytes'] and hashlib.sha256(b).hexdigest()==r['xzSha256'];assert subprocess.check_output(['git','show',head+':'+r['storedPath']],cwd=root)==b;witnesses.append({'originalPath':str(f),'bytes':len(b),'sha256':r['xzSha256'],'gitCommit':head,'gitPath':r['storedPath'],'completeOriginalBytesCompared':True})
f=tmp/'router-759-compaction-supplement-immutable-blob-witnesses-v1.json';assert not f.exists();f.write_text(json.dumps({'sourceHead':head,'allCandidatesRetainedAsCompleteGitBlobs':witnesses,'rustExecuted':False,'fullGatePass':False},separators=(',',':'))+'\n');files['provenance/'+f.name]=f
rows=[]
for name,f in sorted(files.items()):
 b=f.read_bytes();rows.append({'path':name,'originalPath':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
f=tmp/'router-759-compaction-supplement-v1.manifest.json';assert not f.exists();f.write_text(json.dumps({'members':rows},separators=(',',':'))+'\n');print(json.dumps({'sourceHead':head,'members':len(rows),'originalBytes':sum(r['bytes'] for r in rows),'immutableLogCandidates':len(witnesses),'manifest':str(f)}))
