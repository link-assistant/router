from pathlib import Path
import json,hashlib,subprocess,collections
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');head='5662d363cdbf2aca11378c60d3dfacca24720f57';prefix=Path('/tmp/router-759-cohort-v3-profile-write-'+head[:9]);receipt=json.loads(Path(str(prefix)+'.json').read_text());assert receipt['exitCode']==0 and not receipt['timedOut'] and receipt['sourceInputsUnchanged'] and receipt['headAfter']==head
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads(Path(str(prefix)+'-inputs.json').read_text())['inputs'];original={r['path']:r for r in inputs};matrix_paths=list((root/'profiles').glob('matrix-*.json'));assert len(matrix_paths)==1;matrix_path=matrix_paths[0];matrix=json.loads(matrix_path.read_text());assert len(matrix['profiles'])==3
roots=['tools/translation/meta','packages/javascript/generated/rust-draft','packages/typescript/generated/rust-draft','tools/translation/projects','packages/javascript/generated/rust-project','packages/typescript/generated/rust-project'];all_files=[];members=[];source_rows=[];fingerprints=[]
for member in matrix['profiles']:
 directory=member['directory'];inventory=json.loads((root/member['inventory']).read_text());old=json.loads(subprocess.check_output(['git','show',head+':'+member['inventory']],cwd=root,timeout=30));rows=[]
 for relative in roots:
  for path in (root/directory/relative).rglob('*'):
   if path.is_file():
    assert not path.is_symlink();b=path.read_bytes();rows.append({'path':str(path.relative_to(root)),'bytes':len(b),'sha256':sha(b)})
 path=root/member['inventory'];b=path.read_bytes();rows.append({'path':member['inventory'],'bytes':len(b),'sha256':sha(b)});rows.sort(key=lambda r:r['path']);assert len(rows)==member['outputFiles'] and sum(r['bytes'] for r in rows)==member['expectedBytes'];all_files+=rows
 observed=[]
 for source in inventory['sources']:
  expected=original[source['source']];assert source['sha256']==expected['sha256'] and source['bytes']==expected['bytes'];assert all((root/t).is_file() for t in source['targets'].values());observed.append(source['source'])
 assert len(observed)==804 and len(set(observed))==804
 for cargo in matrix['cargo']:
  expected=original[cargo['source']];assert cargo['sha256']==expected['sha256']
 for path,digest in inventory['implementationHashes'].items():
  assert sha((root/path).read_bytes())==digest,(member['name'],path);fingerprints.append({'profile':member['name'],'path':path,'sha256':digest})
 assert inventory['totals']==member['totals'];assert inventory['projects']==member['projects'];assert sha(json.dumps(inventory['implementationHashes'],separators=(',',':'),ensure_ascii=False).encode()+b'\n')==matrix['translatorImplementationSha256']
 members.append({'name':member['name'],'directory':directory,'profileSha256':member['profileSha256'],'outputFiles':len(rows),'expectedBytes':sum(r['bytes'] for r in rows),'freshTotals':inventory['totals'],'previousTotals':old['totals'],'change':{k:inventory['totals'][k]-old['totals'][k] for k in inventory['totals']},'projects':inventory['projects'],'sourceFiles':len(observed),'implementationHashes':len(inventory['implementationHashes']),'sourceProfiles':sum(p.startswith('tools/translation/source-profiles/') for p in inventory['implementationHashes']),'retainedRuntimeParity':inventory['runtimeParity']});source_rows.append({'profile':member['name'],'sources':observed})
assert sum(m['expectedBytes'] for m in members)==matrix['expectedBytes'];b=matrix_path.read_bytes();all_files.append({'path':str(matrix_path.relative_to(root)),'bytes':len(b),'sha256':sha(b)});changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=root,timeout=30).decode().split('\0');untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root,timeout=30).decode().split('\0');changes=sorted(set(p for p in changed+untracked if p));allowed={r['path'] for r in all_files};assert all(p in allowed for p in changes),'Unexpected changed path'
review={'schema':'router-759-complete-matrix-output-review-v1','producer':receipt,'matrixPath':str(matrix_path.relative_to(root)),'matrixSha256':matrix['matrixSha256'],'sourceSetSha256':matrix['sourceSetSha256'],'profiles':members,'fullOutputFiles':len(all_files),'fullOutputBytes':sum(r['bytes'] for r in all_files),'changedOutputFiles':len(changes),'changedOutputBytes':sum((root/p).stat().st_size for p in changes if (root/p).is_file()),'all804OriginalRustSourcesVerifiedPerProfile':True,'allCompilerFingerprintsVerifiedPerProfile':True,'unexpectedSourceChanges':0,'canonicalGeneratedChanges':0,'runtimeParity':False,'rustExecutions':0,'allGeneratedFiles':all_files,'allChangedPaths':changes,'allCompilerFingerprints':fingerprints,'sourceSelection':source_rows}
output=Path('/tmp/router-759-5662-matrix-complete-review-v1.json');assert not output.exists();output.write_text(json.dumps(review,separators=(',',':'))+'\n');print(json.dumps({k:v for k,v in review.items() if k not in ['producer','allGeneratedFiles','allChangedPaths','allCompilerFingerprints','sourceSelection']}))
