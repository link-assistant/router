import pathlib,subprocess,json,hashlib,time,resource
p=pathlib.Path("packages/javascript/node_modules/.issue-759-verification/opaque-reference-impl-complete-v1");rows=[]
files=["tools/translation/test/nested-implementation-obligations.test.mjs","tools/translation/test/clone-source-methods.test.mjs","tools/translation/test/clone-unit-methods.test.mjs","tools/translation/test/default-source-methods.test.mjs","tools/translation/test/default-unit-methods.test.mjs","tools/translation/test/default-container-source.test.mjs","tools/translation/test/original-default-helper-owners.test.mjs","tools/translation/test/clone-container-source.test.mjs"]
inputs=files+["tools/translation/nested-implementation-obligations.mjs","tools/translation/clone-record-no-drop.mjs","tools/translation/clone-source-ir.mjs","tools/translation/default-unit-source.mjs","tools/translation/default-source-ir.mjs","tools/translation/project-copy.mjs"]
def vector():return [{"path":n,"bytes":len((b:=pathlib.Path(n).read_bytes())),"sha256":hashlib.sha256(b).hexdigest()} for n in inputs]
before=vector();(p/"inputs.json").write_text(json.dumps(before,indent=2)+"\n")
for name in inputs:
 dst=p/"source-snapshots"/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(pathlib.Path(name).read_bytes())
for label,cmd in [("node",["node","--test","--test-concurrency=1",*files]),("bun",["bun","test",*files])]:
 start=time.monotonic()
 with (p/(label+".stdout.raw.log")).open("wb") as a,(p/(label+".stderr.raw.log")).open("wb") as b:
  try:code=subprocess.run(cmd,stdout=a,stderr=b,timeout=600).returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 row={"command":cmd,"wholeFiles":len(files),"exitCode":code,"timedOut":timed,"capSeconds":600,"elapsedSeconds":time.monotonic()-start,"maxWaitedChildRssBytes":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rssScope":"RUSAGE_CHILDREN lifetime high-water, not per-command reset/concurrent sum","inputsUnchanged":vector()==before};rows.append(row);print(json.dumps(row),flush=True)
(p/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
