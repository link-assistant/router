import fs from 'node:fs';
import {loadJsonMacroSourceProof,jsonMacroOriginalSource} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match/tools/translation/json-macro-inputs.mjs';
import {compileDeclarativeMacro,expandDeclarativeMacro,declarativeNestedMacroInvocations,declarativeNestedMacroInput} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match/tools/translation/declarative-token-macros.mjs';
import {originalMacroInvocation,originalMacroTreeText} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-const-match/tools/translation/macro-token-trees.mjs';
const deps=loadJsonMacroSourceProof({manifest:fs.readFileSync('Cargo.toml','utf8'),lock:fs.readFileSync('Cargo.lock','utf8')}),source=jsonMacroOriginalSource(deps,'serde_json','src/macros.rs');const defs=Object.fromEntries(['json','json_internal','json_unexpected','json_expect_expr_comma'].map(name=>[name,compileDeclarativeMacro(source.source,{name,owner:['serde_json'],...(name==='json_internal'?{maxRules:37}:{})})]));
const root=expandDeclarativeMacro(defs.json,originalMacroInvocation('json!({"error":{"type":error.code,"message":error.to_string()}})').trees),trace=[root];
for(let index=0;index<trace.length;index++)for(const call of declarativeNestedMacroInvocations(trace[index])){
 const name=call.writtenPath.at(-1),input=declarativeNestedMacroInput(trace[index],call);
 try{trace.push(expandDeclarativeMacro(defs[name],input));}catch(error){console.log(JSON.stringify({index,name,input,text:input.map(originalMacroTreeText).join(' '),error:error.message}));process.exit(1);}
}
