import pathlib,subprocess,json,hashlib,time
p=pathlib.Path("packages/javascript/node_modules/.issue-759-verification/nested-macro-inputs-v1");files=["tools/translation/test/declarative-nested-macro-inputs.test.mjs","tools/translation/test/declarative-rule-budget.test.mjs","tools/translation/test/declarative-macros.test.mjs","tools/translation/test/declarative-closure.test.mjs"];inputs=files+["tools/translation/declarative-macro-engine.mjs","tools/translation/declarative-token-macros.mjs","tools/translation/declarative-macros.mjs"];rows=[]
def vector():return [{"path":n,"bytes":len((b:=pathlib.Path(n).read_bytes())),"sha256":hashlib.sha256(b).hexdigest()} for n in inputs]
before=vector();(p/"inputs.json").write_text(json.dumps(before,indent=2)+"\n")
for name in inputs:
 dst=p/"source-snapshots"/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(pathlib.Path(name).read_bytes())
for label,cmd in [("node",["node","--test","--test-concurrency=1",*files]),("bun",["bun","test",*files])]:
 start=time.monotonic()
 with (p/(label+".stdout.raw.log")).open("wb") as a,(p/(label+".stderr.raw.log")).open("wb") as b:
  try:code=subprocess.run(cmd,stdout=a,stderr=b,timeout=300).returncode;timed=False
  except subprocess.TimeoutExpired:code=None;timed=True
 row={"command":cmd,"wholeFiles":len(files),"exitCode":code,"timedOut":timed,"elapsedSeconds":time.monotonic()-start,"capSeconds":300,"inputsUnchanged":vector()==before};rows.append(row);print(json.dumps(row),flush=True)
(p/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n")
