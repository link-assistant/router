import {writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolveModuleGraph} from '../../../../../tools/translation/project.mjs';
import {trackedSource} from '../../../../../tools/translation/source-corpus.mjs';
import {PRODUCTION_PROFILE} from '../../../../../tools/translation/cfg-profile.mjs';
import {originalNestedImplementationObligations} from '../../../../../tools/translation/nested-implementation-obligations.mjs';
import {originalSourceModuleItems} from '../../../../../tools/translation/source-module-views.mjs';
const root=process.cwd(),paths=execFileSync('git',['ls-files','-z','--','*.rs']).toString().split('\0').filter(Boolean),graph=resolveModuleGraph({entry:'src/lib.rs',paths,readSource:name=>trackedSource(root,name),compilationProfile:PRODUCTION_PROFILE}),rows=[];
for(const module of graph.modules)for(const obligation of originalNestedImplementationObligations(module)){const items=originalSourceModuleItems(module),item=items.find(x=>x.start===obligation.enclosingSpan.start),tokens=item.tokens.filter(t=>t.type!=='comment'),at=tokens.findIndex(t=>t.start===obligation.span.start),open=tokens.findIndex((t,i)=>i>at&&t.text==='{');let depth=1,end=open+1;for(;end<tokens.length;end++){if(tokens[end].text==='{')depth++;if(tokens[end].text==='}')depth--;if(!depth)break;}rows.push({obligation,originalSource:module.source,header:module.source.slice(tokens[at].start,tokens[open].start),implementationSpan:{start:tokens[at].start,end:tokens[end]?.end},implementation:module.source.slice(tokens[at].start,tokens[end]?.end)});}
writeFileSync(new URL('complete-census.json',import.meta.url),JSON.stringify({sourceHead:execFileSync('git',['rev-parse','HEAD']).toString().trim(),completeModuleCount:graph.modules.length,rows,runtimeParity:false},null,2)+'\n');console.log(JSON.stringify(rows.map(r=>({source:r.obligation.source,module:r.obligation.module,enclosing:r.obligation.enclosingName,header:r.header,span:r.implementationSpan}))));
