from pathlib import Path
import subprocess,json,time,os,sys,hashlib,datetime
p=Path('packages/javascript/node_modules/.issue-759-verification/option-clone-review-v1')
label=sys.argv[1];engine=sys.argv[2];files=sys.argv[3:]
args=[engine,'--test',*files] if engine=='node' else [engine,'test',*files]
source=[]
for f in ['scripts/review-translation-draft.mjs',*files,'changelog.d/20261014_000092_option_clone_independent_review.md']:
 b=Path(f).read_bytes();source.append({'path':f,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});target=p/(label+'-inputs')/f;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();start=time.monotonic();startUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()
vectors=(p/(label+'-vectors')).resolve();vectors.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,ROUTER_OPTION_CLONE_REVIEW_VECTORS=str(vectors/'option'),ROUTER_CLONE_REVIEW_VECTORS=str(vectors/'clone'),ROUTER_CONTAINER_REVIEW_VECTORS=str(vectors/'container'),ROUTER_HISTORICAL_VECTORS=str(vectors/'historical.json'))
with (p/(label+'.raw.log')).open('wb') as log:
 try:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300);status=r.returncode
 except subprocess.TimeoutExpired:status=124
for row in source:row['unchanged']=hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
resource={'command':args,'sourceHead':head,'status':status,'startUtc':startUtc,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-start,'outerDeadlineSeconds':300,'sourcePins':source}
(p/(label+'-resource.json')).write_text(json.dumps(resource,indent=2)+'\n');print(json.dumps(resource));print((p/(label+'.raw.log')).read_text()[-7000:])
sys.exit(status)
