from pathlib import Path
import subprocess,json,time,datetime,concurrent.futures,sys
p=Path('packages/javascript/node_modules/.issue-759-verification/remote-deliverable-review-20261014-v1')
jobs=json.loads(Path(sys.argv[1]).read_text())
def run(job):
 name,endpoint,paginate=job;args=['gh','api',*(['--paginate','--slurp'] if paginate else []),endpoint];start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (p/(name+'.json')).open('wb') as out,(p/(name+'.stderr.raw.log')).open('wb') as err:
  try:r=subprocess.run(args,stdout=out,stderr=err,timeout=60);status=r.returncode
  except subprocess.TimeoutExpired:status=124
 row={'command':args,'startUtc':started,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-start,'status':status,'readOnly':True,'outerDeadlineSeconds':60};(p/(name+'.resource.json')).write_text(json.dumps(row,indent=2)+'\n');return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for row in pool.map(run,jobs):print(json.dumps(row))
