from pathlib import Path
import json,gzip,tarfile,hashlib,subprocess,io,time,datetime
p=Path('packages/javascript/node_modules/.issue-759-verification/remote-deliverable-review-20261014-v1');repo=Path('../issue-759-gate').resolve();case=repo/'docs/case-studies/issue-759';head='a40901b8145d15f51aa0714e78294540827c8add';started=time.monotonic();deadline=started+180
sha=lambda b:hashlib.sha256(b).hexdigest()
def check():
 if time.monotonic()>deadline:raise TimeoutError('CI archive verification180s deadline')
runs=[r for page in json.loads((p/'branch-all-runs.json').read_text()) for r in page['workflow_runs']];heads={r['head_sha'] for r in runs};packroot=case/'raw/current-task';index=json.loads(gzip.decompress((packroot/'index.json.gz').read_bytes()));f=index['completeOriginalIndex'];b=(packroot/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];raw=gzip.decompress(b);assert len(raw)==f['decodedBytes'] and sha(raw)==f['decodedSha256'];full=json.loads(raw)
packs=[dict(row,base='raw/current-task',receipt='raw/current-task/'+f['path']) for row in full['packs'] if row.get('headSha') in heads and any(str(row.get('label','')).startswith(prefix) for prefix in ['ci-cycle','cycle-8-complete-ci'])]
name='current/ci-cycle-nine-24cbcc00';r=json.loads((case/name/'router-759-ci-cycle-9-terminal-pack-receipt.json').read_text());packs.append({'headSha':r['headSha'],'pack':r['archive'],'storedBytes':r['archiveBytes'],'sha256':r['archiveSha256'],'members':r['members'],'base':name,'receipt':name+'/router-759-ci-cycle-9-terminal-pack-receipt.json'})
covered={};results=[];errors=[]
for row in packs:
 check();path=case/row['base']/row['pack'];blob=path.read_bytes();assert len(blob)==row['storedBytes'] and sha(blob)==row['sha256'];relative=str(path.relative_to(repo));gitblob=subprocess.check_output(['git','rev-parse',head+':'+relative],cwd=repo,text=True,timeout=30).strip();assert hashlib.sha1(b'blob '+str(len(blob)).encode()+b'\0'+blob).hexdigest()==gitblob
 expected={m['path']:m for m in row['members']};seen={};payload={}
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as archive:
  for member in archive:
   check();assert member.name in expected and member.name not in seen and not member.name.startswith('/') and '..' not in member.name.split('/');m=expected[member.name]
   if member.islnk():data=payload[member.linkname]
   else:assert member.isfile();data=archive.extractfile(member).read()
   assert len(data)==m['bytes'] and sha(data)==m['sha256'];seen[member.name]=True;payload[member.name]=data
 assert set(seen)==set(expected)
 manifests=[(name,json.loads(data)) for name,data in payload.items() if name.endswith('logs-manifest.json')]
 for manifestname,manifest in manifests:
  prefix=manifestname[:-len('logs-manifest.json')]
  for runid,record in manifest.items():
   run=next((r for r in runs if str(r['id'])==runid),None)
   if not run:continue
   assert record['headSha']==run['head_sha'] and record['attempt']==run['run_attempt'];refs=record.get('entries',[]);decoded=0
   for ref in refs:
    packed=payload[prefix+ref['storedPath']];data=gzip.decompress(packed);assert len(packed)==ref['storedBytes'] and len(data)==ref['decodedBytes'] and sha(data)==ref['sha256'];decoded+=len(data)
   names=[name for name in payload if name.endswith('/runs/'+runid+'/jobs.json') or name=='runs/'+runid+'/jobs.json'];archived=[]
   for name in names:
    value=json.loads(payload[name]);archived.extend(value['jobs'] if isinstance(value,dict) else value)
   current=[j for page in json.loads((p/('run-'+runid+'-jobs.json')).read_text()) for j in page['jobs']];byid={j['id']:j for j in archived};missing=[j['id'] for j in current if j['id'] not in byid]
   mismatched=[j['id'] for j in current if j['id'] in byid and any(j.get(k)!=byid[j['id']].get(k) for k in ['id','run_id','name','status','conclusion','started_at','completed_at'])]
   aggregate=[ref for ref in refs if '/' not in ref['path'] and ref['path'].endswith('.txt')]
   def normalize(name):return name.replace('/','_')
   nonSkipped=[j for j in current if j['conclusion']!='skipped'];missingLogs=[j['id'] for j in nonSkipped if not any(normalize(j['name']) in ref['path'] for ref in aggregate)]
   covered[runid]={'runId':run['id'],'headSha':run['head_sha'],'attempt':run['run_attempt'],'packet':relative,'packetCommit':head,'packetBlob':gitblob,'packetSha256':sha(blob),'completeMembersVerified':len(seen),'logReferencesVerified':len(refs),'completeDecodedLogReferenceBytes':decoded,'jobs':len(current),'archivedJobIds':sorted(byid),'missingJobIds':missing,'mismatchedJobFields':mismatched,'missingAggregateLogJobIds':missingLogs,'failureJobIds':[j['id'] for j in current if j['conclusion']=='failure']}
 results.append({'packet':relative,'bytes':len(blob),'sha256':sha(blob),'blob':gitblob,'commit':head,'membersVerified':len(seen),'logManifestMembers':[name for name,_ in manifests]})
missingRuns=[{'id':r['id'],'attempt':r['run_attempt'],'headSha':r['head_sha']} for r in runs if str(r['id']) not in covered]
report={'schema':'complete-exact-branch-ci-archive-coverage-v1','capturedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runAttemptsRequested':len(runs),'coveredRunAttempts':len(covered),'missingRunAttempts':missingRuns,'packets':results,'runs':[covered[k] for k in sorted(covered)],'currentHead':runs[0]['head_sha'],'elapsedSeconds':time.monotonic()-started,'outerDeadlineSeconds':180,'archiveAllOriginalMembersReopened':True,'newLogsDownloaded':False,'readOnly':True}
(p/'complete-existing-ci-coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['packets','runs']},indent=2));print('missingjobids',sum(len(r['missingJobIds']) for r in covered.values()),'fieldmismatches',sum(len(r['mismatchedJobFields']) for r in covered.values()),'missingaggregatelogs',sum(len(r['missingAggregateLogJobIds']) for r in covered.values()))
