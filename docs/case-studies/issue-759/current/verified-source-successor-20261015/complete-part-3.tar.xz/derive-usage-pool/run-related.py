import os,json,time,subprocess,resource,datetime,pathlib
root=pathlib.Path(__file__).resolve().parent
names=['clone-sibling-trait-source','clone-container-source','clone-source-methods','clone-unit-methods','clone-unit-source','default-container-source','default-source-methods','default-unit-methods','standard-body-source','derive-bang-footprints','serde-deserialize-bang-footprints','schemars-bang-footprints']
paths=['tools/translation/test/'+name+'.test.mjs' for name in names]
engine=os.environ['ROUTER_SIBLING_ENGINE'];label=engine+os.environ.get('ROUTER_SIBLING_RUN_SUFFIX','');command=(['node','--test','--test-concurrency=1'] if engine=='node' else ['bun','test'])+paths
vectors=root/('related-'+label);vectors.mkdir(exist_ok=True)
env=dict(os.environ,ROUTER_TRANSLATION_TSC='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/packages/javascript/node_modules/.bin/tsc',ROUTER_SIBLING_CLONE_EVIDENCE_DIR=str(vectors),ROUTER_OPTION_CLONE_EVIDENCE_DIR=str(vectors))
started=time.time();receipt={'command':command,'engine':engine,'testFiles':paths,'outerTimeoutSeconds':300,'individualDeadlinesChanged':False,'startUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tsc':env['ROUTER_TRANSLATION_TSC']}
with open(root/('related-'+label+'.raw.log'),'wb') as raw:
 try:result=subprocess.run(command,env=env,stdout=raw,stderr=subprocess.STDOUT,timeout=300);receipt['exitCode']=result.returncode
 except subprocess.TimeoutExpired:receipt['outerTimedOut']=True;receipt['exitCode']=None
receipt.update(elapsedSeconds=time.time()-started,childrenResourceUsage=dict(zip(['userSeconds','systemSeconds','maxRss','integralSharedMemory','integralUnsharedData','integralUnsharedStack','minorFaults','majorFaults','swaps','blockInputs','blockOutputs','messagesSent','messagesReceived','signals','voluntaryContextSwitches','involuntaryContextSwitches'],resource.getrusage(resource.RUSAGE_CHILDREN))))
(root/('related-'+label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
