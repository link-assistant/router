import pathlib,hashlib,subprocess,json,gzip,sys
root=pathlib.Path(__file__).resolve().parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
status=subprocess.check_output(['git','status','--porcelain','-z']).decode().split('\0')
changed=[]
for row in status:
 if not row:continue
 p=pathlib.Path(row[3:])
 if p.is_dir():changed.extend(x for x in p.rglob('*') if x.is_file())
 elif p.is_file():changed.append(p)
sourceFiles=set(changed)
sourceFiles.update(pathlib.Path('tools/translation/test/'+name+'.test.mjs') for name in ['clone-sibling-trait-source','clone-container-source','clone-source-methods','clone-unit-methods','clone-unit-source','default-container-source','default-source-methods','default-unit-methods','standard-body-source','derive-bang-footprints','serde-deserialize-bang-footprints','schemars-bang-footprints'])
snapshots=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source':p.read_text()} for p in sorted(sourceFiles)]
def originals(ref):
 rows=[]
 for entry in subprocess.check_output(['git','ls-tree','-r','-z',ref]).split(b'\0'):
  if not entry:continue
  left,name=entry.decode().split('\t');path=pathlib.Path(name)
  if path.suffix!='.rs' and name not in ['Cargo.toml','Cargo.lock']:continue
  mode,kind,blob=left.split();rows.append({'path':name,'blob':blob})
 return rows
old=originals('6daf6cd495ff6b76848b0a77cb737439367596b1');current=originals(head)
assert old==current
materialized=[{**row,'sha256':hashlib.sha256(pathlib.Path(row['path']).read_bytes()).hexdigest()} for row in current if pathlib.Path(row['path']).is_file()]
value={'head':head,'originalBase':'6daf6cd495ff6b76848b0a77cb737439367596b1','originalRustCount':sum(row['path'].endswith('.rs') for row in current),'originalCargoCount':2,'originalsUnchanged':old==current,'originalGitInputs':current,'materializedOriginals':materialized,'sources':snapshots}
(root/(sys.argv[1]+'.json.gz')).write_bytes(gzip.compress((json.dumps(value,sort_keys=True)+'\n').encode()))
print(len(snapshots),value['originalRustCount'],len(materialized))
