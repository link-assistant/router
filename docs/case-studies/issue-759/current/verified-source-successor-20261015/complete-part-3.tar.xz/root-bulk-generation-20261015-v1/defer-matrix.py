from pathlib import Path
import json,time,os,signal,datetime
out=Path(__file__).parent;start=time.monotonic();cap=1200
while time.monotonic()-start<cap:
 r=json.loads((out/"running.json").read_text())
 if r["stage"]=="matrix":
  assert r["sourceHead"]=="a40901b8145d15f51aa0714e78294540827c8add"
  assert r["command"]==["node","scripts/translate-router.mjs","--profile-matrix","--progress"]
  pid=r["pid"];assert os.getpgid(pid)==pid
  before=datetime.datetime.now(datetime.timezone.utc).isoformat()
  os.killpg(pid,signal.SIGTERM)
  report={"schema":"coordinator-controlled-local-stage-deferral-v1","sourceHead":r["sourceHead"],"stage":"matrix","pid":pid,"signal":"SIGTERM","requestedUtc":before,"reason":"A newly completed actual UsagePool Clone source join needs its full negative-control cohort; defer these old-batch profile outputs and regenerate every full profile once after that completed batch is integrated.","canonicalInterrupted":False,"remoteCIInterrupted":False,"matrixPassClaim":False,"fullGatePass":False,"runtimeParity":False,"rustExecuted":False}
  (out/"matrix-controlled-deferral.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report),flush=True);break
 time.sleep(.25)
else:raise TimeoutError("No matrix phase observed within coordinator wait cap; no process was signaled")
