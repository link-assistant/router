from pathlib import Path
import subprocess,json,hashlib,time,os,signal,datetime
root=Path.cwd();out=Path(__file__).parent
head=subprocess.check_output(["git","rev-parse","HEAD"]).decode().strip()
assert not subprocess.check_output(["git","status","--porcelain"])
paths=sorted(p for p in subprocess.check_output(["git","ls-files","-z","--","*.rs","Cargo.toml","Cargo.lock","tools/translation","scripts"]).decode().split("\0") if p and not p.startswith(("tools/translation/meta/","tools/translation/projects/","tools/translation/js-to-rust/generated/")))
def vector():
 missing=[p for p in paths if not(root/p).is_file()];objects={}
 data=subprocess.check_output(["git","cat-file","--batch"],input="".join(head+":"+p+"\n" for p in missing).encode(),timeout=120);offset=0
 for p in missing:
  end=data.index(b"\n",offset);h=data[offset:end].split();assert len(h)==3 and h[1]==b"blob";size=int(h[2]);offset=end+1;objects[p]=data[offset:offset+size];offset+=size;assert data[offset:offset+1]==b"\n";offset+=1
 assert offset==len(data)
 return [{"path":p,"bytes":len((b:=(root/p).read_bytes() if (root/p).is_file() else objects[p])),"sha256":hashlib.sha256(b).hexdigest()} for p in paths]
before=vector();(out/"inputs.json").write_text(json.dumps({"sourceHead":head,"inputs":before},indent=2)+"\n");rows=[]
for name,argv,cap in [("canonical",["node","scripts/translate-router.mjs","--progress"],2400),("matrix",["node","scripts/translate-router.mjs","--profile-matrix","--progress"],3600)]:
 start=time.monotonic();timed=False
 with (out/(name+".stdout.raw.log")).open("xb") as a,(out/(name+".stderr.raw.log")).open("xb") as b:
  child=subprocess.Popen(argv,stdout=a,stderr=b,start_new_session=True);(out/"running.json").write_text(json.dumps({"stage":name,"pid":child.pid,"sourceHead":head,"capSeconds":cap,"command":argv},indent=2)+"\n")
  try:pid,status,usage=os.wait4(child.pid,os.WNOHANG)
  except ChildProcessError:raise
  while not pid and time.monotonic()-start<cap:
   time.sleep(.25);pid,status,usage=os.wait4(child.pid,os.WNOHANG)
  if not pid:
   timed=True;os.killpg(child.pid,signal.SIGTERM);end=time.monotonic()+5
   while not pid and time.monotonic()<end:time.sleep(.05);pid,status,usage=os.wait4(child.pid,os.WNOHANG)
   if not pid:os.killpg(child.pid,signal.SIGKILL);pid,status,usage=os.wait4(child.pid,0)
  code=os.waitstatus_to_exitcode(status);child.returncode=code
 row={"stage":name,"command":argv,"sourceHead":head,"exitCode":code,"elapsedSeconds":time.monotonic()-start,"capSeconds":cap,"timedOut":timed,"inputsUnchanged":before==vector(),"headUnchanged":head==subprocess.check_output(["git","rev-parse","HEAD"]).decode().strip(),"maxWaitedChildRssBytes":usage.ru_maxrss,"resourceScope":"wait4 on the one direct Node child on Darwin; not aggregate concurrent RSS or coordinator memory","userCpuSeconds":usage.ru_utime,"systemCpuSeconds":usage.ru_stime,"runtimeParity":False,"fullGatePass":False,"rustExecuted":False};rows.append(row);(out/"receipt.json").write_text(json.dumps(rows,indent=2)+"\n");print(json.dumps(row),flush=True)
 if code or timed or not row["inputsUnchanged"] or not row["headUnchanged"]:raise SystemExit(1)
