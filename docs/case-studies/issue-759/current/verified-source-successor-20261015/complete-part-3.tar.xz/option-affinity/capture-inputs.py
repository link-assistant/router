from pathlib import Path
import subprocess,hashlib,json,sys
root=Path('.');folder=Path(__file__).resolve().parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','*.rs','Cargo.toml','Cargo.lock','**/Cargo.toml','**/Cargo.lock','packages/javascript/package.json','packages/javascript/package-lock.json','tools/translation','scripts']).decode().split('\0');paths=sorted(set(p for p in paths if p and not any(p.startswith(x)for x in ['tools/translation/meta/','tools/translation/projects/','tools/translation/generated/','tools/translation/js-to-rust/generated/'])));missing=[p for p in paths if not(root/p).exists()];blobs={}
if missing:
 data=subprocess.check_output(['git','cat-file','--batch'],input=''.join(head+':'+p+'\n'for p in missing).encode());offset=0
 for p in missing:
  end=data.index(b'\n',offset);header=data[offset:end].split();assert header[1]==b'blob';size=int(header[2]);offset=end+1;blobs[p]=data[offset:offset+size];offset+=size;assert data[offset:offset+1]==b'\n';offset+=1
 assert offset==len(data)
rows=[]
for p in paths:
 h=hashlib.sha256();size=0
 if p in blobs:h.update(blobs[p]);size=len(blobs[p]);storage='original-HEAD-sparse-fallback'
 else:
  assert not(root/p).is_symlink();storage='worktree'
  with(root/p).open('rb')as f:
   while chunk:=f.read(1024*1024):h.update(chunk);size+=len(chunk)
 rows.append({'path':p,'bytes':size,'sha256':h.hexdigest(),'storage':storage})
(folder/('compiler-inputs-'+sys.argv[1]+'.json')).write_text(json.dumps({'head':head,'files':rows},indent=2));print(json.dumps({'head':head,'sourceInputs':len(rows)}))
