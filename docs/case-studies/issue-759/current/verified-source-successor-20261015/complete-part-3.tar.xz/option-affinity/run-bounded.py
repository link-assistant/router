from pathlib import Path
import sys,subprocess,time,json,resource,hashlib,os,signal
folder=Path(__file__).resolve().parent;root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-option-cycle');label=sys.argv[1];argv=sys.argv[2:];start=time.monotonic()
with(folder/(label+'.stdout.raw.log')).open('xb')as out,(folder/(label+'.stderr.raw.log')).open('xb')as err:
 child=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err,start_new_session=True)
 try:code=child.wait(timeout=300)
 except subprocess.TimeoutExpired:
  os.killpg(child.pid,signal.SIGKILL);child.wait();code='timeout'
after=resource.getrusage(resource.RUSAGE_CHILDREN);v={'command':argv,'exitCode':code,'seconds':time.monotonic()-start,'capSeconds':300,'maxWaitedChildRssBytes':after.ru_maxrss,'scope':'RUSAGE_CHILDREN maximum in fresh driver, including waited descendants, not aggregate concurrent RSS or coordinator','userCpuSeconds':after.ru_utime,'systemCpuSeconds':after.ru_stime};(folder/(label+'-run.json')).write_text(json.dumps(v,indent=2));print(json.dumps(v))
