import {pathToFileURL}from'node:url';import{resolve,join}from'node:path';import{writeFileSync}from'node:fs';import assert from'node:assert/strict';
const root=resolve(process.argv[2]),folder=resolve(process.argv[3]),native=Object.defineProperty;let calls=0;
Object.defineProperty=function(...args){calls++;return Reflect.apply(native,Object,args);};
try{
 const {copyMetadata}=await import(pathToFileURL(join(root,'tools/translation/extensions/source-links.mjs')).href+'?prebound-control');const{copyMetadata:previous}=await import(pathToFileURL(join(root,'tools/translation/test/fixtures/source-metadata-copy-previous.mjs')).href);const input={z:2,a:{x:1}};
 calls=0;const old=previous(input),oldCalls=calls;calls=0;const current=copyMetadata(input),currentCalls=calls;const result={old:JSON.stringify(old),current:JSON.stringify(current),oldCalls,currentCalls,preImportDefinePropertyWrapped:true};writeFileSync(join(folder,'prebound-intrinsic-result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));assert.equal(result.current,result.old);assert.equal(currentCalls,oldCalls);
}finally{Object.defineProperty=native;}
