import{types}from'node:util';
// This captures syntax validation machinery, never caller data or authority.
const metadataObject=Object,metadataReflect=Reflect,metadataArray=Array,metadataSet=Set,metadataBuffer=Buffer,metadataFunction=Function,metadataNumber=Number,metadataString=String;
const metadataIteratorKey=Symbol.iterator;
const metadataNative=Object.freeze({descriptor:Object.getOwnPropertyDescriptor,descriptors:Object.getOwnPropertyDescriptors,keys:Reflect.ownKeys,prototype:Object.getPrototypeOf,isArray:Array.isArray,define:Object.defineProperty,create:Object.create,sort:Array.prototype.sort,push:Array.prototype.push,proxy:types.isProxy,byteLength:Buffer.byteLength,setHas:Set.prototype.has,setAdd:Set.prototype.add,setDelete:Set.prototype.delete,iterator:Array.prototype[Symbol.iterator],call:Function.prototype.call,safeInteger:Number.isSafeInteger});
const metadataObjectKeys=metadataNative.keys(Object.prototype),metadataArrayKeys=metadataNative.keys(Array.prototype);
function originalMetadataMachinery(){
  const data=(owner,key,value)=>{const descriptor=metadataNative.descriptor(owner,key);return descriptor&&'value'in descriptor&&descriptor.value===value;};
  if(!data(globalThis,'Object',metadataObject)||!data(globalThis,'Reflect',metadataReflect)||!data(globalThis,'Array',metadataArray)||!data(globalThis,'Set',metadataSet)||!data(globalThis,'Buffer',metadataBuffer)||!data(globalThis,'Function',metadataFunction)||!data(globalThis,'Number',metadataNumber)||!data(globalThis,'String',metadataString))return false;
  if(!data(metadataArray.prototype,metadataIteratorKey,metadataNative.iterator)||!data(metadataFunction.prototype,'call',metadataNative.call)||!data(metadataNumber,'isSafeInteger',metadataNative.safeInteger))return false;
  for(const[key,value]of [['getOwnPropertyDescriptor',metadataNative.descriptor],['getOwnPropertyDescriptors',metadataNative.descriptors],['getPrototypeOf',metadataNative.prototype],['defineProperty',metadataNative.define],['create',metadataNative.create]])if(!data(metadataObject,key,value))return false;
  if(!data(metadataReflect,'ownKeys',metadataNative.keys)||!data(metadataArray,'isArray',metadataNative.isArray)||!data(metadataArray.prototype,'sort',metadataNative.sort)||!data(metadataArray.prototype,'push',metadataNative.push)||!data(types,'isProxy',metadataNative.proxy)||!data(metadataBuffer,'byteLength',metadataNative.byteLength))return false;
  if(!data(metadataSet.prototype,'has',metadataNative.setHas)||!data(metadataSet.prototype,'add',metadataNative.setAdd)||!data(metadataSet.prototype,'delete',metadataNative.setDelete))return false;
  const sameKeys=(owner,expected)=>{const keys=metadataNative.keys(owner);if(keys.length!==expected.length)return false;for(let index=0;index<keys.length;index++)if(keys[index]!==expected[index])return false;return true;};
  return sameKeys(metadataObject.prototype,metadataObjectKeys)&&sameKeys(metadataArray.prototype,metadataArrayKeys);
}
console.log(JSON.stringify({fastAvailable:originalMetadataMachinery(),bufferDescriptor:Object.getOwnPropertyDescriptor(globalThis,'Buffer')}));
