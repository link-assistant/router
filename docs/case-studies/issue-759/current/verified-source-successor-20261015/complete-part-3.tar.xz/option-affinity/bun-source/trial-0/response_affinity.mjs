import { validateRustValue as ml_validate_rust_value } from "../runtime/type-layout-runtime.mjs";

import { std_time_duration_from_secs as ml_host_std_time_duration_from_secs } from "../runtime/time-runtime.mjs";

import { assertImmutableCopy as ml_assert_immutable_copy } from "../runtime/copy-runtime.mjs";

function ml_fixed(value, min, max, message) {
  if (value < min || value > max) throw new RangeError(message);
  return value;
}

const ml_host_value_schema_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef = {"schemaVersion":1,"types":{"rp_526573706f6e73654e616d657370616365":{"kind":"data","name":"rp_526573706f6e73654e616d657370616365","ctors":[{"name":"OpenAiResponses","fields":[]},{"name":"CodexResponses","fields":[]},{"name":"QwenResponses","fields":[]},{"name":"OpenAiChat","fields":[]},{"name":"CodexChat","fields":[]},{"name":"QwenChat","fields":[]},{"name":"OpenAiConversations","fields":[]},{"name":"CodexConversations","fields":[]},{"name":"QwenConversations","fields":[]},{"name":"OpenAiConversationItems","fields":[]},{"name":"CodexConversationItems","fields":[]},{"name":"QwenConversationItems","fields":[]},{"name":"OpenAiRealtimeCalls","fields":[]},{"name":"CodexRealtimeCalls","fields":[]},{"name":"AnthropicFiles","fields":[]},{"name":"AnthropicBatches","fields":[]},{"name":"AnthropicSkills","fields":[]},{"name":"AnthropicSkillVersions","fields":[]},{"name":"CodexFiles","fields":[]},{"name":"CodexMcpSessions","fields":[]},{"name":"CodexPluginInstalls","fields":[]},{"name":"CodexPluginUploads","fields":[]},{"name":"CodexWorkspacePlugins","fields":[]}]}}};

const ml_host_value_refinements_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef = new Map([]);

const ml_host_value_schema_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846 = {"schemaVersion":1,"types":{"rp_5265636f72644f7574636f6d65":{"kind":"data","name":"rp_5265636f72644f7574636f6d65","ctors":[{"name":"Inserted","fields":[]},{"name":"Existing","fields":[]}]}}};

const ml_host_value_refinements_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846 = new Map([]);

function rp_46494c455f4e414d45() {
  return "response-affinities.lino";
}

function rp_53544f52455f56455253494f4e() {
  return 1n;
}

function rp_44454641554c545f54544c() {
  return ml_host_std_time_duration_from_secs(ml_fixed((ml_fixed((ml_fixed((30n * 24n), 0n, 18446744073709551615n, "attempt to multiply with overflow") * 60n), 0n, 18446744073709551615n, "attempt to multiply with overflow") * 60n), 0n, 18446744073709551615n, "attempt to multiply with overflow"));
}

function rp_44454641554c545f4d41585f5245434f524453() {
  return 10000n;
}

function rp_4d41585f524553504f4e53455f49445f4259544553() {
  return 256n;
}

function rp_6d6c5f696d706c5f363337323631373436353265353236353733373036663665373336353465363136643635373337303631363336355f363637323666366435663730363137343638(path) {
  if (!(typeof path === 'string' && !/[\ud800-\udbff](?![\udc00-\udfff])|(?<![\ud800-\udbff])[\udc00-\udfff]/u.test(path))) throw new TypeError('argument outside supported Rust value domain');
  if ((() => {
    const ml_text_1 = path;
    const ml_text_2 = "/api/services/openai/v1/responses";
    return ml_text_1.startsWith(ml_text_2);
  })()) {
    return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'OpenAiResponses' }) });
  } else {
    if ((() => {
    const ml_text_3 = path;
    const ml_text_4 = "/api/services/codex/v1/responses";
    return ml_text_3.startsWith(ml_text_4);
  })()) {
      return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'CodexResponses' }) });
    } else {
      if ((() => {
    const ml_text_5 = path;
    const ml_text_6 = "/api/services/qwen/v1/responses";
    return ml_text_5.startsWith(ml_text_6);
  })()) {
        return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'QwenResponses' }) });
      } else {
        if ((() => {
    const ml_text_7 = path;
    const ml_text_8 = "/api/services/openai/v1/chat/completions";
    return ml_text_7.startsWith(ml_text_8);
  })()) {
          return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'OpenAiChat' }) });
        } else {
          if ((() => {
    const ml_text_9 = path;
    const ml_text_10 = "/api/services/codex/v1/chat/completions";
    return ml_text_9.startsWith(ml_text_10);
  })()) {
            return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'CodexChat' }) });
          } else {
            if ((() => {
    const ml_text_11 = path;
    const ml_text_12 = "/api/services/qwen/v1/chat/completions";
    return ml_text_11.startsWith(ml_text_12);
  })()) {
              return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'QwenChat' }) });
            } else {
              return Object.freeze({ $: 'None' });
            }
          }
        }
      }
    }
  }
}

function rp_6d6c5f696d706c5f363337323631373436353265353236353733373036663665373336353465363136643635373337303631363336355f36333666366537363635373237333631373436393666366537333566363637323666366435663730363137343638(path) {
  if (!(typeof path === 'string' && !/[\ud800-\udbff](?![\udc00-\udfff])|(?<![\ud800-\udbff])[\udc00-\udfff]/u.test(path))) throw new TypeError('argument outside supported Rust value domain');
  if ((() => {
    const ml_text_1 = path;
    const ml_text_2 = "/api/services/openai/v1/conversations";
    return ml_text_1.startsWith(ml_text_2);
  })()) {
    return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'Tuple', field0: Object.freeze({ $: 'OpenAiConversations' }), field1: Object.freeze({ $: 'OpenAiConversationItems' }) }) });
  } else {
    if ((() => {
    const ml_text_3 = path;
    const ml_text_4 = "/api/services/codex/v1/conversations";
    return ml_text_3.startsWith(ml_text_4);
  })()) {
      return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'Tuple', field0: Object.freeze({ $: 'CodexConversations' }), field1: Object.freeze({ $: 'CodexConversationItems' }) }) });
    } else {
      if ((() => {
    const ml_text_5 = path;
    const ml_text_6 = "/api/services/qwen/v1/conversations";
    return ml_text_5.startsWith(ml_text_6);
  })()) {
        return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'Tuple', field0: Object.freeze({ $: 'QwenConversations' }), field1: Object.freeze({ $: 'QwenConversationItems' }) }) });
      } else {
        return Object.freeze({ $: 'None' });
      }
    }
  }
}

function rp_6d6c5f696d706c5f363337323631373436353265353236353733373036663665373336353465363136643635373337303631363336355f36333663366636653635(ml_clone_self) {
  ml_assert_immutable_copy(ml_clone_self);
  ml_validate_rust_value(ml_clone_self, {"kind":"data","name":"rp_526573706f6e73654e616d657370616365"}, ml_host_value_schema_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef, { refinements: ml_host_value_refinements_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef });
  return ml_clone_self;
}

function rp_6d6c5f696d706c5f36333732363137343635326535323635363336663732363434663735373436333666366436355f36333663366636653635(ml_clone_self) {
  ml_assert_immutable_copy(ml_clone_self);
  ml_validate_rust_value(ml_clone_self, {"kind":"data","name":"rp_5265636f72644f7574636f6d65"}, ml_host_value_schema_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846, { refinements: ml_host_value_refinements_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846 });
  return ml_clone_self;
}
export const translated = Object.freeze({ ["FILE_NAME"]: rp_46494c455f4e414d45(), ["STORE_VERSION"]: rp_53544f52455f56455253494f4e(), ["DEFAULT_TTL"]: rp_44454641554c545f54544c(), ["DEFAULT_MAX_RECORDS"]: rp_44454641554c545f4d41585f5245434f524453(), ["MAX_RESPONSE_ID_BYTES"]: rp_4d41585f524553504f4e53455f49445f4259544553() });
export const provenance = {"entry":"src/response_affinity.rs","runtimeParity":false,"moduleCount":1,"executableFunctions":0,"executableConstants":5};
