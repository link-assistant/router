type MLData_72705f3532363536333666373236343466373537343633366636643635 = Readonly<{ readonly "$": "Inserted" }> | Readonly<{ readonly "$": "Existing" }>;
type MLData_72705f35323635373337303666366537333635346536313664363537333730363136333635 = Readonly<{ readonly "$": "OpenAiResponses" }> | Readonly<{ readonly "$": "CodexResponses" }> | Readonly<{ readonly "$": "QwenResponses" }> | Readonly<{ readonly "$": "OpenAiChat" }> | Readonly<{ readonly "$": "CodexChat" }> | Readonly<{ readonly "$": "QwenChat" }> | Readonly<{ readonly "$": "OpenAiConversations" }> | Readonly<{ readonly "$": "CodexConversations" }> | Readonly<{ readonly "$": "QwenConversations" }> | Readonly<{ readonly "$": "OpenAiConversationItems" }> | Readonly<{ readonly "$": "CodexConversationItems" }> | Readonly<{ readonly "$": "QwenConversationItems" }> | Readonly<{ readonly "$": "OpenAiRealtimeCalls" }> | Readonly<{ readonly "$": "CodexRealtimeCalls" }> | Readonly<{ readonly "$": "AnthropicFiles" }> | Readonly<{ readonly "$": "AnthropicBatches" }> | Readonly<{ readonly "$": "AnthropicSkills" }> | Readonly<{ readonly "$": "AnthropicSkillVersions" }> | Readonly<{ readonly "$": "CodexFiles" }> | Readonly<{ readonly "$": "CodexMcpSessions" }> | Readonly<{ readonly "$": "CodexPluginInstalls" }> | Readonly<{ readonly "$": "CodexPluginUploads" }> | Readonly<{ readonly "$": "CodexWorkspacePlugins" }>;
type MLData_72705f3532363537333730366636653733363534663737366536353732 = Readonly<{ readonly "$": "ResponseOwner"; readonly "client_kind": string; readonly "principal_id": string }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633313337356637323735373337343566366637373665363536343566373337343732363936653637 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": string }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633323334333435663665363136643635363435663335333233363636333733353337333433363335333733323335333433373335333733303336363333363335333536363333333433333330333536363336363533363331333636343336333533363334333536363333333533333332333333363333333533333337333333333333333733333330333333363336333633333336333633353333333733333333333333363333333533333334333633353333333633333331333333363336333433333336333333353333333733333333333333373333333033333336333333313333333633333333333333363333333533353636333333343333333033353636333636353336333133363634333633353336333433353636333333353333333233333336333333353333333733333333333333373333333033333336333633363333333633363335333333373333333333333336333333353333333433363335333333363333333133333336333633343333333633333335333333373333333333333337333333303333333633333331333333363333333333333336333333353335363633373332333733353337333333373334333536363333333533363332333333373336333233333337333633343333333233363333333333373336333233333337333633343333333533363334 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f35323666373537343635373235343735373036633635356633343330356636653631366436353634356633353332333633353337333333373330333636363336363533373333333633353334363533363331333636343336333533373333333733303336333133363333333633353566333433303566366536313664363536343566333533323336333533373333333733303336363633363635333733333336333533343635333633313336363433363335333733333337333033363331333633333336333535663732373537333734356633353632333736323337363433323633333736323337363433353634 }>;
type MLData_72705f35323666373537343635373234663730373436393666366535663333333735663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663335333633363331333636333337333533363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326535363631366337353635 }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633333338356636653631366436353634356633373333333733343336333435663337333433363339333636343336333535663334333433373335333733323336333133373334333633393336363633363635 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f37333734363432653734363936643635326534343735373236313734363936663665 }>;
type MLData_72705f3532366637353734363537323466373037343639366636653566333333393566366536313664363536343566333733333336333533373332333633343336333533353636333636313337333333363636333636353566333436353337333533363634333633323336333533373332 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f37333635373236343635356636613733366636653265346537353664363236353732 }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633333566363933333332 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": bigint }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633333566363933363334 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": bigint }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633333566373533363334 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": bigint }>;
type MLData_72705f35323666373537343635373234663730373436393666366535663334333035663665363136643635363435663335333233363335333733333337333033363636333636353337333333363335333436353336333133363634333633353337333333373330333633313336333333363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f35323635373337303666366537333635346536313664363537333730363136333635 }>;
type MLData_72705f3532366637353734363537323466373037343639366636653566333435663632366636663663 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": boolean }>;
type MLData_72705f3532366637353734363537323466373037343639366636653566333435663735366536393734 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": null }>;
type MLData_72705f35323666373537343635373234663730373436393666366535663335333235663732373537333734356636663737366536353634356637363635363335663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663335333633363331333636333337333533363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": ReadonlyArray<MLData_72705f3733363537323634363535663661373336663665326535363631366337353635> }>;
type MLData_72705f3532366637353734363537323466373037343639366636653566333533343566373236353636363537323635366536333635356637333638363137323635363435663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663335333633363331333636333337333533363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326535363631366337353635 }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633353336356637323635363636353732363536653633363535663733363836313732363536343566366536313664363536343566333733333336333533373332333633343336333533353636333636313337333333363636333636353566333436353337333533363634333633323336333533373332 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f37333635373236343635356636613733366636653265346537353664363236353732 }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633353339356636653631366436353634356633373333333633353337333233363334333633353335363633363631333733333336363633363635356633343634333633313337333033353636333533333337333433373332333633393336363533363337333536363335333633363331333636333337333533363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f373336353732363436353566366137333666366532653464363137303566353337343732363936653637356635363631366337353635 }>;
type MLData_72705f35323666373537343635373234663730373436393666366535663335356636363663366636313734 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": number }>;
type MLData_72705f3532366637353734363537323466373037343639366636653566333633393566373236353636363537323635366536333635356637333638363137323635363435663732373537333734356636663737366536353634356637363635363335663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663335333633363331333636333337333533363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": ReadonlyArray<MLData_72705f3733363537323634363535663661373336663665326535363631366337353635> }>;
type MLData_72705f353236663735373436353732346637303734363936663665356633363566373337343732363936653637 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": string }>;
type MLData_72705f35323666373537343635373234663730373436393666366535663337333635663732363536363635373236353665363336353566373336383631373236353634356636653631366436353634356633373333333633353337333233363334333633353335363633363631333733333336363633363635356633343634333633313337333033353636333533333337333433373332333633393336363533363337333536363335333633363331333636333337333533363335 = Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": MLData_72705f373336353732363436353566366137333666366532653464363137303566353337343732363936653637356635363631366337353635 }>;
type MLData_72705f35323666373537343635373235323635373337353663373435663331333035663732373537333734356637353733363937613635356633323336356636653631366436353634356633353333333733343336363633373332333633353334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": bigint }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3533373436663732363534353732373236663732 }>;
type MLData_72705f35323666373537343635373235323635373337353663373435663331333735663732373537333734356636663737366536353634356637333734373236393665363735663332333835663665363136643635363435663337333333373334333633343566333633393336363635663334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": string }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f373337343634326536393666326534353732373236663732 }>;
type MLData_72705f3532366637353734363537323532363537333735366337343566333133373566373237353733373435663666373736653635363435663733373437323639366536373566333333363566366536313664363536343566333733333337333433363334356633363335333636353337333635663335333633363331333733323334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": string }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3733373436343265363536653736326535363631373234353732373236663732 }>;
type MLData_72705f35323666373537343635373235323635373337353663373435663331333735663732373537333734356636663737366536353634356637333734373236393665363735663333333735663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": string }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326534353732373236663732 }>;
type MLData_72705f35323666373537343635373235323635373337353663373435663331333735663732373537333734356636663737366536353634356637363635363335663735333835663333333735663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": ReadonlyArray<bigint> }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326534353732373236663732 }>;
type MLData_72705f353236663735373436353732353236353733373536633734356633333332356636653631366436353634356633353332333633353336333333363636333733323336333433343636333733353337333433363333333636363336363433363335356633323336356636653631366436353634356633353333333733343336363633373332333633353334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": MLData_72705f3532363536333666373236343466373537343633366636643635 }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3533373436663732363534353732373236663732 }>;
type MLData_72705f353236663735373436353732353236353733373536633734356633333332356636653631366436353634356633353332333633353337333333373330333636363336363533373333333633353334363633373337333636353336333533373332356633313337356637323735373337343566366637373665363536343566373337343732363936653637 = Readonly<{ readonly "$": "Ok"; readonly "field0": MLData_72705f3532363537333730366636653733363534663737366536353732 }> | Readonly<{ readonly "$": "Err"; readonly "field0": string }>;
type MLData_72705f3532366637353734363537323532363537333735366337343566333333373566366536313664363536343566333733333336333533373332333633343336333533353636333636313337333333363636333636353566333533363336333133363633333733353336333535663333333735663665363136643635363435663337333333363335333733323336333433363335333536363336363133373333333636363336363535663334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326535363631366337353635 }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326534353732373236663732 }>;
type MLData_72705f35323666373537343635373235323635373337353663373435663333333835663665363136643635363435663337333333373334333633343566333733343336333933363634333633353566333433343337333533373332333633313337333433363339333636363336363535663336333435663665363136643635363435663337333333373334333633343566333733343336333933363634333633353566333533343337333233373339333433363337333233363636333636343334333633363633333636363336333133373334333533333336333533363333333733333334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": MLData_72705f37333734363432653734363936643635326534343735373236313734363936663665 }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f373337343634326537343639366436353265353437323739343637323666366434363663366636313734353336353633373334353732373236663732 }>;
type MLData_72705f3532366637353734363537323532363537333735366337343566333435663632366636663663356633323336356636653631366436353634356633353333333733343336363633373332333633353334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": boolean }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3533373436663732363534353732373236663732 }>;
type MLData_72705f3532366637353734363537323532363537333735366337343566333435663735366536393734356633323336356636653631366436353634356633353333333733343336363633373332333633353334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": null }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f3533373436663732363534353732373236663732 }>;
type MLData_72705f353236663735373436353732353236353733373536633734356633343566373536653639373435663332333835663665363136643635363435663337333333373334333633343566333633393336363635663334333533373332333733323336363633373332 = Readonly<{ readonly "$": "Ok"; readonly "field0": null }> | Readonly<{ readonly "$": "Err"; readonly "field0": MLData_72705f373337343634326536393666326534353732373236663732 }>;
type MLData_72705f35323666373537343635373235343735373036633635356633343330356636653631366436353634356633353332333633353337333333373330333636363336363533373333333633353334363533363331333636343336333533373333333733303336333133363333333633353566333433303566366536313664363536343566333533323336333533373333333733303336363633363635333733333336333533343635333633313336363433363335333733333337333033363331333633333336333535663732373537333734356633353632333736323337363433323633333736323337363433353634 = Readonly<{ readonly "$": "Tuple"; readonly "field0": MLData_72705f35323635373337303666366537333635346536313664363537333730363136333635; readonly "field1": MLData_72705f35323635373337303666366537333635346536313664363537333730363136333635 }>;
type MLData_72705f3533373436663732363534353732373236663732 = Readonly<{ readonly "$": "Io"; readonly "field0": MLData_72705f373337343634326536393666326534353732373236663732 }> | Readonly<{ readonly "$": "Decode"; readonly "field0": MLData_72705f3733363537323634363535663661373336663665326534353732373236663732 }> | Readonly<{ readonly "$": "Collision" }> | Readonly<{ readonly "$": "Invalid"; readonly "field0": string }>;
type MLData_72705f3733363537323634363535663661373336663665326534353732373236663732 = Readonly<{ readonly "$": "JsonError"; readonly "category": MLData_72705f3733363537323634363535663661373336663665326536353732373236663732326534333631373436353637366637323739; readonly "line": bigint; readonly "column": bigint; readonly "message": string }>;
type MLData_72705f3733363537323634363535663661373336663665326534643631373034353665373437323739 = Readonly<{ readonly "$": "MapEntry"; readonly "key": string; readonly "value": MLData_72705f3733363537323634363535663661373336663665326535363631366337353635 }>;
type MLData_72705f373336353732363436353566366137333666366532653464363137303566353337343732363936653637356635363631366337353635 = Readonly<{ readonly "$": "Map"; readonly "entries": ReadonlyArray<MLData_72705f3733363537323634363535663661373336663665326534643631373034353665373437323739> }>;
type MLData_72705f37333635373236343635356636613733366636653265346537353664363236353732 = Readonly<{ readonly "$": "PosInt"; readonly "field0": bigint }> | Readonly<{ readonly "$": "NegInt"; readonly "field0": bigint }> | Readonly<{ readonly "$": "Float"; readonly "field0": number }>;
type MLData_72705f3733363537323634363535663661373336663665326535363631366337353635 = Readonly<{ readonly "$": "Null" }> | Readonly<{ readonly "$": "Bool"; readonly "field0": boolean }> | Readonly<{ readonly "$": "Number"; readonly "field0": MLData_72705f37333635373236343635356636613733366636653265346537353664363236353732 }> | Readonly<{ readonly "$": "String"; readonly "field0": string }> | Readonly<{ readonly "$": "Array"; readonly "field0": ReadonlyArray<MLData_72705f3733363537323634363535663661373336663665326535363631366337353635> }> | Readonly<{ readonly "$": "Object"; readonly "field0": MLData_72705f373336353732363436353566366137333666366532653464363137303566353337343732363936653637356635363631366337353635 }>;
type MLData_72705f3733363537323634363535663661373336663665326536353732373236663732326534333631373436353637366637323739 = Readonly<{ readonly "$": "Io" }> | Readonly<{ readonly "$": "Syntax" }> | Readonly<{ readonly "$": "Data" }> | Readonly<{ readonly "$": "Eof" }>;
type MLData_72705f3733373436343265363536653736326535363631373234353732373236663732 = Readonly<{ readonly "$": "NotPresent" }> | Readonly<{ readonly "$": "NotUnicode"; readonly "field0": MLData_72705f3733373436343265363636363639326534663733353337343732363936653637 }>;
type MLData_72705f3733373436343265363636363639326534663733353337343732363936653637 = Readonly<{ readonly "$": "OsString"; readonly "bytes": ReadonlyArray<bigint> }>;
type MLData_72705f373337343634326536393666326534353732373236663732 = Readonly<{ readonly "$": "IoError"; readonly "kind": string; readonly "message": string; readonly "raw_os_error": MLData_72705f353236663735373436353732346637303734363936663665356633333566363933333332 }>;
type MLData_72705f37333734363432653665373536643265343936653734343537323732366637323462363936653634 = Readonly<{ readonly "$": "Empty" }> | Readonly<{ readonly "$": "InvalidDigit" }> | Readonly<{ readonly "$": "PosOverflow" }> | Readonly<{ readonly "$": "NegOverflow" }> | Readonly<{ readonly "$": "Zero" }>;
type MLData_72705f373337343634326536653735366432653530363137323733363534393665373434353732373236663732 = Readonly<{ readonly "$": "ParseIntError"; readonly "kind": MLData_72705f37333734363432653665373536643265343936653734343537323732366637323462363936653634 }>;
type MLData_72705f37333734363432653734363936643635326534343735373236313734363936663665 = Readonly<{ readonly "$": "Duration"; readonly "secs": bigint; readonly "nanos": bigint }>;
type MLData_72705f373337343634326537343639366436353265353437323739343637323666366434363663366636313734353336353633373334353732373236663732 = Readonly<{ readonly "$": "TryFromFloatSecsError"; readonly "kind": MLData_72705f3733373436343265373436393664363532653534373237393436373236663664343636633666363137343533363536333733343537323732366637323462363936653634 }>;
type MLData_72705f3733373436343265373436393664363532653534373237393436373236663664343636633666363137343533363536333733343537323732366637323462363936653634 = Readonly<{ readonly "$": "Negative" }> | Readonly<{ readonly "$": "OverflowOrNan" }>;
import { validateRustValue as ml_validate_rust_value } from "../runtime/type-layout-runtime.mjs";

import { std_time_duration_from_secs as ml_host_std_time_duration_from_secs } from "../runtime/time-runtime.mjs";

import { assertImmutableCopy as ml_assert_immutable_copy } from "../runtime/copy-runtime.mjs";

function ml_fixed(value: bigint, min: bigint, max: bigint, message: string) {
  if (value < min || value > max) throw new RangeError(message);
  return value;
}

const ml_host_value_schema_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef = {"schemaVersion":1,"types":{"rp_526573706f6e73654e616d657370616365":{"kind":"data","name":"rp_526573706f6e73654e616d657370616365","ctors":[{"name":"OpenAiResponses","fields":[]},{"name":"CodexResponses","fields":[]},{"name":"QwenResponses","fields":[]},{"name":"OpenAiChat","fields":[]},{"name":"CodexChat","fields":[]},{"name":"QwenChat","fields":[]},{"name":"OpenAiConversations","fields":[]},{"name":"CodexConversations","fields":[]},{"name":"QwenConversations","fields":[]},{"name":"OpenAiConversationItems","fields":[]},{"name":"CodexConversationItems","fields":[]},{"name":"QwenConversationItems","fields":[]},{"name":"OpenAiRealtimeCalls","fields":[]},{"name":"CodexRealtimeCalls","fields":[]},{"name":"AnthropicFiles","fields":[]},{"name":"AnthropicBatches","fields":[]},{"name":"AnthropicSkills","fields":[]},{"name":"AnthropicSkillVersions","fields":[]},{"name":"CodexFiles","fields":[]},{"name":"CodexMcpSessions","fields":[]},{"name":"CodexPluginInstalls","fields":[]},{"name":"CodexPluginUploads","fields":[]},{"name":"CodexWorkspacePlugins","fields":[]}]}}};

const ml_host_value_refinements_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef = new Map([]);

const ml_host_value_schema_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846 = {"schemaVersion":1,"types":{"rp_5265636f72644f7574636f6d65":{"kind":"data","name":"rp_5265636f72644f7574636f6d65","ctors":[{"name":"Inserted","fields":[]},{"name":"Existing","fields":[]}]}}};

const ml_host_value_refinements_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846 = new Map([]);

function rp_46494c455f4e414d45(): string {
  return "response-affinities.lino";
}

function rp_53544f52455f56455253494f4e(): bigint {
  return 1n;
}

function rp_44454641554c545f54544c(): Readonly<{ readonly "$": "Duration"; readonly "secs": bigint; readonly "nanos": bigint }> {
  return ml_host_std_time_duration_from_secs(ml_fixed((ml_fixed((ml_fixed((30n * 24n), 0n, 18446744073709551615n, "attempt to multiply with overflow") * 60n), 0n, 18446744073709551615n, "attempt to multiply with overflow") * 60n), 0n, 18446744073709551615n, "attempt to multiply with overflow"));
}

function rp_44454641554c545f4d41585f5245434f524453(): bigint {
  return 10000n;
}

function rp_4d41585f524553504f4e53455f49445f4259544553(): bigint {
  return 256n;
}

function rp_6d6c5f696d706c5f363337323631373436353265353236353733373036663665373336353465363136643635373337303631363336355f363637323666366435663730363137343638(path: string): Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": Readonly<{ readonly "$": "OpenAiResponses" }> | Readonly<{ readonly "$": "CodexResponses" }> | Readonly<{ readonly "$": "QwenResponses" }> | Readonly<{ readonly "$": "OpenAiChat" }> | Readonly<{ readonly "$": "CodexChat" }> | Readonly<{ readonly "$": "QwenChat" }> | Readonly<{ readonly "$": "OpenAiConversations" }> | Readonly<{ readonly "$": "CodexConversations" }> | Readonly<{ readonly "$": "QwenConversations" }> | Readonly<{ readonly "$": "OpenAiConversationItems" }> | Readonly<{ readonly "$": "CodexConversationItems" }> | Readonly<{ readonly "$": "QwenConversationItems" }> | Readonly<{ readonly "$": "OpenAiRealtimeCalls" }> | Readonly<{ readonly "$": "CodexRealtimeCalls" }> | Readonly<{ readonly "$": "AnthropicFiles" }> | Readonly<{ readonly "$": "AnthropicBatches" }> | Readonly<{ readonly "$": "AnthropicSkills" }> | Readonly<{ readonly "$": "AnthropicSkillVersions" }> | Readonly<{ readonly "$": "CodexFiles" }> | Readonly<{ readonly "$": "CodexMcpSessions" }> | Readonly<{ readonly "$": "CodexPluginInstalls" }> | Readonly<{ readonly "$": "CodexPluginUploads" }> | Readonly<{ readonly "$": "CodexWorkspacePlugins" }> }> {
  if (!(typeof path === 'string' && !/[\ud800-\udbff](?![\udc00-\udfff])|(?<![\ud800-\udbff])[\udc00-\udfff]/u.test(path))) throw new TypeError('argument outside supported Rust value domain');
  if ((() => {
    const ml_text_1 = path;
    const ml_text_2 = "/api/services/openai/v1/responses";
    return ml_text_1.startsWith(ml_text_2);
  })()) {
    return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'OpenAiResponses' }) });
  } else {
    if ((() => {
    const ml_text_3 = path;
    const ml_text_4 = "/api/services/codex/v1/responses";
    return ml_text_3.startsWith(ml_text_4);
  })()) {
      return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'CodexResponses' }) });
    } else {
      if ((() => {
    const ml_text_5 = path;
    const ml_text_6 = "/api/services/qwen/v1/responses";
    return ml_text_5.startsWith(ml_text_6);
  })()) {
        return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'QwenResponses' }) });
      } else {
        if ((() => {
    const ml_text_7 = path;
    const ml_text_8 = "/api/services/openai/v1/chat/completions";
    return ml_text_7.startsWith(ml_text_8);
  })()) {
          return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'OpenAiChat' }) });
        } else {
          if ((() => {
    const ml_text_9 = path;
    const ml_text_10 = "/api/services/codex/v1/chat/completions";
    return ml_text_9.startsWith(ml_text_10);
  })()) {
            return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'CodexChat' }) });
          } else {
            if ((() => {
    const ml_text_11 = path;
    const ml_text_12 = "/api/services/qwen/v1/chat/completions";
    return ml_text_11.startsWith(ml_text_12);
  })()) {
              return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'QwenChat' }) });
            } else {
              return Object.freeze({ $: 'None' });
            }
          }
        }
      }
    }
  }
}

function rp_6d6c5f696d706c5f363337323631373436353265353236353733373036663665373336353465363136643635373337303631363336355f36333666366537363635373237333631373436393666366537333566363637323666366435663730363137343638(path: string): Readonly<{ readonly "$": "None" }> | Readonly<{ readonly "$": "Some"; readonly "field0": Readonly<{ readonly "$": "Tuple"; readonly "field0": Readonly<{ readonly "$": "OpenAiResponses" }> | Readonly<{ readonly "$": "CodexResponses" }> | Readonly<{ readonly "$": "QwenResponses" }> | Readonly<{ readonly "$": "OpenAiChat" }> | Readonly<{ readonly "$": "CodexChat" }> | Readonly<{ readonly "$": "QwenChat" }> | Readonly<{ readonly "$": "OpenAiConversations" }> | Readonly<{ readonly "$": "CodexConversations" }> | Readonly<{ readonly "$": "QwenConversations" }> | Readonly<{ readonly "$": "OpenAiConversationItems" }> | Readonly<{ readonly "$": "CodexConversationItems" }> | Readonly<{ readonly "$": "QwenConversationItems" }> | Readonly<{ readonly "$": "OpenAiRealtimeCalls" }> | Readonly<{ readonly "$": "CodexRealtimeCalls" }> | Readonly<{ readonly "$": "AnthropicFiles" }> | Readonly<{ readonly "$": "AnthropicBatches" }> | Readonly<{ readonly "$": "AnthropicSkills" }> | Readonly<{ readonly "$": "AnthropicSkillVersions" }> | Readonly<{ readonly "$": "CodexFiles" }> | Readonly<{ readonly "$": "CodexMcpSessions" }> | Readonly<{ readonly "$": "CodexPluginInstalls" }> | Readonly<{ readonly "$": "CodexPluginUploads" }> | Readonly<{ readonly "$": "CodexWorkspacePlugins" }>; readonly "field1": Readonly<{ readonly "$": "OpenAiResponses" }> | Readonly<{ readonly "$": "CodexResponses" }> | Readonly<{ readonly "$": "QwenResponses" }> | Readonly<{ readonly "$": "OpenAiChat" }> | Readonly<{ readonly "$": "CodexChat" }> | Readonly<{ readonly "$": "QwenChat" }> | Readonly<{ readonly "$": "OpenAiConversations" }> | Readonly<{ readonly "$": "CodexConversations" }> | Readonly<{ readonly "$": "QwenConversations" }> | Readonly<{ readonly "$": "OpenAiConversationItems" }> | Readonly<{ readonly "$": "CodexConversationItems" }> | Readonly<{ readonly "$": "QwenConversationItems" }> | Readonly<{ readonly "$": "OpenAiRealtimeCalls" }> | Readonly<{ readonly "$": "CodexRealtimeCalls" }> | Readonly<{ readonly "$": "AnthropicFiles" }> | Readonly<{ readonly "$": "AnthropicBatches" }> | Readonly<{ readonly "$": "AnthropicSkills" }> | Readonly<{ readonly "$": "AnthropicSkillVersions" }> | Readonly<{ readonly "$": "CodexFiles" }> | Readonly<{ readonly "$": "CodexMcpSessions" }> | Readonly<{ readonly "$": "CodexPluginInstalls" }> | Readonly<{ readonly "$": "CodexPluginUploads" }> | Readonly<{ readonly "$": "CodexWorkspacePlugins" }> }> }> {
  if (!(typeof path === 'string' && !/[\ud800-\udbff](?![\udc00-\udfff])|(?<![\ud800-\udbff])[\udc00-\udfff]/u.test(path))) throw new TypeError('argument outside supported Rust value domain');
  if ((() => {
    const ml_text_1 = path;
    const ml_text_2 = "/api/services/openai/v1/conversations";
    return ml_text_1.startsWith(ml_text_2);
  })()) {
    return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'Tuple', field0: Object.freeze({ $: 'OpenAiConversations' }), field1: Object.freeze({ $: 'OpenAiConversationItems' }) }) });
  } else {
    if ((() => {
    const ml_text_3 = path;
    const ml_text_4 = "/api/services/codex/v1/conversations";
    return ml_text_3.startsWith(ml_text_4);
  })()) {
      return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'Tuple', field0: Object.freeze({ $: 'CodexConversations' }), field1: Object.freeze({ $: 'CodexConversationItems' }) }) });
    } else {
      if ((() => {
    const ml_text_5 = path;
    const ml_text_6 = "/api/services/qwen/v1/conversations";
    return ml_text_5.startsWith(ml_text_6);
  })()) {
        return Object.freeze({ $: 'Some', field0: Object.freeze({ $: 'Tuple', field0: Object.freeze({ $: 'QwenConversations' }), field1: Object.freeze({ $: 'QwenConversationItems' }) }) });
      } else {
        return Object.freeze({ $: 'None' });
      }
    }
  }
}

function rp_6d6c5f696d706c5f363337323631373436353265353236353733373036663665373336353465363136643635373337303631363336355f36333663366636653635(ml_clone_self: Readonly<{ readonly "$": "OpenAiResponses" }> | Readonly<{ readonly "$": "CodexResponses" }> | Readonly<{ readonly "$": "QwenResponses" }> | Readonly<{ readonly "$": "OpenAiChat" }> | Readonly<{ readonly "$": "CodexChat" }> | Readonly<{ readonly "$": "QwenChat" }> | Readonly<{ readonly "$": "OpenAiConversations" }> | Readonly<{ readonly "$": "CodexConversations" }> | Readonly<{ readonly "$": "QwenConversations" }> | Readonly<{ readonly "$": "OpenAiConversationItems" }> | Readonly<{ readonly "$": "CodexConversationItems" }> | Readonly<{ readonly "$": "QwenConversationItems" }> | Readonly<{ readonly "$": "OpenAiRealtimeCalls" }> | Readonly<{ readonly "$": "CodexRealtimeCalls" }> | Readonly<{ readonly "$": "AnthropicFiles" }> | Readonly<{ readonly "$": "AnthropicBatches" }> | Readonly<{ readonly "$": "AnthropicSkills" }> | Readonly<{ readonly "$": "AnthropicSkillVersions" }> | Readonly<{ readonly "$": "CodexFiles" }> | Readonly<{ readonly "$": "CodexMcpSessions" }> | Readonly<{ readonly "$": "CodexPluginInstalls" }> | Readonly<{ readonly "$": "CodexPluginUploads" }> | Readonly<{ readonly "$": "CodexWorkspacePlugins" }>): Readonly<{ readonly "$": "OpenAiResponses" }> | Readonly<{ readonly "$": "CodexResponses" }> | Readonly<{ readonly "$": "QwenResponses" }> | Readonly<{ readonly "$": "OpenAiChat" }> | Readonly<{ readonly "$": "CodexChat" }> | Readonly<{ readonly "$": "QwenChat" }> | Readonly<{ readonly "$": "OpenAiConversations" }> | Readonly<{ readonly "$": "CodexConversations" }> | Readonly<{ readonly "$": "QwenConversations" }> | Readonly<{ readonly "$": "OpenAiConversationItems" }> | Readonly<{ readonly "$": "CodexConversationItems" }> | Readonly<{ readonly "$": "QwenConversationItems" }> | Readonly<{ readonly "$": "OpenAiRealtimeCalls" }> | Readonly<{ readonly "$": "CodexRealtimeCalls" }> | Readonly<{ readonly "$": "AnthropicFiles" }> | Readonly<{ readonly "$": "AnthropicBatches" }> | Readonly<{ readonly "$": "AnthropicSkills" }> | Readonly<{ readonly "$": "AnthropicSkillVersions" }> | Readonly<{ readonly "$": "CodexFiles" }> | Readonly<{ readonly "$": "CodexMcpSessions" }> | Readonly<{ readonly "$": "CodexPluginInstalls" }> | Readonly<{ readonly "$": "CodexPluginUploads" }> | Readonly<{ readonly "$": "CodexWorkspacePlugins" }> {
  ml_assert_immutable_copy(ml_clone_self);
  ml_validate_rust_value(ml_clone_self, {"kind":"data","name":"rp_526573706f6e73654e616d657370616365"}, ml_host_value_schema_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef, { refinements: ml_host_value_refinements_dbaa90b61a7e970f70e33a8976c9ffa0c88f45b6154a6983410594dd5ba42bef });
  return ml_clone_self;
}

function rp_6d6c5f696d706c5f36333732363137343635326535323635363336663732363434663735373436333666366436355f36333663366636653635(ml_clone_self: Readonly<{ readonly "$": "Inserted" }> | Readonly<{ readonly "$": "Existing" }>): Readonly<{ readonly "$": "Inserted" }> | Readonly<{ readonly "$": "Existing" }> {
  ml_assert_immutable_copy(ml_clone_self);
  ml_validate_rust_value(ml_clone_self, {"kind":"data","name":"rp_5265636f72644f7574636f6d65"}, ml_host_value_schema_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846, { refinements: ml_host_value_refinements_a5c1efd2c5a45b6ce1290ad999dbc91a0f722690ea593b8dade8f356a8be7846 });
  return ml_clone_self;
}
export const translated: Readonly<{ "FILE_NAME": string; "STORE_VERSION": bigint; "DEFAULT_TTL": Readonly<{ readonly "$": "Duration"; readonly "secs": bigint; readonly "nanos": bigint }>; "DEFAULT_MAX_RECORDS": bigint; "MAX_RESPONSE_ID_BYTES": bigint }> = Object.freeze({ ["FILE_NAME"]: rp_46494c455f4e414d45(), ["STORE_VERSION"]: rp_53544f52455f56455253494f4e(), ["DEFAULT_TTL"]: rp_44454641554c545f54544c(), ["DEFAULT_MAX_RECORDS"]: rp_44454641554c545f4d41585f5245434f524453(), ["MAX_RESPONSE_ID_BYTES"]: rp_4d41585f524553504f4e53455f49445f4259544553() });
export const provenance = {"entry":"src/response_affinity.rs","runtimeParity":false,"moduleCount":1,"executableFunctions":0,"executableConstants":5};
