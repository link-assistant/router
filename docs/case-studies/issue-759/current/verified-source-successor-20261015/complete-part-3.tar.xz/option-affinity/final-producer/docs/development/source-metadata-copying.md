# Preserve metadata checks while reducing result construction

Source links validate every own descriptor before traversing child values.
Their metadata copier still rejects proxies, accessors, symbols, hidden
properties, unsupported prototypes, cycles, non-integer numbers, array holes
and extras. The shared 200,000-cell, 4 MiB UTF-8 and depth-160 limits remain.
Canonical field ordering and the original ordering inside Copy-certificate
envelopes remain unchanged.

The optimized route retains the complete original descriptor snapshot. It
assigns copied fields to a newly created, unpublished null-prototype result,
which has no inherited setters. It operates only with unchanged captured
intrinsic bindings and prototype keys, ordinary numeric budgets and private
recursion state. The previous copier handles all other cases. No metadata,
mutable caller object, Map or successful semantic result is cached.

Node 20's global Buffer accessor selects the previous route. Bun 1.4.3's
ordinary data binding permits the optimized route. Five paired translations
of unchanged `src/response_affinity.rs` observed Bun median 3743.12 → 3636.00
milliseconds, with identical complete meta, JavaScript and TypeScript bytes.
The waited-child maximum RSS rose from 1.402 GB to 1.460 GB; it is neither
aggregate concurrent memory nor a memory saving. Rejected direct-descriptor
entry experiments and their complete outputs were retained separately.

These bounded measurements do not establish whole-corpus speed, complete
translation, Rust verification or runtime parity. Original source ownership,
private proof joins and all executable-body refusals remain independent.
