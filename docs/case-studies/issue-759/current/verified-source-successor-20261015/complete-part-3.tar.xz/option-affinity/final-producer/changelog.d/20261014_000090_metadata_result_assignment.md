Reduce metadata copying work by assigning validated fields directly to fresh
null-prototype results while preserving the complete descriptor snapshot,
budgets, cycles, refusal messages and signed Copy-certificate key order.
The previous copier remains the fallback for changed intrinsic machinery,
accessor bindings and caller recursion state; no caller data is cached.

Five unchanged response-affinity source trials observed a 2.86% lower Bun
median, with byte-identical meta/JavaScript/TypeScript. Node 20 retains its
previous route because its global Buffer binding is an accessor. Observed RSS
increased; these measurements establish no memory savings or runtime parity.
