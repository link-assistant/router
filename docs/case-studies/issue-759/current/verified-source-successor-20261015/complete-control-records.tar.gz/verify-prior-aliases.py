from pathlib import Path
import sys,json,time,hashlib,collections
sys.path.insert(0,str(Path('tools/evidence').resolve()));from packet import PacketStore,relative
p=Path('packages/javascript/node_modules/.issue-759-verification/followup-complete-pack-plan-v1');index=json.loads((p/'final-complete-logical-member-index.json').read_text());aliases=[r for r in index['members'] if r['representation']['kind']=='complete-immutable-packet-member'];store=PacketStore(p/'prior-packet-alias-overlay',Path('../issue-759-gate').resolve(),cap_seconds=120);start=time.monotonic();verified={};receipts={}
for r in aliases:
 w=r['representation']['container'];name=w['path'].removeprefix('docs/case-studies/issue-759/');
 if name not in verified:
  receipt=json.loads((Path('../issue-759-gate/docs/case-studies/issue-759')/w['unchangedCompleteReceipt']).read_text());verified[name]=store.verify_members(name,receipt['members']);receipts[name]={member['path']:member for member in receipt['members']}
def validate(rows):
 names=set()
 for r in rows:
  name=relative(r['path']);assert name not in names;names.add(name);w=r['representation']['container'];path=w['path'].removeprefix('docs/case-studies/issue-759/');assert path in verified and store.archives[path]==(w['bytes'],w['sha256'],tuple(w[k] for k in ['commit','path','blob']));member=relative(r['representation']['member']);fact=receipts[path][member];assert (fact['bytes'],fact['sha256'])==(r['bytes'],r['sha256']);original=Path(r['originalPath']);assert original.is_file() and not original.is_symlink();h=hashlib.sha256()
  with original.open('rb') as stream:
   while b:=stream.read(1024*1024):h.update(b)
  assert original.stat().st_size==r['bytes'] and h.hexdigest()==r['sha256']
validate(aliases)
negative=[]
for label,mutate in [('changed-hash',lambda row:row.update(sha256='a'*64)),('changed-size',lambda row:row.update(bytes=row['bytes']+1)),('missing-member',lambda row:row['representation'].update(member='missing')),('foreign-container',lambda row:row['representation']['container'].update(path='docs/case-studies/issue-759/foreign.tar.xz')),('path-escape',lambda row:row.update(path='../escaped')),('changed-container-blob',lambda row:row['representation']['container'].update(blob='a'*40))]:
 row=json.loads(json.dumps(aliases[0]));mutate(row)
 try:validate([row])
 except (AssertionError,KeyError,ValueError):negative.append(label)
 else:raise AssertionError('Accepted '+label)
try:validate([aliases[0],aliases[0]])
except AssertionError:negative.append('duplicate-logical-path')
else:raise AssertionError('Accepted duplicate')
report={'schema':'complete-immutable-prior-packet-alias-recovery-v1','aliasesVerified':len(aliases),'completeOriginalAliasBytes':sum(r['bytes'] for r in aliases),'completeContainersVerified':verified,'allCurrentOriginalAliasFilesExact':True,'negativeControlsRefused':negative,'elapsedSeconds':time.monotonic()-start,'outerDeadlineSeconds':120,'originalsDeleted':False,'caseInstalled':False,'semanticAuthority':False,'runtimeParity':False};(p/'complete-prior-alias-recovery-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
