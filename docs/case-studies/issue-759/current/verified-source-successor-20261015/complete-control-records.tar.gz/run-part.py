from pathlib import Path
import subprocess,sys,json,time,datetime,resource,shutil
p=Path('packages/javascript/node_modules/.issue-759-verification/followup-complete-pack-plan-v1');part=sys.argv[1]
args=['python3','tools/evidence/capture-packet.py','--source-root','.', '--head','1f9f9422fdad9ab8824e2c26cb523da587a7114f','--manifest',str(p/('final-part-'+part+'-manifest.json')),'--archive',str(p/('complete-part-'+part+'.tar.xz')),'--receipt',str(p/('complete-part-'+part+'-receipt.json')),'--cap-seconds','600']
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();free=shutil.disk_usage(Path.cwd()).free
with (p/('complete-part-'+part+'.raw.log')).open('wb') as log:
 try:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=600);status=r.returncode
 except subprocess.TimeoutExpired:status=124
receipt={'command':args,'startUtc':started,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-start,'status':status,'outerDeadlineSeconds':600,'childMaximumResidentSetBytes':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'units':'macOS RUSAGE_CHILDREN ru_maxrss bytes; one capturechild per freshwrapper','freeDiskBytesBefore':free,'freeDiskBytesAfter':shutil.disk_usage(Path.cwd()).free,'caseInstalled':False}
(p/('complete-part-'+part+'-resource.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((p/('complete-part-'+part+'.raw.log')).read_text()[-3000:]);sys.exit(status)
