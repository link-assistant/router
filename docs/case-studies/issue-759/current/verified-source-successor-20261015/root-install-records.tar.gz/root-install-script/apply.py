"""Reviewed Root-only installer; default invocation performs read-only preflight."""
from pathlib import Path
import argparse,collections,datetime,gzip,hashlib,importlib.util,io,json,os,shutil,subprocess,sys,tarfile,time
HERE=Path(__file__).absolute().parent
PLAN=json.loads((HERE/'install-plan.json').read_bytes())
CAP=500000000

def digest_file(path):
    if not path.is_file() or any(p.is_symlink() for p in [path,*path.parents]):raise ValueError('linked/missing file: '+str(path))
    h=hashlib.sha256();n=0
    with path.open('rb') as f:
        while b:=f.read(1048576):h.update(b);n+=len(b)
    return n,h.hexdigest()

def allocated(case):
    seen=set();total=count=0
    for p in case.rglob('*'):
        if p.is_symlink():raise ValueError('linked case path')
        if p.is_file():
            s=p.stat();key=(s.st_dev,s.st_ino);count+=1
            if key not in seen:seen.add(key);total+=s.st_blocks*512
    if total>CAP:raise ValueError('fixed case cap exceeded')
    return {'allocatedBytes':total,'files':count,'distinctInodes':len(seen),'headroom':CAP-total}

def retired_allocation(case,path):
    target=path.stat();identity=(target.st_dev,target.st_ino);aliases=[]
    for candidate in case.rglob('*'):
        if candidate.is_file():
            fact=candidate.stat()
            if (fact.st_dev,fact.st_ino)==identity:aliases.append(candidate)
    if aliases!=[path]:raise ValueError('old container has other in-case inode aliases; savings require a new reviewed plan')
    return target.st_blocks*512

def exact(path,row):
    if digest_file(path)!=(row['bytes'],row['sha256']):raise ValueError('complete pinned bytes differ: '+str(path))

def read_json(path):
    raw=path.read_bytes()
    if path.suffix=='.gz':
        with gzip.GzipFile(fileobj=io.BytesIO(raw))as reader:raw=reader.read(16*1024*1024+1)
    if len(raw)>16*1024*1024:raise ValueError('bounded metadata exceeded')
    return json.loads(raw)

def safe_relative(value):
    if not isinstance(value,str)or not value or '\\'in value or '\x00'in value or value.startswith('/')or any(p in ['','.','..']for p in value.split('/')):raise ValueError('noncanonical relative path')
    return value

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',required=True);parser.add_argument('--expected-head',required=True);parser.add_argument('--apply',action='store_true');parser.add_argument('--output')
    args=parser.parse_args();root=Path(args.root).absolute();case=root/'docs/case-studies/issue-759'
    if any(p.is_symlink() for p in [root,*root.parents]):raise ValueError('linked repository')
    if len(args.expected_head)!=40 or any(c not in '0123456789abcdef' for c in args.expected_head):raise ValueError('exact expected SHA required')
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1')
    def git(*words):return subprocess.check_output(['git',*words],cwd=root,env=env,timeout=30)
    def stable():
        if git('rev-parse','HEAD').decode().strip()!=args.expected_head:raise ValueError('Root HEAD changed')
    stable();index_path=case/'packet-git-index.json';old=PLAN['oldArchive'];old_path=case/old['path']
    if digest_file(index_path)[1]!=PLAN['existingIndexSha256']:raise ValueError('existing index changed; prepare a new reviewed union')
    previous=read_json(index_path);successor=read_json(HERE/'packet-git-index.successor.json')
    if digest_file(HERE/'packet-git-index.successor.json')[1]!=PLAN['successorIndexSha256']:raise ValueError('successor index changed')
    if any(successor['archives'].get(k)!=v for k,v in previous['archives'].items()):raise ValueError('existing archive witness replaced')
    if set(successor['archives'])!=set(previous['archives'])|{old['path']}:raise ValueError('extra/missing successor witness')
    if successor['archives'][old['path']]!={k:old[k] for k in ['bytes','sha256','git']}:raise ValueError('wrong old archive witness')
    exact(old_path,old);git('merge-base','--is-ancestor',old['git']['commit'],args.expected_head)
    if git('rev-parse',old['git']['commit']+':'+old['git']['path']).decode().strip()!=old['git']['blob']:raise ValueError('wrong immutable blob')
    if int(git('cat-file','-s',old['git']['blob']))!=old['bytes']:raise ValueError('wrong immutable length')
    with subprocess.Popen(['git','cat-file','blob',old['git']['blob']],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL) as child:
        h=hashlib.sha256();n=0
        while b:=child.stdout.read(1048576):h.update(b);n+=len(b)
        if child.wait(timeout=30) or (n,h.hexdigest())!=(old['bytes'],old['sha256']):raise ValueError('actual immutable container bytes differ')
    before=allocated(case);safe_relative(old['path']);old_alloc=retired_allocation(case,old_path)
    if len(PLAN['files'])!=13 or len({r['path']for r in PLAN['files']})!=13:raise ValueError('exact13 files required')
    for row in PLAN['files']:
        safe_relative(row['path']);safe_relative(row['destination'])
        if '/'in row['path']or row['destination']!='current/verified-source-successor-20261015/'+row['path']:raise ValueError('foreign destination')
        exact(Path(row['source']),row)
        if (case/row['destination']).exists():raise ValueError('new destination already exists')
    report={'schema':'followup-existing-index-preflight-v2','expectedHead':args.expected_head,'before':before,'files':len(PLAN['files']),'compressedGitWitnessFullyHashed':True,'completeMemberDecodeExecuted':False,'caseMutated':False}
    if not args.apply:stable();print(json.dumps(report));return
    if not args.output:raise ValueError('--output required for explicit apply')
    out=Path(args.output).absolute()
    if not out.is_relative_to(root/'packages/javascript/node_modules/.issue-759-verification')or any(p.is_symlink()for p in [out,*out.parents]):raise ValueError('output must be an unlinked Root ignored verification path')
    out.mkdir(parents=True,exist_ok=False);stage=out/'staged';stage.mkdir()
    if stage.stat().st_dev!=case.stat().st_dev:raise ValueError('atomic same-volume staging required')
    def save(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
    save('before.json',report);(out/'original-index.json').write_bytes(index_path.read_bytes())
    for row in PLAN['files']:
        p=stage/row['path'];shutil.copyfile(row['source'],p);exact(p,row)
    staged=sum((stage/row['path']).stat().st_blocks*512 for row in PLAN['files'])
    if retired_allocation(case,old_path)!=old_alloc:raise ValueError('old container allocation/aliases changed')
    if before['allocatedBytes']-old_alloc+staged+PLAN['metadataReserveBytes']>CAP:raise ValueError('actual staged allocation cannot fit fixed cap')
    def command(label,words,limit=600):
        stable();t=time.monotonic()
        error=None;result=None
        try:
            with (out/(label+'.stdout.raw.log')).open('xb')as a,(out/(label+'.stderr.raw.log')).open('xb')as b:
                result=subprocess.run(words,cwd=root,stdout=a,stderr=b,timeout=limit)
        except BaseException as failure:
            error=failure
        finally:
            save(label+'.command.json',{'argv':words,'exitCode':result.returncode if result else None,'elapsedSeconds':time.monotonic()-t,'limitSeconds':limit,'error':repr(error) if error else None})
        if error:raise error
        stable()
        if result.returncode:raise ValueError('mandatory command failed: '+label)
    # The old index is never edited in-place; its original bytes stay retained.
    new_index=stage/'successor-index.json';new_index.write_bytes((HERE/'packet-git-index.successor.json').read_bytes())
    if allocated(case)['allocatedBytes']+new_index.stat().st_blocks*512-index_path.stat().st_blocks*512+PLAN['metadataReserveBytes']>CAP:raise ValueError('index/reserve cannot fit')
    os.replace(new_index,index_path)
    old_receipt=case/old['unchangedReceipt'];old_receipt_before=digest_file(old_receipt)
    base=['python3','tools/evidence/packet.py','--case-root',str(case),'--repository-root',str(root),'--packet',old['path'],'--members-receipt',str(old_receipt),'--cap-seconds','120']
    ci=['python3','docs/case-studies/issue-759/raw/ci/verify-archive.py','--root',str(case/'raw/ci'),'--git-root',str(root)]
    measure=['node','scripts/measure-js-first.mjs',str(case/'raw')]
    command('old-present',base,120);command('ci-before',ci+['--output',str(out/'ci-before.json')]);command('measure-before',measure+['--output',str(out/'measure-before.json')])
    # Every alias joins the exact whole-container decode to its unchanged receipt.
    sys.path.insert(0,str(root/'tools/evidence'));from packet import PacketStore,relative
    logical=read_json(stage/'complete-logical-member-index.json.gz');aliases=[r for r in logical['members']if r['representation']['kind']=='complete-immutable-packet-member']
    if len(logical['members'])!=5010 or len({relative(r['path'])for r in logical['members']})!=5010 or sum(r['bytes']for r in logical['members'])!=2671317008:raise ValueError('duplicate/incomplete logical originals')
    old_rows=read_json(old_receipt)['members'];by_name={r['path']:r for r in old_rows}
    if len(by_name)!=len(old_rows):raise ValueError('duplicate old member')
    if len(old_rows)!=1270 or sum(r['bytes']for r in old_rows)!=680857769:raise ValueError('old complete receipt changed')
    def aliases_exact():
        store=PacketStore(case,root,cap_seconds=120);decoded=store.verify_members(old['path'],old_rows);seen=set()
        for row in aliases:
            name=relative(row['path']);w=row['representation']['container'];member=relative(row['representation']['member'])
            if name in seen:raise ValueError('duplicate logical alias')
            seen.add(name)
            if w!={**old['git'],'bytes':old['bytes'],'sha256':old['sha256'],'unchangedCompleteReceipt':old['unchangedReceipt']}:raise ValueError('wrong alias immutable witness')
            fact=by_name[member]
            if (row['bytes'],row['sha256'])!=(fact['bytes'],fact['sha256']):raise ValueError('alias does not join actual decoded member')
        if len(seen)!=945 or sum(r['bytes']for r in aliases)!=404479358:raise ValueError('alias inventory changed')
        return {'decoded':decoded,'aliases':len(seen),'fullLogicalBytes':404479358,'originalHistoricalPathsRewritten':False}
    save('old-present-aliases.json',aliases_exact());stable()
    if retired_allocation(case,old_path)!=old_alloc:raise ValueError('old inode allocation/aliases changed before retirement')
    old_path.unlink();allocated(case)
    command('old-absent',base,120);save('old-absent-aliases.json',aliases_exact());command('ci-absent',ci+['--output',str(out/'ci-absent.json')]);command('measure-absent',measure+['--output',str(out/'measure-absent.json')])
    baseline=read_json(out/'measure-before.json')
    if read_json(out/'measure-absent.json')!=baseline:raise ValueError('whole measurements changed')
    for row in PLAN['files']:
        src=stage/row['path'];dst=case/row['destination'];dst.parent.mkdir(parents=True,exist_ok=True);exact(src,row)
        if dst.exists():raise ValueError('destination replacement refused')
        if allocated(case)['allocatedBytes']+src.stat().st_blocks*512+PLAN['metadataReserveBytes']>CAP:raise ValueError('atomic move/reserve exceeds fixed cap')
        os.rename(src,dst);exact(dst,row);allocated(case)
    spec=importlib.util.spec_from_file_location('capture',root/'tools/evidence/capture-packet.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture);new_verified=[];part_rows={}
    destination=case/'current/verified-source-successor-20261015'
    for part in [1,2,3]:
        rec=read_json(destination/f'complete-part-{part}-receipt.json.gz');rows=rec['members'];capture.verify_archive(destination/f'complete-part-{part}.tar.xz',rows,time.monotonic()+600);part_rows[part]={r['path']:r for r in rows};new_verified.extend(rows)
    if len(new_verified)!=4065 or sum(r['bytes']for r in new_verified)!=2266837650:raise ValueError('complete new inventory changed')
    new_logical=[r for r in logical['members']if r['representation']['kind']=='new-complete-packet-member'];seen=set()
    for row in new_logical:
        name=relative(row['path']);rep=row['representation'];fact=part_rows[rep['part']][relative(rep['member'])]
        if name in seen or (row['bytes'],row['sha256'])!=(fact['bytes'],fact['sha256']):raise ValueError('new logical member mismatch')
        seen.add(name)
        if rep['archive']!=f'current/verified-source-successor-20261015/complete-part-{rep["part"]}.tar.xz'or rep['receipt']!=f'current/verified-source-successor-20261015/complete-part-{rep["part"]}-receipt.json.gz':raise ValueError('foreign logical archive/receipt')
        arc=next(r for r in PLAN['files']if r['destination']==rep['archive'])
        if (rep['archiveBytes'],rep['archiveSha256'])!=(arc['bytes'],arc['sha256']):raise ValueError('new archive witness mismatch')
    if len(seen)!=4065 or len(logical['members'])!=5010:raise ValueError('logical inventory incomplete')
    controls=read_json(destination/'complete-control-records-receipt.json');wanted={r['path']:(r['bytes'],r['sha256']) for r in controls['members']};control_seen={}
    if len(wanted)!=36 or sum(r[0] for r in wanted.values())!=controls['completeOriginalBytes']:raise ValueError('complete control inventory changed')
    with tarfile.open(destination/'complete-control-records.tar.gz','r|gz') as archive:
        for member in archive:
            name=relative(member.name)
            if name in control_seen or name not in wanted or not member.isfile() or member.size!=wanted[name][0]:raise ValueError('unsafe/extra control member')
            h=hashlib.sha256();n=0
            with archive.extractfile(member) as stream:
                while b:=stream.read(1048576):h.update(b);n+=len(b)
            if (n,h.hexdigest())!=wanted[name]:raise ValueError('control full bytes changed')
            control_seen[name]=(n,h.hexdigest())
    if set(control_seen)!=set(wanted):raise ValueError('missing complete control member')
    save('complete-controls.json',{'completeMembers':36,'completeOriginalBytes':sum(r[0]for r in control_seen.values()),'allDecodedOriginalsVerified':True})
    witnesses=read_json(destination/'complete-root-reachable-source-witnesses.json.gz')['members'];trees={}
    if len(witnesses)!=3120:raise ValueError('original source witness count changed')
    for commit in sorted(set(r['commit']for r in witnesses)):
        git('merge-base','--is-ancestor',commit,args.expected_head);entries={}
        for line in git('ls-tree','-r','-z',commit).split(b'\0'):
            if not line:continue
            facts,path=line.split(b'\t',1);mode,kind,blob=facts.decode().split(' ')
            if kind=='blob':entries[path.decode()]=(mode,blob)
        trees[commit]=entries
    deadline=time.monotonic()+600;source_bytes=0
    with subprocess.Popen(['git','cat-file','--batch'],cwd=root,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)as batch:
        for row in witnesses:
            if time.monotonic()>deadline:raise TimeoutError('complete source witness deadline exceeded')
            if trees[row['commit']].get(relative(row['path'])) not in [('100644',row['blob']),('100755',row['blob'])]:raise ValueError('wrong/linked source witness')
            batch.stdin.write((row['blob']+'\n').encode());batch.stdin.flush();header=batch.stdout.readline().decode().strip().split(' ')
            if header!=[row['blob'],'blob',str(row['bytes'])]:raise ValueError('wrong complete source blob/length')
            h=hashlib.sha256();left=row['bytes']
            while left:
                data=batch.stdout.read(min(1048576,left))
                if not data:raise ValueError('truncated full source witness')
                h.update(data);left-=len(data)
            if batch.stdout.read(1)!=b'\n' or h.hexdigest()!=row['sha256']:raise ValueError('full source witness SHA mismatch')
            source_bytes+=row['bytes']
        batch.stdin.close()
        if batch.wait(timeout=30):raise ValueError('source witness Git process failed')
    save('complete-source-witnesses.json',{'completeOriginalVersions':3120,'completeOriginalBytes':source_bytes,'allExactRootReachableGitBlobsVerified':True,'originalWorkerSourceFactsRewritten':False})
    command('ci-installed',ci+['--output',str(out/'ci-installed.json')]);command('measure-installed',measure+['--output',str(out/'measure-installed.json')])
    if read_json(out/'measure-installed.json')!=baseline or digest_file(old_receipt)!=old_receipt_before:raise ValueError('unchanged original receipts/measurements violated')
    save('installation-receipt.json',{'schema':'followup-existing-index-install-v2','head':args.expected_head,'before':before,'after':allocated(case),'metadataReserveBytes':PLAN['metadataReserveBytes'],'retiredOldAllocatedBytes':old_alloc,'actualStagedAllocatedBytes':staged,'allOld1270And945AliasesVerifiedPresentAndAbsent':True,'new4065MembersReopened':True,'all5010LogicalOriginalsComplete':True,'wholeMeasurementsIdentical':True,'allThreeCIChecksPassed':True,'originalReceiptsRewritten':False,'runtimeParity':False,'semanticAuthority':False,'fullGatePass':False,'rustExecuted':False,'pushExecuted':False})
    print((out/'installation-receipt.json').read_text())
if __name__=='__main__':main()
