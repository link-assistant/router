This is a Root-only prepared installer, not an executed migration. The existing index is preserved byte for byte in `packet-git-index.previous.json`; `packet-git-index.successor.json` retains its f610 witness and adds only the exact reachable 32ed archive witness. Original capture receipts and historical source paths remain unchanged.

Run only between frozen engine jobs, with the actual then-current full Main SHA:

```sh
python3 /Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-reverse-cycle/packages/javascript/node_modules/.issue-759-verification/followup-complete-pack-plan-v1/current-main-install-v2/apply.py --root "$PWD" --expected-head ACTUAL_FULL_MAIN_SHA
```

The default command hashes only the complete compressed Git/physical archive and the exact 13 source files. It does not decode member archives or change the case. For application, add `--apply --output "$PWD/packages/javascript/node_modules/.issue-759-verification/followup-source-install-v2-UNIQUE"`. An existing output directory is refused. No Git mutation, network fetch, engine test, Rust command or push occurs.

Application stages all 13 exact copies outside the case on the same filesystem, measures their actual distinct allocations, and checks the fixed 500,000,000-byte cap plus a 262,144-byte metadata reserve. Atomic moves cannot temporarily double the case archive allocation. The old archive is retired only after actual compressed Git equality, full 1,270-member decode, all 945 alias joins, CI integrity and unchanged whole measurements. The absent archive is then independently verified through immutable Git. All 4,065 new originals, 36 complete control records and 3,120 exact reachable source versions are subsequently reopened and joined to the logical 5,010-original index. CI integrity and whole measurements run again.

A failure stops immediately and preserves all raw command streams, staged copies and partial installation facts. The existing archive witnesses are never removed; after old-file retirement, original receipts remain recoverable through Git. This script deliberately refuses a changed predecessor index or existing new destinations; investigate any partial failure before preparing a reviewed resume.

Read-only preparation measured 496,037,888 allocated bytes, 29,025 files and 27,793 distinct inodes. Current source copies occupy 74,473,472 bytes; retiring the old 73,596,928-byte allocation projects 2,823,424 bytes of headroom after the metadata reserve. Actual staged and final allocations are measured again during application. No volume-wide reclamation, runtime parity or completed gate is claimed.
