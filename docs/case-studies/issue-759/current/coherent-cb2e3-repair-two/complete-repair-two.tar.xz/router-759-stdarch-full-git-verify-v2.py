from pathlib import Path
import json,hashlib,tarfile
tr=json.loads(Path('/tmp/router-759-stdarch-tree-1.89-response.json').read_text());assert not tr['truncated'];expected={v['path']:v for v in tr['tree'] if v['type']=='blob'};seen={};size=0
with tarfile.open('/tmp/router-759-stdarch-1.89-complete-source.tar.gz','r:gz') as stream:
 for member in stream:
  if member.isdir():continue
  assert member.isfile() and member.size<=8000000
  path=member.name.split('/',1)[1];assert path in expected and path not in seen and member.size==expected[path]['size']
  data=stream.extractfile(member).read();size+=len(data);assert size<100000000
  blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert blob==expected[path]['sha']
  seen[path]={'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlobSha':blob}
assert set(seen)==set(expected)
receipt={'schema':'router-759-complete-official-stdarch-archive-git-verification-v2','ref':tr['sha'],'files':list(seen.values()),'originalBytes':size,'gitBlobMismatches':0,'allOfficialTreeFilesPresent':True,'namespaceAuthority':False,'rustExecutions':0,'temporaryExtractionPerformed':False,'bounds':{'allOriginalBytes':100000000,'eachFullArchiveFileBytes':8000000},'priorAttempt':{'status':'SOURCE_ONLY_INVENTORY_BOUND_FAILURE','reason':'A 4 MB archive-member bound correctly refused the unrelated 6673004-byte Intel XML; source captures remain bounded to 4 MB. This complete archive verification uses 8 MB per metadata-verified member.'}}
Path('/tmp/router-759-stdarch-1.89-full-git-verify-v2.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'officialCompleteFiles':len(seen),'originalArchiveBytes':size,'gitBlobMismatches':0,'sourceSemanticsExecuted':False}))
