from pathlib import Path
import subprocess,json,base64,hashlib,time
revision='8099c08d501ec80214d7bfe3f85002dec7d79655'
requests=[('rust-lang/rust','1.89.0','library/core/src/arch.rs'),('rust-lang/rust','1.89.0','library/core/src/mem/mod.rs'),('rust-lang/rust','1.89.0','library/core/src/mem/maybe_uninit.rs'),('rust-lang/rust','1.89.0','library/core/src/ops/mod.rs'),('rust-lang/rust','1.89.0','library/core/src/ops/range.rs'),('rust-lang/rust','1.89.0','library/core/src/clone.rs')]
requests += [('rust-lang/stdarch',revision,'crates/core_arch/src/'+p) for p in ['lib.rs','mod.rs','macros.rs','x86/mod.rs','x86/sse2.rs','x86/sse41.rs','x86/ssse3.rs','x86_64/mod.rs','x86_64/sse2.rs','x86_64/sse41.rs','aarch64/mod.rs','aarch64/neon/mod.rs','aarch64/neon/generated.rs','arm_shared/mod.rs','arm_shared/neon/mod.rs','arm_shared/neon/generated.rs']]
directory=Path('/tmp/router-759-namespace-originals-v1');directory.mkdir(exist_ok=False);rows=[]
for repository,ref,path in requests:
 label=repository.replace('/','-')+'-'+path.replace('/','-'); endpoint='repos/'+repository+'/contents/'+path+'?ref='+ref
 raw=subprocess.check_output(['gh','api',endpoint],timeout=30);(directory/(label+'.response.json')).write_bytes(raw);response=json.loads(raw)
 if not response.get('content'):
  raw=subprocess.check_output(['gh','api','repos/'+repository+'/git/blobs/'+response['sha']],timeout=30);(directory/(label+'.blob-response.json')).write_bytes(raw);response=json.loads(raw)
 assert response['encoding']=='base64'; data=base64.b64decode(response['content']);assert len(data)<=4000000
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert blob==response['sha']
 (directory/(label+'.rs')).write_bytes(data);rows.append({'repository':repository,'ref':ref,'path':path,'file':label+'.rs','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gitBlobSha':blob,'url':'https://github.com/'+repository+'/blob/'+ref+'/'+path});print(json.dumps(rows[-1]),flush=True)
(directory/'receipt.json').write_text(json.dumps({'schema':'router-original-namespace-download-v1','sources':rows,'rustExecutions':0,'noClone':True,'namespaceAuthority':False},indent=2)+'\n')
