import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
sha=lambda b:hashlib.sha256(b).hexdigest()
destination=root/'docs/case-studies/issue-759/current/coherent-95689-repair-one'
destination.mkdir(parents=True,exist_ok=False)
names=['router-759-coherent-repair-packet-builder-v2.py','router-759-coherent-95689-pair-run-v2.py','router-759-coherent-95689-repair-plan.json','router-759-coherent-95689-repair-inputs.json','router-759-coherent-95689-repair-fingerprints.json','router-759-coherent-95689-direct-source-audit.json','router-759-coherent-95689-complete-failures-v1.json','router-759-coherent-repair-one-archive-v1.py']
names += ['router-759-coherent-95689bb01-repair-one-'+s for s in ['preflight.json','node.raw.log','node-receipt.json','bun.raw.log','bun-receipt.json','summary.json']]
for pattern in ['router-759-coherent-repair-diagnostics-*.raw.log','router-759-coherent-batch-diagnostics-v2*','router-759-coherent-scope-diagnostics-v3*','router-759-coherent-scope-diagnostics-v4*']:
 names += [p.name for p in sorted(Path('/tmp').glob(pattern)) if p.is_file()]
names=sorted(set(names));members=[];archive=destination/'complete-repair-one.tar.xz'
with tarfile.open(archive,'x:xz',preset=6) as stream:
 for name in names:
  data=(Path('/tmp')/name).read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  stream.addfile(info,io.BytesIO(data));members.append({'name':name,'bytes':len(data),'sha256':sha(data),'originalPath':'/tmp/'+name})
summary=json.loads(Path('/tmp/router-759-coherent-95689bb01-repair-one-summary.json').read_text())
receipt={'schema':'router-759-coherent-complete-repair-pair-archive-v1','testedHead':summary['head'],'casesPerEngine':682,'passPerEngine':667,'failPerEngine':15,'skipPerEngine':0,'bothTerminal':True,'timedOut':False,'sourceInputs':1892,'sourceInputsUnchanged':True,'sameFailedNames':True,'diagnosticAuthority':'All preceding dirty-tree probes are source-only and do not establish paired runtime or parity','rustExecutions':0,'runtimeParity':False,'members':members,'archive':{'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'directGitFullBytesVerification':'required after commit before any original cleanup'}
(destination/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
allocated=sum(p.stat().st_blocks*512 for p in (root/'docs/case-studies/issue-759').rglob('*') if p.is_file());assert allocated<500000000
print(json.dumps({'archive':receipt['archive'],'members':len(members),'developmentAllocatedBytes':allocated}))
