import {readFileSync} from 'node:fs';
const root='file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/';
const mod=path=>import(root+'tools/translation/'+path);
const {translateProject,resolveModuleGraph}=await mod('project.mjs');
const {pinnedPrimitiveFrom,pinnedPrimitiveIdentityFrom}=await mod('extensions/host-contracts.mjs').then(async()=>({...await mod('extensions/primitive-from-source.mjs'),...await mod('extensions/primitive-identity-from-source.mjs')}));
const {numericSourceInputsFromFiles,compileNumericSourceStages}=await mod('serialization-schema/numeric-source-stage.mjs');
const {loadPinnedFormatSourceStages}=await mod('format-source-profiles.mjs');
const {compileFormatCallbackDataflow}=await mod('format-builtin-dataflow.mjs');
const {compileBuiltinSourceControl}=await mod('builtin-source-control.mjs');
const row=(label,op)=>{try{console.log(JSON.stringify({label,value:op()},(_,v)=>typeof v==='bigint'?String(v):v));}catch(error){console.log(JSON.stringify({label,error:{name:error.name,message:error.reason??error.message,span:error.span??null}}));}};
const type=name=>({kind:'fixed',bits:Number(name.slice(1)),signed:name[0]==='i',rustPrimitiveName:name});
row('bool-from-original',()=>pinnedPrimitiveFrom({kind:'bool'},type('u64')));
row('fixed-from-original',()=>pinnedPrimitiveFrom(type('u8'),type('u64')));
row('identity-from-original',()=>pinnedPrimitiveIdentityFrom(type('u64')));
for(const name of ['expand_format_args_impl','parse_args'])row(name,()=>{const control=compileBuiltinSourceControl(compileFormatCallbackDataflow(loadPinnedFormatSourceStages(),'compiler/rustc_builtin_macros/src/format.rs',name));return {projected:control.controlSyntaxProjected,diagnostics:control.diagnostics};});
const inputs=numericSourceInputsFromFiles({manifest:readFileSync(new URL('Cargo.toml',root),'utf8'),lock:readFileSync(new URL('Cargo.lock',root),'utf8')});
row('explicit-original-formatter',()=>{const stage=compileNumericSourceStages(inputs,{candidateConfiguration:{flags:{test:false},values:{feature:[]},closedKeys:['feature']}});return {failure:stage.translationFailure,executables:stage.meta?.executable,refused:stage.meta?.refused};});
for(const [label,source]of [
['let-chain-known','pub fn known_some(v:u8)->u8{let subject:Option<u8>=Some(v);if let None=subject && true{return 9u8;}v}pub fn known_none()->u8{let subject:Option<u8>=None;if let Some(v)=subject && true{return v;}7u8}'],
['let-chain-const','pub const fn guarded(value:Option<u8>)->u8{if let Some(v)=value && v>0u8{return v;}0u8}const VALUE:u8=guarded(Some(1u8));'],
['ordinary-greater-equal','pub fn compare(x:u8,y:u8)->bool{x>=y}'],
])row(label,()=>{const stage=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source,cargoManifest:'[package]\nname="fixture"\nversion="0.1.0"\nedition="2024"\n'});return {refused:stage.meta.refused,executables:stage.meta.executable,javascript:stage.javascript};});
