import json,re,hashlib,subprocess,os,shutil,datetime
from pathlib import Path
ROOT=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
P=Path('/tmp/router-759-coherent-95689-repair')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,timeout=30)
def write(p,data):
 with Path(p).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
HEAD=git('rev-parse','HEAD').decode().strip();assert HEAD.startswith('95689bb01');assert not git('status','--porcelain')
union=json.load(open('/tmp/router-759-coherent-inclusive-preliminary-union.json'));tests=[]
for name,static,extra in union:
 raw=(ROOT/name).read_bytes();text=raw.decode();assert len(re.findall(r'^\s*test\(',text,re.M))==static
 generated=[]
 if name.endswith('/translation.test.mjs'):
  fixture='tools/translation/fixtures/portable-cases.json';data=(ROOT/fixture).read_bytes();assert len(json.loads(data))==32;assert 'for (const fixture of cases) test(fixture.name, async () => {' in text
  generated=[{'path':fixture,'sha256':sha(data),'count':32,'originalLoop':'for (const fixture of cases) test(fixture.name, async () => {'}]
 if name.endswith('/tuple-match-matrix.test.mjs'):
  fixture='tools/translation/test/fixtures/tuple-match-frontier.json';data=(ROOT/fixture).read_bytes();assert len(json.loads(data)['sources'])==2;assert 'for(const pin of originals.sources)test(' in text
  generated=[{'path':fixture,'sha256':sha(data),'count':2,'originalLoop':'for(const pin of originals.sources)test('}]
 tests.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'staticTopLevelCalls':static,'fixtureGeneratedCases':generated,'authoredCases':static+extra})
assert len(tests)==75 and sum(r['authoredCases'] for r in tests)==682
names=git('ls-files','-z','--','tools/translation','*.rs','Cargo.toml','Cargo.lock','packages/javascript/src','packages/javascript/package.json','packages/javascript/package-lock.json','package-lock.json','scripts','AGENTS.md').decode().split('\0');rows=[]
for name in sorted(set(filter(None,names))):
 if name.startswith(('tools/translation/meta/','tools/translation/projects/')):continue
 p=ROOT/name
 if p.is_symlink():raise RuntimeError('Tracked source input is symlink: '+name)
 raw=p.read_bytes() if p.is_file() else git('show',HEAD+':'+name)
 rows.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'readBasis':'worktree' if p.is_file() else 'exact-head-blob'})
digest=sha(json.dumps(rows,sort_keys=True,separators=(',',':')).encode())
# Source-only transcription of every static fingerprint construction statement;
# executes no JS/parser/checker/emitter. Object.fromEntries preserves first key order.
bulk=(ROOT/'tools/translation/bulk.mjs').read_text();part=bulk[bulk.index("  const implementation = ["):bulk.index('  const implementationHashes =')];impl=[]
initial=part.splitlines()[0];impl+=re.findall(r"'(tools/translation/[^']+)'",initial)
impl += ['tools/translation/extensions/'+p.name for p in (ROOT/'tools/translation/extensions').iterdir() if p.name.endswith('.mjs')]
for line in part.splitlines()[1:]:
 s=line.strip()
 if not s.startswith('implementation.push('):continue
 if 'sourceProfileInputs.map' in s:
  impl+=['tools/translation/source-profile-inputs.mjs']+[p for p in sorted(filter(None,git('ls-files','-z','--','tools/translation/source-profiles').decode().split('\0')))];continue
 m=re.search(r"source-profiles/([^/']+)/",s)
 if m and ('readdirSync' in s or '...files(' in s):
  directory=ROOT/('tools/translation/source-profiles/'+m.group(1));paths=sorted(directory.rglob('*')) if '...files(' in s else sorted(directory.iterdir());impl += [str(p.relative_to(ROOT)) for p in paths if p.is_file()];continue
 if '.map(name=>' in s or '.map(name =>' in s:
  values=re.findall(r"'([^']+)'",s.split('.map(')[0]);prefix=re.search(r'`([^`]*?)\$\{name\}',s).group(1);impl += [prefix+v for v in values];continue
 impl += re.findall(r"'((?:tools/translation|scripts)/[^']+)'",s)
impl=list(dict.fromkeys(impl));finger=[]
for name in impl:
 raw=(ROOT/name).read_bytes();finger.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
profiles=[r for r in finger if r['path'].startswith('tools/translation/source-profiles/')];assert len(profiles)==319
write(str(P)+'-inputs.json',{'schema':'router-759-coherent-immutable-inputs-v1','sourceHead':HEAD,'inputDigestRecipe':'sha256(JSON sort_keys=True compact ASCII of ordered path/bytes/sha256/readBasis rows)','sourceInputSha256':digest,'files':rows,'testPaths':[r['path'] for r in tests],'expectedCases':682,'expectedTestFiles':75,'sourceOnly':True,'engineRuns':0})
write(str(P)+'-fingerprints.json',{'schema':'router-759-source-only-fingerprint-transcription-v1','sourceHead':HEAD,'implementationSourceSha256':sha(bulk.encode()),'recipe':'Exact static bulk implementation construction transcribed without JS execution; extension directory insertion order, sorted profile paths, then Object.fromEntries first-key order. Runtime producer must independently reproduce these hashes.','files':finger,'sourceProfileFiles':319,'sha256':sha(json.dumps(finger,sort_keys=True,separators=(',',':')).encode()),'compilerExecuted':False})
missing=[r['path'] for r in rows if r['readBasis']=='exact-head-blob'];case_roots=[ROOT/'docs/case-studies/issue-759',ROOT/'dev/log/issues/759'];seen=set();allocated=logical=0
for root in case_roots:
 if not root.exists():continue
 for p in root.rglob('*'):
  if p.is_symlink() or not p.is_file():continue
  st=p.stat();key=(st.st_dev,st.st_ino)
  if key in seen:continue
  seen.add(key);allocated+=st.st_blocks*512;logical+=st.st_size
plan={'schema':'router-759-coherent-inclusive-source-plan-v1','sourceHead':HEAD,'branch':git('branch','--show-current').decode().strip(),'worktree':str(ROOT),'evidenceStatus':'SOURCE_ONLY_UNRUN','engineRuns':0,'repositoryCorpusProducerRuns':0,'fullGateRuns':0,'rustRuns':0,'files':tests,'testFiles':75,'expectedCases':682,'bounds':{'engineSeconds':1800,'engineTerminationGraceSeconds':5,'nodeConcurrency':1,'bunConcurrency':1,'bunDefaultCaseMilliseconds':15000,'gitChildSeconds':30,'runtimeVersionChildSeconds':30,'freeBytesFloor':2*1024**3,'originalCsvSourceCaseSeconds':900,'relocatedReuseCaseSeconds':600,'exportActualCasesSeconds':360,'exportCliCaseSeconds':180,'note':'Existing authored case bounds remain intact; aggregate bound is finite and does not alter mandatory corpus/CI/checker limits.'},'inputs':{'path':str(P)+'-inputs.json','sha256':sha(Path(str(P)+'-inputs.json').read_bytes()),'count':len(rows),'sourceInputSha256':digest,'missingPhysicalSourceCount':len(missing),'missingPhysicalSources':missing,'note':'Sparse original tracked inputs read exact HEAD blob in freeze; execution still requires any consumed original source physically present.'},'fingerprints':{'path':str(P)+'-fingerprints.json','sha256':sha(Path(str(P)+'-fingerprints.json').read_bytes()),'count':len(finger),'profileFiles':319},'preflight':{'observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeBytes':shutil.disk_usage(ROOT).free,'caseEvidenceAllocatedBytes':allocated,'caseEvidenceLogicalBytes':logical,'caseEvidenceCapBytes':500000000,'executables':{n:shutil.which(n) for n in ['node','bun','tsc']},'originalRustAndCargoDiffAgainstValidated2cd':git('diff','--name-only','2cd3dbe0ae3b81646bba90385ed70deb4f189988','--','*.rs','Cargo.toml','Cargo.lock').decode().splitlines()},'lease':{'kind':'exclusive compiler slot coordinated in parent messages; no persistent filesystem compiler lease implemented by these harnesses','activeEngineSessions':[],'status':'RELEASED','nextOwner':'/root','noNewWorkerGrant':True},'preparationHistory':[{'status':'SOURCE_ONLY_SETUP_FAILURE_NO_ENGINE','reason':'Initial union referenced nonexistent declaration-refusals.test.mjs; corrected to both existing 8-case refusal suites before freeze.'},{'status':'SOURCE_ONLY_PREREQUISITE_FAILURE_NO_ENGINE','head':'4ea6098de5ea3a4e55add34f658b1e1b39fa3e69','reason':'Changed descriptive numeric profile bytes mismatched strict loader checksum; aada restores original pinned bytes; complete offline capture described only by separate receipt.'}],'prerequisites':['Read final parent/peer source audits; no source audit is runtime evidence.','Use frozen HEAD and all current original source/dependency/license pins; numeric profile remains original 19160 bytes/61eca5f1...edf1, complete zmij 28612 bytes/29666d0a...fc1b committed.','Existing packages/javascript dependency installation retained; runner records actual versions inside the authorized pair. Do not install or invoke Rust.','Both Node and Bun must complete on identical source before coordinated repairs; retain every failure/timeout/raw/resource/input receipt.','Future serializer artifacts remain prior verified79; no new producer/native import replacement performed by this packet.'],'unfinishedNextSteps':['Initial a0d8d9 pair completed524pass158fail both engines; run this repaired successor full75/682 pair and preserve all remaining failures before another batch.','Resolve full failure set coherently, freeze successor and rerun same full union as needed.','Only after source union passes: actual bounded observable canonical producer, actual new census, declared native reverse generation, three profile outputs and strict TS, then complete mandatory local seven-stage gate.','Publish only a reviewed verified head; strict native/runtime parity remains incomplete.'],'validatedCurrentBranch':'issue-759-current-validated-and-observed-2cd','validatedCurrentHead':'2cd3dbe0ae3b81646bba90385ed70deb4f189988','auditReceipts':['/tmp/router-759-coherent-aada-root-source-audit-v2.json'],'currentTimeoutArchives':['docs/case-studies/issue-759/current/canonical-a7de9a11-progress-timeout/complete-timeout.tar.xz','docs/case-studies/issue-759/current/canonical-37c6b515-timeout/complete-timeout.tar.xz']}
write(str(P)+'-plan.json',plan)
print(json.dumps({'head':HEAD,'files':len(tests),'cases':682,'inputs':len(rows),'inputDigest':digest,'fingerprints':len(finger),'profiles':319,'freeBytes':plan['preflight']['freeBytes'],'caseAllocated':allocated,'missingPhysical':len(missing)},indent=2))
