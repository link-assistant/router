import argparse,gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--cwd',required=True);parser.add_argument('--output-prefix',required=True);args=parser.parse_args();root=Path(args.cwd)
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
head=git('rev-parse','HEAD').decode().strip()
if git('status','--porcelain','--untracked-files=no'):raise RuntimeError('Archive requires final clean tested source')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda value:json.dumps(value,separators=(',',':'),ensure_ascii=False).encode()
contents={}
def add(path):
 path=Path(path);raw=path.read_bytes()
 if path.name in contents:raise RuntimeError('Member collision')
 contents[path.name]=raw
 return raw
for path in ['/tmp/router-759-core-body-refusals-focused.py','/tmp/router-759-core-body-refusals-archive.py','/tmp/router-759-core-body-csv-original-focused.py',__file__]:add(path)
attempts=[];corpora={};normalizations=[]
for scope,prefix,count in [('focused','router-759-core-body-refusals-',182),('original','router-759-core-body-csv-original-',9)]:
 for engine in ['node','bun']:
  stem=Path('/tmp/'+prefix+'initial1-'+engine)
  receipt=add(stem.with_suffix('.json'));d=json.loads(receipt)
  raw=add(stem.with_suffix('.log'));input_raw=add(stem.with_suffix('.inputs.json'));input_manifest=json.loads(input_raw)
  if sha(raw)!=d['logSha256'] or len(raw)!=d['logBytes'] or sha(input_raw)!=d['inputManifestSha256']:raise RuntimeError('Attempt bytes changed')
  if d['sourceHeadBefore']!=head or d['sourceHeadAfter']!=head or d['trackedStatusBefore'] or d['trackedStatusAfter'] or not d['sourceInputsUnchanged'] or not d['sourceHeadUnchanged']:raise RuntimeError('Attempt not frozen')
  if d['exitCode']!=0 or d['timedOut'] or d['counts']['pass']!=count or d['counts']['fail']!=0 or d['counts']['skipped']!=0 or d['producerRuns'] or d['rustBuilds'] or d['fullGateRuns']:raise RuntimeError('Runtime verification incomplete')
  attempts.append(d)
  if scope=='focused':
   if d['evidenceStatus']!='FOCUSED_PASS_NOT_FULL_GATE' or d['testFiles']!=21:raise RuntimeError('Focused receipt incomplete')
   continue
  lines=raw.decode().splitlines();markers=[n for n,line in enumerate(lines) if line.startswith('# ORIGINAL_CSV_INPUTS ') or line.startswith('ORIGINAL_CSV_INPUTS ')]
  if len(markers)!=1:raise RuntimeError('Original receipt marker is not unique')
  n=markers[0];tap='# ' if lines[n].startswith('# ') else '';parts=[lines[n][len(tap)+len('ORIGINAL_CSV_INPUTS '):]]
  for i in range(n+1,len(lines)+1):
   try:original=json.loads(''.join(parts));break
   except json.JSONDecodeError:
    if i>=len(lines) or not tap or not lines[i].startswith(tap):raise RuntimeError('Incomplete consecutive original TAP receipt')
    parts.append(lines[i][len(tap):])
  if original['sourceHead']!=head or len(original['sources'])!=806 or len({v['source'] for v in original['sources']})!=806 or original['originalBytes']!=9952429:raise RuntimeError('Original corpus identity mismatch')
  if sum(v['bytes'] for v in original['sources'])!=original['originalBytes']:raise RuntimeError('Original byte budget mismatch')
  expected=sha(encode({key:original[key] for key in ['entry','sourceHead','compilationProfile','sources']}))
  if expected!=original['digest']:raise RuntimeError('Original receipt digest mismatch')
  actual={v['path']:v for v in input_manifest['files']}
  for value in original['sources']:
   record=actual.get(value['source'])
   if not record or record['bytes']!=value['bytes'] or record['sha256']!=value['sha256']:raise RuntimeError('Original bytes differ from frozen compiler input manifest')
  compact=[{key:v[key] for key in ['source','bytes','sha256']} for v in original['sources']];content_digest=sha(encode(compact))
  corpora[engine]=original
  correction={'schemaVersion':1,'status':'RUNTIME_PASS_ORIGINAL_INPUT_METADATA_VALIDATED','engine':engine,'testedSourceHead':head,'originalHarnessReceiptPreserved':stem.with_suffix('.json').name,'originalHarnessMetadataStatus':d['evidenceStatus'],'rawLog':stem.with_suffix('.log').name,'rawLogSha256':sha(raw),'rawLogChanged':False,'normalization':'Join only consecutive original-receipt TAP diagnostic fragments; no text discarded or substituted','tapFragments':len(parts),'normalizationRequiresEngineRerun':False,'original':original,'originalContentDigest':content_digest,'frozenCompilerInputsMatched':806,'originalRuntimeCounts':d['counts']}
  normalized=stem.with_name(stem.name+'-normalized-original').with_suffix('.json')
  with normalized.open('xb') as stream:stream.write(json.dumps(correction,indent=2)+'\n' if False else (json.dumps(correction,indent=2)+'\n').encode())
  add(normalized);normalizations.append(correction)
if len({d['sourceInputSha256Before'] for d in attempts})!=1:raise RuntimeError('Compiler inputs differed across scopes/engines')
if encode(corpora['node'])!=encode(corpora['bun']):raise RuntimeError('Original engine source receipts differ')
baseline_path='dev/log/issues/759/translator-csv-verification/csv-verification.tar.xz';baseline=git('show','HEAD:'+baseline_path)
if sha(baseline)!='3d03ec6b8da85f60d9a0d26d04edbb7b3172c98b87b169ebfd272bd5d1a144cb':raise RuntimeError('Baseline archive changed')
with tarfile.open(fileobj=io.BytesIO(baseline),mode='r:xz') as tar:
 old_raw=tar.extractfile('original-source-inputs.json').read();old=json.loads(old_raw)
 old_content=[{key:v[key] for key in ['source','bytes','sha256']} for v in old['sources']]
 if encode(old_content)!=encode([{key:v[key] for key in ['source','bytes','sha256']} for v in corpora['node']['sources']]) or encode(old['compilationProfile'])!=encode(corpora['node']['compilationProfile']):raise RuntimeError('Baseline original corpus/profile changed')
 measured=[]
 for engine in ['node','bun']:
  member='router-759-csv-c513-original-'+engine+'-retry1-receipt.json';old_receipt=tar.extractfile(member).read();old_attempt=json.loads(old_receipt);current=next(d for d in attempts if d['engine']==engine and d['testFiles']==1)
  measured.append({'engine':engine,'baselineReceiptMember':member,'baselineReceiptMemberSha256':sha(old_receipt),'baselineSourceHead':old_attempt['head'],'baselineElapsedSeconds':old_attempt['wallSeconds'],'currentSourceHead':head,'currentElapsedSeconds':current['elapsedSeconds'],'baselineOwnedChildrenMaxRssBytes':old_attempt['maxRssBytes'],'currentOwnedChildrenMaxRssBytes':current['measurement']['ownedChildrenMaxRssBytes']})
comparison={'baselineArchivePath':baseline_path,'baselineArchiveSha256':sha(baseline),'baselineOriginalInputMember':'original-source-inputs.json','baselineOriginalInputMemberSha256':sha(old_raw),'originalCorpusContentDigest':sha(encode(old_content)),'identicalOriginalFileContents':806,'identicalOriginalBytes':9952429,'identicalCompilationProfile':True,'timings':measured,'interpretation':'Separate descriptive runs with uncontrolled host load/caches; no controlled speedup, aggregate peak or full parity claim'}
contents['body-original-baseline-comparison.json']=(json.dumps(comparison,indent=2)+'\n').encode()
records=[{'name':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in contents.items()];buffer=io.BytesIO();hardlinks=0
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0,filename='') as gz:
 with tarfile.open(fileobj=gz,mode='w|') as tar:
  seen={}
  for name,raw in contents.items():
   info=tarfile.TarInfo(name);info.mtime=0;info.mode=0o644;key=(len(raw),sha(raw));previous=seen.get(key)
   if previous and contents[previous]==raw:info.type=tarfile.LNKTYPE;info.linkname=previous;info.size=0;tar.addfile(info);hardlinks+=1
   else:info.size=len(raw);tar.addfile(info,io.BytesIO(raw));seen[key]=name
packed=buffer.getvalue()
if len(packed)>300000:raise RuntimeError('Combined evidence exceeds compact budget')
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
 if len(tar.getmembers())!=len(records):raise RuntimeError('Archive dropped member')
 for record in records:
  raw=tar.extractfile(record['name']).read()
  if len(raw)!=record['bytes'] or sha(raw)!=record['sha256']:raise RuntimeError('Reopened member mismatch')
prefix=Path(args.output_prefix);archive=Path(str(prefix)+'.tar.gz');receipt=Path(str(prefix)+'-receipt.json')
if archive.exists() or receipt.exists():raise RuntimeError('Preserve prior evidence')
archive.write_bytes(packed)
document={'schemaVersion':1,'kind':'original-free-function-body-refusal-and-unchanged-original-graph-evidence','status':'FOCUSED_PASS_WITH_NODE_ORIGINAL_RECEIPT_NORMALIZATION_NOT_FULL_GATE','testedSourceHead':head,'frozenCompilerInputSha256':attempts[0]['sourceInputSha256Before'],'frozenCompilerInputs':attempts[0]['inputFiles'],'countsPerEngine':{'focused':182,'original':9},'attempts':attempts,'normalizations':[{'engine':c['engine'],'tapFragments':c['tapFragments'],'rawLogChanged':False,'originalContentDigest':c['originalContentDigest'],'runtimeStatus':c['status']} for c in normalizations],'baselineComparison':comparison,'archive':{'path':archive.name,'bytes':len(packed),'sha256':sha(packed),'members':records,'reopenedMembers':len(records),'reopenErrors':0,'identicalContentHardlinks':hardlinks,'hardlinkExtractionVerified':True},'limits':{'canonicalProducerRuns':0,'profileProducerRuns':0,'fullGateRuns':0,'rustBuilds':0,'newCorpusCensusClaim':False,'runtimeParity':False,'controlledSpeedupClaim':False,'measurementScope':'Owned terminated-child maximum RSS includes git/version/time children; not aggregate process-tree peak or physical footprint'}}
receipt.write_text(json.dumps(document,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'archiveBytes':len(packed),'archiveSha256':sha(packed),'members':len(records),'hardlinks':hardlinks,'receiptBytes':receipt.stat().st_size,'receiptSha256':sha(receipt.read_bytes()),'originalContentDigest':comparison['originalCorpusContentDigest'],'normalizedOriginalInputs':806,'runtimeChecksEachEngine':191,'testedSourceHead':head}))
