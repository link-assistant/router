p='tools/translation/js-to-rust/targets.mjs';s=open(p).read()
old="      case 'method': return rust && expr.name === 'trim' ? `js_trim(&${expression(expr.receiver)})`";assert old in s
s=s.replace(old,"""      case 'method': {
        if(rust&&expr.receiver.type==='utf16-string') {
          const receiver=expression(expr.receiver),argument=expr.args[0],search=argument?.type==='string'?units(argument.value):argument?expression(argument):null;
          if(expr.name==='trim')return `js_payload_trim(${receiver})`;
          if(expr.name==='includes')return `({ let observed = ${receiver}; let search = ${search}; search.is_empty() || observed.windows(search.len()).any(|window| window == search) })`;
          return `${receiver}.${expr.name==='starts-with'?'starts_with':'ends_with'}(${search})`;
        }
        return rust && expr.name === 'trim' ? `js_trim(&${expression(expr.receiver)})`""")
old="`${expression(expr.receiver)}.${map.methods.get(expr.name)[rust ? 'rust' : 'javascript']}(${expr.args.map((arg) => `${rust && arg.type === 'string' ? '&' : ''}${expression(arg)}`).join(', ')})`;";assert old in s;s=s.replace(old,old+'\n      }')
s=s.replace("return rust ? `(${expression(expr.receiver)}.encode_utf16().count() as f64)`", "return rust ? expr.receiver.type==='utf16-string'?`(${expression(expr.receiver)}.len() as f64)`:`(${expression(expr.receiver)}.encode_utf16().count() as f64)`")
s=s.replace("return rust ? `(${expression(expr.receiver)}.chars().count() as f64)`", "return rust ? expr.receiver.type==='utf16-string'?`(js_payload_points(${expression(expr.receiver)}).len() as f64)`:`(${expression(expr.receiver)}.chars().count() as f64)`")
s=s.replace("const iterator=`observed.${expr.unicode?'chars()':'encode_utf16()'}.map(|unit| unit as u32)`;", "const iterator=expr.receiver.type==='utf16-string'?expr.unicode?'js_payload_points(observed).into_iter()':'observed.iter().map(|unit| *unit as u32)':`observed.${expr.unicode?'chars()':'encode_utf16()'}.map(|unit| unit as u32)`;")
s=s.replace("      case 'builtin': return rust && expr.args[0]?.type === 'value'", "      case 'builtin': return rust&&expr.name==='utf8-length'&&expr.args[0]?.type==='utf16-string'?`js_payload_utf8_length(${expression(expr.args[0])})`:rust && expr.args[0]?.type === 'value'")
s=s.replace("program.some(payloadBoundary)?PAYLOAD_HELPERS:'',", "program.some(payloadBoundary)?PAYLOAD_HELPERS:'',\n    program.some(item=>item.lossless)?PAYLOAD_GUARD_HELPERS:'',")
open(p,'w').write(s)
p='tools/translation/js-to-rust/vendor/ir.mjs';s=open(p).read().replace("if(['utf16-string','array-value','json-response'].includes(operand.type)","if(operand.type==='utf16-string'&&!names.lossless||['array-value','json-response'].includes(operand.type)")
old="      if(row.operands==='any'&&!['number','string','boolean','null','undefined'].includes(left.type))";assert old in s
s=s.replace(old,"""      if(names.lossless&&['equal','not-equal'].includes(expr.op)&&[left,right].some(value=>value.type==='utf16-string')&&[left,right].every(value=>value.type==='utf16-string'||value.kind==='string'))return typed({left,right,utf16Comparison:true},'boolean');
"""+old)
open(p,'w').write(s)
p='tools/translation/js-to-rust/targets.mjs';s=open(p).read();old="        if(rust&&expr.primitiveComparison)return";assert old in s;s=s.replace(old,"        if(rust&&expr.utf16Comparison)return `(${expr.left.kind==='string'?units(expr.left.value):expression(expr.left)} ${expr.op==='equal'?'==':'!='} ${expr.right.kind==='string'?units(expr.right.value):expression(expr.right)})`;\n"+old);open(p,'w').write(s)
