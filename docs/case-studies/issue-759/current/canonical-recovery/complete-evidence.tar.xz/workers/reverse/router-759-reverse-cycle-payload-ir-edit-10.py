p='tools/translation/js-to-rust/vendor/ir.mjs';s=open(p).read()
def replace(old,new):
 global s
 assert old in s,old;s=s.replace(old,new)
replace('  const scope = new Map(item.params.map((param) => [param.name, param.type]));',"  if(item.lossless&&item.params.some(param=>param.type==='string'))refuse('collection','a scalar string input in a lossless function');\n  const scope = new Map(item.params.map((param) => [param.name, param.type]));\n  scope.lossless=item.lossless===true;")
replace("['number', 'string', 'null', 'undefined'].includes(operand.type)","['number', 'string','utf16-string', 'null', 'undefined'].includes(operand.type)")
replace("return type.startsWith('value:') ? typed({ projection: type.slice(6) }, type.slice(6)) : typed({}, type);", "return type.startsWith('value:') ? names.lossless&&type==='value:string'?typed({projection:'utf16-string',borrowed:true},'utf16-string'):typed({ projection: type.slice(6) }, type.slice(6)) : typed(type==='utf16-string'?{borrowed:true}:{}, type);")
replace("      if(left.type==='value'||right.type==='value') {", "      if(['and','or'].includes(expr.op)&&left.type==='boolean'&&right.type!=='boolean'&&names.lossless&&canLiftValue(right))return typed({kind:'logical',left,right},'value');\n      if(left.type==='value'||right.type==='value') {")
replace("      const operand = expression(expr.operand, names, table);\n      if (operand.type !== row.operand)","      const operand = expr.op==='not'?condition(expr.operand,names,table):expression(expr.operand, names, table);\n      if (operand.type !== row.operand)")
replace("['number', 'string', 'boolean', 'null', 'undefined'].includes(operand.type)","['number', 'string','utf16-string', 'boolean', 'null', 'undefined'].includes(operand.type)")
replace("    case 'call': {", """    case 'logical': {
      const left=expression(expr.left,names,table),right=expression(expr.right,guardedScope(expr.left,names,expr.op==='and'),table);
      if(!names.lossless||!['and','or'].includes(expr.op)||left.type!=='boolean'||!canLiftValue(right))refuse('type','an unproved mixed primitive short circuit');
      return typed({left,right},'value');
    }
    case 'call': {""")
replace("      if (receiver.type !== row.receiver || args.length !== row.arguments.length || args.some((arg, index) => arg.type !== row.arguments[index])) {", """      if(receiver.type==='utf16-string') {
        if(!['trim','starts-with','ends-with','includes'].includes(expr.name)||args.length!==row.arguments.length||args.some(arg=>arg.type!=='utf16-string'&&!(arg.type==='string'&&arg.kind==='string')))refuse('type','an unimplemented lossless string method');
        return typed({receiver,args,...(expr.name==='trim'?{borrowed:receiver.borrowed===true}:{})},expr.name==='trim'?'utf16-string':'boolean');
      }
      if (receiver.type !== row.receiver || args.length !== row.arguments.length || args.some((arg, index) => arg.type !== row.arguments[index])) {""")
replace("receiver.type !== 'string') refuse('type', 'length", "!['string','utf16-string'].includes(receiver.type)) refuse('type', 'length")
replace("receiver.type !== 'string') refuse('type', 'codepoint", "!['string','utf16-string'].includes(receiver.type)) refuse('type', 'codepoint")
replace("receiver.type !== 'string') refuse('type', 'a regex", "!['string','utf16-string'].includes(receiver.type)) refuse('type', 'a regex")
replace("!(arg.type === 'value' && ['safe-integer', 'finite', 'nan'].includes(expr.name))", "!(arg.type === 'value' && ['safe-integer', 'finite', 'nan'].includes(expr.name))&&!(expr.name==='utf8-length'&&arg.type==='utf16-string')")
replace("if(payload&&(node.projection||['typeof','includes','table-get','table-has'].includes(node.kind)||node.kind==='builtin'&&node.args?.some(arg=>arg.type==='value')))","if(payload&&!item.lossless&&(node.projection||['typeof','includes','table-get','table-has'].includes(node.kind)||node.kind==='builtin'&&node.args?.some(arg=>arg.type==='value')))")
replace("    ...flag,\n    ['parameters'", "    ...flag,\n    ...(item.lossless?[['lossless']]:[]),\n    ['parameters'")
replace("    exported,\n    params: field(link", "    exported,\n    ...(link.some(part=>Array.isArray(part)&&part[0]==='lossless')?{lossless:true}:{}),\n    params: field(link")
replace("    case 'binary':\n      return ['binary'", "    case 'logical':return ['logical',expr.op,linkOf(expr.left),linkOf(expr.right)];\n    case 'binary':\n      return ['binary'")
replace("    case 'binary':\n      return { kind, op:", "    case 'logical':return {kind,op:rest[0],left:exprOf(rest[1]),right:exprOf(rest[2])};\n    case 'binary':\n      return { kind, op:")
open(p,'w').write(s)
p='tools/translation/js-to-rust/vendor/return-types.mjs';s=open(p).read().replace('/^table-map-(string|number|boolean|utf16-string)$/u','/^table-map-(string|number|boolean)$/u');open(p,'w').write(s)
p='tools/translation/js-to-rust/vendor/constructs.lino';s=open(p).read();needle='(type value ';assert needle in s;s=s.replace(needle,'(type nullable-utf16-string (javascript source-owned-nullable-utf16-string) (rust "JsNullable<&[u16]>") (rust-owned "JsNullable<Vec<u16>>"))\n(type optional-utf16-string (javascript source-owned-optional-utf16-string) (rust "JsOptional<&[u16]>") (rust-owned "JsOptional<Vec<u16>>"))\n'+needle,1);open(p,'w').write(s)
