import hashlib,json,pathlib,subprocess
root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');tmp=pathlib.Path('/tmp');head='50b3cb43b790a57be255a54b6c7d4cf8a43f75c7'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
files={};old=json.loads((root/'docs/case-studies/issue-759/current/coherent-source-successor/capture-receipt.json').read_text());oldidentities={}
for row in old['members']:oldidentities.setdefault((row['bytes'],row['sha256']),row)
prefixes=['router-759-cohort-v3-canonical-3c96a4bdd','router-759-actual-canonical-3c96-','router-759-canonical-558657-','router-759-current-native-body-drafts-','router-759-current-bulk-native-strict-','router-759-collected-forward-repairs-','router-759-coherent-eb8666-complete-forward-','router-759-native-portable-adapter-','router-759-complete-compiler-export-','router-759-native-artifacts-v3-','router-759-native-artifacts-v4-','router-759-native-pretty-census-','router-759-mid-sized-log-','router-759-mid-log-compaction-','router-759-readonly-ci-integrity-','router-759-prepare-readonly-ci-integrity-','router-759-coherent-source-successor-direct-git-','router-759-reverse-cycle-incident-']
for f in tmp.iterdir():
 if f.is_file() and any(f.name.startswith(prefix) for prefix in prefixes):files['observations/'+f.name]=f
for name in ['router-759-coherent-forward-failure-repair-v1','router-759-option-next-cycle-20261013-v1','router-759-derive-cycle-20261013-builtin-scalar-v1','router-759-derive-cycle-20261013-default-v1','router-759-native-pretty-census-originals-v1']:
 directory=tmp/name;assert directory.is_dir()
 for f in directory.rglob('*'):
  if f.is_file():files['workers/'+name+'/'+f.relative_to(directory).as_posix()]=f
for version in ['v2','v3']:
 directory=tmp/('router-759-mid-sized-log-compaction-'+version)
 for f in directory.iterdir():
  if f.is_file() and not f.name.endswith('.xz'):files['observations/'+directory.name+'/'+f.name]=f
# Every omitted compressed candidate is retained as a complete immutable Git blob.
# Check complete candidate bytes against committed current paths, preserving full witnesses.
blobwitness=[]
for version in ['v2','v3']:
 directory=tmp/('router-759-mid-sized-log-compaction-'+version);continuity=json.loads((directory/'complete-continuity.json').read_text());stored={r['stored']['sha256']:r['stored'] for r in continuity['completeRenamedLogs']}
 for f in directory.glob('*.xz'):
  b=f.read_bytes();digest=hashlib.sha256(b).hexdigest();r=stored[digest];assert len(b)==r['bytes'];gitbytes=subprocess.check_output(['git','show',head+':'+r['path']],cwd=root);assert gitbytes==b
  blobwitness.append({'originalPath':str(f),'bytes':len(b),'sha256':digest,'gitCommit':head,'gitPath':r['path'],'completeBytesCompared':True})
for filename,key in [('router-759-option-next-cycle-20261013-v1/evidence-artifact-vector.json',None),('router-759-derive-cycle-20261013-builtin-scalar-v1/receipt.json','allEvidenceFiles'),('router-759-derive-cycle-20261013-default-v1/receipt.json','storageFiles')]:
 receipt=tmp/filename;data=json.loads(receipt.read_text());rows=data[key] if key else data
 for r in rows:
  f=pathlib.Path(r['path']);f=f if f.is_absolute() else receipt.parent/f;b=f.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],f
receipt=tmp/'router-759-reverse-cycle-final-inputs-10.json';files['workers/reverse/'+receipt.name]=receipt
for r in json.loads(receipt.read_text())['evidence']:
 f=pathlib.Path(r['path']);b=f.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];files['workers/reverse/'+f.name]=f
for name in ['router-759-bounded-cohort-producer-v5.py','router-759-bounded-native-artifacts-v3.py','router-759-bounded-native-artifacts-v4.py','router-759-bounded-native-artifacts-v5.py','router-759-coordinated-repair-diagnostic-v1.py','router-759-current-688-packet-plan-v1.py']:
 f=tmp/name;assert f.is_file();files['harnesses/'+name]=f
for name in subprocess.check_output(['git','diff','--name-only','682e35cffa0f6cd7237e60f61255d56c31c5674e',head,'--','tools/translation','tools/evidence','scripts','docs/development'],cwd=root).decode().splitlines():
 if name.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/')):continue
 f=root/name
 if f.is_file():b=f.read_bytes();assert subprocess.check_output(['git','show',head+':'+name],cwd=root)==b;files['implementation/'+name]=f
rows=[];references=[]
for name,f in sorted(files.items()):
 b=f.read_bytes();r={'path':name,'originalPath':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};prior=oldidentities.get((r['bytes'],r['sha256']))
 if prior:references.append({**r,'retainedPacket':'docs/case-studies/issue-759/current/coherent-source-successor/complete-evidence.tar.xz','retainedPacketSha256':old['archiveSha256'],'retainedMember':prior['path'],'originalBytesPinnedAndEqual':True})
 else:rows.append(r)
provenance=tmp/'router-759-current-688-packet-retained-complete-originals-v1.json';assert not provenance.exists();provenance.write_text(json.dumps({'schema':'complete-original-storage-witnesses-v1','sourceHead':head,'priorPacketMembers':references,'immutableGitBlobs':blobwitness,'allSelectedOriginalsRetained':True,'fullGatePass':False,'rustExecuted':False},separators=(',',':'))+'\n');b=provenance.read_bytes();rows.append({'path':'provenance/'+provenance.name,'originalPath':str(provenance),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
output=tmp/'router-759-current-688-packet-v1.manifest.json';assert not output.exists();output.write_text(json.dumps({'members':rows},separators=(',',':'))+'\n');print(json.dumps({'sourceHead':head,'members':len(rows),'completeOriginalBytes':sum(r['bytes'] for r in rows),'priorCompleteMembers':len(references),'immutableGitCandidateBlobs':len(blobwitness),'manifest':str(output),'rustExecuted':False,'fullGatePass':False}))
