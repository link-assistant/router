import hashlib,json,pathlib

root=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
source=root/'docs/case-studies/issue-759/raw/ci/verify-archive.py'
target=pathlib.Path('/tmp/router-759-readonly-ci-integrity-v3.py')
receipt=pathlib.Path('/tmp/router-759-readonly-ci-integrity-transform-v3.json')
assert not target.exists() and not receipt.exists()
original=source.read_bytes();text=original.decode()
helper='''
def distinct_allocated_bytes():
 seen=set();total=0
 for base in [ROOT.parent.parent,ROOT.parents[4]/'dev/log/issues/759']:
  for p in base.rglob('*'):
   if not p.is_file() or p.is_symlink():continue
   s=p.stat();identity=(s.st_dev,s.st_ino)
   if identity not in seen:seen.add(identity);total+=s.st_blocks*512
 return total
'''
replacements=[
 ("ROOT=pathlib.Path(__file__).resolve().parent", "ROOT=pathlib.Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/docs/case-studies/issue-759/raw/ci')"+helper),
 ("sum(p.stat().st_blocks*512 for p in case.rglob('*') if p.is_file())",'distinct_allocated_bytes()'),
 ("(ROOT/'archive-integrity.json').write_text", "pathlib.Path('/tmp/router-759-readonly-ci-integrity-v3-complete-report.json').write_text"),
 ("print(json.dumps(result))", "print(json.dumps({key:value for key,value in result.items() if key!='errors'}))")]
for old,new in replacements:
 assert text.count(old)==1,old
 text=text.replace(old,new)
target.write_text(text)
record={'schema':'readonly-ci-integrity-exact-source-transform-v1','originalPath':str(source),
        'originalBytes':len(original),'originalSha256':hashlib.sha256(original).hexdigest(),
        'transformedPath':str(target),'transformedSha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'replacements':[{'original':old,'replacement':new} for old,new in replacements],
        'changes':'Read-only output under /tmp; count each physical inode once across the fixed case/dev budget. Every receipt, decoded hash and credential pattern check is unchanged.',
        'repositoryMutations':[],'rustExecuted':False,'fullGateAuthority':False}
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key!='replacements'}))
