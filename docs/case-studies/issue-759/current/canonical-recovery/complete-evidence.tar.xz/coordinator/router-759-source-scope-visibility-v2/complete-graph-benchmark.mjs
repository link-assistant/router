import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {resolveModuleGraph} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/project.mjs';
import {resolveModuleBindings} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/module-bindings.mjs';
import {configureParserSourceScope as original} from 'file:///Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate/tools/translation/source-scopes.mjs';
import {configureParserSourceScope as candidate} from 'file:///tmp/router-759-source-scope-visibility-v1/candidate-runtime.mjs';
const root='/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate',hash=value=>createHash('sha256').update(value).digest('hex');
const paths=execFileSync('git',['ls-files','-z','--','*.rs'],{cwd:root,encoding:'utf8'}).split('\0').filter(Boolean),inputs=[];
const graph=resolveModuleGraph({entry:'src/lib.rs',paths,readSource:path=>{const b=readFileSync(root+'/'+path);inputs.push({path,bytes:b.length,sha256:hash(b)});return b.toString('utf8');}});
const scopes=resolveModuleBindings({modules:graph.modules,compilationProfile:graph.compilationProfile}).scopes;
const inspect=value=>value instanceof Map?{map:[...value].map(([key,item])=>[key,inspect(item)])}:value instanceof Set?{set:[...value]}:Array.isArray(value)?value.map(inspect):value&&typeof value==='object'?Object.fromEntries(Object.entries(value).map(([key,item])=>[key,inspect(item)])):value;
const vectors=[];
for(const scope of scopes){const a=original({},scope,scopes),b=candidate({},scope,scopes);const raw=JSON.stringify(inspect(a));assert.deepEqual(inspect(b),JSON.parse(raw));vectors.push({source:scope.file,path:scope.path,completeParserNamespaceBytes:Buffer.byteLength(raw),completeParserNamespaceSha256:hash(raw)});}
const measurements=[];
for(let round=0;round<4;round++)for(const [name,configure]of round%2?[['candidate',candidate],['original',original]]:[['original',original],['candidate',candidate]]){const start=performance.now(),cpu=process.cpuUsage();let setupCount=0;for(const scope of scopes){const p=configure({},scope,scopes);assert.equal(Object.getPrototypeOf(p.sourceNamespaceAliases.type),Map.prototype);setupCount++;}measurements.push({round,name,setupCount,wallMilliseconds:performance.now()-start,cpuMicroseconds:process.cpuUsage(cpu)});}
for(const r of inputs){const b=readFileSync(root+'/'+r.path);assert.equal(b.length,r.bytes);assert.equal(hash(b),r.sha256);}
const report={schema:'complete-original-library-namespace-setup-comparison-v1',sourceHead:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),graphModules:graph.modules.length,graphDiagnostics:graph.diagnostics,sourceScopes:scopes.length,completeNamespaceEquality:true,inputs,vectors,measurements,scope:'all original library graph modules; namespace setup only, without procedural derive narrowing or semantic body translation',originalSourceScopesSha256:hash(readFileSync(root+'/tools/translation/source-scopes.mjs')),candidateSourceScopesSha256:hash(readFileSync('/tmp/router-759-source-scope-visibility-v1/candidate-source-scopes.mjs')),compilerSpeedupClaim:false,runtimeParity:false,rustExecuted:false};
writeFileSync('/tmp/router-759-source-scope-visibility-v2/complete-graph-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({graphModules:report.graphModules,sourceScopes:report.sourceScopes,completeNamespaceEquality:true,measurements,compilerSpeedupClaim:false}));
