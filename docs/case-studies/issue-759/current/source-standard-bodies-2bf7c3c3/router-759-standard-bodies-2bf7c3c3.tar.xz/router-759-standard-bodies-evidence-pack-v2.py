import datetime, hashlib, io, json, subprocess, tarfile
from pathlib import Path

ROOT = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core')
HEAD = '2bf7c3c3d18ae9f96b253119352b4d2a9b3243f5'
DEST = ROOT / 'docs/case-studies/issue-759/current/source-standard-bodies-2bf7c3c3'
PACK = DEST / 'router-759-standard-bodies-2bf7c3c3.tar.gz'
RECEIPT = DEST / 'router-759-standard-bodies-2bf7c3c3-receipt.json'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
if git('rev-parse', 'HEAD').decode().strip() != HEAD or git('status', '--porcelain', '--untracked-files=no').strip():
    raise RuntimeError('Require the exact clean tested source head')
if PACK.exists() or RECEIPT.exists():
    raise RuntimeError('Archive already exists; retain previous evidence')

attempts, paths = [], [Path(__file__)]
for version, phases in [('v1', ['initial']), ('v2', ['repair-one', 'repair-two', 'repair-three', 'final-full', 'repair-four', 'repair-four-full'])]:
    for phase in phases:
        for engine in ['node', 'bun']:
            stem = Path('/tmp/router-759-core-standard-bodies-' + version + '-' + phase + '-' + engine)
            attempt = json.loads(stem.with_suffix('.json').read_text())
            if not attempt['sourceHeadUnchanged'] or not attempt['sourceInputsUnchanged'] or attempt['trackedStatusBefore'] or attempt['trackedStatusAfter']:
                raise RuntimeError('Attempt failed its immutable-source observation')
            for suffix, size_key, hash_key in [('.log', 'logBytes', 'logSha256'), ('.inputs.json', 'inputManifestBytes', 'inputManifestSha256')]:
                path = Path(str(stem) + suffix)
                raw = path.read_bytes()
                if len(raw) != attempt[size_key] or sha(raw) != attempt[hash_key]:
                    raise RuntimeError('Attempt raw/input mismatch: ' + str(path))
                paths.append(path)
            paths.append(stem.with_suffix('.json'))
            if phase in ['repair-four', 'repair-four-full']:
                if attempt['sourceHeadBefore'] != HEAD or attempt['evidenceStatus'] != 'FOCUSED_PASS_NOT_FULL_GATE' or attempt['counts']['fail'] or attempt['counts']['skipped'] or attempt['timedOut']:
                    raise RuntimeError('Both final pairs must actually pass on the same source')
                if attempt['testFiles'] != 31:
                    raise RuntimeError('Original full or narrow cohort changed')
            harness_name = 'router-759-core-standard-bodies-focused-' + ('v3' if phase.startswith('repair-four') else version) + '.py'
            harness_raw = (Path('/tmp') / harness_name).read_bytes()
            attempt['immutableHarness'] = {'file': harness_name, 'bytes': len(harness_raw), 'sha256': sha(harness_raw), 'filenamePrefix': version}
            attempts.append(attempt)

for name in [
    'router-759-standard-bodies-evidence-pack-v1.py',
    'router-759-core-standard-bodies-focused-v1.py', 'router-759-core-standard-bodies-focused-v2.py', 'router-759-core-standard-bodies-focused-v3.py',
    'router-759-core-standard-bodies-final-full-node-failures.json', 'router-759-core-standard-bodies-final-full-bun-failures.json', 'router-759-rust-target-rescan-standard-bodies.json',
    'router-759-core-standard-bodies-initial-node-failures.json', 'router-759-core-standard-bodies-initial-bun-failures.json',
    'router-759-core-standard-bodies-repair-one-node-failures.json', 'router-759-core-standard-bodies-repair-one-bun-failures.json',
    'router-759-core-standard-bodies-repair-two-node-failures.json', 'router-759-core-standard-bodies-repair-two-bun-failures.json',
    'router-759-core-standard-bodies-repair-two-bun-complete-failures.json', 'router-759-standard-body-composition-593.json',
]:
    paths.append(Path('/tmp') / name)
for stem in ['router-759-standard-body-private-probe-v1', 'router-759-standard-body-allocation-private-probe-v1']:
    paths.extend(Path('/tmp') / (stem + suffix) for suffix in ['.mjs', '.json', '.log'])

members, hashes = [], {}
DEST.mkdir(parents=True, exist_ok=True)
with tarfile.open(PACK, 'w:gz', compresslevel=9) as archive:
    for path in sorted(set(paths), key=lambda path: path.name):
        raw = path.read_bytes(); digest = sha(raw)
        record = {'name': path.name, 'originalPath': str(path), 'bytes': len(raw), 'sha256': digest}
        info = tarfile.TarInfo(path.name); info.mtime = 0; info.mode = 0o644
        identity = (len(raw), digest)
        if identity in hashes:
            info.type = tarfile.LNKTYPE; info.linkname = hashes[identity]; record['hardlinkTo'] = info.linkname
            archive.addfile(info)
        else:
            info.size = len(raw); archive.addfile(info, io.BytesIO(raw)); hashes[identity] = path.name
        members.append(record)

with tarfile.open(PACK, 'r:gz') as archive:
    for member in members:
        raw = archive.extractfile(member['name']).read()
        if len(raw) != member['bytes'] or sha(raw) != member['sha256'] or raw != Path(member['originalPath']).read_bytes():
            raise RuntimeError('Reopened archive member mismatch: ' + member['name'])

record = {
    'schema': 'paired-source-standard-body-focused-evidence-v2', 'sourceHead': HEAD, 'status': 'FOCUSED_PASS_NOT_FULL_GATE',
    'sourceQueue': [git('rev-parse', name).decode().strip() for name in ['40d9bb2', 'a7521aa', '0c66cfc', '6fec614', 'e2c0ebd', HEAD]],
    'attempts': attempts, 'members': members,
    'archive': {'file': PACK.name, 'bytes': PACK.stat().st_size, 'sha256': sha(PACK.read_bytes()), 'members': len(members), 'hardlinks': sum('hardlinkTo' in member for member in members), 'reopenedHashErrors': 0, 'originalByteComparisons': len(members)},
    'preservedFailures': ['Initial exact 31-file Node and Bun failures, including file-load suppression and complete original CSV graph diagnostics', 'Both complete repair-one narrow pairs: 14 failures each', 'Repair-two Node one allocation failure; Bun same allocation plus inner default 5000ms RunState timeout, including its complete trailing timeout details', 'Repair-three full original31 pair had260/261 under both engines; actual original Encoding.parse trim identity gap retained completely'],
    'repair': 'Separate private token/original-AST declarative engine instances, genuine full-original standalone source context, exact crate-root dependency closure, registered borrowed-str signatures, original-body rechecking under actual declaration references, preserved allocating conversion receiver proofs and one full-original RunState 30000ms test budget; genuine source/registered identity propagation through actual checked borrowed str trim results',
    'verificationLimits': {'fullGate': False, 'canonicalProducer': False, 'profileMatrixProducer': False, 'corpusGain': False, 'fullParity': False, 'completeNamespace': False, 'completeTrait': False, 'wholeCoreTranslated': False, 'mutableBorrowedLocals': False, 'rustBuilds': 0, 'rss': 'RUSAGE_CHILDREN maximum per terminated owned child, not sampled aggregate process-tree peak or footprint; Bun has no separate cancellation count'},
    'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
RECEIPT.write_text(json.dumps(record, separators=(',', ':')) + '\n')
final = [attempt for attempt in attempts if attempt['phase'] == 'repair-four-full']
README = DEST / 'README.md'
README.write_text(
    'Original Rust 1.89 Option methods and primitive Default bodies translate through the shared checked meta representation into JavaScript and strict TypeScript. The original method match arms and Default macro expansion are parsed from their pinned complete source inputs; target-language method templates do not replace those bodies.\n\n'
    + 'At `' + HEAD + '`, the 31-file narrow cohort passed all ' + str(attempts[-4]['counts']['pass']) + ' cases under both Node and Bun. The unchanged original 31-file cohort, including the complete original CSV dependency graph, passed ' + str(final[0]['counts']['pass']) + '/' + str(final[0]['counts']['tests']) + ' under Node in ' + str(final[0]['elapsedSeconds']) + ' seconds and ' + str(final[1]['counts']['pass']) + '/' + str(final[1]['counts']['tests']) + ' under Bun in ' + str(final[1]['elapsedSeconds']) + ' seconds. Both retained the 1800-second outer bound; no cases were skipped and neither engine timed out. All source hashes and tested heads remained unchanged.\n\n'
    + 'The archive preserves all fourteen complete failed and successful engine attempts, full raw logs, exact input manifests, all three immutable harnesses, both private diagnostic probes, the composition receipt and complete failure inventories. The v3 harness retains its inherited v2 output filename prefix; each unique phase and exact archived harness identify the attempt. The original unexecuted v1 archive-builder draft is retained with this corrected v2 builder. Duplicate bytes use tar hardlinks; every member was reopened and compared to its original bytes. The earlier Bun RunState inner timeout is explicitly retained even though its outer engine bound did not expire.\n\n'
    + 'This is focused translator verification. Complete Router parity, canonical and profile corpus regeneration, all trait and namespace resolution, whole core-library translation and mutable borrowed-local flow remain unproved by this cohort. No Rust build ran. Resource measurements describe terminated-child maxima, with no claim of aggregate process-tree peak.\n'
)
print(json.dumps({'archive': record['archive'], 'receiptBytes': RECEIPT.stat().st_size, 'receiptSha256': sha(RECEIPT.read_bytes()), 'readmeBytes': README.stat().st_size}))
