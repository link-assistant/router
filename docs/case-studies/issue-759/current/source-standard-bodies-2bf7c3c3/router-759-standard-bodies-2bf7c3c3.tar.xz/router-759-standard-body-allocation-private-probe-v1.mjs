import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {HostEmitter} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core/tools/translation/extensions/host-contracts.mjs';
import {translateSource} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core/tools/translation/translate.mjs';
const fixtures=readFileSync('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core/tools/translation/fixtures/portable-cases.json');
const fixture=JSON.parse(fixtures).find(item=>item.name==='Unicode prefix and suffix Option values'),emit=HostEmitter.prototype.expr;
HostEmitter.prototype.expr=function(node){if(node.k==='routerPinnedStandardBody')console.log(JSON.stringify({kind:'actual-checker-emitter-input',type:node.type,proofOwner:node.pinnedStandardBodyProof.owner,originalMethod:node.pinnedStandardBodyProof.method,actualOuterOwnershipOperation:node.sourceOwnershipOperation}));return emit.call(this,node);};
console.log(JSON.stringify({kind:'actual-original-fixture',name:fixture.name,fixturesSha256:createHash('sha256').update(fixtures).digest('hex'),source:fixture.source}));
const result=translateSource(fixture.source);console.log(JSON.stringify({kind:'actual-result',items:result.ir.items.map(({name,status,diagnostic})=>({name,status,diagnostic})),counts:result.ir.counts}));
