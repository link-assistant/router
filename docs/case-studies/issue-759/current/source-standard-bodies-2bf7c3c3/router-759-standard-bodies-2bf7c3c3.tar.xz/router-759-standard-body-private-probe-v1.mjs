import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {HostRustParser,HostChecker,HostEmitter} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core/tools/translation/extensions/host-contracts.mjs';
import {translateProject} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core/tools/translation/project.mjs';
import {pinnedOptionBody,parsePinnedBody,parsedPinnedBodyEvidence} from '/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-core/tools/translation/extensions/standard-body-source.mjs';
const hash=value=>createHash('sha256').update(value).digest('hex');
const clean=value=>{
  if(Array.isArray(value))return value.map(clean);
  if(!value||typeof value!=='object')return typeof value==='bigint'?value.toString():value;
  return Object.fromEntries(Object.entries(value).filter(([key])=>!['span','type','patternControl'].includes(key)).map(([key,item])=>[key,clean(item)]));
};
const clone=value=>JSON.parse(JSON.stringify(value,(_,item)=>typeof item==='bigint'?item.toString():item));
const checked=[],targets=new WeakMap();let currentCase;
const check=HostChecker.prototype.expr,emit=HostEmitter.prototype.expr;
HostChecker.prototype.expr=function(node,...args){
  if(node.k==='routerPinnedStandardBodyCall')targets.set(node.object,{method:node.method,span:node.span});
  const value=check.call(this,node,...args);
  if(targets.has(node))console.log(JSON.stringify({kind:'actual-checked-receiver',case:currentCase,call:targets.get(node),type:clone(value.type)}));
  if(value.k==='routerPinnedStandardBody')checked.push({case:currentCase,proof:clone(value.pinnedStandardBodyProof),body:clean(value.body)});
  return value;
};
function differences(a,b,path='$',result=[]){
  if(isDeepStrictEqual(a,b))return result;
  if(a&&b&&typeof a==='object'&&typeof b==='object'){
    const keys=new Set([...Object.keys(a),...Object.keys(b)]);
    for(const key of keys)differences(a[key],b[key],path+'.'+key,result);
  }else result.push({path,before:a,after:b});
  return result;
}
HostEmitter.prototype.expr=function(node){
  if(node.k==='routerPinnedStandardBody'){
    const proof=node.pinnedStandardBodyProof,selection=pinnedOptionBody(proof.method),parsed=parsePinnedBody(HostRustParser,selection),before=checked.find(entry=>entry.case===currentCase&&entry.proof.checkedBodyDigest===proof.checkedBodyDigest),body=clean(node.body);
    console.log(JSON.stringify({kind:'actual-before-emission-standard-body',case:currentCase,method:proof.method,selectionEqual:isDeepStrictEqual(proof.selection,selection),syntaxEqual:proof.syntaxSha256===parsedPinnedBodyEvidence(parsed).syntaxSha256,recordedDigest:proof.checkedBodyDigest,beforeDigest:before?hash(JSON.stringify(before.body)):null,emitterDigest:hash(JSON.stringify(body)),type:clone(node.type),differences:before?differences(before.body,body):null,beforeKeys:before?Object.keys(before.body):null,afterKeys:Object.keys(body)}));
  }
  return emit.call(this,node);
};
const selection=pinnedOptionBody('unwrap_or_default'),parsed=parsePinnedBody(HostRustParser,selection);
console.log(JSON.stringify({kind:'genuine-original-default-body-parse',source:selection.method.bodySource,ast:clone(parsed)}));
for(const [name,source]of [
  ['borrowed-eager','pub fn chosen(value:Option<&str>)->&str{value.unwrap_or("fallback")}'],
  ['integer-default','pub fn empty(value:Option<u8>)->u8{value.unwrap_or_default()}'],
  ['computed-str',"pub fn part(value:&str)->&str{value.split('\"').next().unwrap_or_default()}"],
  ['helper-eager','fn receiver(value:Option<u8>)->Option<u8>{value}fn fallback()->u8{9u8}pub fn eager(value:Option<u8>)->u8{receiver(value).unwrap_or(fallback())}'],
]){
  currentCase=name;
  try{const result=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>source});console.log(JSON.stringify({kind:'project-result',case:name,refused:result.meta.refused}));}
  catch(error){console.log(JSON.stringify({kind:'project-error',case:name,name:error.name,message:error.message}));}
}
