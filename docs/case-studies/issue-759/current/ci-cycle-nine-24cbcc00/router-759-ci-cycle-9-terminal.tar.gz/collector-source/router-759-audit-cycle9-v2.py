"""Audit complete read-only cycle nine evidence; refuses partial inventories."""
import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path('/tmp/router-759-ci-cycle-9')
HEAD = '24cbcc0043385b6c319a43b12e7dd96c1fc49f7c'
MERGE = '6b4218de3f90eba4bc1699a5be940fbc0b725c5b'
STAGES = {'lint', 'node-tests', 'bun-tests', 'typescript', 'parity',
          'translation', 'reverse-translation', 'JavaScript fully green'}
runs = json.loads((ROOT / 'runs.json').read_text())
manifest = json.loads((ROOT / 'logs-manifest.json').read_text())
assert len(runs) == 10 and len(manifest) == 10
assert all(r['head_sha'] == HEAD and r['status'] == 'completed' for r in runs)
artifacts = json.loads((ROOT / 'artifacts-inventory.json').read_text())
assert artifacts['headSha'] == HEAD
assert len(artifacts['runs']) == 10 and all(r['runStatus'] == 'completed' for r in artifacts['runs'])
assert artifacts['availableArtifacts'] == 0, 'Available artifact bytes require separate bounded capture'
objects = {}
references = 0
all_jobs = []
reports = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def seconds(start, end):
    if not start or not end:
        return None
    return (datetime.datetime.fromisoformat(end.replace('Z', '+00:00')) -
            datetime.datetime.fromisoformat(start.replace('Z', '+00:00'))).total_seconds()

for run in runs:
    entries = manifest[str(run['id'])]['entries']
    assert manifest[str(run['id'])]['headSha'] == HEAD
    texts = {}
    for entry in entries:
        data = gzip.decompress((ROOT / entry['storedPath']).read_bytes())
        assert len(data) == entry['decodedBytes'] and sha(data) == entry['sha256']
        objects[entry['storedPath']] = entry
        references += 1
        if '/' not in entry['path']:
            texts[entry['path']] = (entry, data.decode('utf8', 'replace'))
    jobs = json.loads((ROOT / 'runs' / str(run['id']) / 'jobs.json').read_text())
    assert all(j['status'] == 'completed' and j['head_sha'] == HEAD for j in jobs)
    all_jobs.extend(jobs)
    gate_jobs = [j for j in jobs if j['name'].startswith('JavaScript first (same commit) / ')]
    assert {j['name'].split(' / ', 1)[1] for j in gate_jobs} == STAGES
    stages = []
    for job in gate_jobs:
        stage = job['name'].split(' / ', 1)[1]
        matching = [(entry, text) for name, (entry, text) in texts.items()
                    if name.endswith(' _ ' + stage + '.txt')]
        assert len(matching) == 1, (run['id'], stage, 'complete job log absent/ambiguous')
        entry, text = matching[0]
        verified_shas = sorted(set(re.findall(r'EXPECTED_SHA:\s*([a-f0-9]{40})', text)))
        if stage != 'JavaScript fully green':
            assert verified_shas == [MERGE]
        annotation_path = ROOT / 'runs' / str(run['id']) / f"job-{job['id']}-annotations.json"
        annotations = json.loads(annotation_path.read_text()) if annotation_path.exists() else []
        steps = [{key: step.get(key) for key in ('name', 'status', 'conclusion', 'started_at', 'completed_at')}
                 | {'timestampSpanSeconds': seconds(step.get('started_at'), step.get('completed_at'))}
                 for step in job.get('steps', [])]
        summaries = []
        for line in text.splitlines():
            payload = re.sub(r'^\d{4}-\d\d-\d\dT\S+\s+', '', line)
            if payload.startswith('{'):
                try:
                    value = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                if value.get('kind') == 'independent-profile-bulk-inventory-v1':
                    summaries.append({'kind': value['kind'], 'matrixSha256': value.get('matrixSha256'),
                                      'sourceSetSha256': value.get('sourceSetSha256'),
                                      'profiles': [{'name': p['name'], 'profileSha256': p['profileSha256'],
                                                    'totals': p['totals']} for p in value['profiles']]})
                elif value.get('mode') == 'check' and 'sources' in value:
                    summaries.append({key: value.get(key) for key in ('mode', 'sources', 'executable',
                                      'executableFunctions', 'executableConstants', 'executableTypes',
                                      'executableConstructors', 'carried', 'preserved')})
        stages.append({'jobId': job['id'], 'stage': stage, 'conclusion': job['conclusion'],
                       'startedAt': job.get('started_at'), 'completedAt': job.get('completed_at'),
                       'timestampSpanSeconds': seconds(job.get('started_at'), job.get('completed_at')),
                       'labels': job.get('labels'), 'runnerGroup': job.get('runner_group_name'),
                       'completeLog': entry, 'verifiedSourceShas': verified_shas, 'steps': steps,
                       'annotations': [{'message': a.get('message'), 'level': a.get('annotation_level')} for a in annotations],
                       'testSummaries': [line for line in text.splitlines() if re.search(r'# (?:tests|pass|fail|cancelled|skipped|duration_ms)\s', line)],
                       'strictInventories': list(dict.fromkeys(re.findall(r'Native parity inventory:[^\r\n]+', text))),
                       'checkDeadlineDiagnostics': list(dict.fromkeys(line for line in text.splitlines() if 'deterministic --check diagnostics:' in line)),
                       'retainedGeneratedInventorySummaries': summaries})
    downstream = [j for j in jobs if j not in gate_jobs]
    assert all(j.get('conclusion') == 'skipped' and not j.get('steps') for j in downstream)
    reports.append({'runId': run['id'], 'workflow': run['name'], 'conclusion': run['conclusion'],
                    'createdAt': run['created_at'], 'updatedAt': run['updated_at'],
                    'runAttempt': run['run_attempt'], 'stages': stages,
                    'skippedDownstreamJobs': [{'id': j['id'], 'name': j['name']} for j in downstream]})

counts = dict(collections.Counter(j['conclusion'] for j in all_jobs))
report = {'schema': 'complete-published-ci-cycle-nine-audit-v1', 'headSha': HEAD,
          'testedMergeSha': MERGE, 'allTenRunsTerminal': True, 'allJobsTerminal': True,
          'jobCounts': counts, 'rustStarted': 0, 'agentRerunOrCancellation': False,
          'logRunsCaptured': len(manifest), 'logReferencesVerified': references,
          'uniqueLogObjectsVerified': len(objects), 'decodedUniqueLogBytes': sum(e['decodedBytes'] for e in objects.values()),
          'integrityErrors': [], 'cpuLoadTelemetryRecorded': False,
          'schedulingCausalityClaim': False, 'artifacts': artifacts, 'runs': reports}
target = ROOT / 'complete-cycle-nine-audit.json'
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(target), 'sha256': sha(target.read_bytes()), 'bytes': target.stat().st_size,
                  'jobCounts': counts, 'runsTerminal': 10, 'rustStarted': 0,
                  'verifiedLogReferences': references, 'uniqueLogObjects': len(objects)}))
