import argparse,datetime,hashlib,json,pathlib,re,subprocess
p=argparse.ArgumentParser();p.add_argument('--head-sha',required=True);p.add_argument('--destination',required=True);a=p.parse_args()
if not re.fullmatch(r'[a-f0-9]{40}',a.head_sha) or not re.fullmatch(r'/tmp/router-759-ci-cycle-[0-9]+',a.destination):p.error('exact head and task-owned cycle directory required')
d=pathlib.Path(a.destination);runs=json.loads((d/'runs.json').read_text());result=[]
for run in runs:
 if run['head_sha']!=a.head_sha:raise RuntimeError('mixed publication head')
 entries=[];page=1
 while True:
  route=f"repos/link-assistant/router/actions/runs/{run['id']}/artifacts?per_page=100&page={page}"
  v=json.loads(subprocess.check_output(['gh','api',route]));entries.extend(v['artifacts'])
  if len(v['artifacts'])<100:break
  page+=1
 result.append({'runId':run['id'],'name':run['name'],'runStatus':run['status'],'runAttempt':run['run_attempt'],'artifacts':entries,'artifactCount':len(entries)})
o={'schema':'published-head-actions-artifact-availability-v1','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headSha':a.head_sha,'runs':result,'availableArtifacts':sum(sum(not x['expired'] for x in r['artifacts']) for r in result),'limit':'availability metadata only; available artifact bytes must be separately captured before final audit'}
b=(json.dumps(o,indent=2)+'\n').encode();out=d/'artifacts-inventory.json';out.write_bytes(b);print(json.dumps({'runs':len(result),'artifactCount':sum(r['artifactCount'] for r in result),'availableArtifacts':o['availableArtifacts'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}))
