"""Create a lossless terminal-CI pack in task-owned /tmp, without repository writes."""
import gzip
import hashlib
import io
import json
import pathlib
import tarfile

ROOT = pathlib.Path('/tmp/router-759-ci-cycle-9')
HEAD = '24cbcc0043385b6c319a43b12e7dd96c1fc49f7c'
audit = json.loads((ROOT / 'complete-cycle-nine-audit.json').read_text())
assert audit['headSha'] == HEAD and audit['allTenRunsTerminal'] and audit['allJobsTerminal']
assert audit['rustStarted'] == 0 and not audit['integrityErrors']
assert audit['logRunsCaptured'] == 10
helpers = ['router-759-collect-cycle-v2.py', 'router-759-ci-terminal-job.py',
           'router-759-ci-artifact-inventory.py', 'router-759-ci-watch-cycle-9.py',
           'router-759-audit-cycle9.py', 'router-759-audit-cycle9-v2.py', 'router-759-pack-ci-cycle9.py']
pairs = [('ci-cycle-9/' + str(p.relative_to(ROOT)), p)
         for p in ROOT.rglob('*') if p.is_file()]
pairs += [('collector-source/' + name, pathlib.Path('/tmp') / name) for name in helpers]
assert sum(p.stat().st_size for _, p in pairs) <= 40 * 1024 * 1024
target = pathlib.Path('/tmp/router-759-ci-cycle-9-terminal.tar.gz')
members = []
same = {}
with target.open('xb') as output:
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
            for name, path in sorted(pairs):
                assert not path.is_symlink()
                data = path.read_bytes()
                digest = hashlib.sha256(data).hexdigest()
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.mtime = 0
                key = (digest, len(data))
                original = same.get(key)
                if original and original[1] == data:
                    info.type = tarfile.LNKTYPE
                    info.linkname = original[0]
                    tar.addfile(info)
                else:
                    info.size = len(data)
                    tar.addfile(info, io.BytesIO(data))
                    same[key] = (name, data)
                members.append({'path': name, 'bytes': len(data), 'sha256': digest,
                                'hardlinkTo': info.linkname if info.islnk() else None})
assert target.stat().st_size <= 6 * 1024 * 1024
with tarfile.open(target, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for member in members:
        data = tar.extractfile(member['path']).read()
        assert len(data) == member['bytes'] and hashlib.sha256(data).hexdigest() == member['sha256']
receipt = {'schema': 'complete-ci-cycle-nine-lossless-pack-v1', 'headSha': HEAD,
           'testedMergeSha': audit['testedMergeSha'], 'jobCounts': audit['jobCounts'],
           'allTenRunsTerminal': True, 'rustStarted': 0,
           'sourceOrCIMutation': False, 'archive': target.name,
           'archiveBytes': target.stat().st_size,
           'archiveSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'auditSha256': hashlib.sha256((ROOT / 'complete-cycle-nine-audit.json').read_bytes()).hexdigest(),
           'members': members, 'reopenedMemberErrors': 0}
dest = pathlib.Path('/tmp/router-759-ci-cycle-9-terminal-pack-receipt.json')
with dest.open('x') as stream:
    stream.write(json.dumps(receipt, separators=(',', ':')) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'members'}
                 | {'members': len(members), 'hardlinks': sum(bool(m['hardlinkTo']) for m in members)}))
