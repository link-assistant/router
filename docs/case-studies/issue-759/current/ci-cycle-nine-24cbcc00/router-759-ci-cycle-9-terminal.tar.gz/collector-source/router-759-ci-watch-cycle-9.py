"""Bounded read-only exact-head CI collection; never cancel, rerun, or publish."""
import collections
import datetime
import json
import pathlib
import subprocess
import sys
import time

HEAD = '24cbcc0043385b6c319a43b12e7dd96c1fc49f7c'
DEST = pathlib.Path('/tmp/router-759-ci-cycle-9')
EXPECTED = {38208484011, 38208483997, 38208484009, 38208483994,
            38208483978, 38208484012, 38208483982, 38208483991,
            38208484068, 38208484024}
END = time.monotonic() + 7200
previous = None
iteration = 0

def run(script, *extra):
    command = [sys.executable, script, '--head-sha', HEAD,
               '--destination', str(DEST), *extra]
    result = subprocess.run(command, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=240)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace')[-3000:])
    return result.stdout.decode(errors='replace')

while time.monotonic() < END:
    iteration += 1
    try:
        run('/tmp/router-759-collect-cycle-v2.py', '--collect-completed')
        runs = json.loads((DEST / 'runs.json').read_text())
        assert {r['id'] for r in runs} == EXPECTED
        assert all(r['head_sha'] == HEAD for r in runs)
        jobs = []
        for record in runs:
            document = json.loads((DEST / 'runs' / str(record['id']) / 'jobs.json').read_text())
            jobs.extend(document.get('jobs', []) if isinstance(document, dict) else document)
        for job in jobs:
            if job.get('conclusion') not in ('failure', 'cancelled', 'timed_out', 'action_required', 'startup_failure'):
                continue
            receipt = DEST / f"job-{job['id']}-terminal-log-receipt.json"
            if not receipt.exists():
                print(run('/tmp/router-759-ci-terminal-job.py', '--job-id', str(job['id'])), flush=True)
        counts = dict(collections.Counter(j.get('conclusion') or j.get('status') for j in jobs))
        active = sum(r['status'] != 'completed' for r in runs)
        signature = json.dumps([[(r['id'], r['status'], r['conclusion']) for r in runs], counts], sort_keys=True)
        if signature != previous or iteration % 5 == 0:
            observation = {'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                           'headSha': HEAD, 'activeWorkflows': active, 'jobCounts': counts,
                           'workflowStates': [{'id': r['id'], 'status': r['status'], 'conclusion': r['conclusion']} for r in runs]}
            with (DEST / 'watch-observations.ndjson').open('a') as stream:
                stream.write(json.dumps(observation, separators=(',', ':')) + '\n')
            print(json.dumps(observation), flush=True)
            previous = signature
        if not active:
            print(run('/tmp/router-759-ci-artifact-inventory.py'), flush=True)
            print('ALL_TEN_CURRENT_WORKFLOWS_TERMINAL', flush=True)
            sys.exit(0)
    except Exception as error:
        print(json.dumps({'collectorError': str(error), 'sourceOrCIMutation': False}), flush=True)
    time.sleep(45)
print('BOUNDED_WATCH_EXPIRED_WITHOUT_TERMINAL_CLAIM', flush=True)
sys.exit(2)
