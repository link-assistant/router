import argparse,gzip,hashlib,json,pathlib,re,resource,subprocess
p=argparse.ArgumentParser();p.add_argument('--head-sha',required=True);p.add_argument('--destination',required=True);p.add_argument('--job-id',required=True,type=int);a=p.parse_args()
if not re.fullmatch(r'[a-f0-9]{40}',a.head_sha) or not re.fullmatch(r'/tmp/router-759-ci-cycle-[0-9]+',a.destination):p.error('exact head and owned cycle required')
d=pathlib.Path(a.destination);runs=json.loads((d/'runs.json').read_text());match=[]
for run in runs:
 if run['head_sha']!=a.head_sha:raise RuntimeError('mixed head')
 for job in json.loads((d/'runs'/str(run['id'])/'jobs.json').read_text()):
  if job['id']==a.job_id:match.append((run,job))
if len(match)!=1 or match[0][1]['status']!='completed':raise RuntimeError('job must be exact-head, unique and terminal')
r,j=match[0];out=d/f'job-{a.job_id}-terminal-log-receipt.json'
if out.exists():
 receipt=json.loads(out.read_text());b=gzip.decompress((d/receipt['storedPath']).read_bytes());assert len(b)==receipt['bytes'] and hashlib.sha256(b).hexdigest()==receipt['sha256']
else:
 temporary=d/f'job-{a.job_id}-terminal.log'
 def limit():resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024*1024,32*1024*1024))
 with temporary.open('wb') as f:result=subprocess.run(['gh','api',f'repos/link-assistant/router/actions/jobs/{a.job_id}/logs'],stdout=f,stderr=subprocess.PIPE,preexec_fn=limit)
 if result.returncode:raise RuntimeError(result.stderr.decode('utf8','replace'))
 b=temporary.read_bytes();digest=hashlib.sha256(b).hexdigest();target=d/'objects'/(digest+'.log.gz');target.parent.mkdir(exist_ok=True)
 if not target.exists():
  encoded=gzip.compress(b,compresslevel=9,mtime=0);stored=sum(x.stat().st_size for x in d.rglob('*') if x.is_file());
  if stored+len(encoded)>40*1024*1024:raise RuntimeError('cycle stored evidence bound exceeded')
  target.write_bytes(encoded)
 assert gzip.decompress(target.read_bytes())==b
 receipt={'jobId':a.job_id,'runId':r['id'],'headSha':a.head_sha,'conclusion':j['conclusion'],'scope':'complete terminal job log before parent workflow terminal','bytes':len(b),'sha256':digest,'storedPath':str(target.relative_to(d)),'storedBytes':target.stat().st_size}
 out.write_text(json.dumps(receipt,indent=2)+'\n');temporary.unlink()
print(json.dumps(receipt));
for line in b.decode('utf8','replace').splitlines():
 if any(q in line for q in ['draft gaps','validation errors','# tests ','# pass ','# fail ','# cancelled ','# skipped ','# duration_ms ','SIGTERM','timed out']):print(line[:1500])
