from pathlib import Path
import argparse, hashlib, io, json, subprocess, tarfile

p = argparse.ArgumentParser()
p.add_argument('--apply', action='store_true')
a = p.parse_args()
r = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
tmp = Path('/tmp')
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=r)
head = git('rev-parse', 'HEAD').decode().strip()
boundary_head = '3ce07c8fbd20edffdaf0c9b44ce47042fe3c65b4'
assert not git('status', '--porcelain'), 'A complete packet requires unchanged committed inputs'
prefixes = [
    'router-759-coordinated-committed-complete-forward-node-v1',
    'router-759-complete-forward-after-boundaries-node-v1',
    'router-759-complete-forward-after-boundaries-bun-v1',
    'router-759-generic-output-boundary-node-v1',
    'router-759-generic-output-boundary-bun-v1',
    'router-759-copy-timeout-batch-candidate-node-v1',
    'router-759-copy-timeout-batch-candidate-node-v2',
    'router-759-copy-timeout-batch-candidate-node-v3',
    'router-759-copy-timeout-batch-candidate-bun-v3',
    'router-759-ci-api-json-compaction-before-measurement-v1',
    'router-759-ci-api-json-compaction-after-measurement-v1',
]
explicit = [
    'router-759-coordinated-committed-forward-failures-v1.json',
    'router-759-generic-output-boundary-integration-v1.json',
    'router-759-coordinated-repair-direct-git-v1.py',
    'router-759-coordinated-repair-direct-git-v1.json',
    'router-759-coordinated-repair-evidence-archive-v1.applied.json',
    'router-759-coordinated-repair-diagnostic-v1.py',
    'router-759-run-isolated-candidate-diagnostic-v3.py',
    'router-759-run-complete-forward-after-boundaries-v1.py',
    'router-759-complete-forward-bun-boundary-failures-v1.json',
    'router-759-bun-timeout-batch-original-fixtures-v1.tar.xz',
    'router-759-bun-timeout-batch-original-fixtures-v1.tar.json',
    'router-759-copy-timeout-batch-candidate-node-v1-complete-failures.json',
    'router-759-copy-timeout-batch-candidate-node-v2-complete-failures.json',
    'router-759-run-coordinated-copy-timeout-batch-v1.py',
    'router-759-run-coordinated-copy-timeout-batch-v2.py',
    'router-759-run-coordinated-copy-timeout-batch-v3.py',
    'router-759-copy-timeout-batch-candidate-node-v2-failures-full-v1.json',
    'router-759-copy-isolated-native-dependency-closure-v1.cjs',
    'router-759-copy-isolated-native-dependency-closure-v1.json',
    Path(__file__).name,
]
found = set()
for prefix in prefixes:
    for suffix in ('.json', '.raw.log', '-inputs.json'):
        f = tmp / (prefix + suffix)
        assert f.is_file(), 'An execution is still incomplete: ' + str(f)
        found.add(f)
    receipt = json.loads((tmp / (prefix + '.json')).read_text())
    assert not receipt['timedOut']
    if 'after-boundaries' in prefix:
        assert receipt['inputsUnchanged'] and receipt['headUnchanged'] and receipt['sourceHead'] == boundary_head and receipt['exitCode'] == (1 if '-bun-' in prefix else 0)
    elif 'copy-timeout-batch' in prefix:
        assert receipt['candidateInputsUnchanged'] and receipt['exitCode'] == (1 if prefix.endswith(('node-v1','node-v2')) else 0)
    elif 'ci-api-json-compaction' in prefix:
        assert receipt['inputsUnchanged'] and receipt['headUnchanged'] and receipt['exitCode'] == 0
    elif 'output-boundary' in prefix:
        assert receipt['candidateInputsUnchanged'] and receipt['exitCode'] == 0
    else:
        assert receipt['inputsUnchanged'] and receipt['headUnchanged'] and receipt['exitCode'] == 1
for name in explicit:
    f = tmp / name
    assert f.is_file(), f
    found.add(f)
copy_originals = [f for f in tmp.iterdir() if f.name.startswith('router-759-copy-layout-batch-') and f.is_file()]
found.update(copy_originals)
found.update(f for f in tmp.iterdir() if f.name.startswith('router-759-ci-api-json-compaction-') and f.is_file())
for engine in ('node', 'bun'):
    copy_receipt=json.loads((tmp / ('router-759-copy-layout-batch-candidate-'+engine+'-tests-final-v1.json')).read_text())
    assert copy_receipt['exitCode']==0 and not copy_receipt['timedOut'] and copy_receipt['candidateInputsUnchanged']
implementation = [
    'tools/translation/README.md',
    'tools/translation/test/builtin-derive-bang-footprints.test.mjs',
    'tools/translation/test/serde-deserialize-bang-footprints.test.mjs',
    'changelog.d/20261013_000013_issue_759_generic_output_boundaries.md',
]
files = [('observations/' + f.name, f.read_bytes()) for f in sorted(found)]
for name in implementation:
    b = (r / name).read_bytes()
    assert git('show', head + ':' + name) == b
    files.append(('implementation/' + name, b))
candidate=Path('/private/tmp/router-759-e68eea368-next-compiler')
for name in ['tools/translation/project-copy.mjs','tools/translation/test/copy-layout-refusal-batches.test.mjs','tools/translation/test/primitive-bool-from.test.mjs','tools/translation/serialization-schema/serialization-schema.test.mjs'] + [row['path'] for row in json.loads((tmp/'router-759-copy-isolated-native-dependency-closure-v1.json').read_text())['files']]:
    files.append(('isolated-copy-layout-draft/'+name,(candidate/name).read_bytes()))
archive_path = tmp / 'router-759-generic-boundary-complete-evidence-v1.tar.xz'
receipt_path = tmp / 'router-759-generic-boundary-complete-evidence-v1.packet.json'
assert not archive_path.exists() and not receipt_path.exists()
rows, dedup = [], {}
with tarfile.open(archive_path, 'w:xz', preset=9) as t:
    for name, b in files:
        digest = sha(b)
        row = {'path': name, 'bytes': len(b), 'sha256': digest}
        entry = tarfile.TarInfo(name)
        entry.mtime, entry.mode = 0, 0o644
        if digest in dedup and dedup[digest][1] == b:
            entry.type, entry.linkname = tarfile.LNKTYPE, dedup[digest][0]
            t.addfile(entry)
            row['storedAsHardlink'] = entry.linkname
        else:
            entry.size = len(b)
            t.addfile(entry, io.BytesIO(b))
            dedup[digest] = (name, b)
        rows.append(row)
with tarfile.open(archive_path) as t:
    for row, (_, original) in zip(rows, files):
        decoded = t.extractfile(row['path']).read()
        assert decoded == original and sha(decoded) == row['sha256']
packet = {
    'schema': 'complete-generic-input-output-boundary-evidence-v1',
    'sourceHead': head,
    'boundaryExecutionSourceHead': boundary_head,
    'completeForwardNode': {'tests':1542,'pass':1542,'fail':0},
    'completeForwardBun': {'tests':1542,'pass':1540,'fail':2,'cause':'two default five-second test timeouts'},
    'coordinatedCandidateBatch': {'testsPerEngine':89,'files':10,'engines':['node','bun'],'allPassed':True},
    'archive': 'complete-evidence.tar.xz',
    'archiveBytes': archive_path.stat().st_size,
    'archiveSha256': sha(archive_path.read_bytes()),
    'members': rows,
    'allDecodedOriginalsVerified': True,
    'completeOriginalBytes': sum(row['bytes'] for row in rows),
    'rustExecutions': 0,
    'fullGatePass': False,
    'strictParityStatus': 'Complete runtime obligations remain mandatory; no green gate stamp',
}
receipt_path.write_text(json.dumps(packet, indent=2) + '\n')
def allocated():
    seen, size = set(), 0
    for base in ('docs/case-studies/issue-759', 'dev/log/issues/759'):
        for f in (r / base).rglob('*'):
            if f.is_file():
                st = f.stat()
                key = (st.st_dev, st.st_ino)
                if key not in seen:
                    seen.add(key)
                    size += st.st_blocks * 512
    return size
before = allocated()
print(json.dumps({'packet': str(receipt_path), 'archive': str(archive_path), 'archiveBytes': packet['archiveBytes'], 'members': len(rows), 'allocatedBytesBefore': before, 'remainingBytesBefore': 500000000 - before}), flush=True)
if a.apply:
    target = r / 'docs/case-studies/issue-759/current/generic-input-output-boundaries'
    assert not target.exists()
    text = '''# Generic input and output boundary verification

This packet keeps every original raw log, full input vector, failure block, harness and changed fixture for the completed generic boundary repair. The failed complete Node suite at source commit `0dead5f8a19378a29d21dfbdc64c76bc974a021b` ran 1,542 tests: 1,540 passed and two fixtures retained the old blanket refusal of generic input certificates. Both committed-compiler export and relocation fixtures passed in that run. The exact two failure blocks are retained.

The unchanged generic source inputs now receive bounded input certificates. The existing builtin Copy route can prove its zero-associated-item namespace sink, while the actual generic Serde output route still refuses its unsupported generated structure. Custom owners remain unresolved. No copying, generic instantiation or generated trait behavior is certified by these changes. All 20 cases across both corrected files pass in each engine. The subsequent complete Node execution passed all 1,542 cases. Bun completed all 1,542 cases with 1,540 passes and two default five-second timeouts, at 13.259 and 6.715 seconds. Both complete raw outputs, immutable committed input vectors and the entire Bun failure inventory are retained. The two original tests keep every source case and assertion and receive explicit finite 30-second budgets. The coordinated Copy and timeout batch passes all 89 actual cases across all ten intended files in both engines; the first two isolated attempts failed because their copied dependency sets omitted the original affinity module and then its storage dependency. Their complete module-load diagnostics, complete raw outputs and inputs remain retained. An automated traversal using the installed TypeScript parser copied all five original relative module dependencies with identical bytes; the complete originals and traversal receipt are retained.

The separate isolated Copy layout prepass draft reuses the existing original declaration refusal collector. Its 58 related cases pass in both engines after two fixture-only corrections. The first full failed targeted run, both exact failure blocks, both initial implementation files, all original/result comparisons and their complete inputs are retained. The comparison with synthetic host declarations excluded kept the actual original input SHA, full Good certificate, field certificates and all missing-layout results identical, reducing checker calls from 66 to three on that constructed graph. This is not a complete corpus timing claim or a source admission change. The earlier four-versus-67 comparison and the source phase probe are also retained unchanged. Whole original-library verification and integration remain required for that draft. The targeted launcher's initial omission of the new Copy fixture is also retained; the corrected commands explicitly include all ten intended files.

`receipt.json` maps every complete TAR original to its decoded SHA256 and length. Identical originals may use ordinary TAR hardlinks. The packet also retains the independent direct-Git verification of all 85 originals in the preceding coordinated repair archive. Twenty-two complete CI commit/comment/timeline responses are stored losslessly in gzip archives. Their decoded originals and Git blobs are verified, and every field of the two complete CI measurement reports remains equal after exact archive-path normalization and exclusion of the added provenance map. The first comparison harness incorrectly assumed absolute input paths; its original source and diagnostic are retained together with the corrected comparison. This reclaimed 1,654,784 allocated bytes and does not establish a corpus speed improvement.

No Rust compilation ran. Complete canonical/profile regeneration and the full strict JavaScript gate remain separate required checks; these translator fixtures grant no full runtime parity or green stamp.
'''
    estimated = ((packet['archiveBytes'] + 4095) // 4096 + (receipt_path.stat().st_size + 4095) // 4096 + (len(text.encode()) + 4095) // 4096) * 4096
    assert before + estimated < 500000000, 'Lossless packet exceeds fixed evidence allocation'
    target.mkdir()
    (target / 'complete-evidence.tar.xz').write_bytes(archive_path.read_bytes())
    (target / 'receipt.json').write_bytes(receipt_path.read_bytes())
    (target / 'README.md').write_text(text)
    after = allocated()
    assert after < 500000000
    result = {'sourceHead': head, 'target': str(target.relative_to(r)), 'originalMembers': len(rows), 'archiveSha256': packet['archiveSha256'], 'allocatedBytesBefore': before, 'allocatedBytesAfter': after, 'remainingBytes': 500000000 - after}
    applied = tmp / 'router-759-generic-boundary-complete-evidence-v1.applied.json'
    assert not applied.exists()
    applied.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
