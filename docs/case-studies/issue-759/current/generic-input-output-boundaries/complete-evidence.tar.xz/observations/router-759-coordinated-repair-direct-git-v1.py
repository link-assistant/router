from pathlib import Path
import subprocess,json,tarfile,io,hashlib
r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');git=lambda *a:subprocess.check_output(['git',*a],cwd=r);head=git('rev-parse','HEAD').decode().strip();sha=lambda b:hashlib.sha256(b).hexdigest();base='docs/case-studies/issue-759/current/coordinated-original-source-repairs';manifest=json.loads(git('show',head+':'+base+'/receipt.json'));encoded=git('show',head+':'+base+'/complete-evidence.tar.xz');assert sha(encoded)==manifest['archiveSha256'] and len(encoded)==manifest['archiveBytes'];mismatches=[]
with tarfile.open(fileobj=io.BytesIO(encoded)) as t:
 assert sorted(x.name for x in t.getmembers())==sorted(x['path'] for x in manifest['members'])
 for row in manifest['members']:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256'];origin=Path('/tmp')/row['path'].split('/',1)[1] if row['path'].startswith('observations/') else r/row['path'].split('/',1)[1]
  if b!=origin.read_bytes():mismatches.append(row['path'])
compacted=json.loads(git('show',head+':docs/case-studies/issue-759/raw/sources/lossless-json-archives.json'));import gzip
for row in compacted['entries']:
 b=git('show',head+':'+row['archivePath']);raw=gzip.decompress(b);assert len(b)==row['archiveBytes'] and sha(b)==row['archiveSha256'];assert len(raw)==row['originalBytes'] and sha(raw)==row['originalSha256'];assert raw==git('show',compacted['sourceHead']+':'+row['logicalOriginalPath'])
assert subprocess.run(['git','diff','--quiet',head,'747bacb6117c28284b2afdc5e0d5ec4306d4c15d','--','*.rs','Cargo.toml','Cargo.lock'],cwd=r).returncode==0
receipt={'schema':'complete-coordinated-evidence-direct-git-verification-v1','verifiedGitHead':head,'archiveSha256':sha(encoded),'originalMembersVerified':len(manifest['members']),'originalMismatchCount':len(mismatches),'mismatches':mismatches,'compactedOriginalGitJsonVerified':len(compacted['entries']),'allOriginalRustAndCargoGitInputsUnchanged':True,'fullGatePass':False,'harnessSha256':sha(Path(__file__).read_bytes())};p=Path('/tmp/router-759-coordinated-repair-direct-git-v1.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');assert not mismatches;print(json.dumps(receipt))
