import json, subprocess, sys
from pathlib import Path

engine = sys.argv[1]
assert engine in ('node', 'bun')
prior = json.loads(Path('/tmp/router-759-coordinated-committed-complete-forward-node-v1.json').read_text())
files = prior['command'][3:]
assert files and all(name.endswith('.test.mjs') for name in files)
root = Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
discovered = sorted(str(path.relative_to(root)) for base in ('tools/translation/test', 'tools/translation/serialization-schema') for path in (root / base).glob('*.test.mjs'))
assert sorted(files) == discovered, 'Complete forward discovery changed'
command = ['node', '--test', '--test-concurrency=2', *files] if engine == 'node' else ['bun', 'test', *files]
prefix = '/tmp/router-759-complete-forward-after-boundaries-' + engine + '-v1'
raise SystemExit(subprocess.run(['python3', '/tmp/router-759-coordinated-repair-diagnostic-v1.py', '--prefix', prefix, '--cap', '1800', '--', *command]).returncode)
