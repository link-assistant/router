import {createHash} from 'node:crypto';
import {writeFileSync,existsSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';

const [root,output]=process.argv.slice(2);
if(!root||!output||existsSync(output))throw new Error('Requires an explicit source root and unused original receipt path');
const module=name=>pathToFileURL(join(root,'tools/translation',name)).href;
const [{projectCopyEvidence},{HostChecker,parseRust},{sourceItems},{resolveModuleBindings},{moduleScopeKey},{PRODUCTION_PROFILE}]=await Promise.all([
  import(module('project-copy.mjs')),import(module('extensions/host-contracts.mjs')),import(module('rust-structure.mjs')),
  import(module('module-bindings.mjs')),import(module('source-module-views.mjs')),import(module('cfg-profile.mjs')),
]);
const source=Array.from({length:64},(_,index)=>`pub struct Bad${index}{value:Missing${index}}`).join(' ')+' #[derive(Clone,Copy)] pub struct Good{value:u8} #[derive(Clone,Copy)] pub struct Dependent{value:Bad0}';
const view={file:'src/lib.rs',path:[],source,items:sourceItems(source),configurationCondition:'active',compilationProfile:PRODUCTION_PROFILE};
const declarations=parseRust(source+' fn main(){}').items.filter(item=>item.k==='data'&&!item.generated).map(surface=>({name:surface.name,term:'struct',file:view.file,path:[],globalSpan:surface.span,surface}));
const scopes=new Map(resolveModuleBindings({modules:[view],compilationProfile:PRODUCTION_PROFILE}).scopes.map(scope=>[moduleScopeKey(scope),scope]));
const ordinary=HostChecker.prototype.program;let calls=0,evidence;
HostChecker.prototype.program=function(surface){calls++;return ordinary.call(this,surface);};
const start=performance.now();
try{evidence=projectCopyEvidence(declarations,[view],new Map(),scopes);}finally{HostChecker.prototype.program=ordinary;}
const elapsed=performance.now()-start,span={start:0,end:source.length},good=evidence(['Good'],view,span);
const result={schema:'router-759-copy-layout-batch-equivalence-v2',root,sourceBytes:Buffer.byteLength(source),sourceSha256:createHash('sha256').update(source).digest('hex'),layoutProgramCalls:calls,layoutPrepassElapsedMs:elapsed,goodCertificate:good,fieldCertificates:evidence.fieldCertificates(['Good'],view,span),missingResults:Object.fromEntries(['Bad0','Bad63','Dependent'].map(name=>[name,evidence([name],view,span)])),measurementScope:'One constructed original source graph and the actual source-bound layout prepass; does not measure complete corpus wall time or memory',rustExecutions:0,fullGateAuthority:false};
writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,calls,elapsedMs:elapsed,goodVerified:good?.verified}));
