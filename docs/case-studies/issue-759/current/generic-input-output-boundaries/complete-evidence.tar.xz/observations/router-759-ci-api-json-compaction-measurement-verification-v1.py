from pathlib import Path
import hashlib,json

r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate')
plan=Path('/tmp/router-759-ci-api-json-compaction-v1.plan.json')
before=Path('/tmp/router-759-ci-api-json-compaction-before-measurements-v1.json')
after=Path('/tmp/router-759-ci-api-json-compaction-after-measurements-v1.json')
output=Path('/tmp/router-759-ci-api-json-compaction-measurement-verification-v1.json')
assert not output.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads(plan.read_text());a=json.loads(before.read_text());b=json.loads(after.read_text())
manifest=str(r/'docs/case-studies/issue-759/raw/ci/lossless-api-json-archives.json')
assert manifest in b['sources'] and manifest not in a['sources']
b['sources']=[s for s in b['sources'] if s!=manifest]
mapping={str(r/e['archivePath']):str(r/e['logicalOriginalPath']) for e in p['entries']}
def normalize(value):
 if isinstance(value,list):return [normalize(v) for v in value]
 if isinstance(value,dict):return {k:normalize(v) for k,v in value.items()}
 if isinstance(value,str):
  for new,old in mapping.items():value=value.replace(new,old)
  return value
 return value
normalized=normalize(b)
assert a==normalized, 'A complete archived CI measurement field changed beyond its archive location'
result={'schema':'router-759-ci-api-json-compaction-full-measurement-verification-v1','before':{'path':str(before),'bytes':before.stat().st_size,'sha256':sha(before.read_bytes())},'after':{'path':str(after),'bytes':after.stat().st_size,'sha256':sha(after.read_bytes())},'normalizedArchiveLocations':mapping,'excludedAddedProvenanceInput':manifest,'allReportFieldsEqualAfterArchiveLocationNormalization':True,'verifiedSummary':a['summary'],'method':'Compare every complete report field, including runs/jobs/PRs/source paths/warnings/resource samples; normalize only exact gzip archive paths and the newly added provenance input','sourceHeadAtPlan':p['sourceHead'],'rustExecutions':0,'fullGateAuthority':False}
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
