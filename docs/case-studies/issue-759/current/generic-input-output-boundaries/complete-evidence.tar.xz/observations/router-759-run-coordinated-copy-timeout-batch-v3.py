import subprocess
files=['tools/translation/test/copy-layout-refusal-batches.test.mjs', 'tools/translation/test/project-copy-context.test.mjs', 'tools/translation/test/copy-translation.test.mjs', 'tools/translation/test/copy-methods.test.mjs', 'tools/translation/test/project-refusal-batches.test.mjs', 'tools/translation/test/project-method-refusals.test.mjs', 'tools/translation/test/project-body-refusals.test.mjs', 'tools/translation/test/nominal-targets.test.mjs', 'tools/translation/test/primitive-bool-from.test.mjs', 'tools/translation/serialization-schema/serialization-schema.test.mjs']
for engine in ("node","bun"):
 command=(["node","--test","--test-concurrency=2"] if engine=="node" else ["bun","test"])+files
 result=subprocess.run(["python3","/tmp/router-759-run-isolated-candidate-diagnostic-v3.py","--root","/private/tmp/router-759-e68eea368-next-compiler","--prefix","/tmp/router-759-copy-timeout-batch-candidate-"+engine+"-v3","--cap","300","--"]+command)
 if result.returncode:raise SystemExit(result.returncode)
