import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
const root='/private/tmp/router-759-e68eea368-next-compiler';
const load=name=>import(pathToFileURL(join(root,'tools/translation',name)).href);
const [{projectCopyEvidence},{HostChecker,parseRust},{sourceItems},{resolveModuleBindings},{moduleScopeKey},{PRODUCTION_PROFILE},{declarationRefusals}]=await Promise.all([
  load('project-copy.mjs'),load('extensions/host-contracts.mjs'),load('rust-structure.mjs'),load('module-bindings.mjs'),load('source-module-views.mjs'),load('cfg-profile.mjs'),load('extensions/declaration-refusals.mjs'),
]);
const source=Array.from({length:64},(_,index)=>`pub struct Bad${index}{value:Missing${index}}`).join(' ')+' #[derive(Clone,Copy)] pub struct Good{value:u8} #[derive(Clone,Copy)] pub struct Dependent{value:Bad0}';
const module={file:'src/lib.rs',path:[],source,items:sourceItems(source),configurationCondition:'active',compilationProfile:PRODUCTION_PROFILE};
const declarations=parseRust(source+' fn main(){}').items.filter(item=>item.k==='data').map(surface=>({name:surface.name,term:'struct',file:module.file,path:[],globalSpan:surface.span,surface}));
const scopes=new Map(resolveModuleBindings({modules:[module],compilationProfile:PRODUCTION_PROFILE}).scopes.map(scope=>[moduleScopeKey(scope),scope]));
const ordinary=HostChecker.prototype.program;let count=0;
HostChecker.prototype.program=function(surface){const call=++count;try{const result=ordinary.call(this,surface);console.log(JSON.stringify({call,success:true}));return result;}catch(error){const failures=declarationRefusals(error);console.log(JSON.stringify({call,failures:failures?.map(f=>({name:f.name,phase:f.phase,reason:f.error.reason,span:f.error.span}))??[{reason:error.reason,span:error.span}]}));throw error;}};
try{const proof=projectCopyEvidence(declarations,[module],new Map(),scopes)(['Good'],module,{start:0,end:source.length});console.log(JSON.stringify({goodVerified:proof.verified}));}finally{HostChecker.prototype.program=ordinary;}
