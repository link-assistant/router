Source-only next-batch review after the a3f857 frozen pair:

1. Before retaining an unknown external module source candidate, require exactly one original non-inactive module declaration of that actual name in its parent. Preserve unknown status and no body authority. Add same-named Unix/Windows alternatives with separate trait/struct candidates and assert neither child is read or executable; use existing module-path project case.
2. Verify the exact original `library/core/src/arch.rs` public bridge to the captured core_arch family root before granting architecture nontrait-role absence evidence; no target selection or callee authority.
3. Expose bounded original refusal owner names and refusal phase in progress diagnostics if needed to diagnose the previously observed 42 singleton declaration removals at the 1200-second corpus bound. This is source-only instrumentation; emitted artifacts must remain equal with/without callbacks, and callback errors must precede writes.
4. Preserve a3f857 Node/Bun full terminal raw logs and whole frozen input/runner/source evidence. No edits until both engines finish. No Rust build.
