from pathlib import Path
import gzip,hashlib,json,subprocess,os,argparse
p=argparse.ArgumentParser();p.add_argument('--apply',action='store_true');a=p.parse_args()
r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');prefix=Path('/tmp/router-759-source-json-compaction-v1');prepared=Path(str(prefix)+'-prepared');planfile=Path(str(prefix)+'.plan.json');sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *s:subprocess.check_output(['git',*s],cwd=r);head=git('rev-parse','HEAD').decode().strip()
def allocated():
 seen=set();size=0
 for root in [r/'docs/case-studies/issue-759',r/'dev/log/issues/759']:
  for f in root.rglob('*'):
   if f.is_file():
    s=f.stat();k=(s.st_dev,s.st_ino)
    if k not in seen:seen.add(k);size+=s.st_blocks*512
 return size
if not a.apply:
 assert not planfile.exists() and not prepared.exists();prepared.mkdir();entries=[]
 for f in sorted((r/'docs/case-studies/issue-759/raw/sources').rglob('*.json')):
  if 'files' in f.relative_to(r/'docs/case-studies/issue-759/raw/sources').parts:continue
  b=f.read_bytes()
  if len(b)<100000:continue
  path=f.relative_to(r).as_posix();oldgit=git('show',head+':'+path);assert b==oldgit
  json.loads(b);g=gzip.compress(b,compresslevel=9,mtime=0);assert gzip.decompress(g)==b
  target=path+'.gz';assert not (r/target).exists();out=prepared/(str(len(entries))+'.json.gz');out.write_bytes(g)
  entries.append({'logicalOriginalPath':path,'archivePath':target,'originalBytes':len(b),'originalSha256':sha(b),'originalGitBlob':git('rev-parse',head+':'+path).decode().strip(),'archiveBytes':len(g),'archiveSha256':sha(g),'preparedPath':str(out),'originalAllocatedBytes':f.stat().st_blocks*512})
 documents=[]
 for f in sorted((r/'docs/case-studies/issue-759').rglob('*.md')):
  if '/raw/sources/' in f.as_posix():continue
  old=f.read_text();new=old
  for e in entries:
   rel=os.path.relpath(r/e['logicalOriginalPath'],f.parent)
   new=new.replace(']('+rel+')',']('+rel+'.gz)')
  if new!=old:
   o=prepared/('document-'+str(len(documents))+'.md');o.write_text(new);documents.append({'path':f.relative_to(r).as_posix(),'oldSha256':sha(old.encode()),'newSha256':sha(new.encode()),'preparedPath':str(o)})
 plan={'schema':'router-759-original-source-json-lossless-compaction-v1','sourceHead':head,'combinedEvidenceCapBytes':500000000,'allocatedBytesBefore':allocated(),'entries':entries,'citationUpdates':documents,'allOriginalGitBytesVerified':True,'allDecodedOriginalsByteIdentical':True,'scope':'Lossless gzip archives of original GitHub API JSON only; snapshot source files and historical receipt vectors are unchanged','semanticAuthority':False}
 planfile.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'plan':str(planfile),'files':len(entries),'citations':len(documents),'logicalSavingBytes':sum(e['originalBytes']-e['archiveBytes'] for e in entries),'allocatedBytesBefore':plan['allocatedBytesBefore']}))
else:
 plan=json.loads(planfile.read_text());assert plan['sourceHead']==head
 for e in plan['entries']:
  b=(r/e['logicalOriginalPath']).read_bytes();g=Path(e['preparedPath']).read_bytes();assert sha(b)==e['originalSha256'] and sha(g)==e['archiveSha256'] and gzip.decompress(g)==b and git('show',head+':'+e['logicalOriginalPath'])==b;assert not (r/e['archivePath']).exists()
 for e in plan['citationUpdates']:assert sha((r/e['path']).read_bytes())==e['oldSha256'] and sha(Path(e['preparedPath']).read_bytes())==e['newSha256']
 before=allocated()
 for e in plan['entries']:
  (r/e['archivePath']).write_bytes(Path(e['preparedPath']).read_bytes());assert gzip.decompress((r/e['archivePath']).read_bytes())==git('show',head+':'+e['logicalOriginalPath']);(r/e['logicalOriginalPath']).unlink()
 for e in plan['citationUpdates']:(r/e['path']).write_bytes(Path(e['preparedPath']).read_bytes())
 manifest={k:v for k,v in plan.items() if k not in ['entries','citationUpdates']};manifest['entries']=[{k:v for k,v in e.items() if k!='preparedPath'} for e in plan['entries']];manifest['citationUpdates']=[{k:v for k,v in e.items() if k!='preparedPath'} for e in plan['citationUpdates']];manifest['decode']='gzip -dc ARCHIVE.json.gz; verify decoded length and SHA256 against entries';m=r/'docs/case-studies/issue-759/raw/sources/lossless-json-archives.json';assert not m.exists();m.write_text(json.dumps(manifest,indent=2)+'\n')
 after=allocated();assert after<before and after<500000000
 receipt={'schema':'router-759-source-json-compaction-applied-v1','sourceHead':head,'allocatedBytesBefore':before,'allocatedBytesAfter':after,'allocatedBytesReclaimed':before-after,'remainingBytes':500000000-after,'entries':len(plan['entries']),'allDecodedOriginalsByteIdentical':True,'allOriginalGitBytesVerified':True,'manifest':m.relative_to(r).as_posix(),'manifestSha256':sha(m.read_bytes()),'planSha256':sha(planfile.read_bytes()),'harnessSha256':sha(Path(__file__).read_bytes())};Path(str(prefix)+'.applied.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
