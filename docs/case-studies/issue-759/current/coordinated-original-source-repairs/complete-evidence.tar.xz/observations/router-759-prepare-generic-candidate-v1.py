from pathlib import Path
import subprocess,json,hashlib
r=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-gate');c=Path('/private/tmp/router-759-e68eea368-next-compiler');assert c.is_dir();sha=lambda b:hashlib.sha256(b).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();names=sorted(set(subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z','--','tools/translation','*.rs','Cargo.toml','Cargo.lock','scripts/translate-router.mjs'],cwd=r).decode().split('\0'))-{''});rows=[]
for n in names:
 if n.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/')):continue
 f=r/n
 if not f.is_file():continue
 b=f.read_bytes();target=c/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);assert target.read_bytes()==b;rows.append({'path':n,'bytes':len(b),'sha256':sha(b)})
p=Path('/tmp/router-759-generic-candidate-original-export-v1.json');assert not p.exists();p.write_text(json.dumps({'schema':'isolated-original-compiler-export-v1','sourceHead':head,'sourceTree':'coordinated repairs tested by paired 111 cases; dirty original-source worktree','files':rows,'allOriginalSourceBytesPreserved':True,'runtimeAuthority':False},indent=2)+'\n');print(json.dumps({'sourceHead':head,'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'receipt':str(p),'sha256':sha(p.read_bytes())}))
