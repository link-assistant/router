import argparse, datetime, hashlib, json, os, re, resource, signal, subprocess, sys, time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--engine', choices=['node', 'bun'], required=True)
parser.add_argument('--phase', required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('--timeout', type=int, default=360)
parser.add_argument('--scope', choices=['bulk', 'all'], default='all')
args = parser.parse_args()
if not re.fullmatch(r'[a-z][a-z0-9-]{0,48}', args.phase):
    raise RuntimeError('Safe distinct evidence phase required')
cwd = Path(args.cwd)
bulk = ['reexport-generic-owners', 'public-reexports']
modules = ['module-bindings', 'source-namespaces', 'source-namespace-bindings', 'module-path-project', 'module-paths', 'crate-aliases', 'macro-use-bindings', 'macro-subnamespaces-compiler', 'source-links', 'ownership', 'local-lifetime-constraints', 'standard-source-identities', 'generated-type-owners', 'copy-methods']
paths = ['tools/translation/test/' + name + '.test.mjs' for name in dict.fromkeys(bulk + (modules if args.scope == 'all' else []))]
for path in paths:
    if not (cwd / path).is_file():
        raise RuntimeError('Missing focused test: ' + path)
git = lambda *a: subprocess.check_output(['git', *a], cwd=cwd)
status = lambda: git('status', '--porcelain', '--untracked-files=no').decode()
head_before = git('rev-parse', 'HEAD').decode().strip()
status_before = status()
if status_before:
    raise RuntimeError('Focused command requires a clean tracked source tree')
log = Path('/tmp/router-759-core-canonical-type-owners-' + args.phase + '-' + args.engine + '.log')
receipt = log.with_suffix('.json')
inputs = log.with_suffix('.inputs.json')
if any(path.exists() for path in [log, receipt, inputs]):
    raise RuntimeError('Attempt evidence exists; use a new phase and retain it')

def source_inputs():
    records = git('ls-files', '-z', '--', 'tools/translation', 'scripts/translate-router.mjs', '*.rs', 'Cargo.toml', 'Cargo.lock', 'packages/javascript/package.json', 'packages/javascript/package-lock.json').decode().split('\0')
    result = []
    for path in sorted(set(records) - {''}):
        if path.startswith(('tools/translation/meta/', 'tools/translation/projects/')):
            continue
        absolute = cwd / path
        raw = absolute.read_bytes() if absolute.is_file() else git('show', 'HEAD:' + path)
        result.append({'path': path, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    encoded = json.dumps(result, separators=(',', ':'), ensure_ascii=True).encode()
    return result, hashlib.sha256(encoded).hexdigest()

before, digest_before = source_inputs()
inputs.write_text(json.dumps({'sourceHead': head_before, 'sha256': digest_before, 'files': before}, indent=2) + '\n')
engine_version = subprocess.check_output([args.engine, '--version'], cwd=cwd, text=True).strip()
command = ([args.engine, '--test', '--test-concurrency=1'] if args.engine == 'node' else [args.engine, 'test', '--max-concurrency', '1']) + paths
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
started_utc = utc()
started = time.monotonic()
table_command = None
table_exit = None
table_timed_out = False
timed_out = False
with log.open('wb') as stream:
    process = subprocess.Popen(['/usr/bin/time', '-p'] + command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        exit_code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        exit_code = process.returncode
elapsed = round(time.monotonic() - started, 3)
finished_utc = utc()
raw = log.read_bytes()
clean = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode(errors='replace'))
if args.engine == 'node':
    counts = {key: int(match.group(1)) if (match := re.search(r'^# ' + key + r' (\d+)\s*$', clean, re.M)) else None for key in ['tests', 'pass', 'fail', 'skipped', 'todo']}
else:
    def count(label):
        matches = re.findall(r'^\s*(\d+) ' + label + r'\s*$', clean, re.M)
        return int(matches[-1]) if matches else None
    counts = {'tests': None, 'pass': count('pass'), 'fail': count('fail'), 'skipped': count('skip') or 0, 'todo': None}
    if counts['pass'] is not None and counts['fail'] is not None:
        counts['tests'] = counts['pass'] + counts['fail'] + counts['skipped']
head_after = git('rev-parse', 'HEAD').decode().strip()
status_after = status()
after, digest_after = source_inputs()
passed = exit_code == 0 and not timed_out and head_before == head_after and not status_after and digest_before == digest_after and bool(counts['pass']) and counts['fail'] == 0 and counts['skipped'] == 0
result = {'schemaVersion': 1, 'scope': 'exact original parsed type occurrence and consumer scope preserve public canonical owners through generated type normalization; not a corpus producer or full parity gate', 'evidenceStatus': 'FOCUSED_PASS_NOT_FULL_GATE' if passed else 'FOCUSED_FAIL_NOT_FULL_GATE', 'phase': args.phase, 'engine': args.engine, 'engineVersion': engine_version, 'command': command, 'testFiles': len(paths), 'timeoutSeconds': args.timeout, 'testStageTimeoutSeconds':args.timeout,'sourceTableCheckTimeoutSeconds':None,'maximumTestAndTableWallSeconds':args.timeout, 'startedUtc': started_utc, 'finishedUtc': finished_utc, 'elapsedSeconds': elapsed, 'exitCode': exit_code, 'timedOut': timed_out, 'sourceHeadBefore': head_before, 'sourceHeadAfter': head_after, 'trackedStatusBefore': status_before, 'trackedStatusAfter': status_after, 'sourceHeadUnchanged': head_before == head_after, 'sourceInputSha256Before': digest_before, 'sourceInputSha256After': digest_after, 'sourceInputsUnchanged': digest_before == digest_after, 'inputManifest': str(inputs), 'inputManifestBytes': inputs.stat().st_size, 'inputManifestSha256': hashlib.sha256(inputs.read_bytes()).hexdigest(), 'inputFiles': len(before), 'log': str(log), 'logBytes': len(raw), 'logSha256': hashlib.sha256(raw).hexdigest(), 'counts': counts, 'sourceTableCheckCommand':table_command,'sourceTableCheckExitCode':table_exit,'sourceTableCheckRuns':0,'producerRuns': 0, 'rustBuilds': 0, 'fullGateRuns': 0, 'measurement': {'timeFormat': 'posix', 'ownedChildrenMaxRssBytes': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss * (1 if sys.platform == 'darwin' else 1024), 'rssScope': 'all terminated harness child processes, including git and engine version; not process-tree peak or peak footprint'}}
result['sourceTableCheckTimedOut']=table_timed_out
result['sourceTableCheckElapsedSeconds']=None
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
sanitized = re.sub(r'data:text/javascript;base64,[A-Za-z0-9+/=]+', '<data-url-checker-module>', clean)
print(sanitized[-3500:], flush=True)
raise SystemExit(0 if passed else 1)
