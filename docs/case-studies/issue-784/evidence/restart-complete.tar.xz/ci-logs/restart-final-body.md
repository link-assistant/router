Fixes #784

Router previously forwarded location headers and optional search coordinates to
providers. This draft removes supported explicit geolocation metadata by default
from routed inference HTTP, native replay and JSON WebSocket messages. Exactly
one `x-router-share-geolocation: true` header opts in for a request or WebSocket
connection. Router consumes that control header and preserves prompts, tool
schemas, search availability and existing telemetry choices.

The JavaScript policy has matching Rust source, shared fixtures and generated
native TypeScript. Account header overrides cannot restore unconsented location
or ingress IP headers. Gemini retrieval coordinates cover all eight independent
ProtoJSON field-spelling combinations; six mixed combinations leaked before the
restart fix. Existing bounded decoders and WebSocket inspection are reused, with
no new dependency. The historical compiler fixtures retain authenticated original
inputs, their original assertions, strictness and deadlines.

Reproduce by sending a native inference request with `CF-IPCountry: GB`,
`X-Vercel-IP-City: London`, supported search `user_location`, or a mixed-spelling
Gemini retrieval coordinate and inspecting a synthetic upstream. The complete
`geolocation.test.mjs` and `geolocation-websocket.test.mjs` files verify removal,
opt-in, repeated/invalid consent, preserved application content and fragmented
WebSocket forwarding. Node and Bun each pass all **30 focused cases**; the full
native suites each pass **259 cases**.

Validation is incomplete. The unchanged full local JavaScript gate at source
commit `08e09f884546ecf373dfa2997f7d0dd906a0cb1c` attempted all seven groups.
Lint and both native suites pass. Both strict API checks, generation freshness,
strict compilation of 165 native TypeScript files and all nine TypeScript
receiving TAP cases pass. The independent deadline audit fails at
152128.545269 ms against the original 60000 ms limit. All 121 parity acceptance
cases pass, while strict parity fails with 441 draft gaps, a stale account-policy
hash and 12345 carried Rust items. Forward translation was stopped before its
coordinator and two workers exhausted the 2.92 GiB container; reverse translation
results will be recorded after that stage closes. No deadline or parity status
was relaxed. Lockfile TypeScript is 5.9.3.

Earlier published-head CI has separate exact-SHA evidence. Its remaining results
will be added only after the complete cycle finishes. Rust has not run locally
and remains gated in CI by JavaScript failures. No green full gate or Rust
qualification is claimed.

The [case study](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/case-studies/issue-784/README.md)
contains all requirements, GitHub source data, the client matrix, primary-source
research, alternatives and remaining obligations. The
[verification record](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/case-studies/issue-784/verification.md)
preserves complete compressed logs and exact tested SHAs. The
[configuration guide](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/privacy/geolocation.md)
shows actual Codex and Claude Code defaults and opt-in settings. Changelog
fragments use the repository's automated version/release process.

This PR stays **draft and unmerged**. The literal all-tool guarantee remains
unmet: connection IPs are visible, vendors retain mandatory security location
inference, account privacy controls require the respective authenticated
accounts, and direct client, telemetry, OAuth or MCP traffic can bypass Router.
Cursor's private protocol and Gemini subscription modes remain unsupported.
Removing optional metadata does not establish full translation or parity.
