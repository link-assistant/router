#!/usr/bin/env rust-script
//! Create GitHub Release from CHANGELOG.md
//!
//! Usage: rust-script scripts/create-github-release.rs --release-version <version> --repository <repository>
//!   [--crates-io-url <url>] [--docker-hub-url <url>] [--prerelease true]
//!
//! ```cargo
//! [dependencies]
//! regex = "1"
//! serde = { version = "1", features = ["derive"] }
//! serde_json = "1"
//! ```

use regex::Regex;
use serde::Serialize;
use std::env;
use std::fs;
use std::io::Write;
use std::path::Path;
use std::process::{Command, Stdio, exit};

fn get_arg(name: &str) -> Option<String> {
    let args: Vec<String> = env::args().collect();
    let flag = format!("--{}", name);

    if let Some(idx) = args.iter().position(|a| a == &flag) {
        return args.get(idx + 1).cloned();
    }

    let env_name = name.to_uppercase().replace('-', "_");
    env::var(&env_name).ok().filter(|s| !s.is_empty())
}

/// The largest release body the GitHub API accepts.
///
/// Undocumented in the REST reference and enforced as a plain HTTP 422 with no
/// explanatory message, which is how a release for a large changelog failed
/// with nothing on the line to say why.
const MAX_RELEASE_BODY: usize = 125_000;

/// Keep a release body inside what the API will accept, saying what was cut.
///
/// A truncated body that names the full changelog is a release page; a 422 is
/// no release page at all. The marker matters as much as the cut: without it a
/// reader cannot tell a short changelog from a shortened one.
fn fit_release_body(body: String, tag: &str, repository: &str) -> String {
    if body.len() <= MAX_RELEASE_BODY {
        return body;
    }
    let notice = format!(
        "\n\n---\n\n*This release note was truncated to fit GitHub's {MAX_RELEASE_BODY}-character \
         limit. The complete entry is in [CHANGELOG.md](https://github.com/{repository}/blob/{tag}/CHANGELOG.md).*\n"
    );
    // Cut on a line boundary so the body never ends mid-sentence, and never
    // inside a multi-byte character.
    let budget = MAX_RELEASE_BODY.saturating_sub(notice.len());
    let mut end = 0;
    for (index, byte) in body.bytes().enumerate() {
        if index >= budget {
            break;
        }
        if byte == b'\n' {
            end = index + 1;
        }
    }
    if end == 0 {
        end = body
            .char_indices()
            .map(|(index, _)| index)
            .take_while(|index| *index <= budget)
            .last()
            .unwrap_or(0);
    }
    format!("{}{}", &body[..end], notice)
}

fn get_changelog_for_version(version: &str) -> String {
    let changelog_path = "CHANGELOG.md";

    if !Path::new(changelog_path).exists() {
        return format!("Release v{}", version);
    }

    let content = match fs::read_to_string(changelog_path) {
        Ok(c) => c,
        Err(_) => return format!("Release v{}", version),
    };

    let escaped_version = regex::escape(version);
    let header_pattern = format!(r"(?m)^## \[{escaped_version}\]");
    let header_re = Regex::new(&header_pattern).unwrap();

    if let Some(version_header) = header_re.find(&content) {
        let after_header = &content[version_header.end()..];
        let body_start = after_header
            .find('\n')
            .map_or(after_header.len(), |i| i + 1);
        let body = &after_header[body_start..];

        let next_section_re = Regex::new(r"(?m)^## \[").unwrap();
        let section_body = if let Some(next) = next_section_re.find(body) {
            &body[..next.start()]
        } else {
            body
        };

        let trimmed = section_body.trim();
        if trimmed.is_empty() {
            format!("Release v{}", version)
        } else {
            trimmed.to_string()
        }
    } else {
        format!("Release v{}", version)
    }
}

fn badge_escape(value: &str) -> String {
    value
        .replace('-', "--")
        .replace('_', "__")
        .replace(' ', "%20")
        .replace('/', "%2F")
        .replace(':', "%3A")
}

fn crates_io_badge(url: &str, version: &str) -> String {
    let version_url = format!("{}/{}", url.trim_end_matches('/'), version);
    format!(
        "[![crates.io](https://img.shields.io/crates/v/link-assistant-router.svg?label=crates.io)]({}) [![crates.io v{}](https://img.shields.io/badge/crates.io-v{}-orange)]({})",
        url,
        version,
        badge_escape(version),
        version_url
    )
}

fn docker_hub_badge(url: &str, version: &str) -> String {
    let image = url
        .trim_end_matches('/')
        .strip_prefix("https://hub.docker.com/r/")
        .unwrap_or("konard/link-assistant-router");
    let tag_url = format!("{}/tags?name={}", url.trim_end_matches('/'), version);
    let image_tag = format!("{}:{}", image, version);

    format!(
        "[![Docker Hub {}](https://img.shields.io/badge/docker-{}-2496ED?logo=docker)]({})",
        version,
        badge_escape(&image_tag),
        tag_url
    )
}

#[derive(Serialize)]
struct ReleasePayload {
    tag_name: String,
    name: String,
    body: String,
    /// Incomplete releases stay visible for artifact upload, but cannot be Latest.
    prerelease: bool,
    /// Whether this release becomes the one GitHub marks "Latest".
    ///
    /// GitHub derives that marker from publication time, so a release page
    /// created late for an *older* version takes it from the newest one — and
    /// every tool that asks for "the latest release" then gets the wrong
    /// version. A backfill sends `"false"`; a current release omits the field
    /// and keeps GitHub's default.
    #[serde(skip_serializing_if = "Option::is_none")]
    make_latest: Option<String>,
}

/// Versions with a tag on the default branch but no release page.
///
/// The pipeline creates the release page last, so anything that refuses it
/// leaves a version whose tag, crate and images all published with nothing to
/// point a user at — and no later run revisited it, because each run only ever
/// published its own version. That is how v0.116.0 shipped without a release.
fn orphaned_versions(repository: &str, tag_prefix: &str) -> Vec<String> {
    // The release job checks out the tag, not a branch, so `origin/main` may
    // not be a ref here. Fall back to every release tag rather than to nothing:
    // a tag that is not on the default branch simply has no changelog section,
    // and `publish_release` reports that rather than inventing a release.
    let tags = ["origin/main", "HEAD"]
        .into_iter()
        .find_map(|reference| {
            let output = Command::new("git")
                .args([
                    "tag",
                    "--merged",
                    reference,
                    "--sort=v:refname",
                    "--list",
                    &format!("{tag_prefix}*"),
                ])
                .output()
                .ok()?;
            output
                .status
                .success()
                .then(|| String::from_utf8_lossy(&output.stdout).into_owned())
        })
        .unwrap_or_default();
    if tags.trim().is_empty() {
        return Vec::new();
    }
    let releases = match Command::new("gh")
        .args([
            "release",
            "list",
            "--repo",
            repository,
            "--limit",
            "1000",
            "--json",
            "tagName",
            "--jq",
            ".[].tagName",
        ])
        .output()
    {
        Ok(output) if output.status.success() => {
            String::from_utf8_lossy(&output.stdout).into_owned()
        }
        _ => return Vec::new(),
    };
    missing_release_versions(&tags, &releases, tag_prefix)
}

/// The versions in `tags` that no entry in `releases` covers.
fn missing_release_versions(tags: &str, releases: &str, tag_prefix: &str) -> Vec<String> {
    let published: Vec<&str> = releases
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect();
    tags.lines()
        .map(str::trim)
        .filter(|tag| !tag.is_empty() && tag.starts_with(tag_prefix))
        .filter(|tag| !published.contains(tag))
        .filter_map(|tag| tag.strip_prefix(tag_prefix))
        .map(str::to_string)
        .collect()
}

/// gh writes the structured API response to stdout, and only a short HTTP
/// diagnostic to stderr. Accept only duplicate tag errors, never a generic
/// validation failure or an English phrase that could describe another error.
fn is_duplicate_release(stdout: &[u8]) -> bool {
    let Ok(response) = serde_json::from_slice::<serde_json::Value>(stdout) else {
        return false;
    };
    // GitHub may include a string or numeric HTTP status in the body. If it
    // does, contradictory authentication/server errors must not be reused.
    if let Some(status) = response.get("status") {
        if status != "422" && status != 422 {
            return false;
        }
    }
    let Some(errors) = response["errors"].as_array() else {
        return false;
    };
    !errors.is_empty()
        && errors.iter().all(|error| {
            error["resource"] == "Release"
                && error["code"] == "already_exists"
                && error["field"] == "tag_name"
        })
}

fn release_tag_endpoint(repository: &str, tag: &str) -> String {
    use std::fmt::Write as _;

    let mut encoded = String::new();
    for byte in tag.bytes() {
        if byte.is_ascii_alphanumeric() || b"-._~".contains(&byte) {
            encoded.push(char::from(byte));
        } else {
            write!(encoded, "%{byte:02X}").expect("write tag to String");
        }
    }
    format!("repos/{repository}/releases/tags/{encoded}")
}

/// Confirm the exact tag after a duplicate POST. This read preserves assets,
/// notes and publication state, including an already-complete stable release.
fn confirm_existing_release(repository: &str, tag: &str) -> Result<(), String> {
    let output = Command::new("gh")
        .args(["api", &release_tag_endpoint(repository, tag)])
        .output()
        .map_err(|error| format!("Release {tag} lookup failed: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "Release {tag} lookup failed: {}\n{}",
            String::from_utf8_lossy(&output.stderr),
            String::from_utf8_lossy(&output.stdout)
        ));
    }
    let release: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("Release {tag} lookup returned invalid JSON: {error}"))?;
    if release["tag_name"] != tag || release["id"].as_u64().is_none() {
        return Err(format!(
            "Release {tag} lookup did not return the exact-tag release"
        ));
    }
    println!("Release {tag} already exists; preserving its assets and publication state");
    Ok(())
}

/// Publish one version's release page, or report why it could not be.
fn publish_release(
    version: &str,
    repository: &str,
    tag_prefix: &str,
    crates_io_url: Option<&str>,
    docker_hub_url: Option<&str>,
    backfill: bool,
    prerelease: bool,
) -> Result<(), String> {
    let tag = format!("{}{}", tag_prefix, version);
    println!("Creating GitHub release for {}...", tag);

    let mut release_notes = get_changelog_for_version(version);

    // Add package/image badges so release pages visibly show registry status.
    let mut badges = Vec::new();
    if let Some(url) = crates_io_url {
        badges.push(crates_io_badge(url, version));
    }
    if let Some(url) = docker_hub_url {
        badges.push(docker_hub_badge(url, version));
    }
    if !badges.is_empty() {
        release_notes = format!("{}\n\n{}", badges.join("\n"), release_notes);
    }

    // Create release using GitHub API with JSON input
    let payload = ReleasePayload {
        tag_name: tag.clone(),
        name: format!("{}{}", tag_prefix, version),
        body: fit_release_body(release_notes, &tag, repository),
        prerelease,
        make_latest: (backfill || prerelease).then(|| "false".to_string()),
    };

    let payload_json = serde_json::to_string(&payload).expect("Failed to serialize payload");

    let mut child = Command::new("gh")
        .args([
            "api",
            &format!("repos/{repository}/releases"),
            "-X",
            "POST",
            "--input",
            "-",
        ])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("Failed to execute gh command");

    if let Some(ref mut stdin) = child.stdin {
        stdin
            .write_all(payload_json.as_bytes())
            .expect("Failed to write to stdin");
    }

    let output = child
        .wait_with_output()
        .expect("Failed to wait on gh command");

    if output.status.success() {
        println!("Created GitHub release: {tag}");
        return Ok(());
    }
    if is_duplicate_release(&output.stdout) {
        return confirm_existing_release(repository, &tag);
    }
    Err(format!(
        "Error creating release {tag}: {}\n{}",
        String::from_utf8_lossy(&output.stderr),
        String::from_utf8_lossy(&output.stdout)
    ))
}

fn main() {
    let version = match get_arg("release-version") {
        Some(v) => v,
        None => {
            eprintln!("Error: Missing required argument --release-version");
            eprintln!(
                "Usage: rust-script scripts/create-github-release.rs --release-version <version> --repository <repository>"
            );
            exit(1);
        }
    };

    let repository = match get_arg("repository") {
        Some(r) => r,
        None => {
            eprintln!("Error: Missing required argument --repository");
            eprintln!(
                "Usage: rust-script scripts/create-github-release.rs --release-version <version> --repository <repository>"
            );
            exit(1);
        }
    };

    let tag_prefix = get_arg("tag-prefix").unwrap_or_else(|| "v".to_string());
    let crates_io_url = get_arg("crates-io-url");
    let docker_hub_url = get_arg("docker-hub-url");
    let prerelease = get_arg("prerelease").as_deref() == Some("true");

    if let Err(error) = publish_release(
        &version,
        &repository,
        &tag_prefix,
        crates_io_url.as_deref(),
        docker_hub_url.as_deref(),
        false,
        prerelease,
    ) {
        eprintln!("{error}");
        exit(1);
    }

    // Artifact preparation cannot announce unrelated, unverified releases.
    if prerelease {
        return;
    }

    // Then any version that shipped without a release page. Reporting an
    // orphan was not enough: the report had nowhere to go but a human, and the
    // scheduled audit that fails on it cannot create what is missing.
    let orphans = orphaned_versions(&repository, &tag_prefix);
    if orphans.is_empty() {
        return;
    }
    println!(
        "Backfilling {} release page(s) that shipped without one: {}",
        orphans.len(),
        orphans.join(", ")
    );
    let failed: Vec<String> = orphans
        .into_iter()
        .filter(|orphan| {
            publish_release(
                orphan,
                &repository,
                &tag_prefix,
                crates_io_url.as_deref(),
                docker_hub_url.as_deref(),
                true,
                false,
            )
            .map_err(|error| eprintln!("{error}"))
            .is_err()
        })
        .collect();
    if !failed.is_empty() {
        eprintln!(
            "::error::could not backfill {}; the scheduled release audit will keep reporting them",
            failed.join(", ")
        );
        exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exact_tag_lookup_encodes_custom_prefixes_as_one_path_component() {
        assert_eq!(
            release_tag_endpoint("fixture/router", "release/v#%1.18.1"),
            "repos/fixture/router/releases/tags/release%2Fv%23%251.18.1"
        );
        assert_eq!(
            release_tag_endpoint("fixture/router", "v1.18.1"),
            "repos/fixture/router/releases/tags/v1.18.1"
        );
    }

    #[test]
    fn only_structured_duplicate_tag_errors_are_reusable() {
        let duplicate = serde_json::json!({
            "resource": "Release", "code": "already_exists", "field": "tag_name"
        });
        let response = |errors| {
            serde_json::to_vec(&serde_json::json!({
                "message": "Validation Failed", "errors": errors
            }))
            .unwrap()
        };
        assert!(is_duplicate_release(&response(vec![duplicate.clone()])));
        assert!(!is_duplicate_release(&response(
            Vec::<serde_json::Value>::new()
        )));
        assert!(!is_duplicate_release(&response(vec![
            duplicate,
            serde_json::json!({"resource": "Release", "code": "invalid", "field": "body"})
        ])));
        for stdout in [
            b"already exists".as_slice(),
            b"not JSON",
            br#"{"status":"422"}"#,
        ] {
            assert!(!is_duplicate_release(stdout));
        }
    }

    #[test]
    fn an_incomplete_release_is_a_prerelease_and_never_latest() {
        let payload = ReleasePayload {
            tag_name: "v1.16.1".into(),
            name: "v1.16.1".into(),
            body: "artifact preparation".into(),
            prerelease: true,
            make_latest: Some("false".into()),
        };
        let json = serde_json::to_value(payload).unwrap();
        assert_eq!(json["prerelease"], true);
        assert_eq!(json["make_latest"], "false");
    }

    /// A body inside the limit is published exactly as written.
    #[test]
    fn an_ordinary_release_note_is_left_alone() {
        let body = "## [1.2.3]\n\n- one fix\n".to_string();
        assert_eq!(fit_release_body(body.clone(), "v1.2.3", "owner/repo"), body);
    }

    /// A changelog larger than the limit produced an HTTP 422 with no message,
    /// so a release that was built, tested and tagged had no release page.
    /// Truncating publishes it and says where the rest is.
    #[test]
    fn an_oversized_release_note_is_published_truncated_and_says_so() {
        let body = "- a changelog entry that repeats\n".repeat(8_000);
        assert!(body.len() > MAX_RELEASE_BODY, "the fixture must overflow");

        let fitted = fit_release_body(body, "v0.116.0", "owner/repo");

        assert!(
            fitted.len() <= MAX_RELEASE_BODY,
            "the API rejects anything larger: {} bytes",
            fitted.len()
        );
        assert!(
            fitted.contains("truncated"),
            "a shortened body must not read as a complete one"
        );
        assert!(
            fitted.contains("owner/repo/blob/v0.116.0/CHANGELOG.md"),
            "and must name where the rest is: {}",
            &fitted[fitted.len() - 300..]
        );
        // Cut on a line boundary, so the body never ends mid-entry.
        let kept = fitted.split("\n\n---\n\n").next().expect("body");
        assert!(kept.ends_with('\n'), "the cut lands between entries");
    }

    /// The cut must never land inside a multi-byte character, which would
    /// panic on the slice and lose the release entirely.
    #[test]
    fn a_body_of_multibyte_characters_is_cut_safely() {
        // No newlines at all, so the line-boundary search finds nothing and
        // the character-boundary fallback has to carry it.
        let body = "é".repeat(MAX_RELEASE_BODY);
        let fitted = fit_release_body(body, "v1.0.0", "owner/repo");
        assert!(fitted.len() <= MAX_RELEASE_BODY);
        assert!(fitted.contains("truncated"));
    }

    /// A tag with no release page is a version that shipped with nothing to
    /// point a user at. The pipeline creates the page last, so anything that
    /// refuses it strands the version — and nothing revisited it, because each
    /// run only published its own.
    #[test]
    fn a_tag_without_a_release_is_reported_for_backfill() {
        let tags = "v0.115.0\nv0.116.0\nv0.117.0\n";
        let releases = "v0.117.0\nv0.115.0\n";

        assert_eq!(
            missing_release_versions(tags, releases, "v"),
            vec!["0.116.0"],
            "the version that shipped without a release page"
        );
    }

    /// Nothing to do when every tag already has one, so an ordinary release
    /// run does no extra work and says nothing extra.
    #[test]
    fn a_complete_release_set_needs_no_backfill() {
        let tags = "v0.115.0\nv0.116.0\n";
        let releases = "v0.116.0\nv0.115.0\n";

        assert!(missing_release_versions(tags, releases, "v").is_empty());
    }

    /// Whitespace and blank lines from `git tag` / `gh release list` must not
    /// invent an orphan: backfilling a version that does not exist would fail
    /// the pipeline for nothing.
    #[test]
    fn ragged_command_output_does_not_invent_an_orphan() {
        let tags = "\n v0.116.0 \n\n";
        let releases = "\nv0.116.0\n \n";

        assert!(missing_release_versions(tags, releases, "v").is_empty());
    }

    /// A tag that is not a release tag at all is left alone.
    #[test]
    fn only_release_tags_are_considered() {
        let tags = "nightly-2026-08-26\nv0.116.0\n";
        let releases = "v0.116.0\n";

        assert!(missing_release_versions(tags, releases, "v").is_empty());
    }

    /// A backfilled release must never take the "Latest" marker. GitHub
    /// derives it from publication time, so a page created late for an older
    /// version becomes "Latest" and every tool asking for the newest release
    /// gets the wrong one — which is exactly what v0.116.0 did to v0.118.0.
    #[test]
    fn a_backfilled_release_never_becomes_latest() {
        let backfill = ReleasePayload {
            tag_name: "v0.116.0".into(),
            name: "v0.116.0".into(),
            body: "notes".into(),
            prerelease: false,
            make_latest: true.then(|| "false".to_string()),
        };
        let json = serde_json::to_string(&backfill).expect("serialize");
        assert!(
            json.contains("\"make_latest\":\"false\""),
            "a backfill must say so explicitly: {json}"
        );
    }

    /// A release published on time keeps GitHub's own default, so the field is
    /// omitted rather than guessed at.
    #[test]
    fn a_current_release_leaves_the_marker_to_github() {
        let current = ReleasePayload {
            tag_name: "v0.118.0".into(),
            name: "v0.118.0".into(),
            body: "notes".into(),
            prerelease: false,
            make_latest: false.then(|| "false".to_string()),
        };
        let json = serde_json::to_string(&current).expect("serialize");
        assert!(
            !json.contains("make_latest"),
            "the field must be absent, not false: {json}"
        );
    }
}
