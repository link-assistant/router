Requests through Router previously forwarded derived location headers and optional search coordinates without a location-consent policy. This draft removes supported explicit inference location metadata by default and permits it with exactly one `x-router-share-geolocation: true` header. Router consumes the header. Search, prompts, tool schemas and existing credential filtering remain intact.

The implementation covers supported HTTP inference, native byte replay and JSON WebSocket messages, including fragmented messages. JavaScript defines the behavior, generated TypeScript follows its existing producer, and Rust has matching source and shared regression fixtures. The case study records the original issue, primary vendor research, all client boundaries, alternatives and requirement-to-evidence mapping in `docs/case-studies/issue-784/`.

Reproduce the original disclosure by forwarding a native request with `CF-IPCountry: GB`, or an inference body containing a search tool's `user_location`. The pre-fix header regression fails; the new default removes those fields, while explicit opt-in preserves them. Automated regressions also capture real localhost HTTP/WebSocket forwarding, control frames, client EOF, native replay, malformed metadata and consent values.

Validation and exact failure evidence will be filled after the complete local gate and the starting head's entire CI cycle finish. No Rust tools have run locally. Passing focused checks does not establish complete parity or a green gate.

This remains an incomplete draft. Router cannot hide its network source IP, disable providers' mandatory security geolocation, modify unauthenticated vendor account settings, or control direct client connections that bypass it. Cursor's private integration remains unsupported. The full acceptance criterion and same-head CI must pass before readiness; the PR remains unmerged.

Fixes #784
