from pathlib import Path

folder=Path('tools/translation/js-to-rust/test')
def edit(name,changes):
    path=folder/(name+'.test.mjs');source=path.read_text()
    source="import {historicalNativeSources,materializeHistoricalNativeSources} from './historical-native-source.mjs';\n"+source
    for before,after in changes:
        assert before in source,(name,before)
        source=source.replace(before,after)
    path.write_text(source)

edit('callback-inputs',[
 ("originalSources=manifest.nativeCoverage.map(row=>({path:row.path,source:readFileSync(join(ROOT,row.path),'utf8')}))", "historical=historicalNativeSources(),originalSources=manifest.nativeCoverage.map(row=>({path:row.path,source:historical.source(row.path)}))"),
 ("const source=readFileSync(join(ROOT,row.path),'utf8'),analysis=", "const source=historical.source(row.path),analysis=")])
edit('closures',[("sources=manifest.modules.map(module=>({path:module.path,source:readFileSync(join(ROOT,module.path),'utf8')}))", "historical=historicalNativeSources(),sources=manifest.modules.map(module=>({path:module.path,source:historical.source(module.path)}))")])
edit('captured-primitives',[
 ("for(const path of sourceModules(ROOT).filter(path=>path.startsWith('js/src/')&&path.endsWith('.mjs'))){", "const historical=historicalNativeSources();\n  for(const path of historical.paths.filter(path=>path.startsWith('js/src/')&&path.endsWith('.mjs'))){"),
 ("const source=readFileSync(join(ROOT,rustPackageSourcePath(ROOT,path)),'utf8'),current=analyzeJavaScript", "const source=historical.source(path),current=analyzeJavaScript")])
edit('source-calls',[
 ("for(const path of sourceModules(ROOT).filter(path=>path.startsWith('js/src/')&&path.endsWith('.mjs'))){const source=readFileSync(join(ROOT,rustPackageSourcePath(ROOT,path)),'utf8')", "const historical=historicalNativeSources();\n  for(const path of historical.paths.filter(path=>path.startsWith('js/src/')&&path.endsWith('.mjs'))){const source=historical.source(path)")])
edit('sequence-patterns',[
 ("for(const historical of baseline.modules) {", "const original=historicalNativeSources();\n  for(const historical of baseline.modules) {"),
 ("const source=readFileSync(join(ROOT,previous.path),'utf8');", "const source=original.source(previous.path);")])
edit('scoped-payloads',[
 ("const censusPaths=JSON.parse", "const historical=historicalNativeSources();\n  const censusPaths=JSON.parse"),
 ("for(const path of censusPaths){const source=readFileSync(join(ROOT,rustPackageSourcePath(ROOT,path)),'utf8')", "for(const path of censusPaths){const source=historical.source(path)")])
edit('implicit-completion',[
 ("const paths=execFileSync('git',['ls-files','-z','--','js/src/*.mjs'],{cwd:WORK,encoding:'utf8'}).split('\\0').filter(Boolean);", "const historical=historicalNativeSources(),paths=historical.paths.filter(path=>path.startsWith('js/src/')&&path.endsWith('.mjs'));"),
 ("for(const path of paths){const source=readFileSync(join(WORK,path),'utf8')", "for(const path of paths){const source=historical.source(path)")])
edit('source-constructors',[("records=modules.map(module=>({path:module.path,source:readFileSync(join(root,module.path),'utf8')}))", "historical=historicalNativeSources(),records=modules.map(module=>({path:module.path,source:historical.source(module.path)}))")])
edit('completions',[
 ("const inventory=spawnSync('git',['ls-files','-z','--','js/src'],{cwd:root,encoding:'utf8',timeout:10000});assert.equal(inventory.status,0);\n  const paths=inventory.stdout.split('\\0').filter(path=>path.endsWith('.mjs')).sort();assert.equal(paths.length,52);\n  const sources=paths.map(path=>({path,source:readFileSync(join(root,rustPackageSourcePath(root,path)),'utf8')}))", "const historicalRoot=realpathSync(mkdtempSync(join(tmpdir(),'router-original-native-source-')));t.after(()=>rmSync(historicalRoot,{recursive:true,force:true}));\n  const historical=materializeHistoricalNativeSources(historicalRoot,root),paths=historical.paths.filter(path=>path.startsWith('js/src/')&&path.endsWith('.mjs'));assert.equal(paths.length,52);\n  const sources=paths.map(path=>({path,source:historical.source(path)}))"),
 ("join(root,'js/src/protocols.mjs')", "join(historicalRoot,'js/src/protocols.mjs')"),
 ("program,'image_media',[value],{sourceRoot:root,executeOriginalModules:true}", "program,'image_media',[value],{sourceRoot:historicalRoot,executeOriginalModules:true}")])
edit('static-native-performance',[
 ("import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';", "import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,rmSync} from 'node:fs';\nimport {tmpdir} from 'node:os';\nimport {join} from 'node:path';"),
 ("for(const path of sourceModules(sourceRoot).filter(path=>path.startsWith('js/src/'))){const source=readFileSync(resolve(sourceRoot,path),'utf8')", "const historical=historicalNativeSources();\n for(const path of historical.paths.filter(path=>path.startsWith('js/src/'))){const source=historical.source(path)"),
 ("test('all59 original native TypeScript source trees and full output artifacts match the previous independent producer',{timeout:60000},async()=>{", "test('all59 original native TypeScript source trees and full output artifacts match the previous independent producer',{timeout:60000},async t=>{\n const originalRoot=mkdtempSync(join(tmpdir(),'router-original-native-typescript-'));t.after(()=>rmSync(originalRoot,{recursive:true,force:true}));materializeHistoricalNativeSources(originalRoot,sourceRoot);"),
 ("ts=loadTypeScript(sourceRoot),rows=[],paths=sourceModules(sourceRoot);assert.equal(paths.length,59);", "ts=loadTypeScript(originalRoot),rows=[],paths=sourceModules(originalRoot);assert.equal(paths.length,59);"),
 ("for(const path of paths){const source=readFileSync(resolve(sourceRoot,path),'utf8'),previous=old.parseNativeJavaScript", "for(const path of paths){const source=readFileSync(resolve(originalRoot,path),'utf8'),previous=old.parseNativeJavaScript"),
 ("const previous=old.buildNativeTypeScript(sourceRoot),current=buildNativeTypeScript(sourceRoot);", "const previous=old.buildNativeTypeScript(originalRoot),current=buildNativeTypeScript(originalRoot);")])

# Avoid extra unused imports where a census only needs source strings.
for path in folder.glob('*.test.mjs'):
    source=path.read_text()
    if source.startswith('import {historicalNativeSources,materializeHistoricalNativeSources}'):
        if source.count('materializeHistoricalNativeSources')==1:source=source.replace('historicalNativeSources,materializeHistoricalNativeSources','historicalNativeSources')
        if source.count('historicalNativeSources')==1:source=source.replace('historicalNativeSources,materializeHistoricalNativeSources','materializeHistoricalNativeSources')
        path.write_text(source)
