import testCase from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,Hash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {prepareDefaultProofByteAdoption,prepareDefaultProofByteEnclosingHistory,prepareDefaultProofByteReceivingSources,prepareDefaultProofBytePreEntryProbe} from '../prepare-default-proof-byte-adoption.mjs';
import {withDefaultProofByteConsumers as scoped} from '../default-proof-byte-operation.mjs';
import {createScopedPrivateNativeProofJsonSerializer as byteSerializer} from '../operation-proof-byte-bridge.mjs';
import {createScopedPrivateNativeProofJsonSerializer as oldSerializer} from '../private-native-proof-json.mjs';
import * as enclosing from '../derive-enclosing-namespace-context.mjs';
import * as defaults from '../default-trait-source.mjs';
import * as classic from '../derive-bang-context.mjs';
import {loadDeriveDependencyProof} from '../derive-dependencies.mjs';
import {createDeriveFootprintContext,deriveFootprintExternalModules} from '../derive-footprints.mjs';
import {PRODUCTION_PROFILE} from '../cfg-profile.mjs';
import {repositorySourceURL} from './fixtures/repository-paths.mjs';
import {transportConcreteSyntaxMeta} from '../concrete-syntax-meta.mjs';
const root=new URL('../../../',import.meta.url),nativeJSON=JSON.stringify,get=Object.getOwnPropertyDescriptor,define=Object.defineProperty,apply=Reflect.apply,hash=value=>createHash('sha256').update(value).digest('hex');
let vectors=[];const retain=(kind,value)=>{vectors.push({kind,value});return value;};
const test=(name,run)=>testCase(name,{timeout:60000},async()=>{vectors=[];try{await run();}finally{const out=process.env.ROUTER_DEFAULT_PROOF_BYTE_EVIDENCE_DIR;if(out){mkdirSync(out,{recursive:true});const raw=Buffer.from(nativeJSON({name,vectors})+'\n'),packed=gzipSync(raw,{mtime:0});assert.deepEqual(gunzipSync(packed),raw);writeFileSync(join(out,hash(name)+'.json.gz'),packed);}}});
function fixture(source='#[derive(serde::Serialize,serde::Deserialize,Clone,Debug,PartialEq,Eq,PartialOrd,Ord)] pub struct Payload { value:u8 }'){
 const dependencies=loadDeriveDependencyProof({manifest:readFileSync(repositorySourceURL('Cargo.toml',root),'utf8'),lock:readFileSync(repositorySourceURL('Cargo.lock',root),'utf8')}),modules=[{file:'src/lib.rs',path:[],source:'mod model;'},{file:'src/model.rs',path:['model'],source}],deriveContext=createDeriveFootprintContext({modules,dependencies,compilationProfile:PRODUCTION_PROFILE});
 return {deriveContext,modules,externalModules:deriveFootprintExternalModules(deriveContext),compilationProfile:PRODUCTION_PROFILE};
}
const outcome=run=>{try{return {value:run()};}catch(error){return {error:{name:error.name,message:error.message}};}};
async function baseline(){const plan=retain('complete-native-CST-original-receiving-copies',prepareDefaultProofByteReceivingSources({root:fileURLToPath(root)})),apis={};for(const row of plan.files){assert.equal(row.inverse,row.before);assert.equal(transportConcreteSyntaxMeta(row.beforeMeta).source,row.before);assert.equal(transportConcreteSyntaxMeta(row.afterMeta).source,row.after);apis[row.path.endsWith('default-trait-source.mjs')?'defaults':'enclosing']=await import('data:text/javascript;base64,'+Buffer.from(row.after).toString('base64'));}return apis;}
function hashes(run){const update=get(Hash.prototype,'update'),digest=get(Hash.prototype,'digest'),tape=[];try{define(Hash.prototype,'update',{...update,value:function(...args){tape.push({operation:'update',args:args.map(value=>typeof value==='string'?value:{base64:Buffer.from(value).toString('base64')})});return apply(update.value,this,args);}});define(Hash.prototype,'digest',{...digest,value:function(...args){const value=apply(digest.value,this,args);tape.push({operation:'digest',args,value});return value;}});return {value:run(),tape};}finally{define(Hash.prototype,'update',update);define(Hash.prototype,'digest',digest);}}
function jsonCalls(run){const prior=get(JSON,'stringify'),tape=[];try{define(JSON,'stringify',{...prior,value:function(...args){tape.push({receiver:this===JSON,args:args.map(value=>typeof value)});return apply(prior.value,this,args);}});return {result:outcome(run),tape};}finally{define(JSON,'stringify',prior);}}
test('complete default issuer source equations preserve both historical import and scope layers every native binding and Hash site',()=>{
 const plan=retain('complete-default-source-proposal',prepareDefaultProofByteAdoption());assert.equal(plan.files.length,9);assert.equal(plan.historicalLayers.length,1);assert.equal(plan.sameOriginalPrivateIssuers,true);assert.equal(plan.classicCreatorUnchanged,true);assert.equal(plan.originalSourceOwnerAndHashCallsUnchanged,true);assert.equal(plan.newAcrossInvocationEncodedCache,false);assert.equal(plan.performanceQualified,false);assert.equal(plan.diagnosticWarmingCountersMayDiffer,true);
 for(const row of plan.files){assert.equal(row.current,row.after,row.path);assert.equal(row.inverse,row.before);assert.equal(hash(row.before),row.beforeSha256);assert.equal(hash(row.after),row.afterSha256);assert.equal(transportConcreteSyntaxMeta(row.beforeMeta).source,row.before);assert.equal(transportConcreteSyntaxMeta(row.afterMeta).source,row.after);assert.deepEqual(row.stages.map(stage=>stage.phase),['language','repository']);assert.equal(row.nativeCopies.length,2);assert.ok(row.nativeCopies.every(copy=>copy.completeNativeAstCopy));assert.equal(row.nativeBindings.nativeSemanticScopeChecked,true);for(const stage of row.stages){assert.equal(stage.completeInverse,true);assert.equal(transportConcreteSyntaxMeta(stage.beforeMeta).source,stage.before);assert.equal(transportConcreteSyntaxMeta(stage.afterMeta).source,stage.after);}}
 const context=plan.files.find(row=>row.path.endsWith('/derive-enclosing-namespace-context.mjs')),birth=plan.historicalLayers[0].files.find(row=>row.path===context.path);assert.equal(context.before,birth.after);assert.equal(context.inverse,birth.after);assert.ok(context.after.includes(context.originalCall));assert.equal(context.nativeSelections.length,1);assert.equal(context.repositorySelections.length,1);assert.equal(plan.files.filter(row=>row.serializerBindings).length,5);
 const history=retain('complete-one-row-current-enclosing-history',prepareDefaultProofByteEnclosingHistory());assert.equal(history.files.length,1);assert.deepEqual(history.files[0],context);assert.deepEqual(history.inputs,plan.inputs);assert.deepEqual(history.prerequisiteInputs,plan.prerequisiteInputs);assert.equal(history.files[0].inverse,history.historicalLayers[0].files.find(row=>row.path===context.path).after);
 const producer=plan.files.find(row=>row.path.endsWith('/prepare-whole-owner-proof-byte-candidate.mjs'));assert.equal(producer.nativeSelections.length,1);assert.match(producer.nativeSelections[0].replacement,/operation-proof-byte-bridge/);
 assert.equal(producer.preBindingLayer.after,producer.bindingSourceHistory.before);
 assert.equal(producer.bindingSourceHistory.after,producer.after);
 assert.equal(producer.bindingSourceHistory.inverse,producer.preBindingLayer.after);
 assert.equal(producer.bindingSourceHistory.equation.nativeBindings.nativeSemanticScopeChecked,true);
 assert.deepEqual(producer.bindingSourceHistory.equation.stages.map(stage=>stage.phase),['language','repository']);
 assert.equal(producer.stages[1].composedFrom.length,2);
 assert.deepEqual(producer.originalHashCalls,producer.bindingSourceHistory.equation.originalHashCalls);
});
test('original enclosing issuer produces the complete original DATA and keeps its own private context identity',async()=>{
 const old=await baseline(),input=retain('complete-current-profile-and-module-input',fixture()),expected=old.enclosing.createDeriveEnclosingNamespaceContext(input),actual=enclosing.createDeriveEnclosingNamespaceContext(input);retain('complete-old-and-installed-enclosing-contexts',{expected,actual});assert.deepEqual(actual,expected);
 assert.deepEqual(enclosing.deriveEnclosingNamespaceModules(actual,input),old.enclosing.deriveEnclosingNamespaceModules(expected,input));assert.throws(()=>enclosing.deriveEnclosingNamespaceModules(expected,input),/context|original|sealed|changed/u);assert.throws(()=>old.enclosing.deriveEnclosingNamespaceModules(actual,input),/context|original|sealed|changed/u);
});
test('Default enriched external bindings run the original resolver and original same-issuer enclosing context without bulk eligibility',async()=>{
 const old=await baseline(),input=retain('complete-Default-module-and-profile-input',fixture('#[derive(Default,Clone,Debug)] pub struct Payload { value:u8 }')),deriveBangContext=enclosing.createDeriveEnclosingNamespaceContext(input),options={deriveBangContext},expected=old.defaults.createDefaultEnclosingSourceContext(input.deriveContext,options),actual=defaults.createDefaultEnclosingSourceContext(input.deriveContext,options);retain('complete-old-and-installed-Default-contexts',{expected,actual});assert.deepEqual(actual,expected);
 const oldFacts=old.defaults.defaultSourceContextFacts(expected),actualFacts=defaults.defaultSourceContextFacts(actual);assert.equal(actualFacts.deriveContext,input.deriveContext);assert.equal(actualFacts.dependencies,oldFacts.dependencies);assert.deepEqual(actualFacts.binding,oldFacts.binding);assert.throws(()=>defaults.defaultSourceContextFacts(expected),/copied|unsealed/u);assert.throws(()=>old.defaults.defaultSourceContextFacts(actual),/copied|unsealed/u);
});
test('every original Hash update digest argument and native callback tape stays identical under the installed creator wrappers',async()=>{
 const old=await baseline(),input=fixture('#[derive(Clone,Debug,PartialEq,Eq)] pub struct Payload { value:u8 }'),before=()=>old.enclosing.createDeriveEnclosingNamespaceContext(input),after=()=>enclosing.createDeriveEnclosingNamespaceContext(input);before();after();const expected=hashes(before),actual=hashes(after);retain('complete-native-Hash-tapes',{expected,actual});assert.ok(expected.tape.length>0);assert.deepEqual(actual,expected);
 const oldJSON=jsonCalls(before),newJSON=jsonCalls(after);retain('complete-observed-JSON-tapes',{oldJSON,newJSON});assert.deepEqual(newJSON,oldJSON);
});
test('optional bridge refusal before entry runs the old operation once and entered exceptions are never replayed',async()=>{
 const probe=retain('complete-native-CST-pre-entry-fallback-probe',prepareDefaultProofBytePreEntryProbe()),api=await import('data:text/javascript;base64,'+Buffer.from(probe.file.after).toString('base64'));assert.equal(probe.file.inverse,probe.file.before);let runs=0;const marker={original:true};assert.equal(api.withDefaultProofByteConsumers(()=>{runs++;return marker;}),marker);assert.equal(runs,1);runs=0;assert.throws(()=>api.withDefaultProofByteConsumers(()=>{runs++;throw marker;}),error=>error===marker);assert.equal(runs,1);
 runs=0;assert.throws(()=>scoped(()=>{runs++;throw marker;}),error=>error===marker);assert.equal(runs,1);assert.equal(scoped(()=>scoped(()=>marker)),marker);assert.throws(()=>scoped(()=>Promise.resolve(1)),/synchronous|thenable/u);let gets=0;const thenable=define({},'then',{get(){gets++;throw marker;}});assert.throws(()=>scoped(()=>thenable),/synchronous|thenable/u);assert.equal(gets,0);
});
test('classic repeated-call identity and copied foreign mutated issuer refusals remain the original contracts',()=>{
 const input=fixture('#[derive(Clone)] pub struct Payload { value:u8 }'),first=classic.createDeriveBangContext(input),second=classic.createDeriveBangContext(input);assert.equal(first,second);const context=enclosing.createDeriveEnclosingNamespaceContext(input),foreign=fixture('#[derive(Clone)] pub struct Payload { value:u16 }');
 for(const candidate of [{...context},JSON.parse(nativeJSON(context)),{...context,digest:'mutated'}])assert.throws(()=>enclosing.deriveEnclosingNamespaceModules(candidate,input),/context|original|sealed|changed/u);assert.throws(()=>enclosing.deriveEnclosingNamespaceModules(context,foreign),/context|original|sealed|changed/u);for(const deriveContext of [{...input.deriveContext},JSON.parse(nativeJSON(input.deriveContext))])assert.throws(()=>enclosing.createDeriveEnclosingNamespaceContext({deriveContext}),/original|sealed|context/u);
 for(const changed of [{...input,modules:input.modules.map((row,at)=>at===1?{...row,source:row.source+'\n// changed physical source'}:row)},{...input,modules:input.modules.slice(1)},{...input,compilationProfile:{flags:{test:true}}},{...input,externalModules:new Map([...input.externalModules,['foreign',{unknown:true}]])}])assert.throws(()=>enclosing.deriveEnclosingNamespaceModules(context,changed),/context|original|source|profile|namespace|incomplete|changed/u);
 retain('complete-original-classic-and-enclosing-contexts',{first,second,context});
});
test('outside-frame serializers and fallback getters toJSON proxy cycles retain complete old callbacks and close after every return',()=>{
 const old=oldSerializer(),next=byteSerializer(),value=Object.freeze({name:'original immutable DATA',nested:Object.freeze({text:'😀\r\n',count:4})});assert.equal(scoped(()=>next(value)),old(value));assert.equal(next(value),old(value));
 for(const make of [serialize=>({get value(){return {nested:serialize(value)};}}),serialize=>({toJSON(){return {nested:serialize(value)};}}),()=>new Proxy({text:'proxy'},{}),()=>{const value={};value.self=value;return value;}]){const expected=jsonCalls(()=>old(make(old))),actual=jsonCalls(()=>scoped(()=>next(make(next))));retain('complete-original-callback-fallback',{expected,actual});assert.deepEqual(actual,expected);}
 const expected=jsonCalls(()=>old(value)),actual=jsonCalls(()=>next(value));retain('complete-outside-operation-callbacks',{expected,actual});assert.deepEqual(actual,expected);
});
