# Private inference reuse during native regeneration

Native TypeScript regeneration keeps one private TypeScript inference program
for an unchanged source root. The public parser and `buildNativeTypeScript`
continue to create fresh programs. Neither public route can obtain the private
program, checker or syntax nodes retained by regeneration.

Before reusing inference, regeneration creates a fresh compiler host and checks
the complete observations made by the previous host. These include file reads,
positive and negative existence probes, directories, package resolution,
realpaths and environment queries. Every loaded source and declaration text is
also compared in full. The root, ordered input list, compiler options, working
directory, default library path and compiler function identities must match.
Changed input, inconsistent observations or an observation budget overflow
disables reuse. A fresh program then follows the existing compiler path.

This optimization retains inference only. Every regeneration still transports
the complete JavaScript sources through native CST serialization and reparsing,
serializes and reparses checked meta, emits TypeScript, and independently checks
the erased runtime AST. It also reads package metadata and assets afresh. An
eligible retained program's inputs are checked again before accepting outputs;
an uncacheable program follows the original fresh-program path. Generated files and
previous freshness verdicts are never reused as evidence.

The host observations are a boundary for the stock, synchronous generation
workflow. They do not provide an atomic filesystem snapshot, protection against
hostile compiler or filesystem callbacks, or type/ownership authority for a
different compiler. Runtime syntax comparison remains a separate check.

The dedicated receiving file exercises actual regeneration with changed external
declarations, a previously missing dependency, changed and added JavaScript, and
exact Unicode/CRLF asset bytes. These cases supplement the unchanged complete
native TypeScript receiving file and its original deadlines; passing the small
fixtures alone does not qualify that file or the complete JavaScript gate.
