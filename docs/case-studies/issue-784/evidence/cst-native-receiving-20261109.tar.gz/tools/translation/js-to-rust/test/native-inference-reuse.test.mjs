import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,symlinkSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname,resolve} from 'node:path';
import {regenerateNativeTypeScript,loadTypeScript} from '../native-typescript.mjs';

function fixture(){
 const root=mkdtempSync(join(tmpdir(),'router-native-inference-reuse-'));
 const write=(path,source)=>{mkdirSync(dirname(join(root,path)),{recursive:true});writeFileSync(join(root,path),source);};
 write('js/package.json',JSON.stringify({name:'native-inference-fixture',version:'1.0.0',type:'module',devDependencies:{typescript:'5.9.3'}}));
 write('js/catalog.json','[]\n');write('js/index.js','export * from "./src/core.js";\n');write('js/testing.js','export const enabled=true;\n');
 write('js/src/core.js','import {choose} from "fixture-dependency";export function read(){return choose();}\n');
 mkdirSync(join(root,'js/node_modules'),{recursive:true});
 for(const name of ['typescript','@types'])symlinkSync(resolve('js/node_modules',name),join(root,'js/node_modules',name),'dir');
 assert.equal(loadTypeScript(root).version,'5.9.3');
 const declaration=type=>{
  write('js/node_modules/fixture-dependency/package.json',JSON.stringify({name:'fixture-dependency',version:'1.0.0',type:'module',types:'index.d.ts'}));
  write('js/node_modules/fixture-dependency/index.d.ts',`export function choose(): ${type};\n`);
 };
 const generate=()=>regenerateNativeTypeScript(root);
 const meta=()=>JSON.parse(readFileSync(join(root,'tools/translation/js-to-rust/generated/native-typescript/src/core.js.meta.json'),'utf8'));
 return {root,write,declaration,generate,meta,remove:()=>rmSync(root,{recursive:true,force:true})};
}

test('regeneration observes changed external declarations with unchanged JavaScript',{timeout:60000},()=>{
 const f=fixture();try{
  f.declaration('string');f.generate();assert.equal(f.meta().annotations[0].returns.name,'string');
  assert.deepEqual(f.generate().changed,[]);
  f.declaration('number');assert.ok(f.generate().changed.length);assert.equal(f.meta().annotations[0].returns.name,'number');
 }finally{f.remove();}
});

test('previously missing package probes are rechecked before inference reuse',{timeout:60000},()=>{
 const f=fixture();try{
  f.generate();assert.equal(f.meta().annotations[0].returns,null);
  f.declaration('boolean');f.generate();assert.equal(f.meta().annotations[0].returns.name,'boolean');
 }finally{f.remove();}
});

test('source additions changes and exact asset bytes remain fresh on repeated regeneration',{timeout:60000},()=>{
 const f=fixture();try{
  f.declaration('string');f.generate();
  f.write('js/src/core.js','export function read(){return 7;}\n');
  f.write('js/src/added.js','export function added(){return false;}\n');
  f.write('js/catalog.json','{"complete":"Ω😀"}\r\n');f.generate();
  assert.equal(f.meta().annotations[0].returns.name,'number');
  assert.match(readFileSync(join(f.root,'ts/src/added.ts'),'utf8'),/added/u);
  assert.equal(readFileSync(join(f.root,'ts/catalog.json'),'utf8'),'{"complete":"Ω😀"}\r\n');
  assert.deepEqual(f.generate().changed,[]);
 }finally{f.remove();}
});
