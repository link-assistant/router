import {ownershipCompilerRuntimeLoad} from './vendor/module-syntax.mjs';
// Full JavaScript/TypeScript identity lowering through a structured syntax AST.
// Each meta node records SyntaxKind and children. Only lexical leaf tokens
// contain text; no source file or function body is an opaque source carrier.
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync, mkdirSync, writeFileSync, rmSync, symlinkSync, cpSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { inferenceProgram, createInferenceProgramReuse, returnHint, localHint, typeNode, dynamicIndex } from './native-inference.mjs';
import {createRulePipeline} from '../rule-pipeline.mjs';
import {prepareReverseConcreteSource} from './concrete-source.mjs';

const hash = (value) => createHash('sha256').update(value).digest('hex');
const walkFiles = (root, directory) => existsSync(join(root, directory)) ? readdirSync(join(root, directory), { withFileTypes: true }).flatMap((entry) => entry.isDirectory() ? walkFiles(root, `${directory}/${entry.name}`) : [`${directory}/${entry.name}`]).sort() : [];
export function loadTypeScript(sourceRoot) { return ownershipCompilerRuntimeLoad(sourceRoot); }

export function sourceModules(root) {
  return [...walkFiles(root, 'js/src'), ...walkFiles(root, 'js/portable'), 'js/index.js', 'js/testing.js'].filter((path) => /\.(?:mjs|js)$/u.test(path)).sort();
}

function serialize(ts, sourceFile, checker) {
  let count = 0;
  let functionIndex = 0;
  const annotations = [];
  const locals = [];
  const indices = [];
  const gaps=[];
  const occurrences=new Map();
  const globalGaps=new Set();
  const loopBindings=new Set();
  const reassignedBindings=new Set();
  if(checker) {
    const collect=node=>{
      if(ts.isForInStatement(node) && ts.isVariableDeclarationList(node.initializer))for(const declaration of node.initializer.declarations)if(ts.isIdentifier(declaration.name)){const symbol=checker.getSymbolAtLocation(declaration.name);if(symbol)loopBindings.add(symbol);}
      if(ts.isBinaryExpression(node) && ts.isAssignmentOperator(node.operatorToken.kind) && ts.isIdentifier(node.left)){const symbol=checker.getSymbolAtLocation(node.left);if(symbol)reassignedBindings.add(symbol);}
      ts.forEachChild(node,collect);
    };
    collect(sourceFile);
  }
  const encode = (node) => {
    if (ts.isJSDoc(node)) return null;
    const occurrence=occurrences.get(node.kind)??0;occurrences.set(node.kind,occurrence+1);
    if (ts.isFunctionLike(node) && node.parameters) {
      const params = node.parameters.map((parameter) => {
        const doc = ts.getJSDocType(parameter);
        if (doc && [ts.SyntaxKind.StringKeyword, ts.SyntaxKind.NumberKeyword, ts.SyntaxKind.BooleanKeyword].includes(doc.kind)) return ts.SyntaxKind[doc.kind].replace('Keyword', '').toLowerCase();
        // JS default expressions are not contracts: fallback='' can still be
        // called with null. Only explicit JSDoc primitive contracts narrow it.
        return 'any';
      });
      let thisContext = false;
      if (ts.isFunctionDeclaration(node) || ts.isFunctionExpression(node)) {
        const receiver = child => {
          if (child !== node && (ts.isFunctionLike(child) && !ts.isArrowFunction(child) || ts.isClassDeclaration(child) || ts.isClassExpression(child))) return;
          if (child.kind === ts.SyntaxKind.ThisKeyword) thisContext = true;
          ts.forEachChild(child, receiver);
        };
        receiver(node);
      }
      annotations.push({ function: functionIndex++, parameters: params, returns: returnHint(ts, checker, node), ...(thisContext ? { thisContext: true } : {}) });
    }
    if (ts.isVariableDeclaration(node)) locals.push(localHint(ts, checker, node));
    if (ts.isElementAccessExpression(node)) indices.push(dynamicIndex(ts, checker, node));
    const gap={};
    if(checker) {
      const propertyName=node.parent && (ts.isPropertyAccessExpression(node.parent)&&node.parent.name===node || ts.isPropertyAssignment(node.parent)&&node.parent.name===node || ts.isBindingElement(node.parent)&&node.parent.propertyName===node);
      if(ts.isIdentifier(node) && !propertyName && ts.isInExpressionContext(node) && !ts.isDeclarationName(node) && !checker.getSymbolAtLocation(node)) globalGaps.add(node.text);
      if(ts.isIdentifier(node) && !propertyName && !ts.isDeclarationName(node) && loopBindings.has(checker.getSymbolAtLocation(node)))gap.loopBinding=true;
      if(ts.isCallExpression(node) && !ts.isOptionalChain(node) && ![ts.SyntaxKind.ImportKeyword,ts.SyntaxKind.SuperKeyword].includes(node.expression.kind)) {
        const signature=checker.getResolvedSignature(node),parameters=signature?.getParameters()??[];
        const formal=signature?.declaration?.parameters;
        const rest=formal?formal.at(-1)?.dotDotDotToken:parameters.at(-1)?.declarations?.some(declaration=>declaration.dotDotDotToken);
        // The JS checker can infer extra parameters from callers. The emitted
        // declaration still has the original formal list, so compare that list.
        if(node.arguments.length>(formal?.length??parameters.length) && !rest || ts.isPropertyAccessExpression(node.expression) && node.expression.name.text==='bind') gap.call=true;
      }
      if(ts.isPropertyAccessExpression(node) && ts.isIdentifier(node.expression)) {
        const symbol=checker.getSymbolAtLocation(node.expression);
        if(symbol?.declarations?.some(declaration=>declaration.getSourceFile().isDeclarationFile))gap.globalProperty=true;
      }
      if(ts.isPropertyAccessExpression(node) && ts.isIdentifier(node.expression) && reassignedBindings.has(checker.getSymbolAtLocation(node.expression)) && checker.getTypeAtLocation(node.expression).flags&ts.TypeFlags.Any)gap.globalProperty=true;
      if(ts.isBinaryExpression(node)) {
        if(ts.isAssignmentOperator(node.operatorToken.kind) && ts.isIdentifier(node.left))gap.assignment=true;
        if(node.operatorToken.kind===ts.SyntaxKind.PlusToken && [node.left,node.right].some(value=>checker.getTypeAtLocation(value).flags & ts.TypeFlags.BooleanLike))gap.coercion=true;
        if([node.left,node.right].some(value=>ts.isStringLiteralLike(value)&&value.text==='unknown') && [node.left,node.right].some(ts.isTypeOfExpression))gap.coercion=true;
      }
    }
    if(Object.keys(gap).length)gaps.push({kind:node.kind,occurrence,...gap});
    count++;
    const children = node.getChildren(sourceFile).map(encode).filter(Boolean);
    if (children.length) return [node.kind, children];
    const start = node.getStart(sourceFile);
    const text = sourceFile.text.slice(start, node.end);
    if (!text || node.kind === ts.SyntaxKind.EndOfFileToken) return [node.kind, []];
    // Preserve line terminators because JavaScript automatic semicolon
    // insertion and postfix operators observe them; horizontal trivia is free.
    const leading = sourceFile.text.slice(node.pos, start);
    return [node.kind, text, /[\r\n]/u.test(leading) ? 1 : 0];
  };
  const tree=encode(sourceFile);
  return { tree, annotations, locals, indices, gaps, globalGaps:[...globalGaps].sort(), nodes: count };
}

export function parseNativeJavaScript(ts, path, source, { file: inferredFile, checker } = {}) {
  source=prepareReverseConcreteSource(source).source;
  const file = inferredFile ?? ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (file.text !== source) throw new Error(`inference source snapshot differs for ${path}`);
  if (file.parseDiagnostics.length) throw new Error(`invalid authoritative JavaScript syntax in ${path}`);
  return { schema: 'native-js-syntax-ast-v1', compiler: ts.version, path, sourceSha256: hash(source), ...serialize(ts, file, checker) };
}

// Runtime structural fingerprint, independent of the source token AST emitter.
// Precedence is already in the parsed child tree. Parentheses around optional
// chains are retained where a continuation/call/new observes the boundary.
export function runtimeAST(ts, source, { rewriteImports = false } = {}) {
  const file = ts.createSourceFile('runtime.mjs', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (file.parseDiagnostics.length) throw new Error('invalid runtime syntax for identity check');
  const normalize = (node) => {
    if (ts.isParenthesizedExpression(node)) {
      let parent = node.parent;
      while (ts.isParenthesizedExpression(parent)) parent = parent.parent;
      const boundary = ts.isOptionalChain(node.expression) && (ts.isPropertyAccessExpression(parent) || ts.isElementAccessExpression(parent) || ts.isCallExpression(parent) || ts.isNewExpression(parent) || ts.isTaggedTemplateExpression(parent));
      return boundary ? ['optional-chain-boundary', normalize(node.expression)] : normalize(node.expression);
    }
    const children = [];
    ts.forEachChild(node, (child) => { if (!ts.isJSDoc(child)) children.push(normalize(child)); });
    const optional = Boolean(node.flags & ts.NodeFlags.OptionalChain);
    if (children.length) return [node.kind, optional, children];
    if (typeof node.text === 'string') {
      const module = node.parent && (ts.isImportDeclaration(node.parent) || ts.isExportDeclaration(node.parent) || ts.isCallExpression(node.parent) && node.parent.expression.kind === ts.SyntaxKind.ImportKeyword);
      const text = rewriteImports && module && node.text.startsWith('.') ? node.text.replace(/\.mjs$/u, '.js') : node.text;
      return [node.kind, text, node.rawText ?? null];
    }
    return [node.kind];
  };
  return normalize(file);
}

export function reconstructSyntax(meta) {
  const parts = [];
  const visit = (node) => {
    if (!Array.isArray(node) || !Number.isInteger(node[0])) throw new Error('malformed syntax AST node');
    if (Array.isArray(node[1])) for (const child of node[1]) visit(child);
    else {
      if (typeof node[1] !== 'string' || ![0, 1].includes(node[2])) throw new Error('malformed syntax AST token');
      parts.push(`${node[2] ? '\n' : ' '}${node[1]}`);
    }
  };
  visit(meta.tree);
  return parts.join('');
}

export function emitNativeTypeScript(ts, meta) {
  const syntax = reconstructSyntax(meta);
  const file = ts.createSourceFile(meta.path, syntax, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (file.parseDiagnostics.length) throw new Error(`reconstructed ${meta.path} has invalid syntax`);
  const f = ts.factory;
  const any = () => f.createKeywordTypeNode(ts.SyntaxKind.AnyKeyword);
  const primitive = (value) => f.createKeywordTypeNode(({ number: ts.SyntaxKind.NumberKeyword, string: ts.SyntaxKind.StringKeyword, boolean: ts.SyntaxKind.BooleanKeyword })[value] ?? ts.SyntaxKind.AnyKeyword);
  let functionIndex = 0;
  let localIndex = 0;
  let indexIndex = 0;
  let inferredReturns = 0;
  let inferredLocals = 0;
  let explicitAny = 0;
  const occurrences=new Map();
  const plans=new Map((meta.gaps??[]).map(gap=>[`${gap.kind}:${gap.occurrence}`,gap]));
  const namespaces = new Set(file.statements.filter(ts.isImportDeclaration).map((statement) => statement.importClause?.namedBindings).filter((binding) => binding && ts.isNamespaceImport(binding)).map((binding) => binding.name.text));
  const transform = (context) => {
    const visit = (node) => {
      const occurrence=occurrences.get(node.kind)??0;occurrences.set(node.kind,occurrence+1);
      const gap=plans.get(`${node.kind}:${occurrence}`)??{};
      const functionLike = ts.isFunctionLike(node) && node.parameters;
      const hint = functionLike ? meta.annotations[functionIndex++] ?? {} : {};
      const hints = hint.parameters ?? [];
      const local = ts.isVariableDeclaration(node) ? meta.locals?.[localIndex++] : null;
      const keyDynamic = ts.isElementAccessExpression(node) ? meta.indices?.[indexIndex++] : false;
      let updated = ts.visitEachChild(node, visit, context);
      // A var introduced in for-in is function-scoped in JavaScript and can
      // subsequently hold any value, including undefined before the loop.
      // The non-null marker only suppresses TS's definite-assignment premise;
      // the outer explicit any records that no value domain is proved here.
      if(gap.loopBinding && ts.isIdentifier(updated))updated=f.createParenthesizedExpression(f.createAsExpression(f.createNonNullExpression(updated),any()));
      if (functionLike) {
        updated.parameters = f.createNodeArray(updated.parameters.map((parameter, index) => {
          const type = parameter.dotDotDotToken ? f.createArrayTypeNode(any()) : primitive(hints[index]);
          if (!hints[index] || hints[index] === 'any') explicitAny++;
          const laterRequired = updated.parameters.slice(index + 1).some((later, laterIndex) => !later.initializer && !later.dotDotDotToken && (!ts.isIdentifier(later.name) || hints[index + laterIndex + 1] !== 'any'));
          const optional = !laterRequired && hints[index] === 'any' && !parameter.initializer && !parameter.dotDotDotToken && ts.isIdentifier(parameter.name) && !ts.isSetAccessorDeclaration(node) && !ts.isConstructorDeclaration(node);
          return f.updateParameterDeclaration(parameter, parameter.modifiers, parameter.dotDotDotToken, parameter.name, optional ? f.createToken(ts.SyntaxKind.QuestionToken) : parameter.questionToken, type, parameter.initializer);
        }));
        if (hint.thisContext && (ts.isFunctionDeclaration(updated) || ts.isFunctionExpression(updated))) {
          explicitAny++;
          updated.parameters = f.createNodeArray([f.createParameterDeclaration(undefined, undefined, 'this', undefined, any(), undefined), ...updated.parameters]);
        }
        if (!ts.isConstructorDeclaration(updated) && !ts.isSetAccessorDeclaration(updated)) {
          if (hint.returns) { inferredReturns++; updated.type = typeNode(ts, hint.returns); }
          else {
            explicitAny++;
            updated.type = updated.asteriskToken
            ? f.createTypeReferenceNode(updated.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? 'AsyncGenerator' : 'Generator', [any(), any(), any()])
            : updated.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ? f.createTypeReferenceNode('Promise', [any()]) : any();
          }
        }
      }
      if (ts.isVariableDeclaration(updated)) {
        const loop = ts.isVariableDeclarationList(node.parent) && (ts.isForOfStatement(node.parent.parent) || ts.isForInStatement(node.parent.parent));
        if (!loop) {
          if (local) inferredLocals++; else explicitAny++;
          updated = f.updateVariableDeclaration(updated, updated.name, updated.exclamationToken, local ? typeNode(ts, local) : any(), updated.initializer);
        }
      }
      if (ts.isForOfStatement(updated)) updated = f.updateForOfStatement(updated, updated.awaitModifier, updated.initializer, f.createAsExpression(updated.expression, any()), updated.statement);
      if (ts.isCatchClause(updated) && updated.variableDeclaration) updated = f.updateCatchClause(updated, f.updateVariableDeclaration(updated.variableDeclaration, updated.variableDeclaration.name, undefined, any(), undefined), updated.block);
      if (ts.isNewExpression(updated)) updated = f.updateNewExpression(updated, f.createParenthesizedExpression(f.createAsExpression(updated.expression, any())), undefined, updated.arguments);
      // Grouping the receiver of an optional-chain continuation would stop
      // short circuiting: (x?.headers)[key] differs from x?.headers[key].
      if (keyDynamic) updated = ts.isElementAccessChain(updated)
        ? f.updateElementAccessChain(updated, updated.expression, updated.questionDotToken, f.createAsExpression(updated.argumentExpression, any()))
        : f.updateElementAccessExpression(updated, updated.expression, f.createAsExpression(updated.argumentExpression, any()));
      if (ts.isElementAccessExpression(updated) && !ts.isElementAccessChain(updated)) updated = f.updateElementAccessExpression(updated, f.createParenthesizedExpression(f.createAsExpression(updated.expression, any())), updated.argumentExpression);
      if (ts.isPropertyAccessExpression(updated) && ts.isIdentifier(updated.expression) && namespaces.has(updated.expression.text)) updated = f.updatePropertyAccessExpression(updated, f.createParenthesizedExpression(f.createAsExpression(updated.expression, any())), updated.name);
      if (ts.isCallExpression(updated) && updated.expression.kind === ts.SyntaxKind.ImportKeyword && ts.isStringLiteral(updated.arguments[0]) && updated.arguments[0].text.startsWith('.')) updated = f.updateCallExpression(updated, updated.expression, updated.typeArguments, [f.createStringLiteral(updated.arguments[0].text.replace(/\.mjs$/u, '.js')), ...updated.arguments.slice(1)]);
      if(gap.call && ts.isCallExpression(updated)) {
        const callable=expression=>ts.isParenthesizedExpression(expression)?f.updateParenthesizedExpression(expression,callable(expression.expression))
          : ts.isBinaryExpression(expression)&&expression.operatorToken.kind===ts.SyntaxKind.CommaToken?f.updateBinaryExpression(expression,f.createParenthesizedExpression(f.createAsExpression(expression.left,any())),expression.operatorToken,callable(expression.right))
            : f.createParenthesizedExpression(f.createAsExpression(expression,any()));
        updated=f.updateCallExpression(updated,callable(updated.expression),updated.typeArguments,updated.arguments);
      }
      if(gap.globalProperty && ts.isPropertyAccessExpression(updated))updated=ts.isPropertyAccessChain(updated)
        ? f.updatePropertyAccessChain(updated,f.createParenthesizedExpression(f.createAsExpression(updated.expression,any())),updated.questionDotToken,updated.name)
        : f.updatePropertyAccessExpression(updated,f.createParenthesizedExpression(f.createAsExpression(updated.expression,any())),updated.name);
      if(ts.isBinaryExpression(updated)) {
        if(gap.assignment)updated=f.updateBinaryExpression(updated,f.createParenthesizedExpression(f.createAsExpression(updated.left,any())),updated.operatorToken,updated.right);
        if(gap.coercion)updated=f.updateBinaryExpression(updated,f.createParenthesizedExpression(f.createAsExpression(updated.left,any())),updated.operatorToken,f.createParenthesizedExpression(f.createAsExpression(updated.right,any())));
      }
      if (ts.isCallExpression(updated) && ts.isPropertyAccessExpression(updated.expression) && updated.expression.expression.kind === ts.SyntaxKind.Identifier && updated.expression.expression.text === 'JSON' && updated.expression.name.text === 'parse') updated = f.updateCallExpression(updated, updated.expression, updated.typeArguments, updated.arguments.map((argument) => f.createAsExpression(argument, any())));
      if ((ts.isImportDeclaration(updated) || ts.isExportDeclaration(updated)) && updated.moduleSpecifier && ts.isStringLiteral(updated.moduleSpecifier) && updated.moduleSpecifier.text.startsWith('.')) {
        updated.moduleSpecifier = f.createStringLiteral(updated.moduleSpecifier.text.replace(/\.mjs$/u, '.js'));
      }
      if ((ts.isClassDeclaration(updated) || ts.isClassExpression(updated))) {
        const members = new Set(updated.members.map((member) => member.name?.getText(file)));
        const fields = new Set();
        const collect = (child) => {
          if (child !== node && (ts.isClassDeclaration(child) || ts.isClassExpression(child))) return;
          if (ts.isPropertyAccessExpression(child) && child.expression.kind === ts.SyntaxKind.ThisKeyword && !members.has(child.name.text)) fields.add(child.name.text);
          ts.forEachChild(child, collect);
        };
        collect(node);
        const declarations = [...fields].sort().map((name) => f.createPropertyDeclaration([f.createModifier(ts.SyntaxKind.DeclareKeyword)], name, undefined, any(), undefined));
        explicitAny += declarations.length;
        updated.members = f.createNodeArray([...declarations, ...updated.members]);
      }
      return updated;
    };
    return (root) => {
      const transformed=ts.visitNode(root,visit);
      const declarations=(meta.globalGaps??[]).map(name=>f.createVariableStatement([f.createModifier(ts.SyntaxKind.DeclareKeyword)],f.createVariableDeclarationList([f.createVariableDeclaration(name,undefined,any())],ts.NodeFlags.Const)));
      return f.updateSourceFile(transformed,[...declarations,...transformed.statements]);
    };
  };
  let result;
  const pipeline=createRulePipeline([
    {phase:'language',rules:[{id:'native-typescript:checked-syntax',apply:input=>{result=ts.transform(input,[transform]);return result;}}]},
    {phase:'repository',rules:[
      {id:'native-typescript:print',apply:input=>ts.createPrinter({ newLine: ts.NewLineKind.LineFeed, removeComments: true }).printFile(input.transformed[0])},
      {id:'native-typescript:output-census',apply:text=>{
        const typed = ts.createSourceFile(meta.path.replace(/\.m?js$/u, '.ts'), text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
        explicitAny = 0;
        const countAny = (node) => { if (node.kind === ts.SyntaxKind.AnyKeyword) explicitAny++; ts.forEachChild(node, countAny); };
        countAny(typed);
        return { text, explicitAny, inferredReturns, inferredLocals };
      }},
    ]},
  ]);
  try {
    return pipeline.run(file).value;
  } finally { if(result)result.dispose(); }
}

// Fixed build-only sibling. The public serializer/parser above deliberately
// retain custom-ts/checker traversal observations. This stock-compiler route
// folds lexical-this classification into its existing semantic collect pass;
// getChildren token encoding, inference and every source/hash check stay fresh.
function serializeBuild(ts, sourceFile, checker) {
  if (!checker) return serialize(ts, sourceFile, checker);
  let count = 0;
  let functionIndex = 0;
  const annotations = [];
  const locals = [];
  const indices = [];
  const gaps=[];
  const occurrences=new Map();
  const globalGaps=new Set();
  const loopBindings=new Set();
  const reassignedBindings=new Set();
  const lexicalThis=new WeakSet();
  if(checker) {
    const collect=(node,target=null)=>{
      if(ts.isFunctionDeclaration(node)||ts.isFunctionExpression(node))target=node;
      else if(target!==null&&(ts.isFunctionLike(node)&&!ts.isArrowFunction(node)||ts.isClassDeclaration(node)||ts.isClassExpression(node)))target=null;
      if(target!==null&&node.kind===ts.SyntaxKind.ThisKeyword)lexicalThis.add(target);
      if(ts.isForInStatement(node) && ts.isVariableDeclarationList(node.initializer))for(const declaration of node.initializer.declarations)if(ts.isIdentifier(declaration.name)){const symbol=checker.getSymbolAtLocation(declaration.name);if(symbol)loopBindings.add(symbol);}
      if(ts.isBinaryExpression(node) && ts.isAssignmentOperator(node.operatorToken.kind) && ts.isIdentifier(node.left)){const symbol=checker.getSymbolAtLocation(node.left);if(symbol)reassignedBindings.add(symbol);}
      ts.forEachChild(node,child=>collect(child,target));
    };
    collect(sourceFile);
  }
  const encode = (node) => {
    if (ts.isJSDoc(node)) return null;
    const occurrence=occurrences.get(node.kind)??0;occurrences.set(node.kind,occurrence+1);
    if (ts.isFunctionLike(node) && node.parameters) {
      const params = node.parameters.map((parameter) => {
        const doc = ts.getJSDocType(parameter);
        if (doc && [ts.SyntaxKind.StringKeyword, ts.SyntaxKind.NumberKeyword, ts.SyntaxKind.BooleanKeyword].includes(doc.kind)) return ts.SyntaxKind[doc.kind].replace('Keyword', '').toLowerCase();
        // JS default expressions are not contracts: fallback='' can still be
        // called with null. Only explicit JSDoc primitive contracts narrow it.
        return 'any';
      });
      const thisContext=(ts.isFunctionDeclaration(node)||ts.isFunctionExpression(node))&&lexicalThis.has(node);
      annotations.push({ function: functionIndex++, parameters: params, returns: returnHint(ts, checker, node), ...(thisContext ? { thisContext: true } : {}) });
    }
    if (ts.isVariableDeclaration(node)) locals.push(localHint(ts, checker, node));
    if (ts.isElementAccessExpression(node)) indices.push(dynamicIndex(ts, checker, node));
    const gap={};
    if(checker) {
      const propertyName=node.parent && (ts.isPropertyAccessExpression(node.parent)&&node.parent.name===node || ts.isPropertyAssignment(node.parent)&&node.parent.name===node || ts.isBindingElement(node.parent)&&node.parent.propertyName===node);
      if(ts.isIdentifier(node) && !propertyName && ts.isInExpressionContext(node) && !ts.isDeclarationName(node) && !checker.getSymbolAtLocation(node)) globalGaps.add(node.text);
      if(ts.isIdentifier(node) && !propertyName && !ts.isDeclarationName(node) && loopBindings.has(checker.getSymbolAtLocation(node)))gap.loopBinding=true;
      if(ts.isCallExpression(node) && !ts.isOptionalChain(node) && ![ts.SyntaxKind.ImportKeyword,ts.SyntaxKind.SuperKeyword].includes(node.expression.kind)) {
        const signature=checker.getResolvedSignature(node),parameters=signature?.getParameters()??[];
        const formal=signature?.declaration?.parameters;
        const rest=formal?formal.at(-1)?.dotDotDotToken:parameters.at(-1)?.declarations?.some(declaration=>declaration.dotDotDotToken);
        // The JS checker can infer extra parameters from callers. The emitted
        // declaration still has the original formal list, so compare that list.
        if(node.arguments.length>(formal?.length??parameters.length) && !rest || ts.isPropertyAccessExpression(node.expression) && node.expression.name.text==='bind') gap.call=true;
      }
      if(ts.isPropertyAccessExpression(node) && ts.isIdentifier(node.expression)) {
        const symbol=checker.getSymbolAtLocation(node.expression);
        if(symbol?.declarations?.some(declaration=>declaration.getSourceFile().isDeclarationFile))gap.globalProperty=true;
      }
      if(ts.isPropertyAccessExpression(node) && ts.isIdentifier(node.expression) && reassignedBindings.has(checker.getSymbolAtLocation(node.expression)) && checker.getTypeAtLocation(node.expression).flags&ts.TypeFlags.Any)gap.globalProperty=true;
      if(ts.isBinaryExpression(node)) {
        if(ts.isAssignmentOperator(node.operatorToken.kind) && ts.isIdentifier(node.left))gap.assignment=true;
        if(node.operatorToken.kind===ts.SyntaxKind.PlusToken && [node.left,node.right].some(value=>checker.getTypeAtLocation(value).flags & ts.TypeFlags.BooleanLike))gap.coercion=true;
        if([node.left,node.right].some(value=>ts.isStringLiteralLike(value)&&value.text==='unknown') && [node.left,node.right].some(ts.isTypeOfExpression))gap.coercion=true;
      }
    }
    if(Object.keys(gap).length)gaps.push({kind:node.kind,occurrence,...gap});
    count++;
    const children = node.getChildren(sourceFile).map(encode).filter(Boolean);
    if (children.length) return [node.kind, children];
    const start = node.getStart(sourceFile);
    const text = sourceFile.text.slice(start, node.end);
    if (!text || node.kind === ts.SyntaxKind.EndOfFileToken) return [node.kind, []];
    // Preserve line terminators because JavaScript automatic semicolon
    // insertion and postfix operators observe them; horizontal trivia is free.
    const leading = sourceFile.text.slice(node.pos, start);
    return [node.kind, text, /[\r\n]/u.test(leading) ? 1 : 0];
  };
  const tree=encode(sourceFile);
  return { tree, annotations, locals, indices, gaps, globalGaps:[...globalGaps].sort(), nodes: count };
}

function parseBuildNativeJavaScript(ts, path, source, { file: inferredFile, checker } = {}) {
  source=prepareReverseConcreteSource(source).source;
  const file = inferredFile ?? ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (file.text !== source) throw new Error(`inference source snapshot differs for ${path}`);
  if (file.parseDiagnostics.length) throw new Error(`invalid authoritative JavaScript syntax in ${path}`);
  return { schema: 'native-js-syntax-ast-v1', compiler: ts.version, path, sourceSha256: hash(source), ...serializeBuild(ts, file, checker) };
}

export function buildNativeTypeScript(sourceRoot) {
  const ts = loadTypeScript(sourceRoot);
  const paths = sourceModules(sourceRoot);
  if (!paths.some((path) => path.startsWith('js/src/'))) throw new Error('native JavaScript source modules are missing');
  const artifacts = new Map();
  const rows = [];
  const inference = inferenceProgram(ts, sourceRoot, paths);
  for (const path of paths) {
    const source = readFileSync(join(sourceRoot, path), 'utf8');
    const meta = parseBuildNativeJavaScript(ts, path, source, { file: inference.program.getSourceFile(join(sourceRoot, path)), checker: inference.checker });
    const metaText = `${JSON.stringify(meta)}\n`;
    const reparsed = JSON.parse(metaText);
    const output = emitNativeTypeScript(ts, reparsed);
    const target = path.replace('js/', 'ts/').replace(/\.(?:mjs|js)$/u, '.ts');
    const metaPath = `tools/translation/js-to-rust/generated/native-typescript/${path.slice('js/'.length)}.meta.json`;
    const targetText = `// GENERATED JavaScript -> structured syntax AST -> TypeScript draft.\n// Meta sha256=${hash(metaText)}; dynamic any annotations are explicit draft gaps.\n${output.text}`;
    const erased = ts.transpileModule(output.text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, verbatimModuleSyntax: true, useDefineForClassFields: false }, fileName: target }).outputText;
    const sourceRuntime = JSON.stringify(runtimeAST(ts, source, { rewriteImports: true }));
    let targetRuntime;
    try {targetRuntime=JSON.stringify(runtimeAST(ts,erased));}
    catch(cause){throw new Error(`Invalid erased TypeScript runtime for ${path}`,{cause});}
    if (sourceRuntime !== targetRuntime) throw new Error(`runtime AST identity differs for ${path}`);
    artifacts.set(metaPath, metaText);
    artifacts.set(target, targetText);
    rows.push({ source: path, sourceSha256: hash(source), meta: metaPath, target, nodes: meta.nodes, explicitAny: output.explicitAny, inferredReturns: output.inferredReturns, inferredLocals: output.inferredLocals, metaSha256: hash(metaText), targetSha256: hash(targetText), runtimeASTSha256: hash(sourceRuntime), runtimeASTIdentity: 'verified after type erasure and relative module-extension normalization' });
  }
  // Package resolution and public declarations influence inference even when
  // every JavaScript source hash is unchanged. Record the complete public
  // declaration context so isolated source snapshots can reproduce it.
  const loadedDeclarations = new Set(inference.program.getSourceFiles().filter(file => file.isDeclarationFile).map(file => resolve(file.fileName)));
  const inferenceInputs = ['js/package.json', ...readdirSync(join(sourceRoot, 'js')).filter(name => name.endsWith('.d.ts')).sort().map(name => `js/${name}`)].map(path => ({ path, sha256: hash(readFileSync(join(sourceRoot, path))), role: path.endsWith('.d.ts') ? 'public-declaration' : 'package-resolution', resolvedByCompiler: path.endsWith('.d.ts') ? loadedDeclarations.has(resolve(sourceRoot, path)) : true }));
  const sourcePackage = JSON.parse(readFileSync(join(sourceRoot, 'js/package.json'), 'utf8'));
  artifacts.set('ts/package.json', `${JSON.stringify({ name: '@link-assistant/router-typescript-draft', version: sourcePackage.version, private: true, type: 'module', engines: sourcePackage.engines, exports: { '.': './dist/index.js', './native': './dist/src/index.js', './testing': './dist/testing.js' }, scripts: { build: 'node ../scripts/check-native-typescript.mjs --out-dir ts/dist' }, dependencies: sourcePackage.dependencies, devDependencies: sourcePackage.devDependencies }, null, 2)}\n`);
  artifacts.set('ts/tsconfig.native.json', `${JSON.stringify({ compilerOptions: { strict: true, target: 'ES2022', module: 'NodeNext', moduleResolution: 'NodeNext', skipLibCheck: true, useDefineForClassFields: false, verbatimModuleSyntax: true, outDir: 'dist', rootDir: '.', declaration: true }, include: ['index.ts', 'testing.ts', 'src/**/*.ts', 'portable/**/*.ts'] }, null, 2)}\n`);
  artifacts.set('ts/.gitignore', 'node_modules\n/dist/\n');
  // Public embedded assets have byte-level HTTP contracts. Keep their exact
  // payload alongside the independently checked TypeScript syntax targets.
  for (const path of ['js/catalog.json', ...walkFiles(sourceRoot, 'js/schemas'), ...walkFiles(sourceRoot, 'js/src/assets/admin')]) artifacts.set(path.replace('js/', 'ts/'), readFileSync(join(sourceRoot, path)));
  artifacts.set('tools/translation/js-to-rust/generated/native-typescript/manifest.json', `${JSON.stringify({ schema: 'native-js-syntax-ast-v1', compiler: ts.version, target: 'complete-native-package-typescript-draft', lowering: 'identity runtime semantics; syntax-token AST serialization and explicit draft dynamic type annotations', fullNativeRustTranslation: false, inferenceInputs, modules: rows, assets: ['catalog.json', 'schemas', 'src/assets/admin'], outputs: [...artifacts].map(([path, value]) => ({ path, bytes: Buffer.byteLength(value), sha256: hash(value) })) }, null, 2)}\n`);
  return artifacts;
}

export function regenerateNativeTypeScript(outputRoot, { sourceRoot = outputRoot, check = false } = {}) {
  const artifacts = buildNativeTypeScriptForRegeneration(sourceRoot);
  const changed = [];
  const managed = [
    ...(existsSync(join(outputRoot, 'ts')) ? readdirSync(join(outputRoot, 'ts'), { withFileTypes: true }).filter((entry) => entry.isFile() && /\.(?:ts|json)$/u.test(entry.name) && entry.name !== 'package-lock.json').map((entry) => `ts/${entry.name}`) : []),
    ...walkFiles(outputRoot, 'tools/translation/js-to-rust/generated/native-typescript'),
    ...walkFiles(outputRoot, 'ts/schemas'),
    ...walkFiles(outputRoot, 'ts/src').filter((path) => !path.endsWith('/js-first-policy.ts')
      && !path.startsWith('ts/src/portable-draft/')),
    ...walkFiles(outputRoot, 'ts/portable'),
  ];
  const unexpected = managed.filter((path) => !artifacts.has(path));
  for (const path of unexpected) if (!check) rmSync(join(outputRoot, path));
  for (const [path, value] of artifacts) {
    const file = join(outputRoot, path);
    if (existsSync(file) && Buffer.from(readFileSync(file)).equals(Buffer.from(value))) continue;
    changed.push(path);
    if (!check) { mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, value); }
  }
  return { changed, unexpected, bytes: [...artifacts.values()].reduce((sum, value) => sum + Buffer.byteLength(value), 0) };
}

export function compileNativeTypeScript(outputRoot, { sourceRoot = outputRoot, outDir, emit = false } = {}) {
  const ts = loadTypeScript(sourceRoot);
  const dependencyRoot = join(sourceRoot, 'js/node_modules');
  const packageRoot = join(outputRoot, 'ts');
  const nodeModules = join(packageRoot, 'node_modules');
  if (!existsSync(nodeModules)) symlinkSync(dependencyRoot, nodeModules, 'dir');
  const files = ['index.ts', 'testing.ts', ...walkFiles(outputRoot, 'ts/src').map((path) => path.slice('ts/'.length)), ...walkFiles(outputRoot, 'ts/portable').map((path) => path.slice('ts/'.length))].filter((path) => path.endsWith('.ts')).map((path) => join(packageRoot, path));
  const options = { strict: true, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.NodeNext, moduleResolution: ts.ModuleResolutionKind.NodeNext, skipLibCheck: true, useDefineForClassFields: false, verbatimModuleSyntax: true, declaration: true, rootDir: packageRoot, outDir, noEmit: !emit, typeRoots: [join(dependencyRoot, '@types')] };
  const program = ts.createProgram(files, options);
  const diagnostics = ts.getPreEmitDiagnostics(program);
  if (diagnostics.length) throw new Error(ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCurrentDirectory: () => outputRoot, getCanonicalFileName: (name) => name, getNewLine: () => '\n' }));
  if (emit) {
    program.emit();
    writeFileSync(join(outDir, 'package.json'), '{"type":"module"}\n');
    cpSync(join(packageRoot, 'catalog.json'), join(outDir, 'catalog.json'));
    cpSync(join(packageRoot, 'schemas'), join(outDir, 'schemas'), { recursive: true });
    for(const path of walkFiles(outputRoot,'ts/src/assets/admin').filter(path=>!path.endsWith('.ts'))) {
      const target=join(outDir,path.slice('ts/'.length));mkdirSync(dirname(target),{recursive:true});cpSync(join(outputRoot,path),target);
    }
    if (!existsSync(join(outDir, 'node_modules'))) symlinkSync(dependencyRoot, join(outDir, 'node_modules'), 'dir');
  }
  return { files: files.length, compiler: ts.version };
}

// Separate regeneration-only source-origin contract. Public build/parser APIs
// retain their original standalone observer schedule. No verdict survives a call.
import {prepareReverseConcreteParsedSourceChunks,assertReverseConcreteSourceHost} from './concrete-source.mjs';
function* nativeRegenerationParsedConcreteSources(sourceRoot, paths) {
  const originals=[];
  let cursor=0;
  while(cursor<paths.length) {
    const rows=[];let units=0;
    while(cursor<paths.length && rows.length<16) {
      const path=paths[cursor],source=readFileSync(join(sourceRoot,path),'utf8');
      if(rows.length && units+source.length>65536)break;
      rows.push({path,source});units+=source.length;cursor++;
      if(units>=65536)break;
    }
    const result=prepareReverseConcreteParsedSourceChunks([rows.map(row=>({source:row.source,language:'JavaScript'}))]);
    if(result.chunks.length!==1)throw new Error('native concrete source-origin chunk count differs');
    const batch=result.chunks[0];
    if(batch.stages.length!==rows.length)throw new Error('native concrete batch row count differs');
    for(let at=0;at<rows.length;at++) {
      const row=rows[at],source=batch.stages[at].source;
      assertReverseConcreteSourceHost();
      if(source!==row.source || readFileSync(join(sourceRoot,row.path),'utf8')!==source)throw new Error('native concrete source snapshot differs for '+row.path);
      originals.push(row);yield {path:row.path,source};
      assertReverseConcreteSourceHost();
    }
  }
  // Rejoin every complete physical input after all semantic consumers return.
  for(const row of originals)if(readFileSync(join(sourceRoot,row.path),'utf8')!==row.source)throw new Error('native concrete source changed during regeneration: '+row.path);
  assertReverseConcreteSourceHost();
}

function parseBuildReconstructedNativeJavaScript(ts, path, source, { file: inferredFile, checker } = {}) {
  assertReverseConcreteSourceHost();
  const file = inferredFile ?? ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  if (file.text !== source) throw new Error(`inference source snapshot differs for ${path}`);
  if (file.parseDiagnostics.length) throw new Error(`invalid authoritative JavaScript syntax in ${path}`);
  return { schema: 'native-js-syntax-ast-v1', compiler: ts.version, path, sourceSha256: hash(source), ...serializeBuild(ts, file, checker) };
}

const regenerationInference=createInferenceProgramReuse();
function buildNativeTypeScriptForRegeneration(sourceRoot) {
  const ts = loadTypeScript(sourceRoot);
  const paths = sourceModules(sourceRoot);
  if (!paths.some((path) => path.startsWith('js/src/'))) throw new Error('native JavaScript source modules are missing');
  const artifacts = new Map();
  const rows = [];
  const inference = regenerationInference(ts, sourceRoot, paths);
  for (const {path,source} of nativeRegenerationParsedConcreteSources(sourceRoot, paths)) {
    const meta = parseBuildReconstructedNativeJavaScript(ts, path, source, { file: inference.program.getSourceFile(join(sourceRoot, path)), checker: inference.checker });
    const metaText = `${JSON.stringify(meta)}\n`;
    const reparsed = JSON.parse(metaText);
    const output = emitNativeTypeScript(ts, reparsed);
    const target = path.replace('js/', 'ts/').replace(/\.(?:mjs|js)$/u, '.ts');
    const metaPath = `tools/translation/js-to-rust/generated/native-typescript/${path.slice('js/'.length)}.meta.json`;
    const targetText = `// GENERATED JavaScript -> structured syntax AST -> TypeScript draft.\n// Meta sha256=${hash(metaText)}; dynamic any annotations are explicit draft gaps.\n${output.text}`;
    const erased = ts.transpileModule(output.text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, verbatimModuleSyntax: true, useDefineForClassFields: false }, fileName: target }).outputText;
    const sourceRuntime = JSON.stringify(runtimeAST(ts, source, { rewriteImports: true }));
    let targetRuntime;
    try {targetRuntime=JSON.stringify(runtimeAST(ts,erased));}
    catch(cause){throw new Error(`Invalid erased TypeScript runtime for ${path}`,{cause});}
    if (sourceRuntime !== targetRuntime) throw new Error(`runtime AST identity differs for ${path}`);
    artifacts.set(metaPath, metaText);
    artifacts.set(target, targetText);
    rows.push({ source: path, sourceSha256: hash(source), meta: metaPath, target, nodes: meta.nodes, explicitAny: output.explicitAny, inferredReturns: output.inferredReturns, inferredLocals: output.inferredLocals, metaSha256: hash(metaText), targetSha256: hash(targetText), runtimeASTSha256: hash(sourceRuntime), runtimeASTIdentity: 'verified after type erasure and relative module-extension normalization' });
  }
  // Package resolution and public declarations influence inference even when
  // every JavaScript source hash is unchanged. Record the complete public
  // declaration context so isolated source snapshots can reproduce it.
  const loadedDeclarations = new Set(inference.program.getSourceFiles().filter(file => file.isDeclarationFile).map(file => resolve(file.fileName)));
  const inferenceInputs = ['js/package.json', ...readdirSync(join(sourceRoot, 'js')).filter(name => name.endsWith('.d.ts')).sort().map(name => `js/${name}`)].map(path => ({ path, sha256: hash(readFileSync(join(sourceRoot, path))), role: path.endsWith('.d.ts') ? 'public-declaration' : 'package-resolution', resolvedByCompiler: path.endsWith('.d.ts') ? loadedDeclarations.has(resolve(sourceRoot, path)) : true }));
  inference.assertInputsCurrent();
  const sourcePackage = JSON.parse(readFileSync(join(sourceRoot, 'js/package.json'), 'utf8'));
  artifacts.set('ts/package.json', `${JSON.stringify({ name: '@link-assistant/router-typescript-draft', version: sourcePackage.version, private: true, type: 'module', engines: sourcePackage.engines, exports: { '.': './dist/index.js', './native': './dist/src/index.js', './testing': './dist/testing.js' }, scripts: { build: 'node ../scripts/check-native-typescript.mjs --out-dir ts/dist' }, dependencies: sourcePackage.dependencies, devDependencies: sourcePackage.devDependencies }, null, 2)}\n`);
  artifacts.set('ts/tsconfig.native.json', `${JSON.stringify({ compilerOptions: { strict: true, target: 'ES2022', module: 'NodeNext', moduleResolution: 'NodeNext', skipLibCheck: true, useDefineForClassFields: false, verbatimModuleSyntax: true, outDir: 'dist', rootDir: '.', declaration: true }, include: ['index.ts', 'testing.ts', 'src/**/*.ts', 'portable/**/*.ts'] }, null, 2)}\n`);
  artifacts.set('ts/.gitignore', 'node_modules\n/dist/\n');
  // Public embedded assets have byte-level HTTP contracts. Keep their exact
  // payload alongside the independently checked TypeScript syntax targets.
  for (const path of ['js/catalog.json', ...walkFiles(sourceRoot, 'js/schemas'), ...walkFiles(sourceRoot, 'js/src/assets/admin')]) artifacts.set(path.replace('js/', 'ts/'), readFileSync(join(sourceRoot, path)));
  artifacts.set('tools/translation/js-to-rust/generated/native-typescript/manifest.json', `${JSON.stringify({ schema: 'native-js-syntax-ast-v1', compiler: ts.version, target: 'complete-native-package-typescript-draft', lowering: 'identity runtime semantics; syntax-token AST serialization and explicit draft dynamic type annotations', fullNativeRustTranslation: false, inferenceInputs, modules: rows, assets: ['catalog.json', 'schemas', 'src/assets/admin'], outputs: [...artifacts].map(([path, value]) => ({ path, bytes: Buffer.byteLength(value), sha256: hash(value) })) }, null, 2)}\n`);
  return artifacts;
}
