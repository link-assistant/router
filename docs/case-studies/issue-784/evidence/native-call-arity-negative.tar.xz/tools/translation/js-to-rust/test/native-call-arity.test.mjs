import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,symlinkSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {loadTypeScript,sourceModules,parseNativeJavaScript,regenerateNativeTypeScript,compileNativeTypeScript} from '../native-typescript.mjs';
import {inferenceProgram} from '../native-inference.mjs';

function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'router-native-call-arity-'));
 t.after(()=>rmSync(root,{recursive:true,force:true}));
 mkdirSync(join(root,'js/src'),{recursive:true});
 symlinkSync(resolve('js/node_modules'),join(root,'js/node_modules'),'dir');
 const write=(path,value)=>writeFileSync(join(root,path),value);
 write('js/package.json','{"name":"native-call-arity-fixture","version":"1.0.0","type":"module"}\n');
 write('js/catalog.json','{}\n');write('js/index.js','export const root=1;\n');write('js/testing.js','export const testing=true;\n');
 return {root,write};
}
function compare(t,files){
 const {root,write}=fixture(t);
 for(const [path,source]of Object.entries(files))write(path,source);
 regenerateNativeTypeScript(root);
 const ts=loadTypeScript(root),paths=sourceModules(root),fresh=inferenceProgram(ts,root,paths);
 for(const path of paths){
  const source=readFileSync(join(root,path),'utf8');
  const expected=parseNativeJavaScript(ts,path,source,{file:fresh.program.getSourceFile(join(root,path)),checker:fresh.checker});
  const name='tools/translation/js-to-rust/generated/native-typescript/'+path.slice(3)+'.meta.json';
  assert.equal(readFileSync(join(root,name),'utf8'),JSON.stringify(expected)+'\n',path);
 }
 assert.deepEqual(regenerateNativeTypeScript(root,{check:true}).changed,[]);
 return {root,write};
}

test('native arity retains complete metadata for overloaded generic nullable spread and aliased calls',{timeout:60000},t=>{
 const {root}=compare(t,{
  'js/src/contracts.d.ts':`export function overloaded(value:string):number;
export function overloaded(value:number,other:number):string;
export function generic<T>(value:T,...others:T[]):T;
export function receiver(this:{value:number},value:number):number;
export function factory():{(value:string):string;(value:number,other:number):number};
`,
  'js/src/contracts.js':`export function overloaded(value,other){return value;}
export function generic(value,...others){return value;}
export function receiver(value){return value;}
export function factory(){return value=>value;}
`,
  'js/src/calls.js':`import {overloaded,generic,receiver,factory} from './contracts.js';
function empty(){return 1;}
function single(value){return value;}
function rest(...values){return values;}
const alias=single;
export function exercise(flag){
 const nullable=flag?single:null;
 const union=flag?single:rest;
 const values=[1,2];
 return [empty(1),single(1,2),rest(1,2),alias(1,2),(0,single)(1,2),single(...values),
  overloaded('x'),overloaded(1,2),overloaded(true,1,2),generic(1,2),receiver.call({value:1},2),
  nullable(1,2),nullable?.(1,2),union(1,2),factory()(1,2),single.bind(null,1,2)()];
}
`,
 });
 assert.equal(compileNativeTypeScript(root).compiler,'5.9.3');
});

test('JSDoc constructor calls keep resolver error signatures and declaration changes stay fresh',{timeout:60000},t=>{
 const source=`/** @constructor */ function Legacy(value){this.value=value;}
/** @class */ function Tagged(value){this.value=value;}
/** @template T @param {T} value @returns {T} */ function identity(value){return value;}
export function construct(){return [Legacy(1),Tagged(1),identity(1),new Legacy(2)];}
`;
 const {root,write}=compare(t,{'js/src/classes.js':source});
 const path='tools/translation/js-to-rust/generated/native-typescript/src/classes.js.meta.json';
 const before=JSON.parse(readFileSync(join(root,path),'utf8'));
 const ts=loadTypeScript(root);
 assert.ok(before.gaps.filter(row=>row.kind===ts.SyntaxKind.CallExpression&&row.call).length>=2);
 write('js/src/classes.js',source.replace('function Legacy(value)','function Legacy(value,other)'));
 assert.ok(regenerateNativeTypeScript(root).changed.includes(path));
 const after=JSON.parse(readFileSync(join(root,path),'utf8'));
 assert.notEqual(after.sourceSha256,before.sourceSha256);
 const fresh=inferenceProgram(ts,root,sourceModules(root)),current=readFileSync(join(root,'js/src/classes.js'),'utf8');
 assert.deepEqual(after,parseNativeJavaScript(ts,'js/src/classes.js',current,{file:fresh.program.getSourceFile(join(root,'js/src/classes.js')),checker:fresh.checker}));
});
