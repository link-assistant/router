Fixes #784

Router now removes supported geolocation metadata by default from routed HTTP
and native JSON WebSocket requests. A single explicit
`x-router-share-geolocation: true` header opts in for that request or connection;
Router consumes the control header. Search location fields, Gemini retrieval
coordinates and supported ingress/IP headers are covered. Account header
overrides cannot restore stripped metadata. Prompts, tool schemas, search
availability and the user's telemetry choices remain intact.

Reproduce the privacy defect by sending a supported location header or search
location field through Router without consent. The new privacy regression cases
assert removal, then assert preservation with explicit consent, including account
overrides and WebSocket forwarding. Matching Rust source and oracle tests are
included but remain unrun until the complete same-SHA JavaScript gate passes.

The current CI repair batch fixes the reverse Bun coordinator's argument cursor,
restores complete historical generator inputs, composes current native/runtime,
Unicode and privacy source equations, and supplies missing fixture dependencies.
It also rejects a plainly contradictory unit predecessor before expensive full
preparation. Every valid predecessor still executes the complete original
native/CST checks. Original archives, whole test files, assertions, refusal
boundaries, strictness and deadlines are preserved. Withdrawn investigation
proposals are explicitly classified and are not production entry points.

This is an authorized **draft feedback checkpoint** at
`17c7dd994`. Latest fetched `main`,
`eb2dad1c0a18394dc1aad46413e11401e74eb502`, is already an ancestor. The working
tree is clean. No full-gate success or release readiness is claimed.

Recorded local verification (Node 20.20.2, Bun 1.4.4, installed TypeScript 5.9.3;
CI retains pinned Bun 1.4.3):

- Complete JavaScript syntax command passes all 1,819 source files.
- Named core producers: all five complete cases pass in both engines; the Node
  independent audit passes the original deadlines. Complete valid/invalid
  results are compared with the retained original operation.
- Current unit/Unicode source composition: all nine complete cases pass in each
  engine. Named source phases: four per engine. Unicode/ASCII producers: three
  per engine. Named reverse/retention producers: three per engine. Current
  privacy parent composition: two per engine. Current native/runtime join:
  six per engine. Each focused Node qualification retains its deadline audit.
- Complete Serde/TOML fixture Node receiving passes nine cases; original Bun
  Serde deadlines still fail. Complete ASCII Node files retain functional
  passes but breach an original 60-second deadline; Bun attempts remain
  incomplete at the unchanged memory guard.
- The complete seven-case unit application attempt aborts on its bounded
  512-MiB heap after three observed completed cases; its first case also
  exceeds its original deadline. All complete temporary files and failed
  streams are retained. The nine target application functions are unqualified.

The latest complete local gate attempt was at earlier source `d46b10bba`.
Lint and both 259-case native suites pass; TypeScript 5.9.3 compiles 167 native
files. Nine TypeScript behaviors report functional passes, but the independent
audit fails regeneration at 110908.639926 / 60000 ms. All 121 parity acceptance
cases pass; strict parity fails with 441 draft gaps and a stale account-policy
inventory hash. Forward translation is interrupted at the unchanged memory
guard; reverse is unrun. Later native regeneration changes improve focused
transport checks but the complete native TypeScript deadline still fails at
104580.741099 / 60000 ms. The complete gate, full production generation and
broader consumer receiving are not qualified for this checkpoint. No green
stamp exists. No local Rust tool has run.

The entire previous published CI cycle at `28aba1b62` completed before this
checkpoint. [Run 42443083163, attempt 2](https://github.com/link-assistant/router/actions/runs/42443083163/attempts/2)
fails; six supplemental workflows skip under the existing draft policy. The
recovered final forward shard's complete 3,731-line artifact contains 633
completion events, ten failures and five original deadline breaches. Its
shorter CLI stream is not mistaken for complete output. All eight forward
artifacts, 30 diagnostic groups and 22 original deadline audits were collected
before drafting this batch.

| Mandatory criterion | Previous completed cycle / remaining qualification |
| --- | --- |
| Lint and native Node/Bun | Passed, including 259 cases per engine. |
| TypeScript | Genuine owned-definition matrix index is missing; no fabricated sidecar. |
| Strict parity | Fails: 441 incomplete features, 12,345 carried items, stale account-policy inventory hash; runtime parity remains false. |
| Canonical and profile generation | Complete actual canonical, owned and three-profile outputs, independent review, installation and freshness remain unfinished. |
| Forward translation | Complete source-join repairs need fresh CI; original source deadlines and remaining genuine failures are mandatory. |
| Reverse translation | Actual eight-bin CLI regression is repaired locally; all production bins and regeneration still require same-head CI. |
| Aggregate and Rust | Aggregate remains failed until every required JavaScript stage passes for the same SHA; Rust and release must remain gated. |

No missing secret or human-only access prerequisite explains these failures, so
no required code check is skipped. Fresh CI results must replace the previous
cycle's evidence before completion; passing focused cases alone cannot do so.

The [case study](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/case-studies/issue-784/README.md)
records requirements, primary vendor research, all eight clients, reusable
components, alternatives and limitations. The
[configuration guide](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/privacy/geolocation.md)
shows Codex and Claude defaults and explicit opt-in. The
[current repair ledger](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/experiments/issue-784/current-native-ci-repair.md)
maps complete receiving results, failed deadlines, generation failures and unrun
checks. Complete source/evidence packets remain in the case-study evidence
directory; each new archive member is read back and verified before only exact
inactive raw duplicates are retired.

**Draft, unfinished and unmerged.** The literal all-tool privacy guarantee is
also unmet: providers see connection IPs and may retain mandatory security
data; account controls need authenticated accounts; direct client, telemetry,
OAuth and MCP traffic can bypass Router. Cursor's private protocol and Gemini
subscription modes are unsupported. Account settings were not changed. These
limits remain explicit acceptance obligations, not a claim that the issue is
complete. Changelog fragments use the existing release process.
