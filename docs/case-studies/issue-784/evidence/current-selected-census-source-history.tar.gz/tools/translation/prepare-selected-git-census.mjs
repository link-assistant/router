// Complete source substitutions only. Every caller keeps its original checks.
import {readFileSync,writeFileSync,lstatSync,mkdtempSync,mkdirSync,rmSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gunzipSync,gzipSync} from 'node:zlib';
import {ownershipCompiler} from './js-to-rust/vendor/module-syntax.mjs';
import {verifyNativeCopiedModuleBindings} from './source-copy-native-bindings.mjs';
import {prepareStrictStaticSourceProducer} from './prepare-strict-static-source-producer.mjs';
import {transportConcreteNamedSourcePhases} from './concrete-source-origin-phases.mjs';
const ROOT=fileURLToPath(new URL('../../',import.meta.url)),P='tools/translation/';
const ARCHIVE=P+'source-profiles/selected-git-census/complete-originals.json.gz';
const hash=x=>createHash('sha256').update(x).digest('hex'),fail=message=>{throw TypeError('Selected Git census source: '+message);};
const one=(rows,name)=>{if(rows.length!==1)fail('one actual native '+name+' required');return rows[0];};
function native(ts,path,source){const file=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);if(file.parseDiagnostics.length)fail('complete native grammar differs: '+path);return file;}
function find(ts,node,predicate){const rows=[];function visit(value){if(predicate(value))rows.push(value);ts.forEachChild(value,visit);}visit(node);return rows;}
function selected(file,node,replacement){return {span:[node.getStart(file),node.end],expected:node.getText(file),replacement};}
function apply(before,edits){let after=before,end=before.length;for(const row of [...edits].sort((a,b)=>b.span[0]-a.span[0])){if(row.span[1]>end||after.slice(...row.span)!==row.expected)fail('native source selection differs');after=after.slice(0,row.span[0])+row.replacement+after.slice(row.span[1]);end=row.span[0];}let delta=0;const mapped=[...edits].sort((a,b)=>a.span[0]-b.span[0]).map(row=>{const at=row.span[0]+delta;delta+=row.replacement.length-row.expected.length;return {...row,afterSpan:[at,at+row.replacement.length]};});let inverse=after;for(const row of mapped.reverse()){if(inverse.slice(...row.afterSpan)!==row.replacement)fail('native inverse selection differs');inverse=inverse.slice(0,row.afterSpan[0])+row.expected+inverse.slice(row.afterSpan[1]);}if(inverse!==before)fail('complete native inverse differs');return after;}
function derive(ts,path,before){
 const file=native(ts,path,before),universe=path.endsWith('static-source-universe.mjs'),owner=one(file.statements.filter(node=>ts.isFunctionDeclaration(node)&&node.name?.text===(universe?'inventory':'staticCapture')),'actual source census'),edits=[];
 if(universe){const loop=one(find(ts,owner,node=>ts.isForOfStatement(node)&&node.expression.getText(file).includes("['ls-tree','-r','-l','-z',expectedHead]")),'current complete metadata loop');edits.push(selected(file,loop.expression,"readSelectedGitSizeRecords({revision:expectedHead,run:(args,options)=>git(root,args,options),select:isStaticSourceUniversePath,maxPaths:LIMITS.paths,maxFileBytes:LIMITS.fileBytes,maxTotalBytes:LIMITS.sourceBytes})"));}
 else{const declaration=one(find(ts,owner,node=>ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name)&&node.name.text==='listing'),'original complete listing'),filter=one(find(ts,owner,node=>ts.isIfStatement(node)&&node.expression.getText(file).includes("!path.endsWith('.rs')")),'actual original source selection');if(!declaration.initializer.getText(file).includes("['ls-tree','-r','-l','-z',rev]"))fail('actual original Git call differs');edits.push(selected(file,declaration.initializer,'readSelectedGitSizeRecords({revision:rev,run:(args,options)=>staticGit(root,args,options),select:path=>!('+filter.expression.getText(file)+'),maxPaths:STATIC_SOURCE_LIFECYCLE_LIMITS.paths,maxFileBytes:STATIC_SOURCE_LIFECYCLE_LIMITS.fileBytes,maxTotalBytes:STATIC_SOURCE_LIFECYCLE_LIMITS.sourceBytes})'));}
 const language=apply(before,edits),intermediate=native(ts,path,language),firstImport=intermediate.statements.find(ts.isImportDeclaration);if(!firstImport)fail('actual import boundary required');const importAt=firstImport.getStart(intermediate),repository=[{span:[importAt,importAt],expected:'',replacement:"import {readSelectedGitSizeRecords} from './selected-git-size-records.mjs';\n"}];
 if(!universe){const producers=intermediate.statements.filter(node=>ts.isFunctionDeclaration(node)&&['prepareStaticSourceLifecycleProposal','prepareStaticSourceLifecycleProposalReleased','prepareStrictStaticSourceLifecycleProposal'].includes(node.name?.text));if(producers.length!==2)fail('both actual complete static producers required');for(const producer of producers){const call=one(find(ts,producer,node=>ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='gzipSync'),'actual archive compression'),level=one(call.arguments[1].properties.filter(node=>ts.isPropertyAssignment(node)&&node.name.getText(intermediate)==='level'),'actual archive compression level');if(level.initializer.getText(intermediate)!=='9')fail('original archive compression differs');repository.push(selected(intermediate,level.initializer,'1'));}}
 // Preserve the exact intermediate installed by the census-only producer:
 // both original archive encoders still select their original level nine.
 // Derive this whole source from native selections, never from physical bytes.
 const censusOnly=apply(language,[repository[0]]);
 const after=apply(language,repository);native(ts,path,after);return {path,before,language,after,censusOnly,beforeSha256:hash(before),afterSha256:hash(after),nativeSelections:edits,repositorySelections:repository,inverse:before,allOriginalValidationBodiesRetained:true,semanticAuthority:false};
}
function strictProducerHistory(ts,producer,current){
 const before=producer.source,file=native(ts,producer.path,before);
 const owner=one(file.statements.filter(node=>ts.isFunctionDeclaration(node)&&node.name?.text==='prepareStrictStaticSourceProducer'),'original strict copy producer');
 const guard=one(find(ts,owner,node=>ts.isIfStatement(node)&&node.expression.getText(file)==="current!==''&&current!==after"),'original strict output guard');
 if(guard.getText(file)!=="if(current!==''&&current!==after)fail('unknown existing strict producer output');")fail('original strict output refusal differs');
 const replacement='// Complete prior output, before the source archive compression repair.\n'
  +' // This pin accepts no other physical source as an installation predecessor.\n'
  +" if(current!==''&&current!==after&&hash(current)!=='644663d19e7b94b783504ec182eadcbc58e5810b7327c0e996e9bc020619241f')fail('unknown existing strict producer output');";
 // The original guard immediately follows the catch on the same line. Its
 // independently authored successor starts a new line before the comments.
 const edit=selected(file,guard,'\n '+replacement),after=apply(before,[edit]);
 if(hash(after)!=='add7542caf50f0bde993169e97f01a8233b3814321abb9aa1243acc0f9f1209f')fail('complete known strict producer successor differs');
 native(ts,producer.path,after);
 if(current!==before&&current!==after)fail('actual strict copy producer changed');
 return {path:producer.path,before,after,current,inverse:before,nativeSelections:[edit],
  beforeSha256:hash(before),afterSha256:hash(after),
  semanticAuthority:false};
}
export function prepareSelectedGitCensus({root=ROOT}={}){
 root=resolve(root);const ts=ownershipCompiler();if(ts.version!=='5.9.3')fail('actual TypeScript5.9.3 required');const packed=readFileSync(join(root,ARCHIVE));if(packed.length!==29505||hash(packed)!=='058d24ef98fdbf70abf08e29211e57755562d486d9f0538d67cae9e2020d6ca6')fail('complete original source archive differs');const raw=gunzipSync(packed,{maxOutputLength:1048576});if(raw.length!==127645||hash(raw)!=='8bcce2f1ddc995b925e3555960cdb01900e2affcc9e33d4fd3f7b6cc0f752d04')fail('complete original source bytes differ');const archive=JSON.parse(raw);if(archive.schema!=='selected-git-census-complete-originals-v1'||archive.revision!=='a7d10d2c811b13590e465145889640e5227bdefc'||archive.rows.length!==4)fail('complete actual original source census required');
 for(const row of archive.rows)if(Buffer.byteLength(row.source)!==row.bytes||hash(row.source)!==row.sha256||createHash('sha1').update(Buffer.from('blob '+row.bytes+'\0')).update(row.source).digest('hex')!==row.gitBlob)fail('complete original Git/source join differs');
 const producer=one(archive.rows.filter(row=>row.path===P+'prepare-strict-static-source-producer.mjs'),'original strict copy producer'),producerHistory=strictProducerHistory(ts,producer,readFileSync(join(root,producer.path),'utf8'));const files=archive.rows.filter(row=>row!==producer).map(row=>derive(ts,row.path,row.source));
 for(const row of files){const path=join(root,row.path),stat=lstatSync(path);if(!stat.isFile()||stat.isSymbolicLink())fail('regular complete current source required');row.current=readFileSync(path,'utf8');if(row.current!==row.before&&row.current!==row.after&&row.current!==row.censusOnly)fail('unknown current source: '+row.path);row.censusHistory=[];}
 // One fresh DATA transaction retains every complete source, both phases and
 // every inverse. No CST result or native binding verdict survives this call.
 const histories=files.filter(row=>row.current===row.censusOnly&&row.censusOnly!==row.after);
 const requests=[...files.map(row=>({before:row.before,middle:row.language,after:row.after})),
  {before:producerHistory.before,middle:producerHistory.before,after:producerHistory.after},
  ...histories.map(row=>({before:row.censusOnly,middle:row.censusOnly,after:row.after}))];
 const equations=transportConcreteNamedSourcePhases(requests.map(row=>({...row,language:'JavaScript',
  rules:['javascript:select-metadata-before-batched-sizes','repository:shared-census-and-fast-lossless-archive',
   'javascript:restore-complete-original-census','repository:restore-complete-original-source']})));
 for(const [at,equation]of equations.entries())if(equation.before!==requests[at].before||equation.middle!==requests[at].middle||equation.after!==requests[at].after||equation.inverse!==requests[at].before)fail('complete batched source equation differs');
 for(const [at,row]of files.entries()){row.stages=equations[at].stages;row.trace=equations[at].trace;}
 producerHistory.stages=equations[files.length].stages;
 for(const [at,row]of histories.entries())row.censusHistory=equations[files.length+1+at].stages;
 const bindings=verifyNativeCopiedModuleBindings(ts,files.map(row=>({path:resolve(ROOT,row.path),source:row.after})));
 for(const [at,row]of files.entries())row.nativeBindings=bindings[at];
 const stage=mkdtempSync(join(tmpdir(),'router-selected-git-strict-source-'));let strict;
 try{mkdirSync(join(stage,P),{recursive:true});const original=one(files.filter(row=>row.path===P+'prepare-real-source-fixtures.mjs'),'complete updated original producer');writeFileSync(join(stage,original.path),original.after);strict=prepareStrictStaticSourceProducer({root:stage});if(strict.files.length!==1||strict.files[0].after!==one(files.filter(row=>row.path===P+'strict-static-source-producer.mjs'),'complete strict afterimage').after)fail('actual strict producer full-source equation differs');}finally{rmSync(stage,{recursive:true,force:true});}
 const inputs=[...files.map(row=>({path:row.path,source:row.current})),{path:producer.path,source:producerHistory.current},...['prepare-selected-git-census.mjs','selected-git-size-records.mjs'].map(name=>({path:P+name,source:readFileSync(join(root,P+name),'utf8')}))];for(const row of inputs)if(readFileSync(join(root,row.path),'utf8')!==row.source)fail('complete input changed');if(!readFileSync(join(root,ARCHIVE)).equals(packed))fail('complete source archive changed');return {schema:'selected-git-census-source-proposal-v1',root,files,strictProducer:strict,producerHistory,inputs,binaryInputs:[{path:ARCHIVE,bytes:packed.length,sha256:hash(packed)}],originalLimitsAndValidationBodiesRetained:true,canonicalArchiveBytesUnchanged:true,gzipEncodingMayDiffer:true,newCaches:false,semanticAuthority:false,performanceQualified:false};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){const args=process.argv.slice(2);if(args.length!==1||!['--emit','--write','--check'].includes(args[0]))fail('use --emit|--write|--check');const plan=prepareSelectedGitCensus();if(args[0]==='--write'){for(const row of plan.files){if(readFileSync(join(ROOT,row.path),'utf8')!==row.current)fail('current complete source changed');writeFileSync(join(ROOT,row.path),row.after);}}else if(args[0]==='--check'&&plan.files.some(row=>row.current!==row.after))fail('actual source copies are stale');if(args[0]==='--emit')console.log(JSON.stringify(plan));else console.log(JSON.stringify({files:plan.files.map(row=>row.path),fresh:args[0]==='--check',semanticAuthority:false,performanceQualified:false}));}
