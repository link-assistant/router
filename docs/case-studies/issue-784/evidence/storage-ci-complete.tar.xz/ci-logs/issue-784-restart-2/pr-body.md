Fixes #784

Router forwarded location headers and optional search coordinates to providers.
This draft removes supported explicit geolocation metadata by default from
routed inference HTTP, native replay and JSON WebSocket messages. Exactly one
`x-router-share-geolocation: true` header opts in for a request or WebSocket
connection. Router consumes the control header and preserves prompts, tool
schemas, search availability and existing telemetry choices.

The JavaScript policy has matching Rust source, shared fixtures and generated
native TypeScript. Account header overrides cannot restore unconsented location
or ingress IP headers. Gemini retrieval coordinates cover all eight independent
ProtoJSON spelling combinations; six mixed combinations leaked before the
restart fix. Existing bounded decoders and WebSocket inspection are reused,
with no new dependency. Rust execution remains unverified.

Reproduce by sending a native inference request with `CF-IPCountry: GB`,
`X-Vercel-IP-City: London`, supported search `user_location`, or a mixed-spelling
Gemini retrieval coordinate and inspecting a synthetic upstream. The complete
`geolocation.test.mjs` and `geolocation-websocket.test.mjs` files verify removal,
opt-in, repeated/invalid consent, preserved application content and fragmented
WebSocket forwarding. Node and Bun each pass all **30 focused cases**. The
published-head CI passes the full native suites: **259 cases under each engine**.

Historical compiler fixtures retain authenticated original inputs, assertions,
strictness and deadlines. The current-source fixture was regenerated through
its unchanged producer for the PR's two new Rust files; both historical source
universes remain byte-identical. The refreshed fixture exposed the exporter's
unchanged 4 MiB per-file limit. The repair factors repeated Git blob identifiers
through the existing source dictionary, retains old archive support and refusal
checks, and regenerates the complete fixture with maximum gzip compression.
The **4,134,635-byte archive** retains its exact logical content hash and all
historical/current source bytes. The complete offline export regression passes
in the latest CI. No test deadline, resource bound or parity status was relaxed.

The second CI repair resolves two additional causes without weakening the gate:

- Select both complete profile TypeScript trees from the explicit inventory,
  supporting the checked-in modern and legacy layouts. All three real profiles
  compile strictly with TypeScript 5.9.3. Two complete regression cases pass on
  Node and Bun, including an unindexed draft error and a project error. The full
  gate-control file passes 40 cases on Node 20, including its deadline-control assertions.
- Authenticate the current guarded lexing import against the original complete
  immutable-composer source pin and its exact native/CST inverse. Regenerate the
  operation scope and consumer scope through their producers. Complete source
  comparison confirms only the lexing module literal changes in each generated
  file. Operation checks pass 9/9 on Node 20 with their independent deadline
  audit and 9/9 on Bun; the affected shared producer checks pass 12/12 and their
  deadline audit. Original body/refusal bytes and deadlines remain intact.

The next TypeScript prerequisite is still **failed**: the complete owned-definition
matrix index has never been generated. The complete forward/reverse producers
must generate and qualify it; no fabricated empty index or skip is used.

Published repair head: `84779613d`. Its complete same-head CI cycle is pending;
the locally passed checks above are not a substitute for that cycle. The PR
remains draft and unmerged.

Latest completed CI before these repairs: [run 42342602437](https://github.com/link-assistant/router/actions/runs/42342602437),
**2026-11-07 05:24:32–06:30:15 UTC**, **failure**, published head
`7dceb9b0a545aa5c61f078920d966d6220e355b1`. All seven same-head workflows
finished before drafting the repair batch. All complete logs and job inventories
were downloaded. The following line numbers refer to the main complete log.

| Required JavaScript stage | Result |
| --- | --- |
| Native Node, native Bun, lint | **Pass**; 259 native cases per engine. |
| TypeScript | **Fail**: missing neutral profile tree, line 4513. The focused path repair passes locally; the next owned-definition index prerequisite is missing. |
| Strict parity | **Fail**: stale account-policy source, **441 draft gaps**, **12345 carried items**, runtime parity false, lines 5761–5764. |
| Profile matrix | **Fail**: neutral worker aborted at its unchanged 2048 MiB V8 heap limit, line 4834. |
| Forward translation | **Cancelled at 60 minutes**. The incomplete cohort contains compiler-pin failures and three composer-source refusals, lines 2436 and 3166–3208. Focused composer repair is locally qualified; the complete cohort is not. |
| Reverse translation | **Cancelled at 15 minutes**, after case 76, line 6469. Later checks were unrun. |
| Aggregate and Rust | Aggregate **failed**, line 8050. Downstream Rust/release jobs stayed skipped. No Rust tool ran locally. |

Passing native and focused compiler checks do not establish a green full gate.
No missing-secret or human-access prerequisite was identified in these failures;
they are not bypassed through a pull-request-only skip.

Earlier local evidence remains relevant and preserved in the verification record:

- The complete local gate at `08e09f884546ecf373dfa2997f7d0dd906a0cb1c`
  attempted all seven groups and failed four. Native Node/Bun and lint passed;
  TypeScript failed an independent original 60000 ms deadline, strict parity
  failed, forward translation required an owned memory stop, and reverse
  translation reached its original outer deadline. Later commands were unrun.
- The complete five-file export receiving attempt at
  `b913882ab538e0ffda77ff1b6a1171a53228ca59` reported **33/34 Node TAP passes**.
  The real producer child reached its unchanged 20000 ms deadline; the independent
  audit also failed a 65319.319072 ms case against its original 60000 ms deadline.
  Bun passed 23 cases before an owned guard stopped the four-file attempt at
  2869792768 sampled total cgroup bytes. Later codec cases remain unqualified.
  A new complete local gate is unrun; unchanged memory-stopped workloads were
  not repeated in the 2.92 GiB container.
- Complete failed and passed streams, failed compression alternatives, original
  source/proposal bytes and cleanup receipts are retained in verified compressed
  evidence packets. The latest committed packet contains 160 complete originals
  in 14.2 MB; it predates and does not replace the latest CI cycle linked above.

The [case study](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/case-studies/issue-784/README.md)
contains the requirement inventory, GitHub source data, client matrix,
primary-source research, alternatives and remaining obligations. The
[verification record](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/case-studies/issue-784/verification.md)
preserves complete compressed evidence and exact tested SHAs. The
[configuration guide](https://github.com/link-assistant/router/blob/issue-784-1f6838f56841/docs/privacy/geolocation.md)
shows actual Codex and Claude Code defaults and opt-in settings. Changelog
fragments use the repository's automatic version/release process.

This PR stays **draft and unmerged; issue completion remains unfinished**.
The literal all-tool guarantee remains unmet: connection IPs are visible,
vendors retain mandatory security location inference, account privacy controls
require the respective authenticated accounts, and direct client, telemetry,
OAuth or MCP traffic can bypass Router. Cursor's private protocol and Gemini
subscription modes remain unsupported. Account settings were not changed.
The remaining compiler/profile/parity failures, Rust verification and this
universal scope are unresolved acceptance criteria.
