import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {ownershipCompiler} from '../js-to-rust/vendor/module-syntax.mjs';
import {prepareFacadeAstReceivingHistory} from '../prepare-facade-ast-receiving-history.mjs';
import {currentCoreFacadeLaterHistory,restoreCorePrimitiveReceivingHistory,restoreBuiltinAstReceivingHistory,legacyProofConsumerSource} from './fixtures/facade-ast-receiving-history.mjs';
import {transportConcreteSyntaxMeta} from '../concrete-syntax-meta.mjs';
import {gunzipSync} from 'node:zlib';
import {currentCoreFiles,currentCoreReceivingFiles} from './current-core-text-fixture.mjs';
const hash=value=>createHash('sha256').update(value).digest('hex');
function cases(source){const ts=ownershipCompiler(),file=ts.createSourceFile('whole.test.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),rows=[];function visit(node){if(ts.isCallExpression(node)&&['test','nodeTest'].includes(node.expression.getText(file))&&node.arguments[0]&&ts.isStringLiteral(node.arguments[0]))rows.push(node.getText(file));ts.forEachChild(node,visit);}visit(file);return rows;}

test('complete genuine facade and AST histories retain original whole cases, full source fields and every inverse',{timeout:60000},()=>{
 const plan=prepareFacadeAstReceivingHistory();assert.equal(plan.files.length,3);assert.equal(plan.facades.length,6);assert.equal(plan.originalFacades.length,5);assert.deepEqual(plan.facades.slice(0,5),plan.originalFacades);assert.equal(plan.currentRuntimeModulesUnchanged,true);assert.equal(plan.receivingExecuted,false);assert.equal(plan.ownerAuthority,false);assert.match(plan.knownSemanticFollowup,/Complete current primitive inputs/);for(const row of plan.files){assert.equal(row.inverse,row.before);assert.deepEqual(row.stages.map(stage=>stage.phase),['language','repository']);for(const stage of row.stages){assert.equal(transportConcreteSyntaxMeta(stage.beforeMeta).source,stage.before);assert.equal(transportConcreteSyntaxMeta(stage.afterMeta).source,stage.after);assert.equal(stage.inverse,stage.before);}if(row.path.endsWith('/derive-output-effects.test.mjs'))assert.deepEqual(cases(row.after),cases(row.before));if(row.path.endsWith('/current-core-text-fixture.mjs')){assert.ok(row.after.includes('assert.equal(delta,CORE_BASE64_ADOPTION.length)'));assert.ok(row.after.includes('assert.equal(expected.length,27)'));assert.ok(row.previousSource.includes('assert.equal(expected.length,25)'));assert.ok(row.after.includes('assert.deepEqual(result.meta.refused,expected)'));}}
 const ast=plan.ast.files[0];assert.equal(Buffer.byteLength(ast.before),25881);assert.equal(Buffer.byteLength(ast.after),31339);assert.equal(hash(ast.before),'e568e87935e993223b820a84c45f4aa1b9eca2d96a515f2adebd38a8bfca0ca5');assert.equal(ast.inverse,ast.before);assert.ok(plan.primitive.nativeAppend.source.includes('ascii_chars_in'));
});

test('actual complete AST source restores the independently pinned original without changing runtime source or issuer',{timeout:60000},()=>{
 const url=new URL('../builtin-derive-ast-meta.mjs',import.meta.url),current=readFileSync(url,'utf8'),retained=[];const before=restoreBuiltinAstReceivingHistory(current,(kind,value)=>retained.push({kind,value}));assert.equal(Buffer.byteLength(before),25881);assert.equal(hash(before),'e568e87935e993223b820a84c45f4aa1b9eca2d96a515f2adebd38a8bfca0ca5');assert.equal(legacyProofConsumerSource(current),before);assert.equal(retained.length,1);assert.equal(retained[0].value.current,current);assert.equal(retained[0].value.historical,before);assert.equal(retained[0].value.inverse,current);assert.ok(before.includes('compilerOutputAstSourceAccess'));assert.ok(before.includes('requireCompilerOutputAstSourceAccess'));assert.ok(before.includes('compilerOutputCollectionSourceAccess'));assert.equal(readFileSync(url,'utf8'),current);assert.throws(()=>restoreBuiltinAstReceivingHistory(current+'\n// foreign source\n'),/complete actual AST source differs/);assert.throws(()=>restoreBuiltinAstReceivingHistory(current.replace('function','functioN')),/complete actual AST source differs/);
});

test('all five later facade layers and the primitive append preserve old bytes and reject unknown current sources',{timeout:60000},()=>{
 const current=readFileSync(new URL('../../../rust/src/translation_core.rs',import.meta.url),'utf8'),history=currentCoreFacadeLaterHistory(current);assert.equal(history.layers.length,6);assert.deepEqual(history.layers.slice(0,5).map(row=>row.kind),['vector','vector-spacing','matches','ascii','unit-matches']);assert.equal(history.layers[5].kind,'unicode-predicates');assert.equal(hash(history.before),'0ac537078f36e8b9f6aa1bbfa252ab9f59bdca9374b51897df4286f599d32e95');assert.equal(history.actual,current);assert.equal(history.inverse,history.before);assert.equal(history.delta,current.length-history.before.length);assert.equal(transportConcreteSyntaxMeta(history.afterMeta).source,current);let previous=history.before;for(const row of history.layers){assert.equal(row.before,previous);assert.equal(row.concrete.before,row.before);assert.equal(row.concrete.after,row.after);assert.equal(row.concrete.inverse,row.before);assert.equal(transportConcreteSyntaxMeta(row.concrete.beforeMeta).source,row.before);assert.equal(transportConcreteSyntaxMeta(row.concrete.afterMeta).source,row.after);previous=row.after;}assert.equal(previous,current);const primitive=readFileSync(new URL('../../../rust/src/translation_core/primitives.rs',import.meta.url),'utf8'),before=restoreCorePrimitiveReceivingHistory(primitive);assert.equal(Buffer.byteLength(before),3253);assert.equal(hash(before),'36ed8563a7c9fb2e340e874fdbd95b30eb106c6e2a39577915987ab44ea7d123');assert.ok(primitive.startsWith(before));assert.throws(()=>currentCoreFacadeLaterHistory(current+'\n'),/complete actual facade differs/);assert.throws(()=>restoreCorePrimitiveReceivingHistory(primitive+'\n'),/complete actual primitive source differs/);
});

test('all original receiving workloads use the complete current primitive child while historical source APIs stay byte exact',{timeout:60000},()=>{
 const raw=gunzipSync(readFileSync(new URL('fixtures/current-core-text-sources.json.gz',import.meta.url))),oracle=JSON.parse(raw),primitive=readFileSync(new URL('../../../rust/src/translation_core/primitives.rs',import.meta.url),'utf8');
 assert.equal(hash(raw),'d484c8599546faebc8f1cde10fe85a4559ba617b50efb98f3ead806d0afd7f8d');assert.equal(oracle.contexts.length,8);
 for(const row of oracle.contexts){const original=currentCoreFiles(row.path,row.name,row.source),snapshot=JSON.stringify(original),receiving=currentCoreReceivingFiles(row.path,row.name,row.source);assert.equal(JSON.stringify(original),snapshot);assert.equal(original['src/translation_core/primitives.rs'],restoreCorePrimitiveReceivingHistory(primitive));assert.equal(receiving['src/translation_core/primitives.rs'],primitive);assert.equal(receiving[row.path],original[row.path]);assert.notEqual(receiving['src/translation_core.rs'],original['src/translation_core.rs']);}
});

test('batched history runtime retains the complete original factory and derives its receiving copy by actual native spans',{timeout:60000},()=>{
 const plan=prepareFacadeAstReceivingHistory(),copy=plan.runtimeCopy;assert.equal(copy.inverse,copy.before);assert.equal(copy.nativeSelections.length,3);let actual=copy.before;
 for(const row of [...copy.nativeSelections].sort((a,b)=>b.span[0]-a.span[0])){assert.equal(actual.slice(...row.span),row.expected);actual=actual.slice(0,row.span[0])+row.replacement+actual.slice(row.span[1]);}
 assert.equal(actual,copy.after);assert.ok(copy.before.includes('function phase(before,after)'));assert.ok(copy.before.includes('transportConcreteSyntaxMeta(serializeConcreteSyntaxMeta(inverse.value))'));assert.ok(copy.after.includes('transports[position++]'));
 const equation=plan.runtimeEquation;assert.equal(equation.inverse,equation.before);assert.ok(equation.before.includes(copy.before));assert.ok(equation.after.includes(copy.after));for(const stage of equation.stages){assert.equal(transportConcreteSyntaxMeta(stage.beforeMeta).source,stage.before);assert.equal(transportConcreteSyntaxMeta(stage.afterMeta).source,stage.after);assert.equal(stage.inverse,stage.before);}
});

test('complete base64 history copy retains its source checks and replaces only native CST declarations',{timeout:60000},()=>{
 const plan=prepareFacadeAstReceivingHistory(),equation=plan.coreEquation;assert.equal(equation.nativeSelections.length,3);assert.equal(equation.inverse,equation.before);let source=equation.before;
 for(const edit of [...equation.nativeSelections].sort((a,b)=>b.span[0]-a.span[0])){assert.equal(source.slice(...edit.span),edit.expected);source=source.slice(0,edit.span[0])+edit.replacement+source.slice(edit.span[1]);}assert.equal(source,equation.after);assert.ok(equation.before.includes('const before=transportConcreteSyntaxSource(row.source'));assert.ok(equation.after.includes('after={source:equation.after,meta:equation.afterMeta}'));
 for(const row of [equation.before,equation.after])for(const guard of ['assert.equal(target,later.before)','assert.equal(after.source,target)','assert.equal(restored.source,row.source)','assert.equal(expected.length,25)','assert.deepEqual(result.meta.refused,expected)'])assert.ok(row.includes(guard),guard);
 for(const stage of equation.stages){assert.equal(transportConcreteSyntaxMeta(stage.beforeMeta).source,stage.before);assert.equal(transportConcreteSyntaxMeta(stage.afterMeta).source,stage.after);assert.equal(stage.inverse,stage.before);}
});

test('batched producer equations equal the complete retained original phase operation',{timeout:60000},async()=>{
 const ts=ownershipCompiler(),source=readFileSync(new URL('../prepare-facade-ast-receiving-history.mjs',import.meta.url),'utf8');
 const file=ts.createSourceFile('complete-producer.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),nodes=file.statements.filter(node=>ts.isFunctionDeclaration(node)&&node.name?.text==='stage');
 assert.equal(nodes.length,1);const original=nodes[0].getText(file);assert.equal(hash(original),'dcc15837b5ae6b422817d4878dc3632ac1ea3a91e9c3d91db9559cf3112b1674');
 const module="import {transportConcreteSyntaxSource,transportConcreteSyntaxMeta,serializeConcreteSyntaxMeta,applyConcreteSyntaxSubstitutions} from "+JSON.stringify(new URL('../concrete-syntax-meta.mjs',import.meta.url).href)+";\nconst fail=message=>{throw new TypeError('Facade/AST receiving history: '+message);};\n"+original+'\nexport {stage};\n';
 const retained=await import('data:text/javascript;base64,'+Buffer.from(module).toString('base64')),plan=prepareFacadeAstReceivingHistory();
 for(const equation of [plan.facades.at(-1),plan.unicodeCoreEquation])for(const actual of equation.stages){
  const type=equation.path.endsWith('.rs')?'Rust':'JavaScript';
  assert.deepEqual(actual,retained.stage(actual.before,actual.after,type,actual.phase));
 }
 assert.equal(plan.unicodeCoreEquation.inverse,plan.unicodeCoreEquation.before);
});
