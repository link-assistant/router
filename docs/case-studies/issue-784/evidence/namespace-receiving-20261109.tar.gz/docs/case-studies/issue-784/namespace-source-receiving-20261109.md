# Namespace composition and complete source-history receiving

This continuation repairs concrete failures from PR #785's published
`1c82cbd9355724439a953ddaa7642193d03878ca` CI cycle. It does not establish
complete translation, parity, release readiness, or universal tool privacy.

The complete terminal cycle contains 59 jobs: 18 failures, eight successes,
eight cancellations and 25 skips. All 26 failed/cancelled logs and all 26 final
artifacts were inspected. The complete retained packet is
[evidence/current-1c82-terminal-ci.tar.gz](evidence/current-1c82-terminal-ci.tar.gz)
(6664954 bytes, SHA-256
`16e021db43e563dd9f57ccc662d4adaf15a7e07bb7c3ccdf8ae29737f45e7c36`).
The canonical artifact admits 161 of 2578 production functions, three more
than the preceding 158 baseline. The other 2417 remain carried; those counts
belong to the published head, not this working tree.

Ordinary projects now share the genuine enclosing Default context with Clone,
while retaining complete ordinary module and macro evidence. Owned-definition
projects retain their separate enclosing declaration scope and issue a complete
method parser context when a method requires one. The original method-owner
file reproduced two failures before the repair and passes all four cases after
it. The new context tests compare complete legacy evidence and bindings, reject
copied or foreign contexts, execute checked JavaScript and strict TypeScript,
and keep a large unsupported Clone body from suppressing an unrelated owned
function. Enclosing names provide no body, type or ownership authority.

The existing seven namespace phase names are also reported for explicitly
requested ordinary-project diagnostics. Full emitted JavaScript, TypeScript and
meta output remain equal in the finite receiving case; callback errors propagate.
These observations do not measure actual production function gains.

Pinned repository source profiles compose the existing complete project and
native regeneration equations with the current source. Each profile declares
ordered repository substitutions, complete before/after pins and an exact
ordered inverse. The real producers still transport the complete sources through
both CST phases, serialized reparsing and independent native checks. The generic
profile reader itself supplies source DATA and no semantic or executable proof.
The native producer restores all original public callable bodies; optimized
emission and inference release remain private implementation details.

The Clone validation and compiler-alias source producers compose the known
complete enclosing-Clone history. The generated whole-owner derive candidate is
rederived with its original producer. The complete current proof fixture has a
separate receiving equation for its one known Clone-history call; the historical
negative-budget test then reads its original complete fixture bytes. Its old
source pin, assertions and deadlines remain unchanged.

The latest six-file Node 20.20.2 cohort passes 18/18 cases and its independent
deadline audit in 85.107 seconds, with a sampled total cgroup peak of 1318490112
bytes. Bun 1.4.4 passes the same 18 cases in 41.456 seconds, peak 1604927488
bytes. TypeScript remains the lockfile-installed version 5.9.3. Earlier failed
new-test assumptions and intermediate source drafts remain in the evidence.
All 17 original facade, derive and resolver Node cases also pass their
independent deadline audit (182.412 seconds, peak 2529644544 bytes). Bun's
combined four-file cohort stops at the unchanged cgroup guard after 61.339
seconds, peak 2869485568 bytes, after three resolver assertions. Remaining
cases are unrun. All owned children are reaped. The alias file subsequently
passes all five original cases in 95.730 seconds in a separate process. This
does not qualify the interrupted resolver file.

The full gate after this batch is unrun. Strict parity, generated forward and
reverse freshness, complete profile matrices, original receiving deadlines and
the original universal privacy criteria remain unfinished. In particular, the
terminal Bun deterministic-regeneration case took 62967.05 ms against its
original 5000 ms deadline; the last local four-regeneration case exceeded its
60000 ms limit. Neither deadline is changed or waived. No Rust tool is run.
