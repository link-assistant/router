# Complete published 1c82 CI failure inventory

All 26 failed/cancelled jobs and their complete logs were read; intentional negative controls remain separate.

## JavaScript first (same commit) / parity

- Line 901: 2026-11-09T22:20:25.3278952Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-freshness

- Line 288: 2026-11-09T20:59:36.9132146Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / typescript

- Line 466: 2026-11-09T21:01:43.7746637Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / owned-profile-matrix

- Line 8869: 2026-11-09T21:58:15.7427804Z ##[error]The operation was canceled.
- Line 8884: 2026-11-09T21:58:15.8558088Z ##[error]No files were found with the provided path: js/node_modules/.matrix-drafts/. No artifacts will be uploaded.

## JavaScript first (same commit) / translation (2)

- Line 731: 2026-11-09T21:01:37.0823533Z not ok 89 - complete native Clone source equation preserves both CST phases and original inverse
  - Line 734: 2026-11-09T21:01:37.0825089Z   location: '/home/runner/work/router/router/tools/translation/test/clone-validation-order.test.mjs:39:1'
  - Line 736: 2026-11-09T21:01:37.0826349Z   error: 'Clone validation order source: unexpected current complete source'
  - Line 737: 2026-11-09T21:01:37.0826859Z   code: 'ERR_TEST_FAILURE'
- Line 1019: 2026-11-09T21:28:24.1582793Z not ok 143 - pending complete original src/config.rs parse_csv retains source and checked frontier
  - Line 1022: 2026-11-09T21:28:24.1599133Z   location: '/home/runner/work/router/router/tools/translation/test/csv-original-source.test.mjs:25:59'
  - Line 1024: 2026-11-09T21:28:24.1600470Z   error: 'test timed out after 900000ms'
  - Line 1025: 2026-11-09T21:28:24.1600977Z   code: 'ERR_TEST_FAILURE'
  - Line 1031: 2026-11-09T21:28:24.1605813Z   location: '/home/runner/work/router/router/tools/translation/test/csv-original-source.test.mjs:25:59'
  - Line 1033: 2026-11-09T21:28:24.1659663Z   error: '[{"file":"src/storage/associative.rs","name":"std","term":"use","kind":"module-binding","message":"use parent is unresolved, ambiguous or has no importable module/enum namespace","span":{"start":0,"end":61}},{"file":"src/storage/associative.rs","name":"std","term":"use","kind":"module-binding","message":"use parent is unresolved, ambiguous or has no importable module/enum namespace","span":{"start":0,"end":61}},{"file":"src/storage/associative.rs","name":"s
  - Line 1034: 2026-11-09T21:28:24.1697934Z   code: 'ERR_ASSERTION'
- Line 1028: 2026-11-09T21:28:24.1603885Z not ok 144 - pending complete original src/storage/associative.rs split_repository_list retains source and checked frontier
  - Line 1031: 2026-11-09T21:28:24.1605813Z   location: '/home/runner/work/router/router/tools/translation/test/csv-original-source.test.mjs:25:59'
  - Line 1033: 2026-11-09T21:28:24.1659663Z   error: '[{"file":"src/storage/associative.rs","name":"std","term":"use","kind":"module-binding","message":"use parent is unresolved, ambiguous or has no importable module/enum namespace","span":{"start":0,"end":61}},{"file":"src/storage/associative.rs","name":"std","term":"use","kind":"module-binding","message":"use parent is unresolved, ambiguous or has no importable module/enum namespace","span":{"start":0,"end":61}},{"file":"src/storage/associative.rs","name":"s
  - Line 1034: 2026-11-09T21:28:24.1697934Z   code: 'ERR_ASSERTION'
- Line 1698: 2026-11-09T21:38:15.0062749Z not ok 275 - combined 208 and private-dispatch prerequisite execute unchanged safe_number in the complete actual root
  - Line 1701: 2026-11-09T21:38:15.0064665Z   location: '/home/runner/work/router/router/tools/translation/test/json-source-f64-original-root.test.mjs:19:1'
  - Line 1703: 2026-11-09T21:38:15.0101592Z   error: '[{"file":"src/subscription_usage_normalize.rs","name":"base64","term":"use","kind":"module-binding","message":"use parent is unresolved, ambiguous or has no importable module/enum namespace","span":{"start":0,"end":24}},{"file":"src/subscription_usage_normalize.rs","module":["subscription_usage","normalize"],"name":"normalize_anthropic","term":"fn","kind":"unsupported","message":"assignment target: only scalar local bindings are assignable","span":{"start":
  - Line 1704: 2026-11-09T21:38:15.0130778Z   code: 'ERR_ASSERTION'
- Line 2969: 2026-11-09T21:38:30.2060908Z not ok 526 - complete source proof preservation composes after the exact checkedSource parent and retains native copies and inverses
  - Line 2972: 2026-11-09T21:38:30.2062720Z   location: '/home/runner/work/router/router/tools/translation/test/source-proof-preservation.test.mjs:15:1'
  - Line 2974: 2026-11-09T21:38:30.2064099Z   error: 'Project facade retention source: complete physical project is neither original nor an exact derived output'
  - Line 2975: 2026-11-09T21:38:30.2064535Z   code: 'ERR_TEST_FAILURE'
- Line 3312: 2026-11-09T21:39:40.9105968Z not ok 588 - the actual complete copied consumer closure preserves native bindings Hash calls and every full source inverse
  - Line 3315: 2026-11-09T21:39:40.9107776Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-proof-byte-candidate.test.mjs:24:24'
  - Line 3317: 2026-11-09T21:39:40.9109413Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 3318: 2026-11-09T21:39:40.9110078Z   code: 'ERR_TEST_FAILURE'
- Line 3358: 2026-11-09T21:39:40.9135930Z not ok 594 - the complete real physical proposal retains every sixteen source packets and refuses omitted mutated or foreign bytes
  - Line 3361: 2026-11-09T21:39:40.9137161Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-proof-byte-candidate.test.mjs:24:24'
  - Line 3363: 2026-11-09T21:39:40.9138070Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 3364: 2026-11-09T21:39:40.9138470Z   code: 'ERR_TEST_FAILURE'
- Line 3389: 2026-11-09T21:39:41.3977900Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-bun (8)

- Line 291: 2026-11-09T21:04:00.3309011Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / profile-matrix

- Line 3363: 2026-11-09T21:58:15.3958001Z ##[error]The operation was canceled.
- Line 3378: 2026-11-09T21:58:15.5720180Z ##[error]No files were found with the provided path: js/node_modules/.matrix-drafts/. No artifacts will be uploaded.

## JavaScript first (same commit) / translation (3)

- Line 739: 2026-11-09T21:00:01.1938996Z not ok 91 - complete earlier Clone source and native DAG output retain data, freezing and private issuers
  - Line 742: 2026-11-09T21:00:01.1941324Z   location: '/home/runner/work/router/router/tools/translation/test/clone-completed-freeze.test.mjs:34:1'
  - Line 744: 2026-11-09T21:00:01.1942944Z   error: 'Clone validation order source: unexpected current complete source'
  - Line 745: 2026-11-09T21:00:01.1943639Z   code: 'ERR_TEST_FAILURE'
- Line 760: 2026-11-09T21:00:01.1957121Z not ok 92 - Clone retains the complete original observer callback order and thrown error identity
  - Line 763: 2026-11-09T21:00:01.1959194Z   location: '/home/runner/work/router/router/tools/translation/test/clone-completed-freeze.test.mjs:62:1'
  - Line 765: 2026-11-09T21:00:01.1960717Z   error: 'complete earlier receiving module required'
  - Line 766: 2026-11-09T21:00:01.1961314Z   code: 'ERR_ASSERTION'
- Line 1000: 2026-11-09T21:00:30.9700750Z not ok 137 - progress substitutions and complete layout inverses reconstruct all three source files through both concrete rule phases
  - Line 1003: 2026-11-09T21:00:30.9736774Z   location: '/home/runner/work/router/router/tools/translation/test/core-adoption-progress.test.mjs:23:24'
  - Line 1005: 2026-11-09T21:00:30.9738879Z   error: |-
  - Line 1006: 2026-11-09T21:00:30.9739355Z     Expected values to be strictly equal:
  - Line 1010: 2026-11-09T21:00:30.9740987Z   code: 'ERR_ASSERTION'
- Line 1623: 2026-11-09T21:04:57.4319421Z not ok 257 - one genuine original project batch equals independently applied original artifacts and executes JS plus strict TS
  - Line 1626: 2026-11-09T21:04:57.4321476Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:47:1'
  - Line 1628: 2026-11-09T21:04:57.4323525Z   error: 'Original project batch: Original project batch: Original project batch: Original project child: registered complete bytes or mode changed: tools/translation/builtin-clone-ast-route.mjs'
  - Line 1629: 2026-11-09T21:04:57.4324749Z   code: 'ERR_TEST_FAILURE'
  - Line 1636: 2026-11-09T21:04:57.4329803Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:56:1'
  - Line 1638: 2026-11-09T21:04:57.4331899Z   error: 'Original project batch: Original project batch: Original project batch: Original project child: registered complete bytes or mode changed: tools/translation/builtin-clone-ast-route.mjs'
  - Line 1639: 2026-11-09T21:04:57.4333079Z   code: 'ERR_TEST_FAILURE'
- Line 1633: 2026-11-09T21:04:57.4327836Z not ok 258 - complete Unicode BOM CRLF comments raw strings multi-entry sources retain CST and carried refusals
  - Line 1636: 2026-11-09T21:04:57.4329803Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:56:1'
  - Line 1638: 2026-11-09T21:04:57.4331899Z   error: 'Original project batch: Original project batch: Original project batch: Original project child: registered complete bytes or mode changed: tools/translation/builtin-clone-ast-route.mjs'
  - Line 1639: 2026-11-09T21:04:57.4333079Z   code: 'ERR_TEST_FAILURE'
  - Line 1646: 2026-11-09T21:04:57.4338685Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:63:1'
  - Line 1648: 2026-11-09T21:04:57.4340879Z   error: 'Original project batch: Original project batch: Original project batch: Original project child: registered complete bytes or mode changed: tools/translation/builtin-clone-ast-route.mjs'
  - Line 1649: 2026-11-09T21:04:57.4342064Z   code: 'ERR_TEST_FAILURE'
- Line 1643: 2026-11-09T21:04:57.4336548Z not ok 259 - primitive canonical schema validation precedes task creation and clean child launch ignores parent loader environment
  - Line 1646: 2026-11-09T21:04:57.4338685Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:63:1'
  - Line 1648: 2026-11-09T21:04:57.4340879Z   error: 'Original project batch: Original project batch: Original project batch: Original project child: registered complete bytes or mode changed: tools/translation/builtin-clone-ast-route.mjs'
  - Line 1649: 2026-11-09T21:04:57.4342064Z   code: 'ERR_TEST_FAILURE'
  - Line 1656: 2026-11-09T21:04:57.4347402Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:71:1'
  - Line 1658: 2026-11-09T21:04:57.4348759Z   error: |-
- Line 1653: 2026-11-09T21:04:57.4345234Z not ok 260 - a genuinely escaped mutable parent lexer constant cannot affect fresh canonical child parser classes
  - Line 1656: 2026-11-09T21:04:57.4347402Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:71:1'
  - Line 1658: 2026-11-09T21:04:57.4348759Z   error: |-
  - Line 1663: 2026-11-09T21:04:57.4351178Z   code: 'ERR_ASSERTION'
- Line 1674: 2026-11-09T21:04:57.4359542Z not ok 261 - controlled parent Hash file writes cannot admit changed manifest compiler or installed TS bytes
  - Line 1677: 2026-11-09T21:04:57.4361542Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:78:1'
  - Line 1679: 2026-11-09T21:04:57.4362899Z   error: |-
  - Line 1680: 2026-11-09T21:04:57.4363345Z     Expected values to be strictly equal:
  - Line 1685: 2026-11-09T21:04:57.4366738Z   code: 'ERR_ASSERTION'
- Line 1702: 2026-11-09T21:04:57.4381028Z not ok 262 - driver raw-byte mutation and spoofed native digest refuse before launch with restored genuine positive
  - Line 1705: 2026-11-09T21:04:57.4383067Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:89:1'
  - Line 1707: 2026-11-09T21:04:57.4384483Z   error: |-
  - Line 1708: 2026-11-09T21:04:57.4385063Z     Expected values to be strictly equal:
  - Line 1713: 2026-11-09T21:04:57.4388246Z   code: 'ERR_ASSERTION'
- Line 1735: 2026-11-09T21:04:57.4407230Z not ok 264 - deterministic proposal tool rederives every complete frozen original pin and actual two-phase bootstrap proposal
  - Line 1738: 2026-11-09T21:04:57.4425364Z   location: '/home/runner/work/router/router/tools/translation/test/isolated-project-batch.test.mjs:131:1'
  - Line 1740: 2026-11-09T21:04:57.4427011Z   error: 'Portable original Git fixture: actual original full source changed'
  - Line 1741: 2026-11-09T21:04:57.4427702Z   code: 'ERR_TEST_FAILURE'
- Line 3455: 2026-11-09T22:00:36.2772354Z not ok 604 - native complete resolver effects and private bootstrap copies retain actual wrappers complete sources and CST inverses
  - Line 3458: 2026-11-09T22:00:36.2773410Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-resolver-candidate.test.mjs:24:1'
  - Line 3460: 2026-11-09T22:00:36.2774286Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 3461: 2026-11-09T22:00:36.2774674Z   code: 'ERR_TEST_FAILURE'
- Line 3509: 2026-11-09T22:00:36.2878781Z ##[error]The operation was canceled.

## JavaScript first (same commit) / translation (5)

- Line 1389: 2026-11-09T21:03:32.9652451Z not ok 221 - complete checked-source layer joins the unchanged lifetime birth and retains both CST phases and full inverse
  - Line 1392: 2026-11-09T21:03:32.9654305Z   location: '/home/runner/work/router/router/tools/translation/test/executable-checked-source.test.mjs:19:1'
  - Line 1394: 2026-11-09T21:03:32.9655546Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 1395: 2026-11-09T21:03:32.9656066Z   code: 'ERR_TEST_FAILURE'
- Line 1879: 2026-11-09T21:06:12.4918081Z not ok 316 - all three real repository builds and checked semantic targets stay inside the original workloads
  - Line 1882: 2026-11-09T21:06:12.4920107Z   location: '/home/runner/work/router/router/tools/translation/test/native-portable-bulk-concrete-syntax.test.mjs:181:1'
  - Line 1884: 2026-11-09T21:06:12.4942854Z   error: 'test timed out after 60000ms'
  - Line 1885: 2026-11-09T21:06:12.4943158Z   code: 'ERR_TEST_FAILURE'
- Line 2373: 2026-11-09T21:07:24.4948166Z not ok 414 - owned methods link their actual parser scope when enclosing and full-bang evidence differ
  - Line 2376: 2026-11-09T21:07:24.4970109Z   location: '/home/runner/work/router/router/tools/translation/test/project-method-owner-scope.test.mjs:21:1'
  - Line 2378: 2026-11-09T21:07:24.4970975Z   error: |-
  - Line 2379: 2026-11-09T21:07:24.4971285Z     Expected values to be strictly equal:
  - Line 2383: 2026-11-09T21:07:24.4972396Z   code: 'ERR_ASSERTION'
- Line 2399: 2026-11-09T21:07:24.4990294Z not ok 415 - closed enclosing output never substitutes for unresolved method bang-macro evidence
  - Line 2402: 2026-11-09T21:07:24.4991444Z   location: '/home/runner/work/router/router/tools/translation/test/project-method-owner-scope.test.mjs:38:1'
  - Line 2404: 2026-11-09T21:07:24.4992200Z   error: |-
  - Line 2405: 2026-11-09T21:07:24.4992453Z     Expected values to be strictly equal:
  - Line 2409: 2026-11-09T21:07:24.4993299Z   code: 'ERR_ASSERTION'
- Line 2429: 2026-11-09T21:07:24.5001694Z not ok 417 - the source recipe selects only the original private import and method linker with a complete inverse
  - Line 2432: 2026-11-09T21:07:24.5002950Z   location: '/home/runner/work/router/router/tools/translation/test/project-method-owner-scope.test.mjs:60:1'
  - Line 2434: 2026-11-09T21:07:24.5004135Z   error: 'Project facade retention source: complete physical project is neither original nor an exact derived output'
  - Line 2435: 2026-11-09T21:07:24.5004657Z   code: 'ERR_TEST_FAILURE'
- Line 2449: 2026-11-09T21:09:13.5788476Z not ok 418 - twelve complete current native copies share the selected byte issuers and preserve full source CST inverses and Hash calls
  - Line 2452: 2026-11-09T21:09:13.5790017Z   location: '/home/runner/work/router/router/tools/translation/test/proof-byte-core-stream-candidate.test.mjs:31:1'
  - Line 2454: 2026-11-09T21:09:13.5791183Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 2455: 2026-11-09T21:09:13.5794209Z   code: 'ERR_TEST_FAILURE'
- Line 2475: 2026-11-09T21:09:13.6128480Z not ok 420 - foreign copied and changed-source contexts cannot cross the coherent private issuer or original callback fallback
  - Line 2478: 2026-11-09T21:09:13.6181857Z   location: '/home/runner/work/router/router/tools/translation/test/proof-byte-core-stream-candidate.test.mjs:45:1'
  - Line 2480: 2026-11-09T21:09:13.6183082Z   error: |-
  - Line 2481: 2026-11-09T21:09:13.6183531Z     Expected values to be strictly deep-equal:
- Line 18454: 2026-11-09T21:09:13.8541066Z not ok 423 - independent full three-stage JSON and Hash observations retain every actual callback argument result and refusal
  - Line 18457: 2026-11-09T21:09:13.8541650Z   location: '/home/runner/work/router/router/tools/translation/test/proof-byte-core-stream-candidate.test.mjs:60:1'
  - Line 18459: 2026-11-09T21:09:13.8541852Z   error: |-
  - Line 18460: 2026-11-09T21:09:13.8541981Z     Expected values to be strictly equal:
  - Line 18463: 2026-11-09T21:09:13.8542533Z     + Error: spawnSync /opt/hostedtoolcache/node/20.20.2/x64/bin/node ETIMEDOUT
- Line 18547: 2026-11-09T21:09:13.8573887Z not ok 431 - complete base source equations retain actual native declarations imports phases and inverses
  - Line 18550: 2026-11-09T21:09:13.8574461Z   location: '/home/runner/work/router/router/tools/translation/test/router-core-ascii-base-assets.test.mjs:18:1'
  - Line 18552: 2026-11-09T21:09:13.8574829Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 18553: 2026-11-09T21:09:13.8574926Z   code: 'ERR_TEST_FAILURE'
- Line 18667: 2026-11-09T21:09:13.8599428Z not ok 452 - current runtime-import consumers retain the complete historical producers and fresh reversible source equations
  - Line 18670: 2026-11-09T21:09:13.8599979Z   location: '/home/runner/work/router/router/tools/translation/test/runtime-import-current.test.mjs:7:1'
  - Line 18672: 2026-11-09T21:09:13.8600291Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 18673: 2026-11-09T21:09:13.8600369Z   code: 'ERR_TEST_FAILURE'
- Line 19382: 2026-11-09T21:13:28.1730795Z not ok 592 - the complete three resolver rows and nested whole eight-producer result match every original field
  - Line 19385: 2026-11-09T21:13:28.1736935Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-source-cst-batch.test.mjs:31:1'
  - Line 19387: 2026-11-09T21:13:28.1737893Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 19388: 2026-11-09T21:13:28.1738155Z   code: 'ERR_TEST_FAILURE'
- Line 19427: 2026-11-09T21:13:28.5419845Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-translation (2)

- Line 543: 2026-11-09T21:04:44.9572188Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / translation (1)

- Line 736: 2026-11-09T21:02:53.8001604Z not ok 89 - all original current pins retain exact complete inverses through declared source evolution
  - Line 739: 2026-11-09T21:02:53.8023472Z   location: '/home/runner/work/router/router/tools/translation/test/compiler-alias-source-evolution.test.mjs:21:1'
  - Line 741: 2026-11-09T21:02:53.8026005Z   error: 'Compiler alias source evolution: complete original source pin differs'
  - Line 742: 2026-11-09T21:02:53.8026725Z   code: 'ERR_TEST_FAILURE'
- Line 757: 2026-11-09T21:02:53.8041363Z not ok 90 - every actual history reader preserves its independently pinned complete historical bytes
  - Line 760: 2026-11-09T21:02:53.8043482Z   location: '/home/runner/work/router/router/tools/translation/test/compiler-alias-source-evolution.test.mjs:32:1'
  - Line 762: 2026-11-09T21:02:53.8045216Z   error: 'Compiler alias source evolution: complete original source pin differs'
  - Line 763: 2026-11-09T21:02:53.8045901Z   code: 'ERR_TEST_FAILURE'
- Line 783: 2026-11-09T21:02:53.8063362Z not ok 92 - the complete fixture producer retains all six original current and historical pins
  - Line 786: 2026-11-09T21:02:53.8065463Z   location: '/home/runner/work/router/router/tools/translation/test/compiler-alias-source-evolution.test.mjs:46:1'
  - Line 788: 2026-11-09T21:02:53.8067226Z   error: 'Compiler alias source evolution: complete original source pin differs'
  - Line 789: 2026-11-09T21:02:53.8067903Z   code: 'ERR_TEST_FAILURE'
- Line 1879: 2026-11-09T21:46:17.7532371Z not ok 308 - the complete original clients parent context executes qwen_model_is_managed without a projected owner
  - Line 1882: 2026-11-09T21:46:17.7534102Z   location: '/home/runner/work/router/router/tools/translation/test/option-borrowed-str-equality.test.mjs:68:1'
  - Line 1884: 2026-11-09T21:46:17.7535236Z   error: 'test timed out after 60000ms'
  - Line 1885: 2026-11-09T21:46:17.7535780Z   code: 'ERR_TEST_FAILURE'
- Line 2349: 2026-11-09T21:46:21.1821490Z not ok 401 - complete project retention equation preserves both native callable bodies and every serialized CST inverse
  - Line 2352: 2026-11-09T21:46:21.1822748Z   location: '/home/runner/work/router/router/tools/translation/test/project-facade-retention.test.mjs:26:1'
  - Line 2354: 2026-11-09T21:46:21.1823872Z   error: 'Project facade retention source: complete physical project is neither original nor an exact derived output'
  - Line 2355: 2026-11-09T21:46:21.1824393Z   code: 'ERR_TEST_FAILURE'
- Line 2596: 2026-11-09T21:46:21.1940985Z not ok 445 - native source producers retain complete historical inputs actual current outputs and every CST inverse
  - Line 2599: 2026-11-09T21:46:21.1942206Z   location: '/home/runner/work/router/router/tools/translation/test/router-core-matches.test.mjs:33:29'
  - Line 2601: 2026-11-09T21:46:21.1943160Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 2602: 2026-11-09T21:46:21.1943549Z   code: 'ERR_TEST_FAILURE'
- Line 3258: 2026-11-09T21:46:24.8581025Z not ok 573 - actual finite proposal routes the physical original creator to the fresh additive operation and preserves the complete original twelve
  - Line 3261: 2026-11-09T21:46:24.8582391Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-original-trial.test.mjs:23:1'
  - Line 3263: 2026-11-09T21:46:24.8583483Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 3264: 2026-11-09T21:46:24.8583976Z   code: 'ERR_TEST_FAILURE'
- Line 3299: 2026-11-09T21:46:24.8615213Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / translation-freshness

- Line 338: 2026-11-09T21:44:41.0810637Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-translation (4)

- Line 485: 2026-11-09T21:02:21.9962771Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-translation (1)

- Line 319: 2026-11-09T21:15:32.6237281Z ##[error]The operation was canceled.

## JavaScript first (same commit) / translation (7)

- Line 2324: 2026-11-09T21:16:21.0927277Z not ok 408 - negative budget source proposal copies actual whole census, matches actual composer bounds and preserves complete source inverses
  - Line 2327: 2026-11-09T21:16:21.0927852Z   location: '/home/runner/work/router/router/tools/translation/test/private-negative-budget-proof-json.test.mjs:28:1'
  - Line 2329: 2026-11-09T21:16:21.0928212Z   error: 'Compiler alias source evolution: complete original source pin differs'
  - Line 2330: 2026-11-09T21:16:21.0928304Z   code: 'ERR_TEST_FAILURE'
- Line 2370: 2026-11-09T21:16:21.0937993Z not ok 414 - the actual additive eligibility export restores every byte of the complete historical native helper
  - Line 2373: 2026-11-09T21:16:21.0938587Z   location: '/home/runner/work/router/router/tools/translation/test/private-negative-budget-proof-json.test.mjs:95:1'
  - Line 2375: 2026-11-09T21:16:21.0938911Z   error: 'Compiler alias source evolution: complete original source pin differs'
  - Line 2376: 2026-11-09T21:16:21.0938967Z   code: 'ERR_TEST_FAILURE'
- Line 2696: 2026-11-09T21:16:23.7040329Z not ok 476 - native source producer derives the actual owned wrapper and composes complete source inverses
  - Line 2699: 2026-11-09T21:16:23.7041858Z   location: '/home/runner/work/router/router/tools/translation/test/router-core-vectors.test.mjs:46:29'
  - Line 2701: 2026-11-09T21:16:23.7043127Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 2702: 2026-11-09T21:16:23.7043461Z   code: 'ERR_TEST_FAILURE'
- Line 3177: 2026-11-09T21:18:27.9191107Z not ok 569 - complete Core candidate source copies retain native bindings both CST phases original API bodies and whole inverses
  - Line 3180: 2026-11-09T21:18:27.9192641Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-core-producer-candidate.test.mjs:24:1'
  - Line 3182: 2026-11-09T21:18:27.9193948Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 3183: 2026-11-09T21:18:27.9194489Z   code: 'ERR_TEST_FAILURE'
- Line 3198: 2026-11-09T21:18:27.9374980Z not ok 570 - genuine enclosing private creator resolver and complete detached inspection equal the original full source pipeline
  - Line 3201: 2026-11-09T21:18:27.9384617Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-core-producer-candidate.test.mjs:41:1'
  - Line 3203: 2026-11-09T21:18:27.9385690Z   error: |-
  - Line 3204: 2026-11-09T21:18:27.9385958Z     Expected values to be strictly deep-equal:
- Line 13840: 2026-11-09T21:18:28.0952753Z not ok 574 - independent cold warm and same-context complete Core creation inspection retain every original JSON and Hash callback
  - Line 13843: 2026-11-09T21:18:28.0953464Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-core-producer-candidate.test.mjs:69:1'
  - Line 13845: 2026-11-09T21:18:28.0953662Z   error: |-
  - Line 13846: 2026-11-09T21:18:28.0953806Z     Expected values to be strictly deep-equal:
- Line 13976: 2026-11-09T21:18:28.4141515Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-translation (6)

- Line 349: 2026-11-09T20:59:58.1621315Z not ok 12 - complete native proposal retains original public functions and both full CST source phases
  - Line 352: 2026-11-09T20:59:58.1623613Z   location: '/home/runner/work/router/router/tools/translation/js-to-rust/test/native-regeneration-batch.test.mjs:22:1'
  - Line 354: 2026-11-09T20:59:58.1625488Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 355: 2026-11-09T20:59:58.1626217Z   code: 'ERR_TEST_FAILURE'
- Line 432: 2026-11-09T21:13:16.5192473Z ##[error]The operation was canceled.

## JavaScript first (same commit) / reverse-translation (3)

- Line 434: 2026-11-09T21:00:58.7159332Z not ok 32 - complete source-native inverse retains all original runtime loops full parser diagnostics and untouched original three-build test
  - Line 437: 2026-11-09T21:00:58.7160950Z   location: '/home/runner/work/router/router/tools/translation/js-to-rust/test/runtime-import-parents.test.mjs:17:24'
  - Line 439: 2026-11-09T21:00:58.7161887Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 440: 2026-11-09T21:00:58.7162530Z   code: 'ERR_TEST_FAILURE'
- Line 469: 2026-11-09T21:00:58.7178907Z not ok 36 - late native mutation tracing/performance uncertainty and exceptions irreversibly retire ancestor DATA while keeping original checks
  - Line 472: 2026-11-09T21:00:58.7180632Z   location: '/home/runner/work/router/router/tools/translation/js-to-rust/test/runtime-import-parents.test.mjs:17:24'
  - Line 474: 2026-11-09T21:00:58.7181499Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 475: 2026-11-09T21:00:58.7181837Z   code: 'ERR_TEST_FAILURE'
- Line 524: 2026-11-09T21:00:58.7725341Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / translation (6)

- Line 1165: 2026-11-09T21:06:13.0008549Z not ok 175 - current negative-budget history reproduces the complete physical fixture and both source phases
  - Line 1168: 2026-11-09T21:06:13.0012219Z   location: '/home/runner/work/router/router/tools/translation/test/current-negative-budget-history.test.mjs:27:1'
  - Line 1170: 2026-11-09T21:06:13.0014162Z   error: |-
  - Line 1171: 2026-11-09T21:06:13.0014685Z     Expected values to be strictly equal:
  - Line 1176: 2026-11-09T21:06:13.0017643Z   code: 'ERR_ASSERTION'
- Line 1857: 2026-11-09T21:09:08.1064954Z not ok 309 - complete actual provider and affinity parents retain checked methods refusals and strict behavior
  - Line 1860: 2026-11-09T21:09:08.1093085Z   location: '/home/runner/work/router/router/tools/translation/test/internal-metadata-digest-adoption.test.mjs:33:24'
  - Line 1862: 2026-11-09T21:09:08.1094562Z   error: 'test timed out after 60000ms'
  - Line 1863: 2026-11-09T21:09:08.1094937Z   code: 'ERR_TEST_FAILURE'
- Line 2266: 2026-11-09T21:12:29.8397452Z not ok 390 - all three real repository builds and actual JS plus strictTS consume checked semantic meta
  - Line 2269: 2026-11-09T21:12:29.8399473Z   location: '/home/runner/work/router/router/tools/translation/test/native-portable-corpus-concrete-syntax.test.mjs:149:1'
  - Line 2271: 2026-11-09T21:12:29.8401033Z   error: 'test timed out after 60000ms'
  - Line 2272: 2026-11-09T21:12:29.8401551Z   code: 'ERR_TEST_FAILURE'
- Line 2335: 2026-11-09T21:38:26.5482049Z not ok 403 - complete original ActivityPub parent executes require_string and dependent validate_activity through genuine project scopes
  - Line 2338: 2026-11-09T21:38:26.5484665Z   location: '/home/runner/work/router/router/tools/translation/test/option-ok-or.test.mjs:60:1'
  - Line 2340: 2026-11-09T21:38:26.5485975Z   error: 'test timed out after 60000ms'
  - Line 2341: 2026-11-09T21:38:26.5486428Z   code: 'ERR_TEST_FAILURE'
- Line 2485: 2026-11-09T21:38:29.1277823Z not ok 431 - genuine compiler source commit tree modes complete blobs and installed TS stay exact
  - Line 2488: 2026-11-09T21:38:29.1279955Z   location: '/home/runner/work/router/router/tools/translation/test/portable-git-fixtures.test.mjs:28:1'
  - Line 2490: 2026-11-09T21:38:29.1281186Z   error: 'Portable original Git fixture: actual original full source changed'
  - Line 2491: 2026-11-09T21:38:29.1281715Z   code: 'ERR_TEST_FAILURE'
- Line 2505: 2026-11-09T21:38:29.1291296Z not ok 432 - actual metadata producer is deterministic and full proposal roundtrip preserves installed packet
  - Line 2508: 2026-11-09T21:38:29.1293156Z   location: '/home/runner/work/router/router/tools/translation/test/portable-git-fixtures.test.mjs:34:1'
  - Line 2510: 2026-11-09T21:38:29.1294399Z   error: 'Portable original Git fixture: actual original full source changed'
  - Line 2511: 2026-11-09T21:38:29.1294933Z   code: 'ERR_TEST_FAILURE'
- Line 2535: 2026-11-09T21:38:29.1310629Z not ok 435 - original isolated producer reconstructs exact registry bootstrap six substitutions and full undo
  - Line 2538: 2026-11-09T21:38:29.1312158Z   location: '/home/runner/work/router/router/tools/translation/test/portable-git-fixtures.test.mjs:50:1'
  - Line 2540: 2026-11-09T21:38:29.1313878Z   error: 'Portable original Git fixture: actual original full source changed'
  - Line 2541: 2026-11-09T21:38:29.1314319Z   code: 'ERR_TEST_FAILURE'
- Line 2555: 2026-11-09T21:38:29.1323425Z not ok 436 - output aliases existing destinations and changed full TS input refuse before accepted writes
  - Line 2558: 2026-11-09T21:38:29.1324984Z   location: '/home/runner/work/router/router/tools/translation/test/portable-git-fixtures.test.mjs:56:1'
  - Line 2560: 2026-11-09T21:38:29.1326199Z   error: 'Portable original Git fixture: actual original full source changed'
  - Line 2561: 2026-11-09T21:38:29.1326697Z   code: 'ERR_TEST_FAILURE'
- Line 2575: 2026-11-09T21:38:29.1336147Z not ok 437 - original callable still runs through genuine isolated compiler and strict target oracle
  - Line 2578: 2026-11-09T21:38:29.1338056Z   location: '/home/runner/work/router/router/tools/translation/test/portable-git-fixtures.test.mjs:61:1'
  - Line 2580: 2026-11-09T21:38:29.1339836Z   error: 'Original project batch: Original project batch: Original project batch: Original project child: registered complete bytes or mode changed: tools/translation/builtin-clone-ast-route.mjs'
  - Line 2581: 2026-11-09T21:38:29.1340808Z   code: 'ERR_TEST_FAILURE'
  - Line 2588: 2026-11-09T21:38:29.1345601Z   location: '/home/runner/work/router/router/tools/translation/test/primitive-identity-boundary.test.mjs:15:1'
  - Line 2590: 2026-11-09T21:38:29.1346862Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 2591: 2026-11-09T21:38:29.1347371Z   code: 'ERR_TEST_FAILURE'
- Line 2585: 2026-11-09T21:38:29.1343929Z not ok 438 - source boundary complete HostEmitter equation follows actual native methods with complete parent and inverse
  - Line 2588: 2026-11-09T21:38:29.1345601Z   location: '/home/runner/work/router/router/tools/translation/test/primitive-identity-boundary.test.mjs:15:1'
  - Line 2590: 2026-11-09T21:38:29.1346862Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 2591: 2026-11-09T21:38:29.1347371Z   code: 'ERR_TEST_FAILURE'
- Line 2775: 2026-11-09T21:38:29.1460361Z not ok 473 - complete receiving static compiler source graph is retained without issuing an executable program
  - Line 2778: 2026-11-09T21:38:29.1461894Z   location: '/home/runner/work/router/router/tools/translation/test/private-rust-compiler-execution.test.mjs:59:1'
  - Line 2780: 2026-11-09T21:38:29.1463310Z   error: 'Private Rust compiler source tool: complete source byte bound'
  - Line 2781: 2026-11-09T21:38:29.1463786Z   code: 'ERR_TEST_FAILURE'
- Line 3106: 2026-11-09T21:38:29.1691614Z not ok 518 - complete original Router callers retain their full parents and independent later refusal evidence
  - Line 3109: 2026-11-09T21:38:29.1693344Z   location: '/home/runner/work/router/router/tools/translation/test/router-core-json-parse.test.mjs:30:24'
  - Line 3111: 2026-11-09T21:38:29.1694464Z   error: 'test timed out after 60000ms'
  - Line 3112: 2026-11-09T21:38:29.1694815Z   code: 'ERR_TEST_FAILURE'
- Line 3155: 2026-11-09T21:56:20.3711707Z not ok 527 - all nine target bodies require fresh complete production parents Cargo and owned-definition checking
  - Line 3158: 2026-11-09T21:56:20.3713342Z   location: '/home/runner/work/router/router/tools/translation/test/router-core-unit-matches.test.mjs:109:1'
  - Line 3160: 2026-11-09T21:56:20.3714070Z   error: 'test timed out after 60000ms'
  - Line 3161: 2026-11-09T21:56:20.3714303Z   code: 'ERR_TEST_FAILURE'
- Line 3163: 2026-11-09T22:02:01.6909430Z ##[error]The operation was canceled.

## JavaScript first (same commit) / reverse-bun (3)

- Line 294: 2026-11-09T21:07:44.7613782Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / translation (4)

- Line 1275: 2026-11-09T21:11:47.0218098Z not ok 198 - both complete original derive parents retain the unchanged native and typed behavior
  - Line 1278: 2026-11-09T21:11:47.0223445Z   location: '/home/runner/work/router/router/tools/translation/test/grouped-original-method-producers.test.mjs:164:1'
  - Line 1280: 2026-11-09T21:11:47.0225233Z   error: 'test timed out after 60000ms'
  - Line 1281: 2026-11-09T21:11:47.0225727Z   code: 'ERR_TEST_FAILURE'
- Line 1973: 2026-11-09T21:16:23.6658546Z not ok 333 - labeled original-root declaration projection verifies original recovery dependency behavior
  - Line 1976: 2026-11-09T21:16:23.6660918Z   location: '/home/runner/work/router/router/tools/translation/test/original-option-regression-owners.test.mjs:52:1'
  - Line 1978: 2026-11-09T21:16:23.6662153Z   error: 'test timed out after 90000ms'
  - Line 1979: 2026-11-09T21:16:23.6662516Z   code: 'ERR_TEST_FAILURE'
- Line 2487: 2026-11-09T21:16:24.0027626Z not ok 435 - selected ASCII producer retains all complete original native nodes current layers and full CST inverses
  - Line 2490: 2026-11-09T21:16:24.0029236Z   location: '/home/runner/work/router/router/tools/translation/test/router-core-ascii-assets.test.mjs:21:1'
  - Line 2492: 2026-11-09T21:16:24.0030830Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 2493: 2026-11-09T21:16:24.0031344Z   code: 'ERR_TEST_FAILURE'
- Line 3322: 2026-11-09T21:18:15.2676482Z not ok 599 - actual three physical overlays route complete creator and resolver entries through the correct private physical issuer
  - Line 3325: 2026-11-09T21:18:15.2677537Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-resolver-original-trial.test.mjs:19:1'
  - Line 3327: 2026-11-09T21:18:15.2678413Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 3328: 2026-11-09T21:18:15.2678797Z   code: 'ERR_TEST_FAILURE'
- Line 3363: 2026-11-09T21:18:15.7466131Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / translation (8)

- Line 296: 2026-11-09T21:00:05.4929033Z not ok 1 - all37 stored gains retain complete original source, declaration and generation context
  - Line 299: 2026-11-09T21:00:05.4949147Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:116:1'
  - Line 301: 2026-11-09T21:00:05.4956358Z   error: |-
  - Line 307: 2026-11-09T21:00:05.4983780Z   code: 'ERR_ASSERTION'
- Line 325: 2026-11-09T21:00:05.5006836Z not ok 2 - all26 constants including the complete ten-area source table have independent expectations
  - Line 328: 2026-11-09T21:00:05.5009205Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:122:1'
  - Line 330: 2026-11-09T21:00:05.5010731Z   error: |-
  - Line 336: 2026-11-09T21:00:05.5015948Z   code: 'ERR_ASSERTION'
- Line 354: 2026-11-09T21:00:05.5033427Z not ok 3 - complete original ClientKind and UsageProvider unit enums cover every package/parse arm
  - Line 357: 2026-11-09T21:00:05.5035553Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:128:1'
  - Line 359: 2026-11-09T21:00:05.5036856Z   error: |-
  - Line 365: 2026-11-09T21:00:05.5040501Z   code: 'ERR_ASSERTION'
- Line 383: 2026-11-09T21:00:05.5055424Z not ok 4 - catalog context variants require exact nonempty Anthropic-owned complete model rows
  - Line 386: 2026-11-09T21:00:05.5057886Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:138:1'
  - Line 388: 2026-11-09T21:00:05.5059571Z   error: |-
  - Line 394: 2026-11-09T21:00:05.5061732Z   code: 'ERR_ASSERTION'
- Line 412: 2026-11-09T21:00:05.5070424Z not ok 5 - status precedence covers every boolean branch and u64 boundary without floating coercion
  - Line 415: 2026-11-09T21:00:05.5071610Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:146:1'
  - Line 417: 2026-11-09T21:00:05.5072368Z   error: |-
  - Line 423: 2026-11-09T21:00:05.5074791Z   code: 'ERR_ASSERTION'
- Line 441: 2026-11-09T21:00:05.5087465Z not ok 6 - results counts Rust LF/CRLF lines and Rust whitespace while retaining BOM and scalar guards
  - Line 444: 2026-11-09T21:00:05.5089741Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:155:1'
  - Line 446: 2026-11-09T21:00:05.5091170Z   error: |-
  - Line 452: 2026-11-09T21:00:05.5094856Z   code: 'ERR_ASSERTION'
- Line 470: 2026-11-09T21:00:05.5104496Z not ok 7 - allfour new record constructors and both source helper constructors retain exact fields/order
  - Line 473: 2026-11-09T21:00:05.5106386Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:161:1'
  - Line 475: 2026-11-09T21:00:05.5107183Z   error: |-
  - Line 481: 2026-11-09T21:00:05.5109344Z   code: 'ERR_ASSERTION'
- Line 499: 2026-11-09T21:00:05.5119289Z not ok 8 - constructor immutable ABI isolates owned vector aliases and never retains mutable static-slice aliases
  - Line 502: 2026-11-09T21:00:05.5120518Z   location: '/home/runner/work/router/router/tools/translation/test/actual-gain-families.test.mjs:173:1'
  - Line 504: 2026-11-09T21:00:05.5121286Z   error: |-
  - Line 510: 2026-11-09T21:00:05.5123732Z   code: 'ERR_ASSERTION'
- Line 576: 2026-11-09T21:01:13.6775192Z not ok 18 - every full birth source plan field equals the current plan except its explicitly additional fresh provider source inputs
  - Line 579: 2026-11-09T21:01:13.6778213Z   location: '/home/runner/work/router/router/tools/translation/test/batched-proof-byte-source-candidate.test.mjs:16:1'
  - Line 581: 2026-11-09T21:01:13.6784672Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 582: 2026-11-09T21:01:13.6786643Z   code: 'ERR_TEST_FAILURE'
- Line 597: 2026-11-09T21:01:13.6808011Z not ok 19 - the current support census authenticates each additional actual provider source while retaining the complete original twelve workload
  - Line 600: 2026-11-09T21:01:13.6810490Z   location: '/home/runner/work/router/router/tools/translation/test/batched-proof-byte-source-candidate.test.mjs:21:1'
  - Line 602: 2026-11-09T21:01:13.6812410Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 603: 2026-11-09T21:01:13.6813644Z   code: 'ERR_TEST_FAILURE'
- Line 618: 2026-11-09T21:01:13.6833593Z not ok 20 - fresh repeated complete current plans retain every source fingerprint stage trace physical overlay and original refusal marker
  - Line 621: 2026-11-09T21:01:13.6836316Z   location: '/home/runner/work/router/router/tools/translation/test/batched-proof-byte-source-candidate.test.mjs:25:1'
  - Line 623: 2026-11-09T21:01:13.6839052Z   error: 'Whole-owner resolver source: fresh complete original whole-owner private issuer closure required'
  - Line 624: 2026-11-09T21:01:13.6840035Z   code: 'ERR_TEST_FAILURE'
- Line 1315: 2026-11-09T21:07:59.5202345Z not ok 152 - all three real repository builds and actual JS plus strictTS consume checked semantic meta
  - Line 1318: 2026-11-09T21:07:59.5205822Z   location: '/home/runner/work/router/router/tools/translation/test/corpus-native-parse-provenance.test.mjs:164:1'
  - Line 1320: 2026-11-09T21:07:59.5207773Z   error: 'test timed out after 60000ms'
  - Line 1321: 2026-11-09T21:07:59.5208442Z   code: 'ERR_TEST_FAILURE'
- Line 3130: 2026-11-09T21:15:35.9440471Z not ok 514 - the complete historical compiler readers equal their actual current source producer output
  - Line 3133: 2026-11-09T21:15:35.9443926Z   location: '/home/runner/work/router/router/tools/translation/test/source-producer-freshness.test.mjs:43:1'
  - Line 3135: 2026-11-09T21:15:35.9446196Z   error: 'Compiler alias source evolution: complete original source pin differs'
  - Line 3136: 2026-11-09T21:15:35.9447140Z   code: 'ERR_TEST_FAILURE'
- Line 3481: 2026-11-09T21:21:10.9418086Z not ok 581 - complete actual native copies retain eight output equations source spans both CST phases license and whole inverses
  - Line 3484: 2026-11-09T21:21:10.9420794Z   location: '/home/runner/work/router/router/tools/translation/test/whole-owner-derive-candidate.test.mjs:22:1'
  - Line 3486: 2026-11-09T21:21:10.9422550Z   error: |-
  - Line 3487: 2026-11-09T21:21:10.9423361Z     Expected values to be strictly equal:
  - Line 3497: 2026-11-09T21:21:10.9439794Z   code: 'ERR_ASSERTION'
- Line 4357: 2026-11-09T21:21:11.6018103Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-bun (2)

- Line 287: 2026-11-09T21:05:36.8713748Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / reverse-bun (1)

- Line 288: 2026-11-09T21:20:03.8750275Z ##[error]The operation was canceled.

## JavaScript first (same commit) / reverse-bun (6)

- Line 287: 2026-11-09T21:19:19.5414611Z ##[error]The operation was canceled.

## JavaScript first (same commit) / reverse-translation (8)

- Line 317: 2026-11-09T21:04:11.5928303Z not ok 7 - reverse ASCII complete current source equations retain native copies CST phases and full inverses
  - Line 320: 2026-11-09T21:04:11.5935293Z   location: '/home/runner/work/router/router/tools/translation/js-to-rust/test/owned-core-ascii.test.mjs:25:24'
  - Line 322: 2026-11-09T21:04:11.5937067Z   error: 'Physical native source is neither full original nor exact proposal'
  - Line 323: 2026-11-09T21:04:11.5937746Z   code: 'ERR_TEST_FAILURE'
- Line 447: 2026-11-09T21:08:06.6329845Z ##[error]Process completed with exit code 1.

## JavaScript first (same commit) / JavaScript fully green

- Line 146: 2026-11-09T22:20:32.1186458Z ##[error]Process completed with exit code 1.

