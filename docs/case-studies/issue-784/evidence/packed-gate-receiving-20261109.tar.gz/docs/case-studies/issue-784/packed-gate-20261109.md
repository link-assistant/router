# Complete local gate attempt after Clone/CST and native repairs

[PR #785](https://github.com/link-assistant/router/pull/785) remains a draft.
At clean source `baa608114df8fbad9ed085b18919f043eed8be10`, the complete local
JavaScript gate was attempted without stage selection. It is **not green**.
No local Rust tool ran. This receiving observation does not establish parity.

## Attempts and exact limits

The first attempt stopped during fingerprinting after 52.414 s at the unchanged
2,866,933,760 B cgroup guard (2,869,686,272 sampled B). Its completed prefix was
42,780 of 50,443 inputs. Every verification stage remained unrun. A subsequent
closed-file page-advice pass preserved file identities and bytes; it deleted no
files and changed neither test clocks nor resource limits.

The second invocation was rejected by the observation wrapper because its
command shape did not match the existing cache-advice policy. It exited 2
before launching the gate or any checks. This is a harness rejection, not a
test failure or a verification result.

The corrected third attempt ran the standard complete gate with Node 20.20.2,
an explicitly bounded 128 MiB coordinator, inherited 1,280 MiB child heaps,
Bun 1.4.4 and lockfile TypeScript 5.9.3. CI uses Bun 1.4.3. The existing adviser
followed actual completed fingerprint prefixes once; it advised only eligible
closed, single-link, task-owned regular files after identity and active-use
checks. Original case clocks, source inputs and the cgroup guard stayed intact.

## Completed and unfinished verification

| Verification | Third-attempt result |
| --- | --- |
| Complete input fingerprint | Complete, 50,443 inputs |
| All ten lint commands | Pass |
| Native Node runtime suite | 259/259 pass, 45.316 s |
| Native Bun runtime suite | 259/259 pass, 84.309 s |
| Complete deadline-auditor controls | 10/10 and original deadlines pass; `complete-IB8TgE` |
| JavaScript package type checks | Both pass |
| Native TypeScript freshness | Pass, 11,586,409 B; zero changed/unexpected outputs, 35.982 s |
| Strict native TypeScript compilation | Pass, all 167 files, TypeScript 5.9.3, 12.001 s |
| Complete native TypeScript receiving file | Interrupted by the cgroup guard; incomplete, not qualified |
| Remaining TypeScript commands | Unrun |
| Acceptance, strict parity, forward and reverse stages | Unrun |
| Final input fingerprint and green stamp | Not reached |

The third attempt stopped after 780.952 s, at 2,877,132,800 sampled cgroup B.
The observer reaped its complete owned process set. The interrupted receiving
runner retained only four case reports and could not finish `case-deadlines.json`;
the missing-report error is a consequence of interruption. Buffered TAP cannot
identify the active case or qualify the unreported cases. All selected source
and command observations and both complete terminal receipts are retained.

A broad Git diff ran concurrently near the interruption, contrary to the
intended workload separation. This added avoidable load. The cgroup sample
does not isolate its contribution or establish which allocation caused the
threshold crossing. This attempt is retained as failed/incomplete and is not a
controlled performance comparison. Further Git review runs separately.

The separately completed unchanged native TypeScript file still fails its
original four-build deadline at 75.809 s against 60 s, despite all nine assertions
passing. The unchanged ClientKind deadline also remains failed at 279.719 s.
See [native receiving evidence](native-regeneration-receiving-20261109.md) and
[Clone/CST receiving evidence](clone-cst-receiving-20261109.md). No bound or
deadline was raised, no case was filtered and no failed stage became optional.

## Evidence

The complete attempts, wrapper rejection, closed-file advice and nested Node
receipts are retained in the adjacent `packed-gate-receiving-20261109` archive
and member-hash receipt. Every member is read back before retiring inactive raw
task copies. Source snapshots describe this evidence draft and its predecessor;
they do not establish historical transitive custody for unrelated observations.
