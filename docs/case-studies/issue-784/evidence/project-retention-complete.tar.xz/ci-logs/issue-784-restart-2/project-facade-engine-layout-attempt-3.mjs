// Finite Bun experiment: canonical private issuers, complete project source.
// This is a candidate source observation, not a source producer or parity check.
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {plugin} from 'bun';
const project=new URL('../../tools/translation/project.mjs',import.meta.url);
let source=readFileSync(project,'utf8');
function replace(before,after){assert.equal(source.split(before).length,2);source=source.replace(before,()=>after);}
replace('function createProjectLowerer(target,entry,name){return function','const createProjectLowerer=(()=>function(target,entry,name){return function');
replace('  };}\nfunction createProjectCheckedSource','  };})();\nfunction createProjectCheckedSource');
replace('function createProjectCheckedSource(checked,graph,entry){const checkedSource=','const createProjectCheckedSource=(()=>function(checked,graph,entry){const facade={checkedSource:');
replace('  };return checkedSource;}','  }};return facade.checkedSource;})();');
plugin({name:'complete-project-engine-layout',setup(builder){builder.onLoad({filter:/\/tools\/translation\/project\.mjs$/},args=>{assert.equal(args.path,project.pathname);return {contents:source,loader:'js'};});}});
const {translateProject}=await import(project.href);
const result=translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=> 'pub fn root(x:u8)->u8{x+1}'});
const facade=result.executableDeclarations.find(row=>row.name==='root');
const observe=fn=>({name:fn.name,length:fn.length,prototype:Object.hasOwn(fn,'prototype'),source:Function.prototype.toString.call(fn)});
console.log(JSON.stringify({candidateSha256:createHash('sha256').update(source).digest('hex'),lower:observe(facade.lower),checkedSource:observe(facade.checkedSource)}));
