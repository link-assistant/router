import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {serializeProgram} from '../semantic-meta.mjs';
import {translateProject} from '../project.mjs';
import {prepareProjectFacadeRetention,composeProjectFacadeRetention} from '../prepare-project-facade-retention.mjs';
import {transportConcreteSyntaxMeta} from '../concrete-syntax-meta.mjs';
const limits={timeout:60000};
const input='pub fn root(x:u8)->u8{child::add(x)} pub mod child {pub fn add(x:u8)->u8{x+1}} pub mod other {pub fn same(x:u8)->u8{x}}';
function project(){return translateProject({entry:'src/lib.rs',paths:['src/lib.rs'],readSource:()=>input});}

test('complete project retention equation preserves both native callable bodies and every serialized CST inverse',limits,()=>{
 const plan=prepareProjectFacadeRetention(),row=plan.files[0];
 assert.equal(plan.typescriptVersion,'5.9.3');assert.equal(plan.sourceAuthority,false);assert.equal(plan.semanticAuthority,false);
 assert.equal(row.current,row.after);assert.equal(readFileSync(new URL('../project.mjs',import.meta.url),'utf8'),row.after);
 assert.equal(row.inverse,row.before);assert.equal(row.selection.completeNativeInverse,row.before);
 assert.deepEqual(row.nativeBindings.unboundIdentifiers,[]);assert.ok(row.nativeCopies.every(copy=>copy.completeNativeAstCopy));
 assert.deepEqual(row.stages.map(stage=>stage.phase),['language','repository']);
 for(const stage of row.stages){
  assert.equal(transportConcreteSyntaxMeta(stage.beforeMeta).source,stage.before);
  assert.equal(transportConcreteSyntaxMeta(stage.afterMeta).source,stage.after);
  assert.equal(stage.completeInverse,true);assert.deepEqual(stage.trace.map(part=>part.phase),['language','repository']);
 }
 const facade=project().executableDeclarations.find(item=>item.name==='root');
 assert.equal(Function.prototype.toString.call(facade.lower),row.selection.lowerFunction);
 assert.equal(Function.prototype.toString.call(facade.checkedSource),row.selection.checkedSourceFunction);
 const prior={[row.path]:{after:row.before}},joined=composeProjectFacadeRetention(prior);
 assert.equal(joined.historicalSources,prior);assert.equal(joined.sources[row.path].after,row.after);
 assert.throws(()=>composeProjectFacadeRetention({[row.path]:{after:row.before+' '}}),/preceding complete project equation/);
});

test('retained checked-source facade observes live module paths and ambiguous siblings and returns fresh frozen copies',limits,()=>{
 const result=project(),facade=result.executableDeclarations.find(row=>row.qualifiedName==='child.add');
 const first=facade.checkedSource(),second=facade.checkedSource();
 assert.notEqual(first,second);assert.notEqual(first.declaration,second.declaration);assert.deepEqual(first,second);
 assert.ok(Object.isFrozen(second.declaration.body));
 const child=result.meta.sources.find(row=>row.module.join('.')==='child'),other=result.meta.sources.find(row=>row.module.join('.')==='other');
 child.module.push('moved');assert.throws(()=>facade.checkedSource(),/association differs/);child.module.pop();
 other.module[0]='child';assert.throws(()=>facade.checkedSource(),/association differs/);other.module[0]='other';
 facade.span.start++;assert.throws(()=>facade.checkedSource(),/association differs/);facade.span.start--;
 assert.deepEqual(facade.checkedSource(),first);
 result.meta.checkedSemanticProgram={forged:true};assert.deepEqual(facade.checkedSource(),first);
});

test('retained lowerers preserve callable descriptors and ordinary option observations across receivers',limits,()=>{
 const result=project(),facade=result.executableDeclarations.find(row=>row.qualifiedName==='root');
 assert.equal(facade.lower.name,'');assert.equal(facade.checkedSource.name,'checkedSource');
 assert.equal(facade.lower.length,0);assert.equal(facade.checkedSource.length,0);
 assert.equal(Object.hasOwn(facade.lower,'prototype'),true);assert.equal(Object.hasOwn(facade.checkedSource,'prototype'),false);
 const calls=[],options={get runtimeModule(){calls.push('runtimeModule');return '../runtime/effects.mjs';}};
 const first=facade.lower(options),second=facade.lower.call(Object.freeze({receiver:true}),options);
 assert.deepEqual(calls,['runtimeModule','runtimeModule']);
 assert.equal(serializeProgram(first.program),serializeProgram(second.program));assert.deepEqual(first.emitted,second.emitted);
 assert.equal(first.own.fullName,second.own.fullName);assert.deepEqual(facade.lower().own,first.own);
});
