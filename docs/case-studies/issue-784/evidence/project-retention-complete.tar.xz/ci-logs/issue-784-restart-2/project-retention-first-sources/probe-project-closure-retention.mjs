// Finite diagnostic only. Neither the compiler nor its source pins are changed.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,unlinkSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {ownershipCompiler} from '../../tools/translation/js-to-rust/vendor/module-syntax.mjs';

const originalURL=new URL('../../tools/translation/project.mjs',import.meta.url);
const corpus=process.argv[2];
assert.ok(corpus===undefined||corpus==='actual-config');
const minimal=process.argv[3]==='--minimal-source-view';
assert.ok(process.argv[3]===undefined||minimal);assert.ok(process.argv.length<=4);
const outputURL=new URL('./project-closure-candidate.mjs',import.meta.url);
const source=readFileSync(originalURL,'utf8'),ts=ownershipCompiler();
assert.equal(ts.version,'5.9.3');
const file=ts.createSourceFile('project.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
assert.equal(file.parseDiagnostics.length,0);
const lowers=[],accessors=[],imports=[];
function walk(node){
 if(ts.isVariableDeclaration(node)&&node.name.getText(file)==='lowerDeclaration')lowers.push(node);
 if(ts.isPropertyAssignment(node)&&node.name.getText(file)==='checkedSource')accessors.push(node);
 if(ts.isImportDeclaration(node)&&ts.isStringLiteral(node.moduleSpecifier))imports.push(node.moduleSpecifier);
 ts.forEachChild(node,walk);
}
walk(file);assert.equal(lowers.length,1);assert.equal(accessors.length,1);
const lower=lowers[0].initializer,accessor=accessors[0].initializer;
assert.ok(ts.isArrowFunction(lower)&&ts.isFunctionExpression(lower.body));
assert.ok(ts.isArrowFunction(accessor)&&accessor.parameters.length===0);
const helpers='\nfunction createProjectLowerer(target,entry,name){return '+lower.body.getText(file)+';}\n'
 +'function createProjectCheckedSource(checked,graph,entry){const checkedSource='+accessor.getText(file)+';return checkedSource;}\n';
const edits=[
 [lower.getStart(file),lower.end,'(entry,name)=>createProjectLowerer(target,entry,name)'],
 [accessor.getStart(file),accessor.end,minimal?'createProjectCheckedSource(checked,{modules:graph.modules},entry)':'createProjectCheckedSource(checked,graph,entry)'],
 ...imports.filter(node=>node.text.startsWith('.')).map(node=>[node.getStart(file),node.end,JSON.stringify(new URL(node.text,originalURL).href)]),
];
edits.sort((a,b)=>b[0]-a[0]);let candidate=source;
for(const [start,end,text]of edits)candidate=candidate.slice(0,start)+text+candidate.slice(end);
candidate+=helpers;
assert.equal(ts.createSourceFile('candidate.mjs',candidate,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS).parseDiagnostics.length,0);
const sha=value=>createHash('sha256').update(value).digest('hex');
writeFileSync(outputURL,candidate,{flag:'wx'});
try{
 const originalResults=new Map();
 for(const name of ['original','candidate'])for(const mode of ['lower','facade']){
  const loader=name==='candidate'?['--experimental-loader',new URL('./project-closure-diagnostic-loader.mjs',import.meta.url).pathname]:[];
  const result=spawnSync(new URL('./toolchain/node20/bin/node',import.meta.url).pathname,['--max-old-space-size=512','--expose-gc',...loader,new URL('./probe-project-closure-retention-child.mjs',import.meta.url).pathname,originalURL.href,mode,...(corpus?[corpus]:[])],{encoding:'utf8',maxBuffer:1024*1024});
  console.log(JSON.stringify({name,mode,minimal,typescriptVersion:ts.version,sourceSha256:sha(name==='original'?source:candidate),status:result.status,signal:result.signal,stdout:result.stdout,stderr:result.stderr}));
  assert.equal(result.status,0);
  const record=JSON.parse(result.stdout),stable=Object.fromEntries(Object.entries(record).filter(([key])=>!['alive','heapUsed'].includes(key)));
  if(name==='original')originalResults.set(mode,stable);else assert.deepEqual(stable,originalResults.get(mode));
 }
}finally{unlinkSync(outputURL);}
