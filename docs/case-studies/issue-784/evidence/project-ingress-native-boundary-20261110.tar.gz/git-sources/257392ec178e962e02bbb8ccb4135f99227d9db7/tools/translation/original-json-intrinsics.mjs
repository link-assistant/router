// Reuse of privately computed JSON bytes is valid only under the same ordinary
// native serializer and plain-data prototype chains. This issues no authority.
import {types} from 'node:util';
const descriptor=Object.getOwnPropertyDescriptor,prototype=Object.getPrototypeOf,apply=Reflect.apply,keys=Reflect.ownKeys,hasOwn=Object.hasOwn;
const originalObject=Object,originalArray=Array,originalJson=JSON,objectPrototype=Object.prototype,arrayPrototype=Array.prototype;
const globalJson=descriptor(globalThis,'JSON'),globalObject=descriptor(globalThis,'Object'),globalArray=descriptor(globalThis,'Array'),stringify=descriptor(JSON,'stringify');
const functionText=Function.prototype.toString;
function snapshot(owner){const names=keys(owner),result=[];for(let index=0;index<names.length;index++)result[index]=[names[index],descriptor(owner,names[index])];return result;}
const mapPrototype=Map.prototype,setPrototype=Set.prototype,weakSetPrototype=WeakSet.prototype,arrayDescriptors=snapshot(arrayPrototype),mapDescriptors=snapshot(mapPrototype),setDescriptors=snapshot(setPrototype),weakSetDescriptors=snapshot(weakSetPrototype);
const globalMap=descriptor(globalThis,'Map'),globalSet=descriptor(globalThis,'Set'),globalWeakSet=descriptor(globalThis,'WeakSet'),species=descriptor(originalArray,Symbol.species);
const objectOperations=['keys','values','entries','fromEntries'],objectPins=[];for(let index=0;index<objectOperations.length;index++){const name=objectOperations[index];objectPins[index]=[name,descriptor(originalObject,name)];}
const objectHasOwn=descriptor(originalObject,'hasOwn'),objectDescriptor=descriptor(originalObject,'getOwnPropertyDescriptor');
const globalsAreData=globalJson&&hasOwn(globalJson,'value')&&globalJson.value===originalJson&&globalObject&&hasOwn(globalObject,'value')&&globalObject.value===originalObject&&globalArray&&hasOwn(globalArray,'value')&&globalArray.value===originalArray&&globalMap&&hasOwn(globalMap,'value')&&globalSet&&hasOwn(globalSet,'value');
const native=(fn,name)=>typeof fn==='function'&&!types.isProxy(fn)&&apply(functionText,fn,[])===`function ${name}() { [native code] }`;
function nativePrototype(entries,kind){for(let index=0;index<entries.length;index++){const key=entries[index][0],field=entries[index][1];if(hasOwn(field,'value')){if(typeof field.value!=='function')continue;const name=key==='constructor'?kind:key===Symbol.iterator?(kind==='Map'?'entries':'values'):kind==='Set'&&key==='keys'?'values':key;if(typeof name!=='string'||!native(field.value,name)&&!(kind==='Set'&&key==='keys'&&native(field.value,'keys')))return false;}else if(field.get!==undefined&&!native(field.get,'get '+String(key))||field.set!==undefined&&!native(field.set,'set '+String(key)))return false;}return true;}
let ordinaryNative=globalsAreData&&native(originalObject,'Object')&&native(originalArray,'Array')&&native(globalMap.value,'Map')&&native(globalSet.value,'Set')&&globalWeakSet&&hasOwn(globalWeakSet,'value')&&native(globalWeakSet.value,'WeakSet')&&stringify&&hasOwn(stringify,'value')&&native(stringify.value,'stringify')&&nativePrototype(arrayDescriptors,'Array')&&nativePrototype(mapDescriptors,'Map')&&nativePrototype(setDescriptors,'Set')&&nativePrototype(weakSetDescriptors,'WeakSet')&&species&&!hasOwn(species,'value')&&species.set===undefined&&native(species.get,'get [Symbol.species]');
for(let index=0;index<objectPins.length;index++){const name=objectPins[index][0],field=objectPins[index][1];if(!field||!hasOwn(field,'value')||!native(field.value,name))ordinaryNative=false;}

const iteratorPins=[];if(ordinaryNative)try{const owners=[arrayPrototype,mapPrototype,setPrototype],receivers=[[],new Map(),new Set()];for(let index=0;index<owners.length;index++){const iterator=apply(descriptor(owners[index],Symbol.iterator).value,receivers[index],[]),owner=prototype(iterator),field=descriptor(owner,'next');iteratorPins[index]={owner,field};if(!field||!hasOwn(field,'value')||!native(field.value,'next'))ordinaryNative=false;}}catch{ordinaryNative=false;}

// A native from a different collection can have the same name. Check receiver
// brands only after all operations used by these private probes qualify native.
if(ordinaryNative)try{const key={},value={},map=new Map(),set=new Set(),weak=new WeakSet();ordinaryNative=map.set(key,value)===map&&map.get(key)===value&&map.has(key)&&map.size===1&&map.delete(key)&&map.size===0&&set.add(key)===set&&set.has(key)&&set.size===1&&set.delete(key)&&set.size===0&&weak.add(key)===weak&&weak.has(key)&&weak.delete(key)&&!weak.has(key);}catch{ordinaryNative=false;}

// TypedArray and collection natives can share Array/Object method names while
// rejecting their receivers. These bounded probes see only private literals.
if(ordinaryNative)try{
 const input=[3,1],plain={key:7},array=value=>prototype(value)===arrayPrototype;
 const mapped=apply(arrayPrototype.map,input,[value=>value+1]),filtered=apply(arrayPrototype.filter,input,[value=>value>1]),flat=apply(arrayPrototype.flatMap,input,[value=>[value]]),slice=apply(arrayPrototype.slice,input,[0,1]);let visited=0;apply(arrayPrototype.forEach,input,[(value,index,owner)=>{if(owner!==input||index!==visited)throw new TypeError('array receiver');visited++;}]);
 ordinaryNative=array(mapped)&&mapped.length===2&&mapped[0]===4&&mapped[1]===2&&array(filtered)&&filtered.length===1&&filtered[0]===3&&array(flat)&&flat.length===2&&flat[0]===3&&flat[1]===1&&array(slice)&&slice.length===1&&slice[0]===3&&visited===2&&apply(arrayPrototype.find,input,[value=>value===1])===1&&apply(arrayPrototype.every,input,[value=>typeof value==='number'])===true&&apply(arrayPrototype.some,input,[value=>value===1])===true&&apply(arrayPrototype.includes,input,[3])===true&&apply(arrayPrototype.includes,input,['3'])===false&&apply(arrayPrototype.at,input,[0])===3&&apply(arrayPrototype.join,input,[':'])==='3:1';
 const names=originalObject.keys(plain),values=originalObject.values(plain),pairs=originalObject.entries(plain),record=originalObject.fromEntries([['key',7]]);ordinaryNative=ordinaryNative&&array(names)&&names.length===1&&names[0]==='key'&&array(values)&&values.length===1&&values[0]===7&&array(pairs)&&pairs.length===1&&array(pairs[0])&&pairs[0][0]==='key'&&pairs[0][1]===7&&prototype(record)===objectPrototype&&hasOwn(record,'key')&&record.key===7;
}catch{ordinaryNative=false;}

function same(actual,expected){if(!actual||!expected||hasOwn(actual,'value')!==hasOwn(expected,'value'))return false;return actual.enumerable===expected.enumerable&&actual.configurable===expected.configurable&&(hasOwn(expected,'value')?actual.value===expected.value&&actual.writable===expected.writable:hasOwn(actual,'get')&&hasOwn(actual,'set')&&hasOwn(expected,'get')&&hasOwn(expected,'set')&&actual.get===expected.get&&actual.set===expected.set);}
function samePrototype(owner,expectedDescriptors){const actual=keys(owner);if(actual.length!==expectedDescriptors.length)return false;for(let index=0;index<actual.length;index++){const entry=expectedDescriptors[index],key=entry[0],expected=entry[1];if(actual[index]!==key||!same(descriptor(owner,key),expected))return false;}return true;}
export function originalJsonIntrinsicsUnchanged(){
 if(!ordinaryNative)return false;for(let index=0;index<iteratorPins.length;index++){const pin=iteratorPins[index];if(!same(descriptor(pin.owner,'next'),pin.field))return false;}for(let index=0;index<objectPins.length;index++){const name=objectPins[index][0],field=objectPins[index][1];if(!same(descriptor(originalObject,name),field))return false;}
 return same(descriptor(originalArray,Symbol.species),species)&&same(descriptor(globalThis,'WeakSet'),globalWeakSet)&&samePrototype(weakSetPrototype,weakSetDescriptors)&&same(descriptor(globalThis,'JSON'),globalJson)&&same(descriptor(globalThis,'Object'),globalObject)&&same(descriptor(globalThis,'Array'),globalArray)&&same(descriptor(globalThis,'Map'),globalMap)&&same(descriptor(globalThis,'Set'),globalSet)&&same(descriptor(originalObject,'hasOwn'),objectHasOwn)&&same(descriptor(originalObject,'getOwnPropertyDescriptor'),objectDescriptor)&&same(descriptor(originalJson,'stringify'),stringify)&&originalObject.prototype===objectPrototype&&originalArray.prototype===arrayPrototype&&prototype(objectPrototype)===null&&prototype(arrayPrototype)===objectPrototype&&!descriptor(objectPrototype,'toJSON')&&!descriptor(arrayPrototype,'toJSON')&&samePrototype(arrayPrototype,arrayDescriptors)&&samePrototype(mapPrototype,mapDescriptors)&&samePrototype(setPrototype,setDescriptors);
}

// Qualification shared by the complete original and current derive leaf. The
// older JSON guard keeps its exact domain; these additional operations qualify
// only the new invocation-local path index, never source/proof authority.
const pathIsArray=descriptor(originalArray,'isArray'),pathIsProxy=descriptor(types,'isProxy'),pathWeakMap=descriptor(globalThis,'WeakMap'),pathReflect=descriptor(globalThis,'Reflect'),pathGetPrototypeOf=descriptor(originalObject,'getPrototypeOf');
let pathWeakPrototype=null,pathWeakHas=null,pathOwnKeys=null,pathNative=ordinaryNative&&native(descriptor,'getOwnPropertyDescriptor')&&native(hasOwn,'hasOwn')&&native(prototype,'getPrototypeOf')&&native(keys,'ownKeys')&&pathIsArray&&hasOwn(pathIsArray,'value')&&native(pathIsArray.value,'isArray')&&pathIsProxy&&hasOwn(pathIsProxy,'value')&&native(pathIsProxy.value,'isProxy')&&pathWeakMap&&hasOwn(pathWeakMap,'value')&&native(pathWeakMap.value,'WeakMap')&&pathReflect&&hasOwn(pathReflect,'value')&&!types.isProxy(pathReflect.value);
if(pathNative){pathWeakPrototype=pathWeakMap.value.prototype;pathWeakHas=descriptor(pathWeakPrototype,'has');pathOwnKeys=descriptor(pathReflect.value,'ownKeys');pathNative=!!(pathWeakHas&&hasOwn(pathWeakHas,'value')&&native(pathWeakHas.value,'has')&&pathOwnKeys&&hasOwn(pathOwnKeys,'value')&&pathOwnKeys.value===keys&&pathGetPrototypeOf&&hasOwn(pathGetPrototypeOf,'value')&&pathGetPrototypeOf.value===prototype);}
if(pathNative)try{const map=new pathWeakMap.value(),value={};pathNative=apply(pathWeakHas.value,map,[value])===false&&pathIsArray.value([])&&!pathIsArray.value({});}catch{pathNative=false;}
export function originalPathMembershipIntrinsicsUnchanged(){
 return !!(pathNative&&originalJsonIntrinsicsUnchanged()&&same(descriptor(originalObject,'getPrototypeOf'),pathGetPrototypeOf)&&same(descriptor(globalThis,'Reflect'),pathReflect)&&same(descriptor(pathReflect.value,'ownKeys'),pathOwnKeys)&&same(descriptor(originalArray,'isArray'),pathIsArray)&&same(descriptor(types,'isProxy'),pathIsProxy)&&same(descriptor(globalThis,'WeakMap'),pathWeakMap)&&pathWeakMap.value.prototype===pathWeakPrototype&&same(descriptor(pathWeakPrototype,'has'),pathWeakHas));
}

// This separate qualification permits invocation-local streaming of namespace
// maps. It does not skip a digest, metadata copy, target check or proof join.
// All common issuers initialize before a consumer's cold-leaf observer tests;
// those tests do not claim equivalence of the whole issuer bootstrap.
const traversalFunctionPrototype=pathNative?prototype(functionText):null;
const traversalCall=pathNative?descriptor(traversalFunctionPrototype,'call'):null;
const traversalDescriptors=pathNative?descriptor(originalObject,'getOwnPropertyDescriptors'):null;
const traversalApply=pathNative?descriptor(pathReflect.value,'apply'):null;
const traversalEntries=pathNative?descriptor(mapPrototype,'entries'):null;
const traversalMapIterator=pathNative?iteratorPins[1]:null;
const traversalIteratorPrototype=traversalMapIterator?prototype(traversalMapIterator.owner):null;
const traversalIteratorParent=traversalIteratorPrototype&&!types.isProxy(traversalIteratorPrototype)?prototype(traversalIteratorPrototype):null;
const traversalIteratorMethod=traversalIteratorPrototype&&!types.isProxy(traversalIteratorPrototype)?descriptor(traversalIteratorPrototype,Symbol.iterator):null;
let traversalNative=!!(pathNative&&traversalCall&&hasOwn(traversalCall,'value')&&native(traversalCall.value,'call')&&traversalDescriptors&&hasOwn(traversalDescriptors,'value')&&native(traversalDescriptors.value,'getOwnPropertyDescriptors')&&traversalApply&&hasOwn(traversalApply,'value')&&traversalApply.value===apply&&native(apply,'apply')&&traversalEntries&&hasOwn(traversalEntries,'value')&&traversalEntries.value===descriptor(mapPrototype,Symbol.iterator)?.value&&traversalMapIterator&&!types.isProxy(traversalMapIterator.owner)&&!descriptor(traversalMapIterator.owner,Symbol.iterator)&&traversalIteratorMethod&&hasOwn(traversalIteratorMethod,'value')&&native(traversalIteratorMethod.value,'[Symbol.iterator]'));
if(traversalNative)try{
 const map=new globalMap.value(),key={},value={};map.set(key,value);
 const cursor=apply(traversalEntries.value,map,[]),first=apply(traversalMapIterator.field.value,cursor,[]),end=apply(traversalMapIterator.field.value,cursor,[]);
 traversalNative=prototype(cursor)===traversalMapIterator.owner&&first.done===false&&first.value.length===2&&first.value[0]===key&&first.value[1]===value&&end.done===true;
}catch{traversalNative=false;}
export function originalNamespaceTraversalIntrinsicsUnchanged(){
 if(!traversalNative||!originalPathMembershipIntrinsicsUnchanged()||!same(descriptor(traversalFunctionPrototype,'call'),traversalCall)||!same(descriptor(originalObject,'getOwnPropertyDescriptors'),traversalDescriptors)||!same(descriptor(pathReflect.value,'apply'),traversalApply)||!same(descriptor(mapPrototype,'entries'),traversalEntries)||prototype(traversalMapIterator.owner)!==traversalIteratorPrototype||descriptor(traversalMapIterator.owner,Symbol.iterator)||prototype(traversalIteratorPrototype)!==traversalIteratorParent||!same(descriptor(traversalIteratorPrototype,Symbol.iterator),traversalIteratorMethod))return false;
 // The old route calls entries.call; a function's own call hook or changed
 // prototype is also observable and therefore keeps the collected fallback.
 return prototype(traversalEntries.value)===traversalFunctionPrototype&&!descriptor(traversalEntries.value,'call')&&prototype(traversalMapIterator.field.value)===traversalFunctionPrototype&&!descriptor(traversalMapIterator.field.value,'call');
}

// Successful flat-token validation may avoid allocating a canonical copy only
// when every skipped copier/coercion operation is genuinely native. This adds
// no cache or source authority and leaves the existing guard domains unchanged.
const tokenBuffer=descriptor(globalThis,'Buffer'),tokenString=descriptor(globalThis,'String'),tokenNumber=descriptor(globalThis,'Number');
const tokenBufferValue=tokenBuffer&&hasOwn(tokenBuffer,'value')&&typeof tokenBuffer.value==='function'&&!types.isProxy(tokenBuffer.value)?tokenBuffer.value:null;
const tokenNumberValue=tokenNumber&&hasOwn(tokenNumber,'value')&&typeof tokenNumber.value==='function'&&!types.isProxy(tokenNumber.value)?tokenNumber.value:null;
const tokenSafeInteger=tokenNumberValue?descriptor(tokenNumberValue,'isSafeInteger'):null;
const tokenRequired=[[originalObject,'create'],[originalObject,'defineProperty'],[originalObject,'keys'],[tokenBufferValue,'byteLength'],[tokenNumberValue,'isSafeInteger']];
const tokenPins=[];let tokenNative=!!(traversalNative&&tokenBufferValue&&tokenString&&hasOwn(tokenString,'value')&&native(tokenString.value,'String')&&tokenNumberValue&&native(tokenNumberValue,'Number')&&tokenSafeInteger&&hasOwn(tokenSafeInteger,'value')&&native(tokenSafeInteger.value,'isSafeInteger'));
function tokenPrototypeSafe(){
 // Copier defaults and ToPropertyDescriptor read these inherited properties.
 if(descriptor(objectPrototype,'cells')||descriptor(objectPrototype,'bytes')||descriptor(objectPrototype,'preserveKeyOrder')||descriptor(objectPrototype,'get')||descriptor(objectPrototype,'set'))return false;
 // A skipped result.push could otherwise invoke a numeric inherited setter or
 // fail on inherited nonwritable data. Native key/coercion calls see strings.
 for(let at=0;at<2;at++){const names=keys(at===0?objectPrototype:arrayPrototype);for(let index=0;index<names.length;index++){const key=names[index];if(typeof key==='string'){const number=tokenNumberValue(key);if(number>=0&&tokenSafeInteger.value(number)&&tokenString.value(number)===key)return false;}}}
 return true;
}
if(tokenNative&&!tokenPrototypeSafe())tokenNative=false;
if(tokenNative)for(let index=0;index<tokenRequired.length;index++){const owner=tokenRequired[index][0],key=tokenRequired[index][1],field=descriptor(owner,key);tokenPins[index]={owner,key,field};if(!field||!hasOwn(field,'value')||!native(field.value,key))tokenNative=false;}
if(tokenNative)try{tokenNative=tokenBufferValue.byteLength('')===0&&tokenBufferValue.byteLength('a')===1&&tokenBufferValue.byteLength('\u03bb\ud83d\ude00\ud800')===9&&tokenString.value(0)==='0'&&tokenString.value(12)==='12'&&tokenNumberValue.isSafeInteger(1)&&!tokenNumberValue.isSafeInteger(1.5);}catch{tokenNative=false;}
export function originalFlatTokenIntrinsicsUnchanged(){
 if(!tokenNative||!originalNamespaceTraversalIntrinsicsUnchanged()||!same(descriptor(globalThis,'Buffer'),tokenBuffer)||!same(descriptor(globalThis,'String'),tokenString)||!same(descriptor(globalThis,'Number'),tokenNumber))return false;
 for(let index=0;index<tokenPins.length;index++){const pin=tokenPins[index];if(!same(descriptor(pin.owner,pin.key),pin.field))return false;}
 return tokenPrototypeSafe();
}

// The static lexer memo skips only native allocation/control flow. Qualify
// every String/RegExp operation used by the complete source lexer, separately
// from Buffer-dependent metadata copying. Consumer oracle leaves share this
// issuer bootstrap; this is not a whole-compiler bootstrap equivalence claim.
const syntaxString=descriptor(globalThis,'String'),syntaxRegExp=descriptor(globalThis,'RegExp');
const syntaxFreeze=descriptor(originalObject,'freeze'),syntaxIsFrozen=descriptor(originalObject,'isFrozen');
const syntaxDefine=descriptor(originalObject,'defineProperty');
let syntaxStringPrototype=null,syntaxRegExpPrototype=null,syntaxStrings=null,syntaxRegexps=null;
let syntaxNative=!!(traversalNative&&syntaxString&&hasOwn(syntaxString,'value')&&!types.isProxy(syntaxString.value)&&native(syntaxString.value,'String')&&syntaxRegExp&&hasOwn(syntaxRegExp,'value')&&!types.isProxy(syntaxRegExp.value)&&native(syntaxRegExp.value,'RegExp')&&syntaxFreeze&&hasOwn(syntaxFreeze,'value')&&native(syntaxFreeze.value,'freeze')&&syntaxIsFrozen&&hasOwn(syntaxIsFrozen,'value')&&native(syntaxIsFrozen.value,'isFrozen')&&syntaxDefine&&hasOwn(syntaxDefine,'value')&&native(syntaxDefine.value,'defineProperty'));
function syntaxPrototypeNative(entries,kind){
 for(let index=0;index<entries.length;index++){
  const key=entries[index][0],field=entries[index][1];
  if(hasOwn(field,'value')){
   if(typeof field.value!=='function')continue;
   const name=key==='constructor'?kind:typeof key!=='symbol'?key:key===Symbol.iterator?'[Symbol.iterator]':key===Symbol.match?'[Symbol.match]':key===Symbol.matchAll?'[Symbol.matchAll]':key===Symbol.replace?'[Symbol.replace]':key===Symbol.search?'[Symbol.search]':key===Symbol.split?'[Symbol.split]':null;
   if(name===null||!native(field.value,name)&&!(kind==='String'&&key==='trimLeft'&&native(field.value,'trimStart'))&&!(kind==='String'&&key==='trimRight'&&native(field.value,'trimEnd')))return false;
  }else if(field.get!==undefined&&!native(field.get,'get '+String(key))||field.set!==undefined&&!native(field.set,'set '+String(key)))return false;
 }
 return true;
}
// Numeric inherited cells can make native Array.push or out-of-range String
// indexing observable. Primitive arithmetic here does not invoke a global
// Number/String hook, or a regexp that would disturb the lexer's final state.
function syntaxNumericPrototypeSafe(){
 const owners=[objectPrototype,arrayPrototype,syntaxStringPrototype];
 for(let index=0;index<owners.length;index++){
  const names=keys(owners[index]);
  for(let at=0;at<names.length;at++){const key=names[at];if(typeof key==='string'){const value=+key;if(value>=0&&value<=9007199254740991&&value%1===0&&''+value===key)return false;}}
 }
 return true;
}
if(syntaxNative){
 syntaxStringPrototype=syntaxString.value.prototype;syntaxRegExpPrototype=syntaxRegExp.value.prototype;
 if(types.isProxy(syntaxStringPrototype)||types.isProxy(syntaxRegExpPrototype))syntaxNative=false;
 else if(!syntaxNumericPrototypeSafe())syntaxNative=false;
 else{syntaxStrings=snapshot(syntaxStringPrototype);syntaxRegexps=snapshot(syntaxRegExpPrototype);syntaxNative=prototype(syntaxStringPrototype)===objectPrototype&&prototype(syntaxRegExpPrototype)===objectPrototype&&syntaxPrototypeNative(syntaxStrings,'String')&&syntaxPrototypeNative(syntaxRegexps,'RegExp')&&syntaxNumericPrototypeSafe();}
}
// Native names alone do not establish receiver brands (Array.slice and
// String.slice are different). These probes use only private primitives after
// all of their operations qualify, once in the shared issuer bootstrap.
if(syntaxNative)try{
 const strings=syntaxStringPrototype,regexps=syntaxRegExpPrototype,rx=/a(b)/u,match=apply(regexps.exec,rx,['ab']);
 syntaxNative=apply(strings.slice,'éabc',[1,3])==='ab'&&apply(strings.indexOf,'éabc',['a'])===1&&apply(strings.startsWith,'éabc',['é'])===true&&apply(strings.charCodeAt,'éabc',[0])===233&&apply(regexps.test,/\s/u,['\n'])===true&&match.length===2&&match[0]==='ab'&&match[1]==='b'&&apply(syntaxIsFrozen.value,originalObject,[{}])===false;
 const frozen=apply(syntaxFreeze.value,originalObject,[{}]);syntaxNative=syntaxNative&&apply(syntaxIsFrozen.value,originalObject,[frozen])===true;
}catch{syntaxNative=false;}
export function originalStaticSourceIntrinsicsUnchanged(){
 return !!(syntaxNative&&originalNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(globalThis,'String'),syntaxString)&&same(descriptor(globalThis,'RegExp'),syntaxRegExp)&&same(descriptor(originalObject,'freeze'),syntaxFreeze)&&same(descriptor(originalObject,'isFrozen'),syntaxIsFrozen)&&same(descriptor(originalObject,'defineProperty'),syntaxDefine)&&syntaxString.value.prototype===syntaxStringPrototype&&syntaxRegExp.value.prototype===syntaxRegExpPrototype&&prototype(syntaxStringPrototype)===objectPrototype&&prototype(syntaxRegExpPrototype)===objectPrototype&&samePrototype(syntaxStringPrototype,syntaxStrings)&&samePrototype(syntaxRegExpPrototype,syntaxRegexps)&&syntaxNumericPrototypeSafe());
}

// Diagnostic metadata belongs to the shared issuer bootstrap. Reader budgets
// are lexical constants; even a replaced freeze cannot widen their domain.
export const STATIC_SOURCE_ITEM_LIMITS=Object.freeze({entries:16,sourceChars:128000,entryCells:200000,cells:400000,chars:1000000});

// Completed deep-data freezing skips only native recursive refreezing. Every
// skipped/added operation qualifies here; existing guard domains are unchanged.
const dataFreeze=descriptor(originalObject,'freeze'),dataIsFrozen=descriptor(originalObject,'isFrozen');
const dataWeakGet=pathWeakPrototype?descriptor(pathWeakPrototype,'get'):null,dataWeakSet=pathWeakPrototype?descriptor(pathWeakPrototype,'set'):null;
let dataFreezeNative=!!(traversalNative&&dataFreeze&&hasOwn(dataFreeze,'value')&&native(dataFreeze.value,'freeze')&&dataIsFrozen&&hasOwn(dataIsFrozen,'value')&&native(dataIsFrozen.value,'isFrozen')&&dataWeakGet&&hasOwn(dataWeakGet,'value')&&native(dataWeakGet.value,'get')&&dataWeakSet&&hasOwn(dataWeakSet,'value')&&native(dataWeakSet.value,'set'));
function dataFreezeNumericSafe(){
 const owners=[objectPrototype,arrayPrototype];for(let index=0;index<owners.length;index++){
  const names=keys(owners[index]);for(let at=0;at<names.length;at++){const key=names[at];if(typeof key==='string'){const number=+key;if(number>=0&&number<=9007199254740991&&number%1===0&&''+number===key)return false;}}
 }return true;
}
if(dataFreezeNative)try{
 const value={},map=new pathWeakMap.value();dataFreezeNative=apply(dataWeakGet.value,map,[value])===undefined&&apply(dataWeakSet.value,map,[value,7])===map&&apply(dataWeakGet.value,map,[value])===7&&apply(dataIsFrozen.value,originalObject,[value])===false&&apply(dataFreeze.value,originalObject,[value])===value&&apply(dataIsFrozen.value,originalObject,[value])===true&&dataFreezeNumericSafe();
}catch{dataFreezeNative=false;}
export function originalDataFreezeIntrinsicsUnchanged(){
 return !!(dataFreezeNative&&originalNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(originalObject,'freeze'),dataFreeze)&&same(descriptor(originalObject,'isFrozen'),dataIsFrozen)&&same(descriptor(pathWeakPrototype,'get'),dataWeakGet)&&same(descriptor(pathWeakPrototype,'set'),dataWeakSet)&&dataFreezeNumericSafe());
}

// Observe through this issuer's trusted bootstrap capture, never through a
// consumer's later Function.prototype.toString. This exposes text only and
// issues no source/proof token or additional existing guard domain.
export function originalCapturedFunctionSource(value){
 if(!pathNative||typeof value!=='function'||pathIsProxy.value(value))return null;
 return apply(functionText,value,[]);
}

// Refuse through own primitive diagnostic data without a late native Error
// constructor, reflection operation, coercion or native function exposure.
const diagnosticTypeField=pathNative?descriptor(globalThis,'TypeError'):null;
const diagnosticType=diagnosticTypeField&&hasOwn(diagnosticTypeField,'value')&&native(diagnosticTypeField.value,'TypeError')?diagnosticTypeField.value:null;
const diagnosticPrototypeField=diagnosticType?descriptor(diagnosticType,'prototype'):null;
const diagnosticPrototype=diagnosticPrototypeField&&hasOwn(diagnosticPrototypeField,'value')&&diagnosticPrototypeField.value&&typeof diagnosticPrototypeField.value==='object'&&!pathIsProxy.value(diagnosticPrototypeField.value)?diagnosticPrototypeField.value:null;
export function throwOriginalCapturedTypeError(message){
 const text=typeof message==='string'?message:'Original captured diagnostic requires primitive text';
 throw {__proto__:diagnosticPrototype,name:'TypeError',message:text};
}

// Additional earliest ingress for private parser execution. The old guards
// retain their exact domains. This captures only within the SAME trusted common
// bootstrap; it cannot authenticate a common issuer first loaded under hooks.
const parserIngressRoot=globalThis;
const parserIngressGlobal=descriptor(parserIngressRoot,'globalThis');
const parserIngressSymbol=descriptor(parserIngressRoot,'Symbol');
const parserIngressNative=!!(pathNative&&parserIngressGlobal&&hasOwn(parserIngressGlobal,'value')&&parserIngressGlobal.value===parserIngressRoot&&parserIngressSymbol&&hasOwn(parserIngressSymbol,'value')&&!pathIsProxy.value(parserIngressSymbol.value)&&native(parserIngressSymbol.value,'Symbol'));
const parserIngressIterator=parserIngressNative?descriptor(parserIngressSymbol.value,'iterator'):null;
const parserIngressSpecies=parserIngressNative?descriptor(parserIngressSymbol.value,'species'):null;
export function originalPrivateParserIngressUnchanged(){
 return !!(parserIngressNative&&parserIngressIterator&&hasOwn(parserIngressIterator,'value')&&typeof parserIngressIterator.value==='symbol'&&parserIngressSpecies&&hasOwn(parserIngressSpecies,'value')&&typeof parserIngressSpecies.value==='symbol'&&same(descriptor(parserIngressRoot,'globalThis'),parserIngressGlobal)&&same(descriptor(parserIngressRoot,'Symbol'),parserIngressSymbol)&&same(descriptor(parserIngressSymbol.value,'iterator'),parserIngressIterator)&&same(descriptor(parserIngressSymbol.value,'species'),parserIngressSpecies));
}

// One fresh namespace traversal for the exact private-parser conjunction.
// All original guards/domains remain intact; both numeric scans and distinct
// freeze pins stay live. No result is retained between calls. The omitted
// duplicate traversal observes only captured native owners without callbacks.
export function originalPrivateParserCommonIntrinsicsUnchanged(){
 if(!originalPrivateParserIngressUnchanged())return false;
 return !!(syntaxNative&&originalNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(globalThis,'String'),syntaxString)&&same(descriptor(globalThis,'RegExp'),syntaxRegExp)&&same(descriptor(originalObject,'freeze'),syntaxFreeze)&&same(descriptor(originalObject,'isFrozen'),syntaxIsFrozen)&&same(descriptor(originalObject,'defineProperty'),syntaxDefine)&&syntaxString.value.prototype===syntaxStringPrototype&&syntaxRegExp.value.prototype===syntaxRegExpPrototype&&prototype(syntaxStringPrototype)===objectPrototype&&prototype(syntaxRegExpPrototype)===objectPrototype&&samePrototype(syntaxStringPrototype,syntaxStrings)&&samePrototype(syntaxRegExpPrototype,syntaxRegexps)&&syntaxNumericPrototypeSafe()&&dataFreezeNative&&same(descriptor(originalObject,'freeze'),dataFreeze)&&same(descriptor(originalObject,'isFrozen'),dataIsFrozen)&&same(descriptor(pathWeakPrototype,'get'),dataWeakGet)&&same(descriptor(pathWeakPrototype,'set'),dataWeakSet)&&dataFreezeNumericSafe());
}

// Only EXPECTED descriptor shape is stored. No current guard/source verdict is
// retained: every warm call still reads each current descriptor in old order.
let privateExpectedPlans=null;
function makePrivateExpectedPlans(){
 const snapshots=[arrayDescriptors,mapDescriptors,setDescriptors,weakSetDescriptors,syntaxStrings,syntaxRegexps];let count=0;
 for(let slot=0;slot<snapshots.length;slot++){
  const entries=snapshots[slot];if(!entries)return false;count+=entries.length;if(count>512)return false;
  for(let index=0;index<entries.length;index++){
   const entry=entries[index],field=entry[1];
   if(entry[0]==='stack'||!field||!hasOwn(field,'enumerable')||!hasOwn(field,'configurable')||typeof field.enumerable!=='boolean'||typeof field.configurable!=='boolean')return false;
   if(hasOwn(field,'value')){if(!hasOwn(field,'writable')||typeof field.writable!=='boolean'||hasOwn(field,'get')||hasOwn(field,'set'))return false;}
   else if(!hasOwn(field,'get')||!hasOwn(field,'set')||hasOwn(field,'writable'))return false;
  }
 }
 // The complete old guard has just qualified captured freeze/apply and both
 // numeric domains. Only new dense private arrays are shallow-frozen here;
 // original payload objects/functions/prototypes remain exactly as before.
 const plans=[];
 for(let slot=0;slot<snapshots.length;slot++){
  const entries=snapshots[slot],rows=[];let standardEnd=0;
  for(let index=0;index<entries.length;index++){
   const entry=entries[index],field=entry[1],data=hasOwn(field,'value');
   if(index>=standardEnd)standardEnd=privateExpectedStandardRunEnd(entries,index);
   rows[index]=apply(syntaxFreeze.value,originalObject,[[entry[0],data,field.enumerable,field.configurable,data?field.value:field.get,data?field.writable:field.set,standardEnd]]);
  }
  plans[slot]=apply(syntaxFreeze.value,originalObject,[rows]);
 }
 return apply(syntaxFreeze.value,originalObject,[plans]);
}
function expectedSamePrototype(owner,entries,rows){
 if(!(owner===arrayPrototype&&entries===arrayDescriptors&&rows===privateExpectedPlans[0]||owner===mapPrototype&&entries===mapDescriptors&&rows===privateExpectedPlans[1]||owner===setPrototype&&entries===setDescriptors&&rows===privateExpectedPlans[2]||owner===weakSetPrototype&&entries===weakSetDescriptors&&rows===privateExpectedPlans[3]||owner===syntaxStringPrototype&&entries===syntaxStrings&&rows===privateExpectedPlans[4]||owner===syntaxRegExpPrototype&&entries===syntaxRegexps&&rows===privateExpectedPlans[5]))return false;
 const names=keys(owner);if(names.length!==rows.length)return false;
 for(let index=0;index<names.length;index++){
  const end=rows[index][6];
  if(end){
   for(;index<end;index++){
    const row=rows[index],key=row[0];if(names[index]!==key)return false;
    const actual=descriptor(owner,key);if(!actual||!hasOwn(actual,'value'))return false;
    if(actual.enumerable!==false||actual.configurable!==true)return false;
    if(actual.value!==row[4]||actual.writable!==true)return false;
   }
   index--;continue;
  }
  const row=rows[index],key=row[0];if(names[index]!==key)return false;
  // Preserve the exact old per-key descriptor read, before the NEXT key test.
  const actual=descriptor(owner,key);if(!actual||hasOwn(actual,'value')!==row[1])return false;
  if(actual.enumerable!==row[2]||actual.configurable!==row[3])return false;
  if(row[1]){if(actual.value!==row[4]||actual.writable!==row[5])return false;}
  else if(!hasOwn(actual,'get')||!hasOwn(actual,'set')||actual.get!==row[4]||actual.set!==row[5])return false;
 }
 return true;
}

function expectedJsonIntrinsicsUnchanged(){
 if(!ordinaryNative)return false;for(let index=0;index<iteratorPins.length;index++){const pin=iteratorPins[index];if(!same(descriptor(pin.owner,'next'),pin.field))return false;}for(let index=0;index<objectPins.length;index++){const name=objectPins[index][0],field=objectPins[index][1];if(!same(descriptor(originalObject,name),field))return false;}
 return same(descriptor(originalArray,Symbol.species),species)&&same(descriptor(globalThis,'WeakSet'),globalWeakSet)&&expectedSamePrototype(weakSetPrototype,weakSetDescriptors,privateExpectedPlans[3])&&same(descriptor(globalThis,'JSON'),globalJson)&&same(descriptor(globalThis,'Object'),globalObject)&&same(descriptor(globalThis,'Array'),globalArray)&&same(descriptor(globalThis,'Map'),globalMap)&&same(descriptor(globalThis,'Set'),globalSet)&&same(descriptor(originalObject,'hasOwn'),objectHasOwn)&&same(descriptor(originalObject,'getOwnPropertyDescriptor'),objectDescriptor)&&same(descriptor(originalJson,'stringify'),stringify)&&originalObject.prototype===objectPrototype&&originalArray.prototype===arrayPrototype&&prototype(objectPrototype)===null&&prototype(arrayPrototype)===objectPrototype&&!descriptor(objectPrototype,'toJSON')&&!descriptor(arrayPrototype,'toJSON')&&expectedSamePrototype(arrayPrototype,arrayDescriptors,privateExpectedPlans[0])&&expectedSamePrototype(mapPrototype,mapDescriptors,privateExpectedPlans[1])&&expectedSamePrototype(setPrototype,setDescriptors,privateExpectedPlans[2]);
}

function expectedPathMembershipIntrinsicsUnchanged(){
 return !!(pathNative&&expectedJsonIntrinsicsUnchanged()&&same(descriptor(originalObject,'getPrototypeOf'),pathGetPrototypeOf)&&same(descriptor(globalThis,'Reflect'),pathReflect)&&same(descriptor(pathReflect.value,'ownKeys'),pathOwnKeys)&&same(descriptor(originalArray,'isArray'),pathIsArray)&&same(descriptor(types,'isProxy'),pathIsProxy)&&same(descriptor(globalThis,'WeakMap'),pathWeakMap)&&pathWeakMap.value.prototype===pathWeakPrototype&&same(descriptor(pathWeakPrototype,'has'),pathWeakHas));
}

function expectedNamespaceTraversalIntrinsicsUnchanged(){
 if(!traversalNative||!expectedPathMembershipIntrinsicsUnchanged()||!same(descriptor(traversalFunctionPrototype,'call'),traversalCall)||!same(descriptor(originalObject,'getOwnPropertyDescriptors'),traversalDescriptors)||!same(descriptor(pathReflect.value,'apply'),traversalApply)||!same(descriptor(mapPrototype,'entries'),traversalEntries)||prototype(traversalMapIterator.owner)!==traversalIteratorPrototype||descriptor(traversalMapIterator.owner,Symbol.iterator)||prototype(traversalIteratorPrototype)!==traversalIteratorParent||!same(descriptor(traversalIteratorPrototype,Symbol.iterator),traversalIteratorMethod))return false;
 // The old route calls entries.call; a function's own call hook or changed
 // prototype is also observable and therefore keeps the collected fallback.
 return prototype(traversalEntries.value)===traversalFunctionPrototype&&!descriptor(traversalEntries.value,'call')&&prototype(traversalMapIterator.field.value)===traversalFunctionPrototype&&!descriptor(traversalMapIterator.field.value,'call');
}

export function originalPrivateParserExpectedCommonIntrinsicsUnchanged(){
 if(!originalPrivateParserIngressUnchanged())return false;
 if(privateExpectedPlans===null){
  // A FALSE live result is never stored. Building data after TRUE performs no
  // callbacks, current-owner reflection or original-object mutations.
  if(!originalPrivateParserCommonIntrinsicsUnchanged())return false;
  privateExpectedPlans=makePrivateExpectedPlans();return true;
 }
 // FALSE here classifies only the private expected shape, not current state.
 // Every fallback call performs the COMPLETE original guard again.
 if(privateExpectedPlans===false)return originalPrivateParserCommonIntrinsicsUnchanged();
 return !!(syntaxNative&&expectedNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(globalThis,'String'),syntaxString)&&same(descriptor(globalThis,'RegExp'),syntaxRegExp)&&same(descriptor(originalObject,'freeze'),syntaxFreeze)&&same(descriptor(originalObject,'isFrozen'),syntaxIsFrozen)&&same(descriptor(originalObject,'defineProperty'),syntaxDefine)&&syntaxString.value.prototype===syntaxStringPrototype&&syntaxRegExp.value.prototype===syntaxRegExpPrototype&&prototype(syntaxStringPrototype)===objectPrototype&&prototype(syntaxRegExpPrototype)===objectPrototype&&expectedSamePrototype(syntaxStringPrototype,syntaxStrings,privateExpectedPlans[4])&&expectedSamePrototype(syntaxRegExpPrototype,syntaxRegexps,privateExpectedPlans[5])&&syntaxNumericPrototypeSafe()&&dataFreezeNative&&same(descriptor(originalObject,'freeze'),dataFreeze)&&same(descriptor(originalObject,'isFrozen'),dataIsFrozen)&&same(descriptor(pathWeakPrototype,'get'),dataWeakGet)&&same(descriptor(pathWeakPrototype,'set'),dataWeakSet)&&dataFreezeNumericSafe());
}

// Optional native numerical work storage, captured only at THIS trusted common
// initialization point. This proves no earlier birth, parser/type/owner fact or
// caller authority. Any uncertainty keeps the independent SHA's old arrays.
function parserUint32Native(value,name){return typeof value==='function'&&!pathIsProxy.value(value)&&apply(functionText,value,[])===`function ${name}() { [native code] }`;}
function parserUint32Data(owner,key){const field=descriptor(owner,key);return field&&hasOwn(field,'value')?field:null;}
function parserUint32Keys(owner,allowed){
 const names=keys(owner);if(names.length!==allowed.length)return null;
 for(let at=0;at<names.length;at++){let found=false;for(let index=0;index<allowed.length;index++)if(names[at]===allowed[index])found=true;if(!found)return null;}
 return names;
}
function captureParserUint32Storage(){
 // Keep optional requalification callback-free even in the old lazy-stack
 // compatibility domain. Unknown expected shape simply retains old arrays.
 if(!pathNative)return null;
 const snapshots=[arrayDescriptors,mapDescriptors,setDescriptors,weakSetDescriptors,syntaxStrings,syntaxRegexps];
 for(let at=0;at<snapshots.length;at++){const entries=snapshots[at];if(!entries)return null;for(let index=0;index<entries.length;index++)if(entries[index][0]==='stack')return null;}
 if(!types||typeof types!=='object'||pathIsProxy.value(types))return null;
 // Do not initialize 287's expected plans earlier than their original caller.
 if(!originalPrivateParserCommonIntrinsicsUnchanged())return null;
 const global=parserUint32Data(parserIngressRoot,'Uint32Array');
 if(!global||!parserUint32Native(global.value,'Uint32Array'))return null;
 const ctor=global.value,ctorKeys=parserUint32Keys(ctor,['length','name','prototype','BYTES_PER_ELEMENT']);if(!ctorKeys)return null;
 const length=parserUint32Data(ctor,'length'),name=parserUint32Data(ctor,'name'),pointee=parserUint32Data(ctor,'prototype'),bytes=parserUint32Data(ctor,'BYTES_PER_ELEMENT');
 if(!length||length.value!==3||!name||name.value!=='Uint32Array'||!pointee||!pointee.value||typeof pointee.value!=='object'||pathIsProxy.value(pointee.value)||pointee.writable||pointee.configurable||pointee.enumerable||!bytes||bytes.value!==4||bytes.writable||bytes.configurable||bytes.enumerable)return null;
 const concrete=pointee.value,concreteKeys=parserUint32Keys(concrete,['constructor','BYTES_PER_ELEMENT']);if(!concreteKeys)return null;
 const back=parserUint32Data(concrete,'constructor'),element=parserUint32Data(concrete,'BYTES_PER_ELEMENT');
 if(!back||back.value!==ctor||!element||element.value!==4||element.writable||element.configurable||element.enumerable)return null;
 const literalFunction=prototype(function(){}),sharedCtor=prototype(ctor),shared=prototype(concrete);
 if(!sharedCtor||!shared||pathIsProxy.value(sharedCtor)||pathIsProxy.value(shared)||!parserUint32Native(sharedCtor,'TypedArray')||prototype(sharedCtor)!==literalFunction||prototype(shared)!==objectPrototype)return null;
 const sharedPrototype=parserUint32Data(sharedCtor,'prototype'),size=descriptor(shared,'length');
 if(!sharedPrototype||sharedPrototype.value!==shared||sharedPrototype.writable||sharedPrototype.configurable||sharedPrototype.enumerable||!size||hasOwn(size,'value')||!hasOwn(size,'get')||!hasOwn(size,'set')||size.set!==undefined||!parserUint32Native(size.get,'get length')||prototype(size.get)!==literalFunction)return null;
 // Genuine native Number-length construction does not consult an iterable,
 // species, global ArrayBuffer, inherited index setter or a source object.
 const small=new ctor(8),large=new ctor(64);
 if(apply(size.get,small,[])!==8||apply(size.get,large,[])!==64||prototype(small)!==concrete||prototype(large)!==concrete)return null;
 const inputs=[0,2147483647,2147483648,4294967295,-1,4294967296,4294967297],expected=[0,2147483647,2147483648,4294967295,4294967295,0,1];
 for(let at=0;at<inputs.length;at++){small[at]=inputs[at];large[at]=inputs[at];if(small[at]!==expected[at]||large[at]!==expected[at])return null;}
 if(!originalPrivateParserCommonIntrinsicsUnchanged())return null;
 return {typeOwner:types,fields:[[parserIngressRoot,'Uint32Array',global],[ctor,'length',length],[ctor,'name',name],[ctor,'prototype',pointee],[ctor,'BYTES_PER_ELEMENT',bytes],[concrete,'constructor',back],[concrete,'BYTES_PER_ELEMENT',element],[sharedCtor,'prototype',sharedPrototype],[shared,'length',size]],parents:[[ctor,sharedCtor],[concrete,shared],[sharedCtor,literalFunction],[shared,objectPrototype],[size.get,literalFunction]],keys:[[ctor,ctorKeys],[concrete,concreteKeys]]};
}
// A negative is optional-feature birth eligibility, never a semantic refusal.
const parserUint32Storage=captureParserUint32Storage();
export function originalPrivateParserUint32WorkStorageUnchanged(){
 // This is ONLY typed-work eligibility. The SHA caller retains its complete
 // common entry/exit checks; fixed captured observers below never read stack.
 if(!originalPrivateParserIngressUnchanged()||!parserUint32Storage||types!==parserUint32Storage.typeOwner)return false;
 for(let at=0;at<parserUint32Storage.keys.length;at++){
  const row=parserUint32Storage.keys[at],names=keys(row[0]);if(names.length!==row[1].length)return false;
  for(let index=0;index<names.length;index++)if(names[index]!==row[1][index])return false;
 }
 for(let at=0;at<parserUint32Storage.parents.length;at++){const row=parserUint32Storage.parents[at];if(prototype(row[0])!==row[1])return false;}
 for(let at=0;at<parserUint32Storage.fields.length;at++){const row=parserUint32Storage.fields[at];if(!same(descriptor(row[0],row[1]),row[2]))return false;}
 return true;
}

// Reuse ONLY immutable expected-key facts and fresh key equality within ONE
// callback-free guard invocation. All old guards and descriptor reads remain.
let parserExpectedNonnumeric=null;
function parserExpectedNumericSubset(){
 // The private 287 plans are frozen own-data tuples, never caller evidence.
 for(let slot=0;slot<=4;slot+=4){
  const rows=privateExpectedPlans[slot];
  for(let at=0;at<rows.length;at++){const key=rows[at][0];if(typeof key==='string'){const value=+key;if(value>=0&&value<=9007199254740991&&value%1===0&&''+value===key)return false;}}
 }
 return true;
}
function parserObjectNumericSafe(){
 const names=keys(objectPrototype);
 for(let at=0;at<names.length;at++){const key=names[at];if(typeof key==='string'){const value=+key;if(value>=0&&value<=9007199254740991&&value%1===0&&''+value===key)return false;}}
 return true;
}
export function originalPrivateParserNumericCommonIntrinsicsUnchanged(){
 if(!originalPrivateParserIngressUnchanged())return false;
 // Cold first success and every unknown expected shape take the WHOLE old
 // route. No current success or refusal is retained across calls.
 if(privateExpectedPlans===null)return originalPrivateParserExpectedCommonIntrinsicsUnchanged();
 if(privateExpectedPlans===false)return originalPrivateParserExpectedCommonIntrinsicsUnchanged();
 if(parserExpectedNonnumeric===null)parserExpectedNonnumeric=parserExpectedNumericSubset();
 if(!parserExpectedNonnumeric)return originalPrivateParserExpectedCommonIntrinsicsUnchanged();
 // Fresh full Array/String key equality above proves their numeric absence.
 // From this Object scan to the data-freeze tail only captured native fixed-
 // owner descriptor reads/primitive comparisons occur; no callback can mutate
 // those same owners between these observations in the trusted stock domain.
 return !!(syntaxNative&&expectedNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(globalThis,'String'),syntaxString)&&same(descriptor(globalThis,'RegExp'),syntaxRegExp)&&same(descriptor(originalObject,'freeze'),syntaxFreeze)&&same(descriptor(originalObject,'isFrozen'),syntaxIsFrozen)&&same(descriptor(originalObject,'defineProperty'),syntaxDefine)&&syntaxString.value.prototype===syntaxStringPrototype&&syntaxRegExp.value.prototype===syntaxRegExpPrototype&&prototype(syntaxStringPrototype)===objectPrototype&&prototype(syntaxRegExpPrototype)===objectPrototype&&expectedSamePrototype(syntaxStringPrototype,syntaxStrings,privateExpectedPlans[4])&&expectedSamePrototype(syntaxRegExpPrototype,syntaxRegexps,privateExpectedPlans[5])&&parserObjectNumericSafe()&&dataFreezeNative&&same(descriptor(originalObject,'freeze'),dataFreeze)&&same(descriptor(originalObject,'isFrozen'),dataIsFrozen)&&same(descriptor(pathWeakPrototype,'get'),dataWeakGet)&&same(descriptor(pathWeakPrototype,'set'),dataWeakSet));
}


// Optional native descriptor collection; all live comparisons remain fresh.
// The fixed private owner list is data, never a retained current verdict.
const batchedDescriptorOwners=[arrayPrototype,mapPrototype,setPrototype,weakSetPrototype,syntaxStringPrototype,syntaxRegExpPrototype];
function batchedExpectedSamePrototype(owner,entries,rows){
 if(!(owner===arrayPrototype&&entries===arrayDescriptors&&rows===privateExpectedPlans[0]||owner===mapPrototype&&entries===mapDescriptors&&rows===privateExpectedPlans[1]||owner===setPrototype&&entries===setDescriptors&&rows===privateExpectedPlans[2]||owner===weakSetPrototype&&entries===weakSetDescriptors&&rows===privateExpectedPlans[3]||owner===syntaxStringPrototype&&entries===syntaxStrings&&rows===privateExpectedPlans[4]||owner===syntaxRegExpPrototype&&entries===syntaxRegexps&&rows===privateExpectedPlans[5]))return false;
 const names=keys(owner);if(names.length!==rows.length)return expectedSamePrototype(owner,entries,rows);
 // Unknown/reordered keys keep the complete old helper. This preflight never
 // obtains the descriptor of any newly attached native lazy stack field.
 for(let index=0;index<names.length;index++)if(names[index]!==rows[index][0])return expectedSamePrototype(owner,entries,rows);
 // The caller freshly qualified this captured native and all six fixed owners.
 // All keys are now the immutable expected set (which excludes stack).
 const fields=apply(traversalDescriptors.value,originalObject,[owner]);
 for(let index=0;index<names.length;index++){
  const row=rows[index],key=row[0];
  const actual=fields[key];if(!actual||hasOwn(actual,'value')!==row[1])return false;
  if(actual.enumerable!==row[2]||actual.configurable!==row[3])return false;
  if(row[1]){if(actual.value!==row[4]||actual.writable!==row[5])return false;}
  else if(!hasOwn(actual,'get')||!hasOwn(actual,'set')||actual.get!==row[4]||actual.set!==row[5])return false;
 }
 return true;
}

function batchedExpectedJsonIntrinsicsUnchanged(){
 if(!ordinaryNative)return false;for(let index=0;index<iteratorPins.length;index++){const pin=iteratorPins[index];if(!same(descriptor(pin.owner,'next'),pin.field))return false;}for(let index=0;index<objectPins.length;index++){const name=objectPins[index][0],field=objectPins[index][1];if(!same(descriptor(originalObject,name),field))return false;}
 return same(descriptor(originalArray,Symbol.species),species)&&same(descriptor(globalThis,'WeakSet'),globalWeakSet)&&batchedExpectedSamePrototype(weakSetPrototype,weakSetDescriptors,privateExpectedPlans[3])&&same(descriptor(globalThis,'JSON'),globalJson)&&same(descriptor(globalThis,'Object'),globalObject)&&same(descriptor(globalThis,'Array'),globalArray)&&same(descriptor(globalThis,'Map'),globalMap)&&same(descriptor(globalThis,'Set'),globalSet)&&same(descriptor(originalObject,'hasOwn'),objectHasOwn)&&same(descriptor(originalObject,'getOwnPropertyDescriptor'),objectDescriptor)&&same(descriptor(originalJson,'stringify'),stringify)&&originalObject.prototype===objectPrototype&&originalArray.prototype===arrayPrototype&&prototype(objectPrototype)===null&&prototype(arrayPrototype)===objectPrototype&&!descriptor(objectPrototype,'toJSON')&&!descriptor(arrayPrototype,'toJSON')&&batchedExpectedSamePrototype(arrayPrototype,arrayDescriptors,privateExpectedPlans[0])&&batchedExpectedSamePrototype(mapPrototype,mapDescriptors,privateExpectedPlans[1])&&batchedExpectedSamePrototype(setPrototype,setDescriptors,privateExpectedPlans[2]);
}

function batchedExpectedPathMembershipIntrinsicsUnchanged(){
 return !!(pathNative&&batchedExpectedJsonIntrinsicsUnchanged()&&same(descriptor(originalObject,'getPrototypeOf'),pathGetPrototypeOf)&&same(descriptor(globalThis,'Reflect'),pathReflect)&&same(descriptor(pathReflect.value,'ownKeys'),pathOwnKeys)&&same(descriptor(originalArray,'isArray'),pathIsArray)&&same(descriptor(types,'isProxy'),pathIsProxy)&&same(descriptor(globalThis,'WeakMap'),pathWeakMap)&&pathWeakMap.value.prototype===pathWeakPrototype&&same(descriptor(pathWeakPrototype,'has'),pathWeakHas));
}

function batchedExpectedNamespaceTraversalIntrinsicsUnchanged(){
 if(!traversalNative||!batchedExpectedPathMembershipIntrinsicsUnchanged()||!same(descriptor(traversalFunctionPrototype,'call'),traversalCall)||!same(descriptor(originalObject,'getOwnPropertyDescriptors'),traversalDescriptors)||!same(descriptor(pathReflect.value,'apply'),traversalApply)||!same(descriptor(mapPrototype,'entries'),traversalEntries)||prototype(traversalMapIterator.owner)!==traversalIteratorPrototype||descriptor(traversalMapIterator.owner,Symbol.iterator)||prototype(traversalIteratorPrototype)!==traversalIteratorParent||!same(descriptor(traversalIteratorPrototype,Symbol.iterator),traversalIteratorMethod))return false;
 // The old route calls entries.call; a function's own call hook or changed
 // prototype is also observable and therefore keeps the collected fallback.
 return prototype(traversalEntries.value)===traversalFunctionPrototype&&!descriptor(traversalEntries.value,'call')&&prototype(traversalMapIterator.field.value)===traversalFunctionPrototype&&!descriptor(traversalMapIterator.field.value,'call');
}

export function originalPrivateParserDescriptorCommonIntrinsicsUnchanged(){
 if(!originalPrivateParserIngressUnchanged())return false;
 // Extra optional work eligibility observes only fixed owners through captured
 // natives. Failure retains the complete old guard, including its fallbacks.
 if(!traversalNative||!same(descriptor(originalObject,'getOwnPropertyDescriptors'),traversalDescriptors)||!same(descriptor(types,'isProxy'),pathIsProxy))return originalPrivateParserNumericCommonIntrinsicsUnchanged();
 for(let slot=0;slot<batchedDescriptorOwners.length;slot++)if(pathIsProxy.value(batchedDescriptorOwners[slot]))return originalPrivateParserNumericCommonIntrinsicsUnchanged();
 // Cold first success and every unknown expected shape take the WHOLE old
 // route. No current success or refusal is retained across calls.
 if(privateExpectedPlans===null)return originalPrivateParserExpectedCommonIntrinsicsUnchanged();
 if(privateExpectedPlans===false)return originalPrivateParserExpectedCommonIntrinsicsUnchanged();
 if(parserExpectedNonnumeric===null)parserExpectedNonnumeric=parserExpectedNumericSubset();
 if(!parserExpectedNonnumeric)return originalPrivateParserExpectedCommonIntrinsicsUnchanged();
 // Fresh full Array/String key equality above proves their numeric absence.
 // From this Object scan to the data-freeze tail only captured native fixed-
 // owner descriptor reads/primitive comparisons occur; no callback can mutate
 // those same owners between these observations in the trusted stock domain.
 return !!(syntaxNative&&batchedExpectedNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(globalThis,'String'),syntaxString)&&same(descriptor(globalThis,'RegExp'),syntaxRegExp)&&same(descriptor(originalObject,'freeze'),syntaxFreeze)&&same(descriptor(originalObject,'isFrozen'),syntaxIsFrozen)&&same(descriptor(originalObject,'defineProperty'),syntaxDefine)&&syntaxString.value.prototype===syntaxStringPrototype&&syntaxRegExp.value.prototype===syntaxRegExpPrototype&&prototype(syntaxStringPrototype)===objectPrototype&&prototype(syntaxRegExpPrototype)===objectPrototype&&batchedExpectedSamePrototype(syntaxStringPrototype,syntaxStrings,privateExpectedPlans[4])&&batchedExpectedSamePrototype(syntaxRegExpPrototype,syntaxRegexps,privateExpectedPlans[5])&&parserObjectNumericSafe()&&dataFreezeNative&&same(descriptor(originalObject,'freeze'),dataFreeze)&&same(descriptor(originalObject,'isFrozen'),dataIsFrozen)&&same(descriptor(pathWeakPrototype,'get'),dataWeakGet)&&same(descriptor(pathWeakPrototype,'set'),dataWeakSet));
}

// Only immutable EXPECTED flags determine these runs. Live keys, descriptors,
// own-value checks and comparison order are still observed on every call.
function privateExpectedStandardRunEnd(entries,start){
 let end=start;
 while(end<entries.length){
  const field=entries[end][1];
  if(!hasOwn(field,'value')||field.enumerable!==false||field.configurable!==true||field.writable!==true)break;
  end++;
 }
 return end>start?end:0;
}

// A digest-only sibling: existing guards, bootstrap and public copier retain
// their original contracts. Extra qualification uses only trusted captures;
// the copy still performs every dynamic input/Buffer/descriptor operation.
// The returned data carries no source, type, owner or proof authority.
export function copyOriginalDigestMetadata(value,fallback,ordinal){
 if(!pathNative||!syntaxNative)return fallback(value);
 const fail=reason=>{throw new TypeError('source links: '+reason);};
 function privateCreate(object){
  if(object!==originalObject)return false;
  const create=descriptor(originalObject,'create');
  return !!(create&&hasOwn(create,'value')&&typeof create.value==='function'&&!pathIsProxy.value(create.value)&&apply(functionText,create.value,[])==='function create() { [native code] }');
 }
 function nativeDefine(object){
  if(object!==originalObject)return false;
  const define=descriptor(originalObject,'defineProperty');
  return !!(define&&hasOwn(define,'value')&&define.value===syntaxDefine.value);
 }
 function copyMetadata(value,{cells=200000,bytes=4194304,preserveKeyOrder=false}={},depth=0,active=new Set(),budget=null){
  budget??={cells,bytes};if(--budget.cells<0||depth>160)fail('metadata budget exhausted');
  if(value===null||value===undefined||typeof value==='boolean'||typeof value==='bigint')return value;
  if(typeof value==='number'){if(!Number.isSafeInteger(value))fail('non-integer metadata number');return value;}
  if(typeof value==='string'){budget.bytes-=Buffer.byteLength(value);if(budget.bytes<0)fail('metadata byte budget exhausted');return value;}
  if(!value||typeof value!=='object'||types.isProxy(value)||active.has(value))fail('metadata must be acyclic data');
  const prototype=Object.getPrototypeOf(value);
  if(prototype!==Object.prototype&&prototype!==null&&prototype!==Array.prototype)fail('unexpected metadata prototype');
  const descriptors=Object.getOwnPropertyDescriptors(value),keys=Reflect.ownKeys(descriptors),array=Array.isArray(value),ownIndexes=array?{__proto__:null}:null;
  for(const key of keys){const descriptor=descriptors[key];if(typeof key!=='string'||!Object.hasOwn(descriptor,'value')||(!descriptor.enumerable&&!(array&&key==='length')))fail('accessor, symbol or hidden metadata');if(array)ownIndexes[key]=true;}
  active.add(value);let result;
  if(array){
   const length=descriptors.length.value;if(!Number.isSafeInteger(length)||length<0||length>budget.cells)fail('array metadata budget exhausted');
   if(keys.length!==length+1)fail('array metadata holes or extra properties');
   result=[];for(let index=0;index<length;index++){const key=String(index);if(ownIndexes[index]!==true)fail('array metadata hole');const descriptor=descriptors[key];if(!descriptor)fail('array metadata hole');result.push(copyMetadata(descriptor.value,{preserveKeyOrder},depth+1,active,budget));}
  }else{
   // The actual legacy Object lookup happens once at its original position.
   // A foreign/proxy receiver is never inspected by optional qualification.
   const createReceiver=Object;let privateTarget;
   {const Object=createReceiver;privateTarget=privateCreate(Object);result=Object.create(null);}
   for(const key of preserveKeyOrder?keys:keys.sort(ordinal)){
    const objectReceiver=Object;
    {const Object=objectReceiver;
    if(privateTarget&&typeof key==='string'&&nativeDefine(Object)){
     // Select the actual old receiver/callee BEFORE any child callback.
     const receiver=Object,selected=receiver.defineProperty;
     const child=copyMetadata(descriptors[key].value,{preserveKeyOrder:preserveKeyOrder||key==='copyCertificate'},depth+1,active,budget);
     if(!descriptor(objectPrototype,'get')&&!descriptor(objectPrototype,'set'))result[key]=child;
     else{
      // Descriptor conversion can observe inherited get/set after the child.
      // Keep the selected callee even if that child rebound global Object.
      privateTarget=false;
      apply(selected,receiver,[result,key,{value:child,enumerable:true,writable:true,configurable:true}]);
     }
    }else{
     // A caller operation can retain this output, even if native identities
     // are restored before a later field. Privacy is never reacquired.
     privateTarget=false;
     Object.defineProperty(result,key,{value:copyMetadata(descriptors[key].value,{preserveKeyOrder:preserveKeyOrder||key==='copyCertificate'},depth+1,active,budget),enumerable:true,writable:true,configurable:true});
    }
    }
   }
  }
  active.delete(value);return result;
 }
 return copyMetadata(value);
}


// Private internal-source digest copy; derived from the complete 645 kernel.
export function createOriginalDigestMetadataCopierForInternalSources(fallback,ordinal){
 if(!pathNative||!syntaxNative)return fallback;
 return function copyMetadata(value){
 const fail=reason=>{throw new TypeError('source links: '+reason);};
 let qualifiedCreate=null;
 function privateCreate(object){
  if(object!==originalObject)return false;
  const create=descriptor(originalObject,'create');
  if(!create||!hasOwn(create,'value')||typeof create.value!=='function')return false;
  if(create.value===qualifiedCreate)return true;
  if(pathIsProxy.value(create.value)||apply(functionText,create.value,[])!=='function create() { [native code] }')return false;
  qualifiedCreate=create.value;return true;
 }
 function nativeDefine(object){
  if(object!==originalObject)return false;
  const define=descriptor(originalObject,'defineProperty');
  return !!(define&&hasOwn(define,'value')&&define.value===syntaxDefine.value);
 }
 function copyMetadata(value,{cells=200000,bytes=4194304,preserveKeyOrder=false}={},depth=0,active=new Set(),budget=null){
  budget??={cells,bytes};if(--budget.cells<0||depth>160)fail('metadata budget exhausted');
  if(value===null||value===undefined||typeof value==='boolean'||typeof value==='bigint')return value;
  if(typeof value==='number'){if(!Number.isSafeInteger(value))fail('non-integer metadata number');return value;}
  if(typeof value==='string'){budget.bytes-=Buffer.byteLength(value);if(budget.bytes<0)fail('metadata byte budget exhausted');return value;}
  if(!value||typeof value!=='object'||types.isProxy(value)||active.has(value))fail('metadata must be acyclic data');
  const prototype=Object.getPrototypeOf(value);
  if(prototype!==Object.prototype&&prototype!==null&&prototype!==Array.prototype)fail('unexpected metadata prototype');
  const descriptors=Object.getOwnPropertyDescriptors(value),keys=Reflect.ownKeys(descriptors),array=Array.isArray(value),ownIndexes=array?{__proto__:null}:null;
  for(const key of keys){const descriptor=descriptors[key];if(typeof key!=='string'||!Object.hasOwn(descriptor,'value')||(!descriptor.enumerable&&!(array&&key==='length')))fail('accessor, symbol or hidden metadata');if(array)ownIndexes[key]=true;}
  active.add(value);let result;
  if(array){
   const length=descriptors.length.value;if(!Number.isSafeInteger(length)||length<0||length>budget.cells)fail('array metadata budget exhausted');
   if(keys.length!==length+1)fail('array metadata holes or extra properties');
   result=[];for(let index=0;index<length;index++){const key=String(index);if(ownIndexes[index]!==true)fail('array metadata hole');const descriptor=descriptors[key];if(!descriptor)fail('array metadata hole');result.push(copyMetadata(descriptor.value,{preserveKeyOrder},depth+1,active,budget));}
  }else{
   // The actual legacy Object lookup happens once at its original position.
   // A foreign/proxy receiver is never inspected by optional qualification.
   const createReceiver=Object;let privateTarget;
   {const Object=createReceiver;privateTarget=privateCreate(Object);result=Object.create(null);}
   for(const key of preserveKeyOrder?keys:keys.sort(ordinal)){
    const objectReceiver=Object;
    {const Object=objectReceiver;
    if(privateTarget&&typeof key==='string'&&nativeDefine(Object)){
     // Select the actual old receiver/callee BEFORE any child callback.
     const receiver=Object,selected=receiver.defineProperty;
     const child=copyMetadata(descriptors[key].value,{preserveKeyOrder:preserveKeyOrder||key==='copyCertificate'},depth+1,active,budget);
     if(!descriptor(objectPrototype,'get')&&!descriptor(objectPrototype,'set'))result[key]=child;
     else{
      // Descriptor conversion can observe inherited get/set after the child.
      // Keep the selected callee even if that child rebound global Object.
      privateTarget=false;
      apply(selected,receiver,[result,key,{value:child,enumerable:true,writable:true,configurable:true}]);
     }
    }else{
     // A caller operation can retain this output, even if native identities
     // are restored before a later field. Privacy is never reacquired.
     privateTarget=false;
     Object.defineProperty(result,key,{value:copyMetadata(descriptors[key].value,{preserveKeyOrder:preserveKeyOrder||key==='copyCertificate'},depth+1,active,budget),enumerable:true,writable:true,configurable:true});
    }
    }
   }
  }
  active.delete(value);return result;
 }
 return copyMetadata(value);
 };
}

// Private fixed-native-output siblings; original guards and captures stay exact.
function kindBatchedExpectedSamePrototype(owner,entries,rows){
 if(!(owner===arrayPrototype&&entries===arrayDescriptors&&rows===privateExpectedPlans[0]||owner===mapPrototype&&entries===mapDescriptors&&rows===privateExpectedPlans[1]||owner===setPrototype&&entries===setDescriptors&&rows===privateExpectedPlans[2]||owner===weakSetPrototype&&entries===weakSetDescriptors&&rows===privateExpectedPlans[3]||owner===syntaxStringPrototype&&entries===syntaxStrings&&rows===privateExpectedPlans[4]||owner===syntaxRegExpPrototype&&entries===syntaxRegexps&&rows===privateExpectedPlans[5]))return false;
 const names=keys(owner);if(names.length!==rows.length)return expectedSamePrototype(owner,entries,rows);
 for(let index=0;index<names.length;index++)if(names[index]!==rows[index][0])return expectedSamePrototype(owner,entries,rows);
 // Both captured descriptor operations must retain their original output realm.
 // The complete key census excludes lazy stack fields before any descriptor.
 if(prototype(objectHasOwn)!==objectPrototype||prototype(traversalDescriptors.value)!==prototype(objectDescriptor.value)||prototype(objectPrototype)!==null||descriptor(objectPrototype,'writable'))return expectedSamePrototype(owner,entries,rows);
 for(let index=0;index<names.length;index++){
  const row=rows[index],actual=descriptor(owner,names[index]);if(!actual)return false;
  const writable=actual.writable;if((writable!==undefined)!==row[1]||actual.enumerable!==row[2]||actual.configurable!==row[3])return false;
  if(row[1]){if(actual.value!==row[4]||writable!==row[5])return false;}
  else if(actual.get!==row[4]||actual.set!==row[5])return false;
 }
 return true;
}

function kindBatchedExpectedJsonIntrinsicsUnchanged(){
 if(!ordinaryNative)return false;for(let index=0;index<iteratorPins.length;index++){const pin=iteratorPins[index];if(!same(descriptor(pin.owner,'next'),pin.field))return false;}for(let index=0;index<objectPins.length;index++){const name=objectPins[index][0],field=objectPins[index][1];if(!same(descriptor(originalObject,name),field))return false;}
 return same(descriptor(originalArray,Symbol.species),species)&&same(descriptor(globalThis,'WeakSet'),globalWeakSet)&&kindBatchedExpectedSamePrototype(weakSetPrototype,weakSetDescriptors,privateExpectedPlans[3])&&same(descriptor(globalThis,'JSON'),globalJson)&&same(descriptor(globalThis,'Object'),globalObject)&&same(descriptor(globalThis,'Array'),globalArray)&&same(descriptor(globalThis,'Map'),globalMap)&&same(descriptor(globalThis,'Set'),globalSet)&&same(descriptor(originalObject,'hasOwn'),objectHasOwn)&&same(descriptor(originalObject,'getOwnPropertyDescriptor'),objectDescriptor)&&same(descriptor(originalJson,'stringify'),stringify)&&originalObject.prototype===objectPrototype&&originalArray.prototype===arrayPrototype&&prototype(objectPrototype)===null&&prototype(arrayPrototype)===objectPrototype&&!descriptor(objectPrototype,'toJSON')&&!descriptor(arrayPrototype,'toJSON')&&kindBatchedExpectedSamePrototype(arrayPrototype,arrayDescriptors,privateExpectedPlans[0])&&kindBatchedExpectedSamePrototype(mapPrototype,mapDescriptors,privateExpectedPlans[1])&&kindBatchedExpectedSamePrototype(setPrototype,setDescriptors,privateExpectedPlans[2]);
}

function kindBatchedExpectedPathMembershipIntrinsicsUnchanged(){
 return !!(pathNative&&kindBatchedExpectedJsonIntrinsicsUnchanged()&&same(descriptor(originalObject,'getPrototypeOf'),pathGetPrototypeOf)&&same(descriptor(globalThis,'Reflect'),pathReflect)&&same(descriptor(pathReflect.value,'ownKeys'),pathOwnKeys)&&same(descriptor(originalArray,'isArray'),pathIsArray)&&same(descriptor(types,'isProxy'),pathIsProxy)&&same(descriptor(globalThis,'WeakMap'),pathWeakMap)&&pathWeakMap.value.prototype===pathWeakPrototype&&same(descriptor(pathWeakPrototype,'has'),pathWeakHas));
}

function kindBatchedExpectedNamespaceTraversalIntrinsicsUnchanged(){
 if(!traversalNative||!kindBatchedExpectedPathMembershipIntrinsicsUnchanged()||!same(descriptor(traversalFunctionPrototype,'call'),traversalCall)||!same(descriptor(originalObject,'getOwnPropertyDescriptors'),traversalDescriptors)||!same(descriptor(pathReflect.value,'apply'),traversalApply)||!same(descriptor(mapPrototype,'entries'),traversalEntries)||prototype(traversalMapIterator.owner)!==traversalIteratorPrototype||descriptor(traversalMapIterator.owner,Symbol.iterator)||prototype(traversalIteratorPrototype)!==traversalIteratorParent||!same(descriptor(traversalIteratorPrototype,Symbol.iterator),traversalIteratorMethod))return false;
 // The old route calls entries.call; a function's own call hook or changed
 // prototype is also observable and therefore keeps the collected fallback.
 return prototype(traversalEntries.value)===traversalFunctionPrototype&&!descriptor(traversalEntries.value,'call')&&prototype(traversalMapIterator.field.value)===traversalFunctionPrototype&&!descriptor(traversalMapIterator.field.value,'call');
}


// Optional fresh fixed-owner descriptor collection. Reuse only the existing
// immutable expected plans; this API never initializes or warms parser state.
// Every global lookup and every original guard boundary remains independent.
function descriptorBatchingReady(){
 if(!privateExpectedPlans||!traversalNative||!parserUint32Storage||types!==parserUint32Storage.typeOwner||pathIsProxy.value(types)||!same(descriptor(originalObject,'getOwnPropertyDescriptors'),traversalDescriptors)||!same(descriptor(types,'isProxy'),pathIsProxy))return false;
 for(let slot=0;slot<batchedDescriptorOwners.length;slot++)if(pathIsProxy.value(batchedDescriptorOwners[slot]))return false;
 return true;
}
export function originalBatchedJsonIntrinsicsUnchanged(){
 return descriptorBatchingReady()?kindBatchedExpectedJsonIntrinsicsUnchanged():originalJsonIntrinsicsUnchanged();
}
export function originalBatchedNamespaceTraversalIntrinsicsUnchanged(){
 return descriptorBatchingReady()?kindBatchedExpectedNamespaceTraversalIntrinsicsUnchanged():originalNamespaceTraversalIntrinsicsUnchanged();
}
export function originalBatchedDataFreezeIntrinsicsUnchanged(){
 return !!(dataFreezeNative&&originalBatchedNamespaceTraversalIntrinsicsUnchanged()&&same(descriptor(originalObject,'freeze'),dataFreeze)&&same(descriptor(originalObject,'isFrozen'),dataIsFrozen)&&same(descriptor(pathWeakPrototype,'get'),dataWeakGet)&&same(descriptor(pathWeakPrototype,'set'),dataWeakSet)&&dataFreezeNumericSafe());
}
