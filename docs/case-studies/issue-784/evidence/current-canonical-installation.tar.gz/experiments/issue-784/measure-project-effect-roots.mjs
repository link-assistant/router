// Finite lexical-cost comparison on complete current physical Router sources.
// No semantic/executable/parity or whole-project speed qualification is made.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {resolveModuleGraph} from '../../tools/translation/project.mjs';
import {createMatchesMacroContext,originalProjectEffectRootNames} from '../../tools/translation/matches-macro-context.mjs';
import {PRODUCTION_PROFILE} from '../../tools/translation/cfg-profile.mjs';

const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const paths=execFileSync('git',['ls-files','-z','--','rust/src'],{maxBuffer:1024*1024}).toString('utf8').split('\0').filter(path=>path.endsWith('.rs'));
assert.ok(paths.length>0&&paths.length<=2048);
const head=execFileSync('git',['rev-parse','HEAD'],{maxBuffer:4096}).toString('ascii').trim();
function originalRoots(graph){
  return new Set(graph.modules.flatMap(module=>[
    ...module.path.filter(name=>['std','tokio','serde_json'].includes(name)),
    ...module.items.filter(item=>item.term==='mod'&&['std','tokio','serde_json'].includes(item.name)).map(item=>item.name),
  ]));
}
function measure(run){
  const start=performance.now();let total=0;
  for(let iteration=0;iteration<128;iteration++)total+=run().size;
  return {milliseconds:performance.now()-start,total};
}
for(const entry of ['rust/src/config.rs','rust/src/translation_core.rs']){
  console.log(JSON.stringify({stage:'start',entry,head,node:process.version}));
  const sources=new Map();let totalBytes=0;
  const graph=resolveModuleGraph({entry,paths,compilationProfile:PRODUCTION_PROFILE,readSource(path){
    const bytes=readFileSync(path);assert.ok(bytes.length<=2*1024*1024);totalBytes+=bytes.length;assert.ok(totalBytes<=8*1024*1024);
    const source=bytes.toString('utf8');assert.ok(Buffer.from(source).equals(bytes));sources.set(path,{bytes:bytes.length,sha256:hash(bytes)});return source;
  }});
  console.log(JSON.stringify({stage:'graph',entry,modules:graph.modules.length,items:graph.modules.reduce((sum,module)=>sum+module.items.length,0),sourceBytes:totalBytes,diagnostics:graph.diagnostics.length}));
  const context=createMatchesMacroContext({modules:graph.modules,compilationProfile:PRODUCTION_PROFILE});
  assert.deepEqual(new Set(originalProjectEffectRootNames(context)),originalRoots(graph));
  const rounds=[];
  for(let round=0;round<4;round++){
    const runs=round%2?['issued','original']:['original','issued'],row={};
    for(const kind of runs)row[kind]=measure(kind==='original'?()=>originalRoots(graph):()=>new Set(originalProjectEffectRootNames(context)));
    assert.equal(row.original.total,row.issued.total);rounds.push(row);
  }
  for(const [path,pin]of sources)assert.deepEqual({bytes:readFileSync(path).length,sha256:hash(readFileSync(path))},pin);
  console.log(JSON.stringify({stage:'complete',entry,head,node:process.version,compilationProfile:PRODUCTION_PROFILE,deriveDependencies:null,sources:[...sources].map(([path,pin])=>({path,...pin})),modules:graph.modules.length,items:graph.modules.reduce((sum,module)=>sum+module.items.length,0),iterationsPerRound:128,rounds,semanticAuthority:false,runtimeParity:false,wholeProjectSpeedQualified:false}));
}
