import test from 'node:test';
import assert from 'node:assert/strict';
import {Buffer} from 'node:buffer';
import {readFileSync} from 'node:fs';
import {nativeTarHeaderChecksum} from '../native-tar-header-checksum.mjs';
import {deriveTarHeaderChecksum} from '../prepare-tar-header-checksum.mjs';

test('native TAR checksum covers every byte and uses spaces for its checksum field',()=>{
 for(const byte of [0,1,7,32,127,128,255]){
  const header=Buffer.alloc(512,byte);
  assert.equal(nativeTarHeaderChecksum(header),504*byte+8*32);
  header.fill(255,148,156);
  assert.equal(nativeTarHeaderChecksum(header),504*byte+8*32);
 }
 const header=Buffer.alloc(512);
 header[0]=3;header[147]=5;header[156]=7;header[511]=11;
 assert.equal(nativeTarHeaderChecksum(header),282);
 for(const input of [Buffer.alloc(511),Buffer.alloc(513),new Uint8Array(512),[],null,new Proxy(Buffer.alloc(512),{})])
  assert.equal(nativeTarHeaderChecksum(input),null);
});

test('custom reduce callbacks and getters retain the complete original invocation',()=>{
 const header=Buffer.alloc(512,1),typed=Object.getPrototypeOf(Uint8Array.prototype);
 const descriptor=Object.getOwnPropertyDescriptor(typed,'reduce');
 let calls=0,cells=0;
 try{
  Object.defineProperty(typed,'reduce',{...descriptor,value:function(callback,initial){
   calls++;
   return Reflect.apply(descriptor.value,this,[(sum,byte,index,owner)=>{cells++;return callback(sum,byte,index,owner);},initial]);
  }});
  const result=nativeTarHeaderChecksum(header)??header.reduce((sum,byte,index)=>sum+(index>=148&&index<156?32:byte),0);
  assert.equal(result,760);assert.equal(calls,1);assert.equal(cells,512);
 }finally{Object.defineProperty(typed,'reduce',descriptor);}
 let reads=0;
 Object.defineProperty(header,'reduce',{get(){reads++;return descriptor.value;},configurable:true});
 assert.equal(nativeTarHeaderChecksum(header),null);assert.equal(reads,0);
 assert.equal(nativeTarHeaderChecksum(header)??header.reduce((sum,byte,index)=>sum+(index>=148&&index<156?32:byte),0),760);
 assert.equal(reads,1);
 delete header.reduce;
 assert.equal(nativeTarHeaderChecksum(header),760);
});

test('complete checksum source proposal reproduces installed consumers and rejects changed originals',{timeout:60000},()=>{
 const read=path=>readFileSync(new URL('../'+path,import.meta.url));
 const archive=read('source-profiles/tar-header-checksum/complete-original-inputs.json.gz');
 const template=read('source-profiles/tar-header-checksum/native-checksum.mjs.txt').toString('utf8');
 const result=deriveTarHeaderChecksum({archive,template});
 for(const row of [...result.files,result.helper])assert.equal(readFileSync(new URL('../../../'+row.path,import.meta.url),'utf8'),row.text);
 for(const row of result.files){assert.equal(row.inverse,row.source);assert.deepEqual(row.trace.map(stage=>stage.phase),['language','repository']);}
 const corrupt=Buffer.from(archive);corrupt[corrupt.length-9]^=1;
 assert.throws(()=>deriveTarHeaderChecksum({archive:corrupt,template}),/original checksum sources/);
 assert.equal(result.sourceVerdictsCached,false);assert.equal(result.qualified,false);
});
