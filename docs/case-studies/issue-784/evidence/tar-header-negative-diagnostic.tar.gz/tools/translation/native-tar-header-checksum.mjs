// Native byte calculation only. No archive, source or proof is retained.
import {Buffer} from 'node:buffer';
import {types} from 'node:util';
import {originalCapturedFunctionSource} from './original-json-intrinsics.mjs';

const get=Object.getOwnPropertyDescriptor,parent=Object.getPrototypeOf,apply=Reflect.apply;
const isProxy=types.isProxy;
const native=(value,name)=>originalCapturedFunctionSource(value)==='function '+name+'() { [native code] }';
let originals=null;
if(native(get,'getOwnPropertyDescriptor')&&native(parent,'getPrototypeOf')&&native(apply,'apply')&&native(isProxy,'isProxy')&&!isProxy(Buffer)){
 const arrayBuffer=get(globalThis,'ArrayBuffer')?.value;
 const isView=arrayBuffer&&!isProxy(arrayBuffer)?get(arrayBuffer,'isView')?.value:null;
 const field=get(Buffer,'prototype'),buffer=field?.value;
 if(buffer&&!isProxy(buffer)){
  const bytes=parent(buffer),typed=bytes&&!isProxy(bytes)?parent(bytes):null;
  if(typed&&!isProxy(typed)){
   const reduce=get(typed,'reduce'),length=get(typed,'length');
   if(native(isView,'isView')&&reduce&&native(reduce.value,'reduce')&&length&&native(length.get,'get length')&&!get(buffer,'reduce')&&!get(bytes,'reduce'))
    originals={buffer,bytes,typed,reduce:reduce.value,length:length.get,isView};
  }
 }
}

// null selects the caller's complete original expression. Descriptor probes
// never invoke a custom reduce getter, and proxies never enter the byte loop.
export function nativeTarHeaderChecksum(header){
 const old=originals;
 if(!old||!old.isView(header)||parent(header)!==old.buffer||parent(old.buffer)!==old.bytes||parent(old.bytes)!==old.typed)return null;
 if(get(header,'reduce')||get(old.buffer,'reduce')||get(old.bytes,'reduce')||get(old.typed,'reduce')?.value!==old.reduce)return null;
 try{if(apply(old.length,header,[])!==512)return null;}catch{return null;}
 let sum=0;
 for(let index=0;index<512;index++){
  const value=header[index];
  sum+=index>=148&&index<156?32:value;
 }
 return sum;
}
