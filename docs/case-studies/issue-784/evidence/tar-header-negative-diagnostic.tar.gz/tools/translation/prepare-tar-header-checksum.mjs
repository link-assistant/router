#!/usr/bin/env node
// Propose the two complete source consumers; never reuse dependency verdicts.
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRulePipeline,exactSubstitutionRule} from './rule-pipeline.mjs';
import {transportConcreteSyntaxSource,transportConcreteSyntaxMeta,serializeConcreteSyntaxMeta} from './concrete-syntax-meta.mjs';
import {ownershipCompiler} from './js-to-rust/vendor/module-syntax.mjs';

const root=new URL('../../',import.meta.url),read=path=>readFileSync(new URL(path,root));
const directory='tools/translation/source-profiles/tar-header-checksum/';
const hash=value=>createHash('sha256').update(value).digest('hex');
const helperPath='tools/translation/native-tar-header-checksum.mjs';
function concrete(source){
 const wire=serializeConcreteSyntaxMeta(transportConcreteSyntaxSource(source,{language:'JavaScript'}).document);
 if(transportConcreteSyntaxMeta(wire).source!==source)throw Error('Complete checksum source CST inverse differs');
 return wire;
}
function syntax(path,source){
 const ts=ownershipCompiler();if(ts.version!=='5.9.3')throw Error('Installed TypeScript 5.9.3 required');
 if(ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS).parseDiagnostics.length)throw Error('Invalid complete checksum source: '+path);
}
export function deriveTarHeaderChecksum({archive,template}){
 if(!Buffer.isBuffer(archive)||hash(archive)!=='e56d283fabb17edcb9cdb7667e3070fb3242b147fbfc4d9bca8b7248e5ea2063'||typeof template!=='string')throw Error('Complete original checksum sources required');
 const original=JSON.parse(gunzipSync(archive,{maxOutputLength:65536}));
 if(original.schema!=='complete-tar-header-checksum-inputs-v1'||original.files.length!==2)throw Error('Original checksum source set differs');
 const files=[];
 for(const row of original.files){
  if(Buffer.byteLength(row.source)!==row.bytes||hash(row.source)!==row.sha256)throw Error('Original complete consumer bytes differ');
  const derive=row.path==='tools/translation/derive-dependencies.mjs';
  if(!derive&&row.path!=='tools/translation/json-macro-inputs.mjs')throw Error('Unknown complete checksum consumer');
  const before=derive?'header.reduce((total,value,index)=>total+(index>=148&&index<156?32:value),0)':'header.reduce((sum, byte, index) => sum + (index >= 148 && index < 156 ? 32 : byte), 0)';
  const language=[['native-byte-sum-with-original-observer-fallback',before,'(nativeTarHeaderChecksum(header)??'+before+')']];
  const anchor="import {cargoLayoutManifestMatches} from './cargo-layout-input-compatibility.mjs';";
  const repository=[['shared-byte-calculation-import',anchor,anchor+"\nimport {nativeTarHeaderChecksum} from './native-tar-header-checksum.mjs';"]];
  const rules=rows=>rows.map(([id,from,to])=>exactSubstitutionRule('tar-header:'+id,from,to,'Complete original checksum source changed: '+id));
  syntax(row.path,row.source);const beforeMeta=concrete(row.source);
  const languageResult=createRulePipeline([{phase:'language',rules:rules(language)},{phase:'repository',rules:[]}]).run(row.source);
  const languageSource=languageResult.value,languageMeta=concrete(languageSource);syntax(row.path,languageSource);
  const result=createRulePipeline([{phase:'language',rules:[]},{phase:'repository',rules:rules(repository)}]).run(languageSource);
  const afterMeta=concrete(result.value);syntax(row.path,result.value);let inverse=result.value;
  for(const [,from,to]of [...language,...repository].reverse()){
   if(inverse.split(to).length!==2)throw Error('Complete checksum source inverse anchor differs');
   inverse=inverse.replace(to,()=>from);
  }
  if(inverse!==row.source)throw Error('Complete checksum source inverse differs');
  files.push({...row,text:result.value,afterSha256:hash(result.value),beforeMeta,languageSource,languageMeta,afterMeta,inverse,language,repository,trace:[...languageResult.trace,...result.trace]});
 }
 syntax(helperPath,template);const helperMeta=concrete(template);
 return {schema:'complete-native-tar-header-checksum-proposal-v1',files,helper:{path:helperPath,text:template,sha256:hash(template),meta:helperMeta},sourceVerdictsCached:false,qualified:false,rustExecuted:false};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [mode,...extra]=process.argv.slice(2);if(extra.length||!['--emit','--check'].includes(mode))throw Error('Use --emit or --check');
 const proposal=deriveTarHeaderChecksum({archive:read(directory+'complete-original-inputs.json.gz'),template:read(directory+'native-checksum.mjs.txt').toString('utf8')});
 if(mode==='--emit')console.log(JSON.stringify(proposal));
 else{
  for(const row of [...proposal.files,proposal.helper])if(read(row.path).toString('utf8')!==row.text)throw Error('Installed checksum source differs: '+row.path);
  console.log(JSON.stringify({checked:true,files:proposal.files.map(row=>({path:row.path,sha256:row.afterSha256})),helperSha256:proposal.helper.sha256,sourceVerdictsCached:false,rustExecuted:false}));
 }
}
