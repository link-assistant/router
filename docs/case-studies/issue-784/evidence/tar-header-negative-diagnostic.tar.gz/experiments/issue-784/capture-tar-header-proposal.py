"""Stream the complete producer result; retain its complete failure stream."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

base = Path('ci-logs/issue-784-restart-2')
output = base / 'tar-header-complete-proposal.json.gz'
with (base / 'tar-header-producer.stderr').open('xb') as errors:
    child = subprocess.Popen([
        'experiments/issue-784/toolchain/node20/bin/node', '--max-old-space-size=512',
        'tools/translation/prepare-tar-header-checksum.mjs', '--emit',
    ], stdout=subprocess.PIPE, stderr=errors)
    digest = hashlib.sha256()
    count = 0
    with gzip.open(output, 'xb') as target:
        for block in iter(lambda: child.stdout.read(65536), b''):
            count += len(block)
            if count > 8 * 1024 * 1024:
                child.terminate()
                child.wait()
                raise RuntimeError('Finite complete proposal bound exceeded')
            digest.update(block)
            target.write(block)
    code = child.wait()
print(json.dumps(dict(exitCode=code, decodedBytes=count, decodedSha256=digest.hexdigest())))
raise SystemExit(code)
