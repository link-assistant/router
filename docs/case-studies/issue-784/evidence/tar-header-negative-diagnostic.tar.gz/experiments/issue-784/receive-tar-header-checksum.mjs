// Independent complete replay and native source receipt before installation.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {deriveTarHeaderChecksum} from '../../tools/translation/prepare-tar-header-checksum.mjs';
import {transportConcreteSyntaxMeta} from '../../tools/translation/concrete-syntax-meta.mjs';

const original='tools/translation/source-profiles/tar-header-checksum/';
const proposal=JSON.parse(gunzipSync(readFileSync('ci-logs/issue-784-restart-2/tar-header-complete-proposal.json.gz'),{maxOutputLength:8*1024*1024}));
const fresh=deriveTarHeaderChecksum({archive:readFileSync(original+'complete-original-inputs.json.gz'),template:readFileSync(original+'native-checksum.mjs.txt','utf8')});
assert.deepEqual(fresh,proposal);
for(const row of proposal.files){
 assert.equal(readFileSync(row.path,'utf8'),row.source);
 for(const [wire,source]of [[row.beforeMeta,row.source],[row.languageMeta,row.languageSource],[row.afterMeta,row.text]])
  assert.equal(transportConcreteSyntaxMeta(wire).source,source);
 let inverse=row.text;
 for(const [,before,after]of [...row.language,...row.repository].reverse()){
  assert.equal(inverse.split(after).length,2);inverse=inverse.replace(after,()=>before);
 }
 assert.equal(inverse,row.source);
}
assert.equal(transportConcreteSyntaxMeta(proposal.helper.meta).source,proposal.helper.text);
const outputs=[...proposal.files,proposal.helper];
for(const row of outputs){
 const native=spawnSync(process.execPath,['--input-type=module','--check'],{input:row.text,encoding:'utf8',maxBuffer:1024*1024});
 assert.equal(native.error,undefined);assert.equal(native.status,0,native.stderr);
 const bun=spawnSync('/home/box/.bun/bin/bun',['--eval','new Bun.Transpiler({loader:"js",target:"bun"}).scan(await Bun.stdin.text())'],{input:row.text,encoding:'utf8',maxBuffer:1024*1024});
 assert.equal(bun.error,undefined);assert.equal(bun.status,0,bun.stderr);
}
for(const row of outputs)writeFileSync(row.path,row.text,{flag:row===proposal.helper?'wx':'w'});
const receipt={schema:'independently-received-tar-header-proposal-v1',files:outputs.map(row=>({path:row.path,source:row.text,sha256:createHash('sha256').update(row.text).digest('hex')})),wholeProposalReplayed:true,allCstPhasesReparsed:true,allOriginalInversesChecked:true,nodeAndBunSyntaxChecked:true,behaviorQualified:false,rustExecuted:false};
writeFileSync('ci-logs/issue-784-restart-2/tar-header-installation.json.gz',gzipSync(Buffer.from(JSON.stringify(receipt))),{flag:'wx'});
console.log(JSON.stringify({installed:receipt.files.map(({path,sha256})=>({path,sha256})),behaviorQualified:false,rustExecuted:false}));
