#!/usr/bin/env python3
"""Run ONLY after explicit Gate compiler grant. Sequential provider42 engines."""
import argparse,hashlib,json,os,pathlib,shutil,signal,subprocess,tempfile,time
FILES=['packages/javascript/test/native-core.test.mjs','packages/javascript/test/native-service.test.mjs','packages/javascript/test/native-server.test.mjs']
def git(root,*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def inputs(root):
    paths=git(root,'ls-files','packages/javascript/native','packages/javascript/portable','packages/javascript/package.json','packages/javascript/catalog.json','packages/javascript/schemas','experiments/issue-759/acceptance','packages/javascript/test','parity/fixtures/server','parity/fixtures/core','package-lock.json').splitlines()
    return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if (root/p).is_file()}
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',required=True)
    parser.add_argument('--head',required=True)
    parser.add_argument('--cap',type=int,default=180)
    args=parser.parse_args()
    root=pathlib.Path(args.root).resolve()
    receipt=pathlib.Path(tempfile.mkdtemp(prefix='router-759-provider-regression-'))
    head=git(root,'rev-parse','HEAD')
    status=git(root,'status','--porcelain')
    if head!=args.head or status not in ('','?? packages/javascript/node_modules'):
        raise SystemExit('Refusing unfrozen or dirty source: '+head+' '+status)
    for required in FILES+['packages/javascript/portable/policy.mjs']:
        if not (root/required).is_file():
            raise SystemExit('Missing prerequisite: '+required)
    if not (root/'packages/javascript/node_modules/ajv').exists():
        raise SystemExit('Missing shared AJV dependency')
    before=inputs(root)
    base={'head':head,'before_status':status,'npm_realpath':str((root/'packages/javascript/node_modules').resolve()),'input_sha256':before,'case_files':FILES,'per_engine_cap_seconds':args.cap,'results':[]}
    (receipt/'inputs.json').write_text(json.dumps(base,indent=2)+'\n')
    print(str(receipt),flush=True)
    for engine,command in [('node',['node','--test','--test-concurrency=1',*FILES]),('bun',['bun','test','--timeout','15000',*FILES])]:
        workspace=pathlib.Path(tempfile.mkdtemp(prefix=engine+'-temp-',dir=receipt))
        env=os.environ.copy()
        env['TMPDIR']=str(workspace)
        env['TMP']=str(workspace)
        env['TEMP']=str(workspace)
        env['ROUTER_ACCEPTANCE_ROOT']=str(root)
        started=time.monotonic()
        timed_out=False
        with (receipt/(engine+'.log')).open('wb') as log:
            process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:
                code=process.wait(timeout=args.cap)
            except subprocess.TimeoutExpired:
                timed_out=True
                os.killpg(process.pid,signal.SIGTERM)
                try: process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid,signal.SIGKILL)
                    process.wait(timeout=5)
                code=process.returncode
        remaining=sum(p.stat().st_size for p in workspace.rglob('*') if p.is_file())
        leftovers=sorted(str(p.relative_to(workspace)) for p in workspace.iterdir())
        shutil.rmtree(workspace)
        result={'engine':engine,'command':command,'exit_code':code,'timed_out':timed_out,'wall_seconds':round(time.monotonic()-started,3),'temporary_bytes_before_cleanup':remaining,'remaining_temporary_entries_before_cleanup':leftovers}
        base['results'].append(result)
        print(json.dumps(result),flush=True)
        (receipt/'receipt.json').write_text(json.dumps(base,indent=2)+'\n')
    base['after_head']=git(root,'rev-parse','HEAD')
    base['after_status']=git(root,'status','--porcelain')
    base['after_input_sha256']=inputs(root)
    base['immutable_inputs']=base['after_head']==head and base['after_status']==status and base['after_input_sha256']==before
    (receipt/'receipt.json').write_text(json.dumps(base,indent=2)+'\n')
    if not base['immutable_inputs'] or any(r['exit_code']!=0 or r['timed_out'] for r in base['results']):
        raise SystemExit(1)
if __name__=='__main__':
    main()
