import os,sys,json,hashlib,time,signal,subprocess,resource
from pathlib import Path
root=Path('/Users/konard/Code/Archive/link-assistant/router/.worktrees/issue-759-full-translation')
engine=sys.argv[1]; scope=sys.argv[2]; cap=180 if scope=='narrow' else 1200
attempt=sys.argv[3] if len(sys.argv)>3 else 'initial'
prefix='/tmp/router-759-csv-c513-baseline-reproduction-node'
if engine!='node' or scope!='narrow':raise SystemExit('Baseline reproduction is Node narrow scope only')
if any(Path(prefix+tail).exists() for tail in ['.log','-inputs.json','-receipt.json']):raise SystemExit('Refusing to overwrite prior attempt evidence: '+prefix)
files=['tools/translation/test/'+x for x in (['csv-strings.test.mjs','result-iterators.test.mjs','option-deref.test.mjs','reverse-string-iterators.test.mjs'] if scope=='narrow' else ['csv-original-source.test.mjs'])]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
paths=subprocess.check_output(['git','ls-files','-z','--','tools/translation','src','Cargo.toml','Cargo.lock'],cwd=root).decode().split('\0')
inputs=[]
for relative in paths:
 if relative and (root/relative).is_file():
  b=(root/relative).read_bytes();inputs.append({'path':relative,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
encoded=json.dumps(inputs,separators=(',',':')).encode();Path(prefix+'-inputs.json').write_bytes(encoded)
cmd=([os.path.expanduser('~/.nvm/versions/node/v20.19.4/bin/node'),'--test','--test-concurrency=1'] if engine=='node' else [os.path.expanduser('~/.bun/bin/bun'),'test'])+files
before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic();env=dict(os.environ);env.pop('NODE_TEST_CONTEXT',None);env['ROUTER_TRANSLATION_TSC']=str(root/'packages/javascript/node_modules/.bin/tsc')
with open(prefix+'.log','xb') as log:
 process=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:status=process.wait(timeout=cap);timedout=False
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  status=process.returncode;timedout=True
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt={'head':head,'engine':engine,'scope':scope,'files':files,'command':cmd,'capSeconds':cap,'exitCode':status,'timedOut':timedout,'wallSeconds':time.monotonic()-start,'userSeconds':usage.ru_utime-before.ru_utime,'systemSeconds':usage.ru_stime-before.ru_stime,'maxRssBytes':usage.ru_maxrss,'resourceScope':'one engine child plus reaped strict-TS/runtime descendants; macOS RUSAGE_CHILDREN maxrss bytes','inputsSha256':hashlib.sha256(encoded).hexdigest(),'logSha256':hashlib.sha256(Path(prefix+'.log').read_bytes()).hexdigest()}
Path(prefix+'-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print('\n'.join(Path(prefix+'.log').read_text().splitlines()[-10:]));sys.exit(0)
