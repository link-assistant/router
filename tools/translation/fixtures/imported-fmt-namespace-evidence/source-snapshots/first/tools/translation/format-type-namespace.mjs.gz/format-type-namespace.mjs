// Source type-name joins for imported fmt paths. Partial external tables never
// establish globs, executable trait methods or caller-wide namespace closure.
import {matchesParserFacts} from './matches-macro-context.mjs';
import {moduleScopeKey,originalSourceModuleItems} from './source-module-views.mjs';
import {STANDARD_NAMESPACE_EVIDENCE,isStandardNamespaceEvidence} from './namespace-standard.mjs';
import {copyMetadata,metadataDigest,ownData} from './extensions/source-links.mjs';
import {freezeMacroTree} from './macro-token-trees.mjs';
import {originalMethodMember} from './impl-resolver.mjs';
const contexts=new WeakMap(),proofs=new WeakMap(),same=(a,b)=>metadataDigest(a)===metadataDigest(b),fail=message=>{throw new TypeError('original fmt type namespace: '+message);};
export function captureOriginalFmtTypeNamespace(parser){
 const state=matchesParserFacts(parser),evidence=freezeMacroTree({schema:'original-fmt-type-namespace-context-v1',originalContextDigest:metadataDigest(state.context),source:state.module.file,module:state.module.path,sourceViewDigest:state.module.sourceView.digest,namespaceComplete:false,runtimeAuthority:false});contexts.set(evidence,{parser,state});return evidence;
}
function originalContext(context){const issued=contexts.get(context);if(!issued||matchesParserFacts(issued.parser)!==issued.state)fail('copied, stale or foreign original parser context');return issued.state;}
function originalModule(state,carrier){
 const file=ownData(carrier,'file'),path=copyMetadata(ownData(carrier,'path')),module=state.facts.modules.find(module=>module.file===file&&same(module.path,path));
 if(!module||ownData(carrier,'source')!==module.source||ownData(carrier,'sourceView')!==module.sourceView)fail('module differs from its complete original source/view/path');originalSourceModuleItems(module);return module;
}
function scopeFor(state,module){
 const ancestors=state.facts.evidence.scopes.filter(scope=>scope.path.every((part,index)=>module.path[index]===part)),scope=ancestors.find(scope=>moduleScopeKey(scope)===moduleScopeKey(module));
 if(!scope||ancestors.some(scope=>scope.configurationCondition!=='active'||scope.unresolvedAttributeMacroScope!==false))fail('original type owner has unresolved condition/attribute scope');
 if(ancestors.some(scope=>scope.bindings.some(binding=>binding.namespace==='type'&&['std','core'].includes(binding.name))))fail('original standard root is shadowed/imported');
 return {scope,ancestors};
}
export function resolveOriginalFmtTypePath(context,carrier,written,expected){
 const state=originalContext(context),module=originalModule(state,carrier),path=copyMetadata(written);if(!Array.isArray(path)||!path.length||path.some(part=>typeof part!=='string'||!part))fail('complete written type path required');
 const {scope,ancestors}=scopeFor(state,module);let target=path,binding=null;
 if(!['std','core'].includes(path[0])){
  const matches=scope.bindings.filter(binding=>binding.namespace==='type'&&binding.name===path[0]);
  if(matches.length!==1||matches[0].status!=='resolved'||!Array.isArray(matches[0].target)||matches[0].via!=='named-import'||ancestors.some(scope=>scope.unresolvedTypeScope!==false))fail('imported formatting type requires its unique resolved original named type binding');
  binding=matches[0];target=[...binding.target,...path.slice(1)];
  const visible=!binding.visibility||binding.visibility.kind==='public'||binding.visibility.path.every((part,index)=>module.path[index]===part);if(!visible)fail('original imported formatting type is inaccessible');
 }
 if(target.length!==3||!['std','core'].includes(target[0])||target[1]!=='fmt'||target[2]!==expected)fail('actual imported target is a different formatting type owner');
 const facts=STANDARD_NAMESPACE_EVIDENCE.facts.filter(fact=>fact.name===expected&&same(fact.target,['std','fmt',expected]));if(facts.length!==1||!isStandardNamespaceEvidence(facts[0]))fail('original standard formatting type/reexports are unavailable');
 const fact=facts[0];if(fact.declaration.name!==expected||fact.declaration.kind!==fact.kind)fail('original formatting declaration/type category differs');
 const evidence=freezeMacroTree({schema:'original-imported-fmt-type-path-v1',source:module.file,module:module.path,sourceViewDigest:module.sourceView.digest,compilationProfile:state.facts.compilationProfile,written:path,target,binding,scopeDigest:metadataDigest(scope),originalContextDigest:context.originalContextDigest,originalStandardType:fact,namespaceComplete:false,runtimeAuthority:false});proofs.set(evidence,{context,state,module});return evidence;
}
export function originalFmtTypePathFacts(proof,context){const state=proofs.get(proof);if(!state||state.context!==context||originalContext(context)!==state.state)fail('copied or foreign original formatting type join');return state;}
// This is a schema parse, not string rewriting. Every original type position
// resolves independently, including different aliases for Formatter and Result.
export function resolveOriginalDisplaySignature(context,carrier,method,formatterName){
 const state=originalContext(context),module=originalModule(state,carrier),origin=originalMethodMember(method);
 if(origin.source!==module.source||origin.sourcePath!==module.file||origin.sourceView!==module.sourceView||!same(origin.modulePath,module.path)||!same(origin.compilationProfile,state.facts.compilationProfile))fail('Display signature differs from its private original method/module/context');
 const tokens=copyMetadata(method.signatureTokens).map(token=>token.text);let at=0;const take=text=>{if(tokens[at++]!==text)fail('complete original shared Display signature differs');};
 for(const token of ['fn','fmt','(','&','self',',',formatterName,':','&','mut'])take(token);
 const typePath=stop=>{const path=[];for(;;){const token=tokens[at++];if(typeof token!=='string'||!/^(?:r#)?[A-Za-z_][A-Za-z0-9_]*$/u.test(token))fail('original formatting type path identifier is unsupported');path.push(token);if(tokens[at]==='::'){at++;continue;}if(tokens[at]!==stop)fail('complete original formatting type path boundary differs');return path;}};
 const formatter=resolveOriginalFmtTypePath(context,carrier,typePath('<'),'Formatter');for(const token of ['<',"'_",'>',')','->'])take(token);
 const result=resolveOriginalFmtTypePath(context,carrier,typePath(undefined),'Result');if(at!==tokens.length)fail('extra original Display signature syntax');return freezeMacroTree({schema:'original-display-format-signature-type-joins-v1',source:module.file,module:module.path,sourceViewDigest:module.sourceView.digest,methodDigest:origin.methodDigest,implementationSpan:origin.implementationSpan,signatureSpan:method.signatureSpan,originalSignature:module.source.slice(method.signatureSpan.start,method.signatureSpan.end),formatter,result,namespaceComplete:false,runtimeAuthority:false});
}
