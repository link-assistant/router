from pathlib import Path
import subprocess,json,os,time,signal,hashlib
r=Path.cwd();e=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();draftStatus=subprocess.check_output(['git','status','--porcelain'],text=True)
paths=[p for p in subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','tools/translation','scripts','Cargo.toml','Cargo.lock'],text=True).split('\0')if p and not p.startswith(('tools/translation/meta/','tools/translation/projects/','tools/translation/js-to-rust/generated/'))]
def inputs():return [{'path':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest(),'bytes':(r/p).stat().st_size}for p in paths]
before=inputs();(e/'inputs-before.json').write_text(json.dumps({'head':head,'inputs':before},indent=2)+'\n');rows=[]
cli=r.parent/'issue-759-gate/packages/javascript/node_modules/typescript/bin/tsc';package=r.parent/'issue-759-gate/packages/javascript/node_modules/typescript/package.json';assert json.loads(package.read_text())['version']=='5.9.3';(e/'ts-input.json').write_text(json.dumps({'version':'5.9.3','cliRealpath':str(cli.resolve()),'cliSha256':hashlib.sha256(cli.read_bytes()).hexdigest(),'packageSha256':hashlib.sha256(package.read_bytes()).hexdigest()},indent=2)+'\n')
files=['tools/translation/test/macro-module-path-metadata.test.mjs', 'tools/translation/test/matches-immutable-context-cache.test.mjs', 'tools/translation/test/source-method-transforms.test.mjs', 'tools/translation/test/source-method-parser.test.mjs', 'tools/translation/test/source-method-admission.test.mjs', 'tools/translation/test/source-method-project.test.mjs', 'tools/translation/test/derive-ancestor-attribute-scope.test.mjs', 'tools/translation/test/serde-deserialize-unit-enum.test.mjs', 'tools/translation/test/source-format-display.test.mjs']
for engine,cmd in [('node',['node','--stack-trace-limit=100','--test','--test-concurrency=1',*files]),('bun',['bun','test',*files])]:
 assert inputs()==before;start=time.monotonic();env={**os.environ,'ROUTER_TRANSLATION_TSC':str(cli),'ROUTER_MACRO_PATH_VECTORS':str(e/(engine+'-paths')),'ROUTER_UNIT_ENUM_VECTOR_DIR':str(e/(engine+'-enum')),'ROUTER_DERIVE_ANCESTOR_EVIDENCE_DIR':str(e/(engine+'-ancestor'))};timed=False
 with(e/(engine+'.stdout.raw.log')).open('xb')as out,(e/(engine+'.stderr.raw.log')).open('xb')as err:
  child=subprocess.Popen(cmd,env=env,stdout=out,stderr=err,start_new_session=True)
  def expire(sig,frame):raise TimeoutError('whole nine-file original limits outer300s')
  signal.signal(signal.SIGALRM,expire);signal.alarm(300)
  try:_,status,usage=os.wait4(child.pid,0)
  except TimeoutError:timed=True;os.killpg(child.pid,signal.SIGKILL);_,status,usage=os.wait4(child.pid,0)
  finally:signal.alarm(0)
  child.returncode=os.waitstatus_to_exitcode(status)
 row={'engine':engine,'command':cmd,'sourceHead':head,'exitCode':child.returncode,'elapsedSeconds':time.monotonic()-start,'maxWaitedChildRssBytes':usage.ru_maxrss,'outerCapSeconds':300,'timedOut':timed,'originalInputCapsUnchanged':True,'inputsUnchanged':inputs()==before,'headUnchanged':head==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'draftStatusUnchanged':draftStatus==subprocess.check_output(['git','status','--porcelain'],text=True),'rustExecuted':False};rows.append(row);(e/'receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if not row['inputsUnchanged']or not row['headUnchanged']:raise RuntimeError('input drift')
(e/'inputs-after.json').write_text(json.dumps({'head':head,'inputs':inputs()},indent=2)+'\n')
