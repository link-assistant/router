#!/usr/bin/env python3
"""Execute only after explicit Gate producer grant; expected import/artifact writes."""
import argparse,pathlib,subprocess,tempfile,json,hashlib,os,time,signal,shutil
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--head',required=True);a=p.parse_args();root=pathlib.Path(a.root).resolve()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def inputs():
 paths=git('ls-files','src','Cargo.toml','Cargo.lock','packages/javascript/native','packages/javascript/portable','tools/translation','package-lock.json').splitlines()
 return {path:sha((root/path).read_bytes())for path in paths if(root/path).is_file()}
head=git('rev-parse','HEAD');status=git('status','--porcelain')
if head!=a.head or status not in ('','?? packages/javascript/node_modules'):raise SystemExit('Refusing unfrozen producer source')
plan=json.loads((root/'tools/translation/serialization-schema/native-import-plan.json').read_text());native='packages/javascript/native/affinity-schema.mjs'
if sha((root/native).read_bytes())!=plan['original_native_source_sha256']:raise SystemExit('Native baseline differs from reviewed plan')
folder=pathlib.Path(tempfile.mkdtemp(prefix='router-759-schema-producer-'));workspace=folder/'temp';workspace.mkdir();env=os.environ.copy();env.update(TMPDIR=str(workspace),TMP=str(workspace),TEMP=str(workspace))
command=['node','tools/translation/serialization-schema/native-descriptor.mjs','--write','--apply-import'];before=inputs();receipt={'head':head,'before_status':status,'before_input_sha256':before,'command':command,'cap_seconds':60,'harness_sha256':sha(pathlib.Path(__file__).read_bytes()),'disk_before':dict(zip(['total','used','free'],shutil.disk_usage(root)))}
(folder/'inputs.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.copyfile(__file__,folder/'harness.py');print(folder,flush=True)
started=time.monotonic();timed_out=False
with(folder/'producer.log').open('wb')as log:
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=60)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
  code=process.returncode
receipt.update(exit_code=code,timed_out=timed_out,wall_seconds=round(time.monotonic()-started,3),after_head=git('rev-parse','HEAD'),after_status=git('status','--porcelain'),after_input_sha256=inputs(),temporary_entries_before_cleanup=sorted(str(path.relative_to(workspace))for path in workspace.iterdir()),temporary_bytes_before_cleanup=sum(path.stat().st_size for path in workspace.rglob('*')if path.is_file()))
shutil.rmtree(workspace)
receipt['unchanged_other_inputs']=all(path==native or receipt['after_input_sha256'].get(path)==digest for path,digest in before.items())
receipt['planned_native_source_matches']=sha((root/native).read_bytes())==plan['planned_native_source_sha256']
body=(root/native).read_text();receipt['interpreter_body_matches']=sha(body[body.index('function freezeSchema'):].encode())==plan['interpreter_body_sha256']
outputs=['tools/translation/serialization-schema/generated/affinity-schema.meta.json','packages/javascript/native/affinity-schema-descriptor.mjs','tools/translation/serialization-schema/generated/affinity-schema-descriptor.ts','tools/translation/serialization-schema/generated/affinity-schema-emission.json'];receipt['outputs']=[{'file':path,'bytes':(root/path).stat().st_size,'sha256':sha((root/path).read_bytes())}for path in outputs if(root/path).is_file()]
raw_status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True)
receipt['after_status_all']=raw_status
receipt['only_expected_mutation_paths']=all(line[3:] in {native,*outputs,'packages/javascript/node_modules'} for line in raw_status.splitlines())
receipt['disk_after']=dict(zip(['total','used','free'],shutil.disk_usage(root)));(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({key:receipt[key]for key in ['exit_code','timed_out','wall_seconds','unchanged_other_inputs','planned_native_source_matches','interpreter_body_matches']}),flush=True)
if code or timed_out or receipt['after_head']!=head or not all(receipt[key]for key in ['unchanged_other_inputs','planned_native_source_matches','interpreter_body_matches','only_expected_mutation_paths'])or len(receipt['outputs'])!=4:raise SystemExit(1)
