#!/usr/bin/env python3
"""Execute only after explicit Gate producer grant; expected four bulk artifact writes only."""
import argparse,pathlib,subprocess,tempfile,json,hashlib,os,time,signal,shutil
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--head',required=True);a=p.parse_args();root=pathlib.Path(a.root).resolve()
OUTPUTS=['tools/translation/serialization-schema/bulk-generated/router-serialization.meta.json', 'tools/translation/serialization-schema/bulk-generated/router-serialization.mjs', 'tools/translation/serialization-schema/bulk-generated/router-serialization.ts', 'tools/translation/serialization-schema/bulk-generated/router-serialization-inventory.json']
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def inputs():
 paths=git('ls-files','src','Cargo.toml','Cargo.lock','packages/javascript/native','packages/javascript/portable','tools/translation','package-lock.json').splitlines()
 return {path:sha((root/path).read_bytes())for path in paths if(root/path).is_file() and path not in OUTPUTS}
head=git('rev-parse','HEAD');status=git('status','--porcelain')
if head!=a.head or status not in ('','?? packages/javascript/node_modules'):raise SystemExit('Refusing unfrozen producer source')
folder=pathlib.Path(tempfile.mkdtemp(prefix='router-759-bulk-scalar-producer-'));workspace=folder/'temp';workspace.mkdir();env=os.environ.copy();env.update(TMPDIR=str(workspace),TMP=str(workspace),TEMP=str(workspace))
command=['node','tools/translation/serialization-schema/bulk.mjs','--write'];before=inputs();receipt={'head':head,'before_status':status,'before_input_sha256':before,'before_output_sha256':{path:sha((root/path).read_bytes())for path in OUTPUTS},'command':command,'cap_seconds':60,'harness_sha256':sha(pathlib.Path(__file__).read_bytes()),'disk_before':dict(zip(['total','used','free'],shutil.disk_usage(root)))}
(folder/'inputs.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.copyfile(__file__,folder/'harness.py');print(folder,flush=True)
started=time.monotonic();timed_out=False
with(folder/'producer.log').open('xb')as log:
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=60)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
  code=process.returncode
receipt.update(exit_code=code,timed_out=timed_out,wall_seconds=round(time.monotonic()-started,3),after_head=git('rev-parse','HEAD'),after_status=git('status','--porcelain'),after_input_sha256=inputs(),temporary_entries_before_cleanup=sorted(str(path.relative_to(workspace))for path in workspace.iterdir()),temporary_bytes_before_cleanup=sum(path.stat().st_size for path in workspace.rglob('*')if path.is_file()))
shutil.rmtree(workspace)
receipt['unchanged_all_original_inputs']=all(receipt['after_input_sha256'].get(path)==digest for path,digest in before.items())
outputs=['tools/translation/serialization-schema/bulk-generated/router-serialization.meta.json', 'tools/translation/serialization-schema/bulk-generated/router-serialization.mjs', 'tools/translation/serialization-schema/bulk-generated/router-serialization.ts', 'tools/translation/serialization-schema/bulk-generated/router-serialization-inventory.json'];receipt['outputs']=[{'file':path,'bytes':(root/path).stat().st_size,'sha256':sha((root/path).read_bytes())}for path in outputs if(root/path).is_file()]
raw_status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True)
receipt['after_status_all']=raw_status
receipt['only_expected_mutation_paths']={line[3:]for line in raw_status.splitlines()if line[3:]!='packages/javascript/node_modules'}==set(OUTPUTS)
receipt['all_four_artifacts_changed']=all(sha((root/path).read_bytes())!=receipt['before_output_sha256'][path]for path in OUTPUTS)
receipt['disk_after']=dict(zip(['total','used','free'],shutil.disk_usage(root)));(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({key:receipt[key]for key in ['exit_code','timed_out','wall_seconds','unchanged_all_original_inputs','only_expected_mutation_paths']}),flush=True)
if code or timed_out or receipt['after_head']!=head or not all(receipt[key]for key in ['unchanged_all_original_inputs','only_expected_mutation_paths','all_four_artifacts_changed'])or len(receipt['outputs'])!=4:raise SystemExit(1)
